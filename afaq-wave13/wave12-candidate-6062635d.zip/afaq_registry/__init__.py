"""Authoritative live registry domain for AFAQ engines and capabilities."""
from .loader import (
    CAPABILITY_IDENTITY_PATH,
    REGISTRY_PATH,
    derive_totals,
    load_capability_identities,
    load_registry,
)

__all__ = [
    "CAPABILITY_IDENTITY_PATH",
    "REGISTRY_PATH",
    "derive_totals",
    "load_capability_identities",
    "load_registry",
]
