"""Registry-integrity checks split by responsibility.

Each section is deterministic and read-only so CI can expose exactly which
invariant class failed without weakening the overall fail-closed gate.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from afaq_agent_runtime.capability_planner import supported_plannable_actions

from .loader import derive_totals, load_capability_identities, load_declarations, load_observations, load_registry
from .proof import PROOF_STATES, validate_contracts
from .admission import load_policy

ROOT = Path(__file__).resolve().parents[1]
EXCLUDED_TOP = {
    ".git",
    "_archive-old-copies",
    "_candidate_shared",
    "_incoming",
    "_precommit",
    "_provenance",
    "node_modules",
    "project-records",
    "site",
    "var",
    "__pycache__",
}
TEXT_SUFFIXES = {".py", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".ps1", ".yml", ".yaml"}
LEGACY_LIVE_PATHS = (
    'project-records" / "engine-registry" / "ENGINES_CAPABILITIES_MERGED.json',
    "project-records/engine-registry/ENGINES_CAPABILITIES_MERGED.json",
    "project-records\\engine-registry\\ENGINES_CAPABILITIES_MERGED.json",
    "project-records/engine-registry/CAPABILITY_ID_MAP.json",
)


def _load() -> tuple[dict[str, Any], dict[str, Any], list[dict[str, Any]], list[dict[str, Any]]]:
    registry = load_registry()
    identities = load_capability_identities()
    return (
        registry,
        identities,
        list(registry.get("engines") or []),
        list(registry.get("capability_packages") or []),
    )


def check_identity() -> dict[str, Any]:
    registry, identities, engines, packages = _load()
    engine_ids = [str(e.get("engine_id") or "") for e in engines]
    package_ids = [str(p.get("package_id") or "") for p in packages]

    if "" in engine_ids or len(engine_ids) != len(set(engine_ids)):
        raise AssertionError("engine IDs must be non-empty and unique")
    if "" in package_ids or len(package_ids) != len(set(package_ids)):
        raise AssertionError("package IDs must be non-empty and unique")

    name_to_id = identities.get("name_to_id") or {}
    if not isinstance(name_to_id, dict):
        raise AssertionError("capability identity name_to_id must be an object")
    if int(identities.get("count") or 0) != len(name_to_id):
        raise AssertionError("capability identity count must equal mapping size")

    capability_ids = list(name_to_id.values())
    if len(capability_ids) != len(set(capability_ids)):
        raise AssertionError("capability IDs must be unique and never reused")

    return {
        "engines": len(engine_ids),
        "packages": len(package_ids),
        "capability_identities": len(name_to_id),
    }


def check_references() -> dict[str, Any]:
    registry, identities, engines, packages = _load()
    engine_set = {str(e.get("engine_id")) for e in engines}
    package_set = {str(p.get("package_id")) for p in packages}
    package_by_id = {str(p.get("package_id")): p for p in packages}
    engine_by_id = {str(e.get("engine_id")): e for e in engines}

    for engine in engines:
        eid = str(engine["engine_id"])
        for pid in engine.get("capability_packages") or []:
            if pid not in package_set:
                raise AssertionError(f"{eid} references unknown package {pid}")
            if eid not in (package_by_id[pid].get("engine_ids") or []):
                raise AssertionError(f"missing reverse package link: {eid} <-> {pid}")

    for package in packages:
        pid = str(package["package_id"])
        for eid in package.get("engine_ids") or []:
            if eid not in engine_set:
                raise AssertionError(f"{pid} references unknown engine {eid}")
            if pid not in (engine_by_id[eid].get("capability_packages") or []):
                raise AssertionError(f"missing reverse engine link: {pid} <-> {eid}")

    totals = registry.get("totals") or {}
    expected_totals = derive_totals(registry)
    name_to_id = identities.get("name_to_id") or {}
    if not isinstance(name_to_id, dict):
        raise AssertionError("capability identity name_to_id must be an object")
    expected_totals["capability_identities"] = len(name_to_id)
    if totals != expected_totals:
        raise AssertionError(f"derived totals mismatch: {totals!r} != {expected_totals!r}")
    if totals["live_runtime"] + totals["live_cap"] != totals["engines"]:
        raise AssertionError("live_runtime + live_cap must equal engine count")

    return {
        "engines": totals["engines"],
        "live_runtime": totals["live_runtime"],
        "live_cap": totals["live_cap"],
        "capability_packages": totals["capability_packages"],
    }


def check_capabilities() -> dict[str, Any]:
    registry, identities, engines, _packages = _load()
    name_to_id = identities.get("name_to_id") or {}

    required = {
        str(cap)
        for engine in engines
        for cap in (engine.get("required_capabilities") or [])
        if isinstance(cap, str) and cap
    }
    missing_required = sorted(required - set(name_to_id))
    if missing_required:
        raise AssertionError(
            f"required capabilities without stable IDs: {missing_required[:20]}"
        )

    planner = set(supported_plannable_actions())
    missing_planner = sorted(planner - set(name_to_id))
    if missing_planner:
        raise AssertionError(
            f"planner actions without stable IDs: {missing_planner}"
        )

    return {
        "required_capability_names": len(required),
        "planner_actions": len(planner),
        "capability_identities": len(name_to_id),
        "declared_engines": len(registry.get("engines") or []),
    }



def check_proof_truth() -> dict[str, Any]:
    """Proof is verifier-derived; observations cannot author proof/readiness."""
    observations = load_observations()
    forbidden = {"operationally_proven", "ready_for_full_work", "proof_state"}
    offenders: list[str] = []
    for row in observations.get("engines") or []:
        if not isinstance(row, dict):
            continue
        present = sorted(forbidden.intersection(row))
        if present:
            offenders.append(f"{row.get('engine_id', '<unknown>')}: {','.join(present)}")
    if offenders:
        raise AssertionError(
            "runtime observations must not author proof/readiness claims: "
            + "; ".join(offenders[:20])
        )
    if "PARTIAL" in PROOF_STATES:
        raise AssertionError("PARTIAL proof state is forbidden")
    validated = validate_contracts(load_declarations())
    policy = load_policy()
    production = (policy.get("environments") or {}).get("production") or {}
    if production.get("mode") != "BLOCK":
        raise AssertionError("production admission must be BLOCK")
    if production.get("required_engine_scope") != "all_declared":
        raise AssertionError("production must cover all declared engines")
    if production.get("minimum_evidence_level") != "E5":
        raise AssertionError("production must require E5 evidence")
    if (policy.get("override") or {}).get("enabled") is not False:
        raise AssertionError("override must remain disabled until governed lifecycle exists")
    return {"observation_proof_claims": 0, **validated}


def check_boundary() -> dict[str, Any]:
    offenders: list[str] = []
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in TEXT_SUFFIXES:
            continue
        rel = path.relative_to(ROOT)
        rel_text = rel.as_posix()
        if rel_text in {
            "afaq_registry/integrity.py",
            "scripts/check_registry_integrity.py",
        }:
            continue
        if rel.parts and rel.parts[0] in EXCLUDED_TOP:
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        if any(marker in text for marker in LEGACY_LIVE_PATHS):
            offenders.append(rel_text)

    if offenders:
        raise AssertionError(
            f"live source depends on legacy project-record registry: {sorted(offenders)}"
        )

    return {"legacy_live_dependencies": 0}


def run_all() -> dict[str, Any]:
    result: dict[str, Any] = {"ok": True}
    for name, check in (
        ("identity", check_identity),
        ("references", check_references),
        ("capabilities", check_capabilities),
        ("proof", check_proof_truth),
        ("boundary", check_boundary),
    ):
        result[name] = check()
    return result
