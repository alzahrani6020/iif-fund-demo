# AFAQ Registry

This package is the live machine-readable registry boundary.

- `declarations/engine-capability-registry.json` owns engine/package identity and relationships.
- `declarations/capability-identities.json` owns stable capability-name to capability-ID assignments.
- `observations/runtime-state.json` owns volatile runtime/activation observations.
- `loader.py` composes declarations and observations into the runtime registry view.
- `mutate.py` is the sole declaration writer; registration never implies activation or authority.
- `integrity.py` contains read-only fail-closed invariants.
- `project-records/engine-registry/` is audit/history only and is never a live runtime input.

Operational proof, admission, and activation remain evidence/governance concerns rather than declaration fields.
