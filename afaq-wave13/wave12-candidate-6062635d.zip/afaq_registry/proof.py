"""Evidence-derived engine proof protocol."""
from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

ROOT = Path(__file__).resolve().parents[1]
CONTRACTS_PATH = ROOT / "afaq_registry" / "declarations" / "engine-proof-contracts.json"
PROOF_RUNS_DIR = ROOT / "var" / "engine_proofs"

PROOF_STATES = ("UNKNOWN", "PROVING", "PROVEN", "FAILED", "EXPIRED")
VERIFIER_NAME = "afaq-engine-proof-verifier"
VERIFIER_VERSION = "1.0.0"
EVIDENCE_SCHEMA_ID = "https://schemas.afaq-global.com/proof/engine-evidence/v1/schema.json"
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
COMMIT_RE = re.compile(r"^[0-9a-f]{40}$")


@dataclass(frozen=True)
class ProofDecision:
    engine_id: str
    state: str
    reason: str
    contract_id: str | None = None
    contract_version: str | None = None
    runtime_fingerprint: str | None = None
    evidence_id: str | None = None
    last_run_at: str | None = None
    last_successful_at: str | None = None

    @property
    def proven(self) -> bool:
        return self.state == "PROVEN"

    def as_dict(self) -> dict[str, Any]:
        return {
            "engine_id": self.engine_id,
            "state": self.state,
            "reason": self.reason,
            "contract_id": self.contract_id,
            "contract_version": self.contract_version,
            "runtime_fingerprint": self.runtime_fingerprint,
            "evidence_id": self.evidence_id,
            "last_run_at": self.last_run_at,
            "last_successful_at": self.last_successful_at,
        }


def verifier_identity() -> dict[str, str]:
    return {
        "name": VERIFIER_NAME,
        "version": VERIFIER_VERSION,
        "implementation_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }


def digest_json(value: Any) -> str:
    raw = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def load_contract_document() -> dict[str, Any]:
    if not CONTRACTS_PATH.exists():
        return {"schema": "AFAQ_ENGINE_PROOF_CONTRACTS_V1", "contracts": []}
    data = json.loads(CONTRACTS_PATH.read_text(encoding="utf-8"))
    if data.get("schema") != "AFAQ_ENGINE_PROOF_CONTRACTS_V1":
        raise ValueError("unsupported engine proof contract schema")
    if tuple(data.get("proof_states") or ()) != PROOF_STATES:
        raise ValueError(f"proof_states must be exactly {PROOF_STATES!r}")
    return data


def load_contracts() -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    for contract in load_contract_document().get("contracts") or []:
        if not isinstance(contract, dict):
            raise ValueError("proof contract must be an object")
        engine_id = str(contract.get("engine_id") or "")
        if not engine_id:
            raise ValueError("proof contract engine_id is required")
        if engine_id in out:
            raise ValueError(f"duplicate proof contract for {engine_id}")
        out[engine_id] = contract
    return out


def contract_hash(contract: Mapping[str, Any]) -> str:
    return digest_json(dict(contract))


def _hash_path(path: Path) -> str:
    if path.is_file():
        return hashlib.sha256(path.read_bytes()).hexdigest()
    if path.is_dir():
        rows = []
        for child in sorted(p for p in path.rglob("*") if p.is_file()):
            if "__pycache__" in child.parts or child.suffix == ".pyc":
                continue
            rows.append({
                "path": child.relative_to(path).as_posix(),
                "sha256": hashlib.sha256(child.read_bytes()).hexdigest(),
            })
        return digest_json(rows)
    return "MISSING"


def runtime_fingerprint(
    declaration: Mapping[str, Any],
    contract: Mapping[str, Any],
) -> dict[str, Any]:
    declaration_identity = {
        key: declaration.get(key)
        for key in (
            "engine_id",
            "name",
            "kind",
            "capability_packages",
            "package_paths",
            "required_capabilities",
            "shared_engine_file",
            "live_path",
            "adapter",
            "classification",
        )
    }
    components = {
        "engine_declaration_sha256": digest_json(declaration_identity),
        "runtime_sources": [
            {"path": str(rel), "sha256": _hash_path(ROOT / str(rel))}
            for rel in contract.get("runtime_paths") or []
        ],
        "required_capabilities_sha256": digest_json(
            list(declaration.get("required_capabilities") or [])
        ),
        "proof_contract_sha256": contract_hash(contract),
    }
    return {
        "algorithm": "sha256",
        "engine_id": str(declaration.get("engine_id") or ""),
        "components": components,
        "fingerprint": digest_json(components),
    }


def _parse_time(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def latest_manifest_path(engine_id: str) -> Path:
    return PROOF_RUNS_DIR / engine_id / "latest.json"


def _decision(
    *,
    engine_id: str,
    state: str,
    reason: str,
    contract: Mapping[str, Any] | None = None,
    fingerprint: str | None = None,
    manifest: Mapping[str, Any] | None = None,
) -> ProofDecision:
    return ProofDecision(
        engine_id=engine_id,
        state=state,
        reason=reason,
        contract_id=str((contract or {}).get("contract_id") or "") or None,
        contract_version=str((contract or {}).get("contract_version") or "") or None,
        runtime_fingerprint=fingerprint,
        evidence_id=str((manifest or {}).get("evidence_id") or "") or None,
        last_run_at=str(
            (manifest or {}).get("finished_at")
            or (manifest or {}).get("started_at")
            or ""
        )
        or None,
        last_successful_at=str((manifest or {}).get("last_successful_at") or "")
        or None,
    )


def evaluate_manifest(
    *,
    declaration: Mapping[str, Any],
    contract: Mapping[str, Any],
    manifest: Mapping[str, Any],
    now: datetime | None = None,
) -> ProofDecision:
    engine_id = str(declaration.get("engine_id") or "")
    fingerprint = runtime_fingerprint(declaration, contract)["fingerprint"]

    if manifest.get("result") == "PROVING":
        return _decision(
            engine_id=engine_id,
            state="PROVING",
            reason="PROOF_RUN_IN_PROGRESS",
            contract=contract,
            fingerprint=fingerprint,
            manifest=manifest,
        )

    if manifest.get("engine_id") != engine_id:
        return _decision(
            engine_id=engine_id,
            state="FAILED",
            reason="ENGINE_ID_MISMATCH",
            contract=contract,
            fingerprint=fingerprint,
            manifest=manifest,
        )

    if (
        manifest.get("proof_contract_id") != contract.get("contract_id")
        or manifest.get("proof_contract_version") != contract.get("contract_version")
        or manifest.get("proof_contract_sha256") != contract_hash(contract)
    ):
        return _decision(
            engine_id=engine_id,
            state="EXPIRED",
            reason="PROOF_CONTRACT_CHANGED",
            contract=contract,
            fingerprint=fingerprint,
            manifest=manifest,
        )

    manifest_verifier = manifest.get("verifier")
    if not isinstance(manifest_verifier, dict):
        return _decision(
            engine_id=engine_id,
            state="FAILED",
            reason="VERIFIER_IDENTITY_MISSING",
            contract=contract,
            fingerprint=fingerprint,
            manifest=manifest,
        )
    current_verifier = verifier_identity()
    if (
        manifest_verifier.get("name") != current_verifier["name"]
        or manifest_verifier.get("version") != current_verifier["version"]
        or manifest_verifier.get("implementation_sha256")
        != current_verifier["implementation_sha256"]
    ):
        return _decision(
            engine_id=engine_id,
            state="EXPIRED",
            reason="VERIFIER_IDENTITY_CHANGED",
            contract=contract,
            fingerprint=fingerprint,
            manifest=manifest,
        )

    runtime = manifest.get("runtime") or {}
    if runtime.get("fingerprint") != fingerprint:
        return _decision(
            engine_id=engine_id,
            state="EXPIRED",
            reason="RUNTIME_FINGERPRINT_CHANGED",
            contract=contract,
            fingerprint=fingerprint,
            manifest=manifest,
        )

    if not COMMIT_RE.fullmatch(str(runtime.get("source_commit") or "")):
        return _decision(
            engine_id=engine_id,
            state="FAILED",
            reason="SOURCE_COMMIT_MISSING_OR_INVALID",
            contract=contract,
            fingerprint=fingerprint,
            manifest=manifest,
        )

    finished = _parse_time(manifest.get("finished_at"))
    if finished is None:
        return _decision(
            engine_id=engine_id,
            state="FAILED",
            reason="FINISHED_AT_MISSING_OR_INVALID",
            contract=contract,
            fingerprint=fingerprint,
            manifest=manifest,
        )

    max_age = int(contract.get("max_evidence_age_seconds") or 0)
    now_utc = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    if max_age <= 0:
        return _decision(
            engine_id=engine_id,
            state="FAILED",
            reason="INVALID_MAX_EVIDENCE_AGE",
            contract=contract,
            fingerprint=fingerprint,
            manifest=manifest,
        )
    if max(0.0, (now_utc - finished).total_seconds()) > max_age:
        return _decision(
            engine_id=engine_id,
            state="EXPIRED",
            reason="EVIDENCE_TOO_OLD",
            contract=contract,
            fingerprint=fingerprint,
            manifest=manifest,
        )

    rows = manifest.get("assertions")
    if not isinstance(rows, list):
        return _decision(
            engine_id=engine_id,
            state="FAILED",
            reason="ASSERTIONS_MISSING",
            contract=contract,
            fingerprint=fingerprint,
            manifest=manifest,
        )
    by_id = {
        str(row.get("id")): row
        for row in rows
        if isinstance(row, dict) and row.get("id")
    }

    for assertion_id in contract.get("required_assertions") or []:
        row = by_id.get(str(assertion_id))
        if not row:
            return _decision(
                engine_id=engine_id,
                state="FAILED",
                reason=f"REQUIRED_ASSERTION_MISSING:{assertion_id}",
                contract=contract,
                fingerprint=fingerprint,
                manifest=manifest,
            )
        if row.get("result") != "PASS":
            return _decision(
                engine_id=engine_id,
                state="FAILED",
                reason=f"REQUIRED_ASSERTION_FAILED:{assertion_id}",
                contract=contract,
                fingerprint=fingerprint,
                manifest=manifest,
            )
        observed = row.get("observed")
        artifact_sha = str(row.get("artifact_sha256") or "")
        if not SHA256_RE.fullmatch(artifact_sha) or digest_json(observed) != artifact_sha:
            return _decision(
                engine_id=engine_id,
                state="FAILED",
                reason=f"EVIDENCE_INTEGRITY_FAILED:{assertion_id}",
                contract=contract,
                fingerprint=fingerprint,
                manifest=manifest,
            )

    if manifest.get("result") != "PASS":
        return _decision(
            engine_id=engine_id,
            state="FAILED",
            reason="PROOF_RUN_FAILED",
            contract=contract,
            fingerprint=fingerprint,
            manifest=manifest,
        )

    evidence_level = str(manifest.get("evidence_level") or "")
    if evidence_level not in ("E0", "E1", "E2", "E3", "E4", "E5"):
        return _decision(
            engine_id=engine_id,
            state="FAILED",
            reason="EVIDENCE_LEVEL_INVALID",
            contract=contract,
            fingerprint=fingerprint,
            manifest=manifest,
        )

    if evidence_level == "E5":
        return _decision(
            engine_id=engine_id,
            state="FAILED",
            reason="E5_ATTESTATION_VERIFICATION_UNIMPLEMENTED",
            contract=contract,
            fingerprint=fingerprint,
            manifest=manifest,
        )

    return _decision(
        engine_id=engine_id,
        state="PROVEN",
        reason="FULL_CONTRACT_PASS",
        contract=contract,
        fingerprint=fingerprint,
        manifest=manifest,
    )


def get_engine_proof_status(declaration: Mapping[str, Any]) -> ProofDecision:
    engine_id = str(declaration.get("engine_id") or "")
    contract = load_contracts().get(engine_id)
    if contract is None:
        return ProofDecision(
            engine_id=engine_id,
            state="UNKNOWN",
            reason="NO_PROOF_CONTRACT",
        )

    fingerprint = runtime_fingerprint(declaration, contract)["fingerprint"]
    path = latest_manifest_path(engine_id)
    if not path.exists():
        return _decision(
            engine_id=engine_id,
            state="UNKNOWN",
            reason="NO_EVIDENCE_MANIFEST",
            contract=contract,
            fingerprint=fingerprint,
        )

    try:
        manifest = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return _decision(
            engine_id=engine_id,
            state="FAILED",
            reason="EVIDENCE_MANIFEST_UNREADABLE",
            contract=contract,
            fingerprint=fingerprint,
        )

    if not isinstance(manifest, dict):
        return _decision(
            engine_id=engine_id,
            state="FAILED",
            reason="EVIDENCE_MANIFEST_INVALID",
            contract=contract,
            fingerprint=fingerprint,
        )

    return evaluate_manifest(
        declaration=declaration,
        contract=contract,
        manifest=manifest,
    )


def validate_contracts(declarations: Mapping[str, Any]) -> dict[str, int]:
    engines = {
        str(row.get("engine_id")): row
        for row in declarations.get("engines") or []
        if isinstance(row, dict) and row.get("engine_id")
    }
    contracts = load_contracts()
    for engine_id, contract in contracts.items():
        if engine_id not in engines:
            raise AssertionError(
                f"proof contract references unknown engine: {engine_id}"
            )
        required = list(contract.get("required_assertions") or [])
        if not required or len(required) != len(set(required)):
            raise AssertionError(f"{engine_id} invalid required assertions")
        case_ids = {
            str(case.get("id"))
            for case in contract.get("cases") or []
            if isinstance(case, dict) and case.get("id")
        }
        if set(required) != case_ids:
            raise AssertionError(
                f"{engine_id} required assertions must exactly match proof cases"
            )
        if int(contract.get("max_evidence_age_seconds") or 0) <= 0:
            raise AssertionError(
                f"{engine_id} invalid max_evidence_age_seconds"
            )
        if not contract.get("runtime_paths"):
            raise AssertionError(f"{engine_id} runtime_paths required")
        decision = contract.get("decision") or {}
        if decision.get("partial_allowed") is not False:
            raise AssertionError(f"{engine_id} PARTIAL proof is forbidden")
        if decision.get("all_required_assertions_must_pass") is not True:
            raise AssertionError(f"{engine_id} all assertions must pass")
    return {
        "proof_contracts": len(contracts),
        "declared_engines": len(engines),
    }
