"""Central admission authority for deployment and runtime enforcement."""
from __future__ import annotations

import hashlib
import json
import subprocess
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping

from .loader import load_declarations
from .proof import (
    PROOF_STATES,
    get_engine_proof_status,
    latest_manifest_path,
    load_contracts,
    runtime_fingerprint,
    verifier_identity,
)

ROOT = Path(__file__).resolve().parents[1]
POLICY_PATH = ROOT / "afaq_registry" / "declarations" / "admission-policy.yml"
DECISION_REGISTER_PATH = ROOT / "var" / "admission" / "decision-register.jsonl"
AUTHORITY_VERSION = "1.0.0"
AUTHORITY_NAME = "afaq-admission-authority"
EVIDENCE_LEVELS = ("E0", "E1", "E2", "E3", "E4", "E5")


@dataclass(frozen=True)
class AdmissionDecision:
    environment: str
    deployment_path: str
    mode: str
    decision: str
    reasons: tuple[str, ...]
    proof_snapshot: tuple[dict[str, Any], ...]

    @property
    def admitted(self) -> bool:
        return self.decision == "ADMITTED"

    @property
    def execution_allowed(self) -> bool:
        return self.decision in {"ADMITTED", "WARNED", "LOGGED"}


class AdmissionBlocked(RuntimeError):
    pass


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _canonical_json(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    ).encode("utf-8")


def load_policy() -> dict[str, Any]:
    # JSON is a valid YAML 1.2 subset. Keeping the authoritative .yml in this
    # subset avoids a runtime YAML dependency in security-critical startup.
    data = json.loads(POLICY_PATH.read_text(encoding="utf-8"))
    if data.get("schema") != "AFAQ_ADMISSION_POLICY_V1":
        raise ValueError("unsupported admission policy schema")
    return data


def policy_identity() -> dict[str, str]:
    policy = load_policy()
    return {
        "id": str(policy.get("$id") or ""),
        "version": str(policy.get("policy_version") or ""),
        "sha256": _sha256_bytes(POLICY_PATH.read_bytes()),
    }


def authority_identity() -> dict[str, str]:
    return {
        "name": AUTHORITY_NAME,
        "version": AUTHORITY_VERSION,
        "implementation_sha256": _sha256_bytes(Path(__file__).read_bytes()),
    }


def admission_cache_identity() -> str:
    """Digest all source/evidence inputs that may affect runtime admission.

    This identity is intentionally recomputed at request time for protected
    production mutations. A source, policy, verifier, contract, declaration,
    or evidence change therefore invalidates a cached admission decision
    before it can be reused.
    """
    declarations = load_declarations()
    engines = {
        str(row.get("engine_id")): row
        for row in declarations.get("engines") or []
        if isinstance(row, dict) and row.get("engine_id")
    }
    contracts = load_contracts()
    contracted = []
    for engine_id in sorted(contracts):
        contract = contracts[engine_id]
        declaration = engines.get(engine_id)
        manifest_path = latest_manifest_path(engine_id)
        manifest_sha256 = (
            _sha256_bytes(manifest_path.read_bytes())
            if manifest_path.exists()
            else None
        )
        contracted.append({
            "engine_id": engine_id,
            "runtime_fingerprint": (
                runtime_fingerprint(declaration, contract)["fingerprint"]
                if declaration is not None
                else "DECLARATION_MISSING"
            ),
            "evidence_manifest_sha256": manifest_sha256,
        })

    payload = {
        "policy": policy_identity(),
        "authority": authority_identity(),
        "verifier": verifier_identity(),
        "declared_engine_ids": sorted(engines),
        "contracted": contracted,
    }
    return _sha256_bytes(_canonical_json(payload))


def _source_commit() -> str | None:
    try:
        value = subprocess.check_output(
            ["git", "rev-parse", "HEAD"],
            cwd=ROOT,
            text=True,
            timeout=5,
        ).strip()
    except (OSError, subprocess.SubprocessError):
        return None
    return value if len(value) == 40 else None


def _evidence_level(engine_id: str) -> str:
    path = latest_manifest_path(engine_id)
    if not path.exists():
        return "E0"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return "E0"
    value = str(data.get("evidence_level") or "E0")
    return value if value in EVIDENCE_LEVELS else "E0"


def _required_engine_ids(scope: str) -> list[str]:
    declarations = load_declarations()
    declared = [
        str(row.get("engine_id"))
        for row in declarations.get("engines") or []
        if isinstance(row, dict) and row.get("engine_id")
    ]
    if scope == "all_declared":
        return sorted(declared)
    if scope == "contracted":
        return sorted(load_contracts())
    if scope == "none":
        return []
    raise ValueError(f"unsupported required_engine_scope: {scope}")


def evaluate_admission(
    *,
    environment: str,
    deployment_path: str,
    engine_ids: Iterable[str] | None = None,
) -> AdmissionDecision:
    policy = load_policy()
    path_policy = (policy.get("deployment_paths") or {}).get(deployment_path)
    if not isinstance(path_policy, dict):
        return AdmissionDecision(
            environment=environment,
            deployment_path=deployment_path,
            mode="BLOCK",
            decision="BLOCKED",
            reasons=("UNREGISTERED_DEPLOYMENT_PATH",),
            proof_snapshot=(),
        )
    expected_environment = str(path_policy.get("environment") or "")
    if expected_environment != environment:
        return AdmissionDecision(
            environment=environment,
            deployment_path=deployment_path,
            mode="BLOCK",
            decision="BLOCKED",
            reasons=(f"DEPLOYMENT_ENVIRONMENT_MISMATCH:{expected_environment}",),
            proof_snapshot=(),
        )

    env_policy = (policy.get("environments") or {}).get(environment)
    if not isinstance(env_policy, dict):
        raise ValueError(f"unknown admission environment: {environment}")

    mode = str(env_policy.get("mode") or policy.get("default_mode") or "BLOCK")
    engine_execution = bool(path_policy.get("engine_execution", True))
    scope = str(
        path_policy.get("required_engine_scope")
        or env_policy.get("required_engine_scope")
        or "all_declared"
    )
    if not engine_execution and scope != "none":
        return AdmissionDecision(
            environment=environment,
            deployment_path=deployment_path,
            mode="BLOCK",
            decision="BLOCKED",
            reasons=("NON_ENGINE_PATH_SCOPE_MUST_BE_NONE",),
            proof_snapshot=(),
        )
    if engine_execution and scope == "none":
        return AdmissionDecision(
            environment=environment,
            deployment_path=deployment_path,
            mode="BLOCK",
            decision="BLOCKED",
            reasons=("ENGINE_PATH_CANNOT_USE_NONE_SCOPE",),
            proof_snapshot=(),
        )
    requested_ids = list(engine_ids) if engine_ids is not None else _required_engine_ids(scope)
    required_ids = sorted(set(requested_ids))
    declarations = {
        str(row.get("engine_id")): row
        for row in load_declarations().get("engines") or []
        if isinstance(row, dict) and row.get("engine_id")
    }

    minimum_level = str(env_policy.get("minimum_evidence_level") or "E0")
    minimum_index = EVIDENCE_LEVELS.index(minimum_level)
    required_state = str(env_policy.get("required_proof_state") or "PROVEN")
    reasons: list[str] = []
    snapshot: list[dict[str, Any]] = []

    for engine_id in required_ids:
        declaration = declarations.get(engine_id)
        if declaration is None:
            reasons.append(f"UNKNOWN_ENGINE:{engine_id}")
            continue
        proof = get_engine_proof_status(declaration)
        level = _evidence_level(engine_id)
        snapshot.append({
            "engine_id": engine_id,
            "proof_state": proof.state,
            "evidence_level": level,
            "reason": proof.reason,
            "evidence_id": proof.evidence_id,
            "runtime_fingerprint": proof.runtime_fingerprint,
        })
        if proof.state != required_state:
            reasons.append(f"PROOF_NOT_{required_state}:{engine_id}:{proof.state}")
        if EVIDENCE_LEVELS.index(level) < minimum_index:
            reasons.append(
                f"EVIDENCE_BELOW_{minimum_level}:{engine_id}:{level}"
            )

    if not required_ids and engine_execution:
        reasons.append("NO_ENGINES_IN_ADMISSION_SCOPE")

    if reasons:
        if mode == "WARN":
            decision = "WARNED"
        elif mode == "LOG":
            decision = "LOGGED"
        else:
            decision = "BLOCKED"
    else:
        decision = "ADMITTED"

    return AdmissionDecision(
        environment=environment,
        deployment_path=deployment_path,
        mode=mode,
        decision=decision,
        reasons=tuple(reasons),
        proof_snapshot=tuple(snapshot),
    )


def _last_register_entry() -> dict[str, Any] | None:
    if not DECISION_REGISTER_PATH.exists():
        return None
    lines = [
        line
        for line in DECISION_REGISTER_PATH.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    if not lines:
        return None
    return json.loads(lines[-1])


def record_decision(decision: AdmissionDecision) -> dict[str, Any]:
    DECISION_REGISTER_PATH.parent.mkdir(parents=True, exist_ok=True)
    previous = _last_register_entry()
    previous_hash = str(previous.get("entry_hash")) if previous else None
    sequence = int(previous.get("ledger_sequence") or 0) + 1 if previous else 1

    entry: dict[str, Any] = {
        "schema": "AFAQ_ADMISSION_DECISION_V1",
        "decision_id": f"ADM-{uuid.uuid4().hex}",
        "ledger_sequence": sequence,
        "previous_hash": previous_hash,
        "environment": decision.environment,
        "deployment_path": decision.deployment_path,
        "mode": decision.mode,
        "decision": decision.decision,
        "reasons": list(decision.reasons),
        "proof_snapshot": list(decision.proof_snapshot),
        "policy": policy_identity(),
        "authority": authority_identity(),
        "source_commit": _source_commit(),
        "decided_at": datetime.now(timezone.utc).isoformat(),
    }
    entry["entry_hash"] = _sha256_bytes(_canonical_json(entry))
    with DECISION_REGISTER_PATH.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(entry, ensure_ascii=False, sort_keys=True) + "\n")
        handle.flush()
    return entry


def verify_decision_register() -> dict[str, int]:
    if not DECISION_REGISTER_PATH.exists():
        return {"entries": 0}
    previous_hash = None
    expected_sequence = 1
    entries = 0
    for raw in DECISION_REGISTER_PATH.read_text(encoding="utf-8").splitlines():
        if not raw.strip():
            continue
        entry = json.loads(raw)
        if entry.get("ledger_sequence") != expected_sequence:
            raise AssertionError("decision register ledger sequence mismatch")
        if entry.get("previous_hash") != previous_hash:
            raise AssertionError("decision register hash chain mismatch")
        claimed = str(entry.get("entry_hash") or "")
        material = dict(entry)
        material.pop("entry_hash", None)
        actual = _sha256_bytes(_canonical_json(material))
        if claimed != actual:
            raise AssertionError("decision register entry hash mismatch")
        previous_hash = claimed
        expected_sequence += 1
        entries += 1
    return {"entries": entries}


def verify_recorded_decision(
    entry: Mapping[str, Any],
    decision: AdmissionDecision,
) -> None:
    verification = verify_decision_register()
    if verification.get("entries", 0) < 1:
        raise AssertionError("decision register entry was not persisted")
    last = _last_register_entry()
    if not isinstance(last, dict):
        raise AssertionError("decision register last entry missing")
    if last.get("entry_hash") != entry.get("entry_hash"):
        raise AssertionError("persisted decision is not the register tail")
    if last.get("decision_id") != entry.get("decision_id"):
        raise AssertionError("persisted decision id mismatch")
    if last.get("environment") != decision.environment:
        raise AssertionError("persisted decision environment mismatch")
    if last.get("deployment_path") != decision.deployment_path:
        raise AssertionError("persisted decision deployment path mismatch")
    if last.get("decision") != decision.decision:
        raise AssertionError("persisted admission decision mismatch")
    if last.get("policy") != policy_identity():
        raise AssertionError("persisted admission policy identity mismatch")
    if last.get("authority") != authority_identity():
        raise AssertionError("persisted admission authority identity mismatch")


def _requires_decision_register(environment: str) -> bool:
    policy = load_policy()
    env_policy = (policy.get("environments") or {}).get(environment) or {}
    return bool(env_policy.get("require_decision_register", False))


def require_admission(
    *,
    environment: str,
    deployment_path: str,
    record: bool = True,
) -> AdmissionDecision:
    decision = evaluate_admission(
        environment=environment,
        deployment_path=deployment_path,
    )

    must_record = _requires_decision_register(environment)
    if must_record or record:
        try:
            entry = record_decision(decision)
            verify_recorded_decision(entry, decision)
        except Exception as exc:
            raise AdmissionBlocked(
                f"{deployment_path} blocked in {environment}: "
                f"DECISION_REGISTER_ENFORCEMENT_FAILED:{type(exc).__name__}:{exc}"
            ) from exc

    if must_record and not DECISION_REGISTER_PATH.exists():
        raise AdmissionBlocked(
            f"{deployment_path} blocked in {environment}: "
            "DECISION_REGISTER_REQUIRED"
        )

    if not decision.execution_allowed:
        raise AdmissionBlocked(
            f"{deployment_path} blocked in {environment}: "
            + "; ".join(decision.reasons[:20])
        )
    return decision
