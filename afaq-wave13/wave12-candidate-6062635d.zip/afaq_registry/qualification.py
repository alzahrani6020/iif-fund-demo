"""Engine qualification gate.

Qualification is intentionally below production eligibility. It converts
current E4 proof into a QUALIFIED candidate decision without authorizing
production, canary, or E5 claims.
"""
from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .loader import load_declarations
from .proof import get_engine_proof_status, latest_manifest_path

ROOT = Path(__file__).resolve().parents[1]
LIFECYCLE_PATH = ROOT / "afaq_registry" / "declarations" / "engine-production-lifecycle.json"
EVIDENCE_LEVELS = ("E0", "E1", "E2", "E3", "E4", "E5")
ALLOWED_INPUT_STATES = {"VERIFIED", "QUALIFIED"}


@dataclass(frozen=True)
class QualificationDecision:
    engine_id: str
    decision: str
    reasons: tuple[str, ...]
    lifecycle_state: str
    proof_state: str
    evidence_level: str | None
    evidence_id: str | None
    runtime_fingerprint: str | None

    @property
    def qualified(self) -> bool:
        return self.decision == "QUALIFIED_CANDIDATE"

    def as_dict(self) -> dict[str, Any]:
        return {
            "engine_id": self.engine_id,
            "decision": self.decision,
            "reasons": list(self.reasons),
            "lifecycle_state": self.lifecycle_state,
            "proof_state": self.proof_state,
            "evidence_level": self.evidence_level,
            "evidence_id": self.evidence_id,
            "runtime_fingerprint": self.runtime_fingerprint,
        }


def _load_lifecycle() -> dict[str, Any]:
    data = json.loads(LIFECYCLE_PATH.read_text(encoding="utf-8"))
    if data.get("schema") != "AFAQ_ENGINE_PRODUCTION_LIFECYCLE_V1":
        raise ValueError("unsupported lifecycle schema")
    if not isinstance(data.get("engines"), dict):
        raise ValueError("lifecycle engines must be an object")
    return data


def _load_manifest(engine_id: str) -> dict[str, Any] | None:
    path = latest_manifest_path(engine_id)
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return data if isinstance(data, dict) else None


def evaluate(engine_id: str) -> QualificationDecision:
    declarations = {
        str(row.get("engine_id")): row
        for row in load_declarations().get("engines") or []
        if isinstance(row, dict) and row.get("engine_id")
    }
    declaration = declarations.get(engine_id)
    lifecycle = _load_lifecycle()
    entry = lifecycle["engines"].get(engine_id) or {}
    lifecycle_state = str(entry.get("state") or lifecycle.get("default_state") or "DECLARED")

    reasons: list[str] = []
    if declaration is None:
        reasons.append("ENGINE_NOT_DECLARED")

    if lifecycle_state not in ALLOWED_INPUT_STATES:
        reasons.append(f"LIFECYCLE_NOT_VERIFIED:{lifecycle_state}")

    if declaration is None:
        proof_state = "UNKNOWN"
        evidence_id = None
        runtime_fingerprint = None
    else:
        proof = get_engine_proof_status(declaration)
        proof_state = proof.state
        evidence_id = proof.evidence_id
        runtime_fingerprint = proof.runtime_fingerprint
        if proof.state != "PROVEN":
            reasons.append(f"PROOF_NOT_PROVEN:{proof.state}")

    manifest = _load_manifest(engine_id)
    evidence_level: str | None = None
    if manifest is None:
        reasons.append("EVIDENCE_MANIFEST_MISSING")
    else:
        evidence_level = str(manifest.get("evidence_level") or "")
        if manifest.get("result") != "PASS":
            reasons.append("EVIDENCE_RESULT_NOT_PASS")
        if evidence_level not in EVIDENCE_LEVELS:
            reasons.append("EVIDENCE_LEVEL_INVALID")
        elif EVIDENCE_LEVELS.index(evidence_level) < EVIDENCE_LEVELS.index("E4"):
            reasons.append(f"EVIDENCE_BELOW_E4:{evidence_level}")
        elif evidence_level == "E5":
            reasons.append("E5_NOT_ACCEPTED_BY_QUALIFICATION_GATE")

    decision = "QUALIFIED_CANDIDATE" if not reasons else "BLOCKED"
    return QualificationDecision(
        engine_id=engine_id,
        decision=decision,
        reasons=tuple(reasons),
        lifecycle_state=lifecycle_state,
        proof_state=proof_state,
        evidence_level=evidence_level,
        evidence_id=evidence_id,
        runtime_fingerprint=runtime_fingerprint,
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--engine", action="append", dest="engines")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    engines = args.engines or sorted(_load_lifecycle()["engines"])
    decisions = [evaluate(engine_id) for engine_id in engines]
    result = {
        "schema": "AFAQ_ENGINE_QUALIFICATION_REPORT_V1",
        "authority": "NON_PRODUCTION_QUALIFICATION_GATE",
        "decisions": [row.as_dict() for row in decisions],
        "summary": {
            "total": len(decisions),
            "qualified_candidates": sum(row.qualified for row in decisions),
            "blocked": sum(not row.qualified for row in decisions),
        },
    }

    rendered = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        out = args.output if args.output.is_absolute() else ROOT / args.output
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(rendered, encoding="utf-8")
    print(rendered, end="")
    return 0 if all(row.qualified for row in decisions) else 1


if __name__ == "__main__":
    raise SystemExit(main())
