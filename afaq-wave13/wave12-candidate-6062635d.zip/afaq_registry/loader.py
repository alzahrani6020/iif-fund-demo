"""Read-only composition of registry declarations and runtime observations.

Declarations own identity and relationships. Observations own volatile runtime
state. project-records/ is evidence/history only and is never a live input.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .proof import PROOF_STATES, get_engine_proof_status

ROOT = Path(__file__).resolve().parents[1]
REGISTRY_PATH = ROOT / "afaq_registry" / "declarations" / "engine-capability-registry.json"
CAPABILITY_IDENTITY_PATH = ROOT / "afaq_registry" / "declarations" / "capability-identities.json"
OBSERVATIONS_PATH = ROOT / "afaq_registry" / "observations" / "runtime-state.json"
CANONICAL_REGISTRY_PATH = ROOT / "capability-foundation" / "CANONICAL_ENGINE_REGISTRY_V11.json"


def _read_object(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"registry document must be an object: {path}")
    return data


def load_declarations() -> dict[str, Any]:
    data = _read_object(REGISTRY_PATH)
    if data.get("schema") != "AFAQ_ENGINE_CAPABILITY_DECLARATIONS_V1":
        raise ValueError("unsupported engine/capability declaration schema")
    return data


def load_observations() -> dict[str, Any]:
    if not OBSERVATIONS_PATH.exists():
        return {
            "schema": "AFAQ_REGISTRY_RUNTIME_STATE_V1",
            "engines": [],
            "capability_packages": [],
        }
    data = _read_object(OBSERVATIONS_PATH)
    if data.get("schema") != "AFAQ_REGISTRY_RUNTIME_STATE_V1":
        raise ValueError("unsupported registry observation schema")
    return data


def _declared_capability_names(data: dict[str, Any]) -> set[str]:
    names: set[str] = set()
    for engine in data.get("engines") or []:
        for name in engine.get("required_capabilities") or []:
            if isinstance(name, str) and name.strip():
                names.add(name.strip())
    for package in data.get("capability_packages") or []:
        for name in package.get("capabilities") or []:
            if isinstance(name, str) and name.strip():
                names.add(name.strip())
    return names


def derive_totals(data: dict[str, Any]) -> dict[str, int]:
    engines = list(data.get("engines") or [])
    packages = list(data.get("capability_packages") or [])
    declared_capabilities = _declared_capability_names(data)
    return {
        "engines": len(engines),
        "ACTIVE": sum(1 for e in engines if e.get("live_status") == "ACTIVE"),
        "activated": sum(1 for e in engines if bool(e.get("activated"))),
        "capability_packages": len(packages),
        "declared_capabilities": len(declared_capabilities),
        "engines_with_packages": sum(1 for e in engines if e.get("capability_packages")),
        "live_runtime": sum(1 for e in engines if e.get("kind") == "live_runtime"),
        "live_cap": sum(1 for e in engines if e.get("kind") == "live_cap"),
        "packages_linked": sum(1 for p in packages if p.get("engine_ids")),
        "packages_unlinked": sum(1 for p in packages if not p.get("engine_ids")),
        "engines_with_required_capabilities": sum(1 for e in engines if e.get("required_capabilities")),
        "engines_with_classification": sum(1 for e in engines if e.get("classification")),
        "packages_with_capability_lists": sum(1 for p in packages if isinstance(p.get("capabilities"), list)),
        **{f"proof_{state}": sum(1 for e in engines if e.get("proof_state") == state) for state in PROOF_STATES},
    }


def load_canonical_registry() -> dict[str, Any]:
    if not CANONICAL_REGISTRY_PATH.exists():
        return {"engines": [], "capability_packages": []}
    data = _read_object(CANONICAL_REGISTRY_PATH)
    if data.get("schema") != "afaq.canonical-engine-registry/v11":
        raise ValueError("unsupported canonical engine registry schema")
    return data


def load_registry() -> dict[str, Any]:
    declarations = load_declarations()
    observations = load_observations()
    canonical = load_canonical_registry()
    canonical_by_id = {
        str(row.get("engine_id")): row
        for row in (canonical.get("engines") or [])
        if row.get("engine_id")
    }
    engine_state = {
        str(row.get("engine_id")): row
        for row in observations.get("engines") or []
        if row.get("engine_id")
    }
    package_state = {
        str(row.get("package_id")): row
        for row in observations.get("capability_packages") or []
        if row.get("package_id")
    }

    engines: list[dict[str, Any]] = []
    for source in declarations.get("engines") or []:
        row = dict(source)
        engine_id = str(row.get("engine_id") or "")
        state = engine_state.get(engine_id, {})
        proof = get_engine_proof_status(source)
        canonical_engine = canonical_by_id.get(engine_id, {})

        # Proof truth is evidence-derived only. Canonical registry flags are
        # historical/design evidence and must never promote live proof state.
        operationally_proven = proof.proven
        proof_state = proof.state
        proof_dict = proof.as_dict()

        runtime_implementation = bool(state.get("runtime_implementation", False))
        activated = bool(state.get("activated", False))
        row.update({
            "live_status": state.get("live_status", "REGISTERED"),
            "activated": activated,
            "activated_on": state.get("activated_on"),
            "proof_state": proof_state,
            "proof": proof_dict,
            "operationally_proven": operationally_proven,
            "ready_for_full_work": bool(
                activated and runtime_implementation and operationally_proven
            ),
            "runtime_implementation": runtime_implementation,
            "state": state.get("state", "REGISTERED"),
        })
        engines.append(row)

    packages: list[dict[str, Any]] = []
    for source in declarations.get("capability_packages") or []:
        row = dict(source)
        state = package_state.get(str(row.get("package_id")), {})
        row.update({
            "activated": bool(state.get("activated", False)),
            "activated_on": state.get("activated_on"),
            "state": state.get("state", "REGISTERED_CAPABILITY"),
        })
        packages.append(row)

    combined = {
        "schema": "AFAQ_ENGINE_CAPABILITY_REGISTRY_VIEW_V1",
        "engines": engines,
        "capability_packages": packages,
    }
    combined["totals"] = derive_totals(combined)

    identity_doc = _read_object(CAPABILITY_IDENTITY_PATH)
    identity_map = identity_doc.get("name_to_id") or {}
    if not isinstance(identity_map, dict):
        raise ValueError("capability identity map must be an object")
    combined["capability_identities"] = [
        {"name": name, "capability_id": capability_id}
        for name, capability_id in sorted(identity_map.items())
    ]
    combined["totals"]["capability_identities"] = len(identity_map)
    combined["all_activated"] = bool(engines) and all(bool(e.get("activated")) for e in engines)
    return combined


def load_capability_identities() -> dict[str, Any]:
    return _read_object(CAPABILITY_IDENTITY_PATH)
