"""Governed mutation of authoritative registry declarations.

This module never writes runtime state. Registration is identity/relationship
management only and never implies activation, authority, readiness, admission,
or operational proof.
"""
from __future__ import annotations

import json
import re
import sys
from typing import Any

from .loader import REGISTRY_PATH as DECLARATIONS_PATH, load_declarations

ENGINE_ID_RE = re.compile(r"^ENG-[A-Z0-9]+-\d{3,}$")
PACKAGE_ID_RE = re.compile(
    r"^(?:W[78]-P\d{2,}(?:-[A-Za-z0-9_]+)?|W[78]-PKG-\d{2,}|AFAQ-P\d{2,}|CAP-[A-Z0-9-]+)$"
)


def _save(data: dict[str, Any]) -> None:
    DECLARATIONS_PATH.write_text(
        json.dumps(data, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def _hints(data: dict[str, Any]) -> dict[str, Any]:
    engines = list(data.get("engines") or [])
    packages = list(data.get("capability_packages") or [])
    cap_nums = []
    for engine in engines:
        match = re.match(r"^ENG-CAP-(\d+)$", str(engine.get("engine_id") or ""))
        if match:
            cap_nums.append(int(match.group(1)))
    w7, w8 = [], []
    for package in packages:
        pid = str(package.get("package_id") or "")
        match = re.match(r"^W7-P(\d+)$", pid)
        if match:
            w7.append(int(match.group(1)))
        match = re.match(r"^W8-P(\d+)$", pid)
        if match:
            w8.append(int(match.group(1)))
    return {
        "next_eng_cap_id": f"ENG-CAP-{((max(cap_nums) + 1) if cap_nums else 1):03d}",
        "next_w7_package_id": f"W7-P{((max(w7) + 1) if w7 else 1):02d}",
        "next_w8_package_id": f"W8-P{((max(w8) + 1) if w8 else 1):02d}",
    }


def ensure_extensibility_block() -> dict[str, Any]:
    data = load_declarations()
    hints = _hints(data)
    return {
        "schema": data.get("schema"),
        "engines": len(data.get("engines") or []),
        "capability_packages": len(data.get("capability_packages") or []),
        **hints,
    }


def add_capability(
    *,
    package_id: str,
    name: str,
    path: str | None = None,
    engine_ids: list[str] | None = None,
    capabilities: list[str] | None = None,
    activate: bool = False,
) -> dict[str, Any]:
    if activate:
        raise ValueError("registration cannot activate a capability package")
    package_id = str(package_id).strip()
    if not PACKAGE_ID_RE.match(package_id):
        raise ValueError(f"invalid package_id: {package_id!r}")

    data = load_declarations()
    packages = list(data.get("capability_packages") or [])
    engines = list(data.get("engines") or [])
    if any(p.get("package_id") == package_id for p in packages):
        raise ValueError(f"duplicate package_id rejected: {package_id}")

    engine_by_id = {e.get("engine_id"): e for e in engines}
    linked = list(dict.fromkeys(engine_ids or []))
    missing = [eid for eid in linked if eid not in engine_by_id]
    if missing:
        raise ValueError(f"cannot link unknown engine_ids: {missing}")

    row = {
        "package_id": package_id,
        "name": str(name),
        "path": path,
        "wave": None,
        "engine_ids": linked,
        "capabilities": list(dict.fromkeys(capabilities or [])),
    }
    packages.append(row)

    for eid in linked:
        engine = engine_by_id[eid]
        refs = list(engine.get("capability_packages") or [])
        if package_id not in refs:
            refs.append(package_id)
            engine["capability_packages"] = refs
        if path:
            paths = list(engine.get("package_paths") or [])
            if path not in paths:
                paths.append(path)
                engine["package_paths"] = paths
        for capability in row["capabilities"]:
            required = list(engine.get("required_capabilities") or [])
            if capability not in required:
                required.append(capability)
                engine["required_capabilities"] = required

    data["engines"] = sorted(engines, key=lambda e: str(e.get("engine_id") or ""))
    data["capability_packages"] = sorted(packages, key=lambda p: str(p.get("package_id") or ""))
    _save(data)
    return row


def link_capability_to_engine(package_id: str, engine_id: str) -> dict[str, Any]:
    data = load_declarations()
    engines = list(data.get("engines") or [])
    packages = list(data.get("capability_packages") or [])
    engine = next((e for e in engines if e.get("engine_id") == engine_id), None)
    package = next((p for p in packages if p.get("package_id") == package_id), None)
    if engine is None:
        raise ValueError(f"unknown engine_id: {engine_id}")
    if package is None:
        raise ValueError(f"unknown package_id: {package_id}")

    refs = list(engine.get("capability_packages") or [])
    if package_id not in refs:
        refs.append(package_id)
        engine["capability_packages"] = refs
    reverse = list(package.get("engine_ids") or [])
    if engine_id not in reverse:
        reverse.append(engine_id)
        package["engine_ids"] = reverse
    if package.get("path"):
        paths = list(engine.get("package_paths") or [])
        if package["path"] not in paths:
            paths.append(package["path"])
            engine["package_paths"] = paths

    _save(data)
    return {"engine_id": engine_id, "package_id": package_id, "linked": True}


def add_engine(
    *,
    engine_id: str,
    name: str,
    kind: str = "live_cap",
    capability_packages: list[str] | None = None,
    package_paths: list[str] | None = None,
    required_capabilities: list[str] | None = None,
    shared_engine_file: str | None = None,
    live_path: str | None = None,
    classification: str | None = None,
    activate: bool = False,
) -> dict[str, Any]:
    if activate:
        raise ValueError("registration cannot activate an engine")
    engine_id = str(engine_id).strip()
    if not ENGINE_ID_RE.match(engine_id):
        raise ValueError(f"invalid engine_id: {engine_id!r}")

    data = load_declarations()
    engines = list(data.get("engines") or [])
    packages = list(data.get("capability_packages") or [])
    if any(e.get("engine_id") == engine_id for e in engines):
        raise ValueError(f"duplicate engine_id rejected: {engine_id}")

    package_by_id = {p.get("package_id"): p for p in packages}
    linked = list(dict.fromkeys(capability_packages or []))
    missing = [pid for pid in linked if pid not in package_by_id]
    if missing:
        raise ValueError(f"cannot link unknown capability packages: {missing}")

    paths = list(package_paths or [])
    if linked and not paths:
        paths = [
            package_by_id[pid].get("path")
            for pid in linked
            if package_by_id[pid].get("path")
        ]

    row = {
        "engine_id": engine_id,
        "name": str(name),
        "kind": kind,
        "capability_packages": linked,
        "package_paths": paths,
        "required_capabilities": list(dict.fromkeys(required_capabilities or [])),
        "shared_engine_file": shared_engine_file,
        "live_path": live_path or f"engines_live/engine_execute.py#{engine_id}",
        "adapter": "cap_execute" if kind != "live_runtime" else f"runtime:{engine_id}",
        "classification": classification,
    }
    engines.append(row)
    for pid in linked:
        reverse = list(package_by_id[pid].get("engine_ids") or [])
        if engine_id not in reverse:
            reverse.append(engine_id)
            package_by_id[pid]["engine_ids"] = reverse

    data["engines"] = sorted(engines, key=lambda e: str(e.get("engine_id") or ""))
    data["capability_packages"] = sorted(packages, key=lambda p: str(p.get("package_id") or ""))
    _save(data)
    return row


def main(argv: list[str] | None = None) -> int:
    argv = list(argv or sys.argv[1:])
    if not argv or argv[0] in {"ensure", "hints"}:
        print(json.dumps(ensure_extensibility_block(), ensure_ascii=False, indent=2))
        return 0
    if argv[0] == "add":
        if len(argv) < 3:
            print("usage: add ENGINE_ID NAME [comma,separated,packages]", file=sys.stderr)
            return 2
        packages = [p.strip() for p in argv[3].split(",") if p.strip()] if len(argv) > 3 else []
        print(json.dumps(add_engine(engine_id=argv[1], name=argv[2], capability_packages=packages), ensure_ascii=False, indent=2))
        return 0
    if argv[0] == "add-capability":
        if len(argv) < 3:
            print("usage: add-capability PACKAGE_ID NAME [path] [comma,engine_ids]", file=sys.stderr)
            return 2
        path = argv[3] if len(argv) > 3 and argv[3] else None
        engine_ids = [x.strip() for x in argv[4].split(",") if x.strip()] if len(argv) > 4 else []
        print(json.dumps(add_capability(package_id=argv[1], name=argv[2], path=path, engine_ids=engine_ids), ensure_ascii=False, indent=2))
        return 0
    if argv[0] == "link":
        if len(argv) < 3:
            print("usage: link PACKAGE_ID ENGINE_ID", file=sys.stderr)
            return 2
        print(json.dumps(link_capability_to_engine(argv[1], argv[2]), ensure_ascii=False, indent=2))
        return 0
    print("usage: hints | add ENGINE_ID NAME [packages] | add-capability PACKAGE_ID NAME [path] [engines] | link PACKAGE_ID ENGINE_ID", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
