"""Shadow Production Admission v2 evaluator.

This module is intentionally non-authorizing.  It models the target admission
contract without changing the canonical v1 authority in afaq_registry.admission.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from .loader import load_declarations
from .proof import get_engine_proof_status, latest_manifest_path

ROOT = Path(__file__).resolve().parents[1]
POLICY_PATH = ROOT / "afaq_registry" / "declarations" / "admission-policy-v2.json"
LIFECYCLE_PATH = ROOT / "afaq_registry" / "declarations" / "engine-production-lifecycle.json"
RELEASE_PATH = ROOT / "var" / "release-candidates" / "latest.json"

EVIDENCE_LEVELS = ("E0", "E1", "E2", "E3", "E4", "E5")
LIFECYCLE_STATES = (
    "DECLARED",
    "IMPLEMENTED",
    "VERIFIED",
    "QUALIFIED",
    "PRODUCTION_ELIGIBLE",
    "CANARY_ACTIVE",
    "PRODUCTION_ACTIVE",
    "RETIRED",
)
COMMIT_RE = re.compile(r"^[0-9a-f]{40}$")
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


@dataclass(frozen=True)
class ShadowDecision:
    environment: str
    decision: str
    reasons: tuple[str, ...]
    scope: tuple[str, ...]
    artifact_sha256: str | None

    @property
    def admitted(self) -> bool:
        return self.decision == "ADMITTED"

    def as_dict(self) -> dict[str, Any]:
        return {
            "schema": "AFAQ_ADMISSION_V2_SHADOW_DECISION_V1",
            "authority": "SHADOW_NON_AUTHORIZING",
            "environment": self.environment,
            "decision": self.decision,
            "reasons": list(self.reasons),
            "scope": list(self.scope),
            "artifact_sha256": self.artifact_sha256,
        }


def _read_object(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"expected JSON object: {path}")
    return data


def load_policy() -> dict[str, Any]:
    data = _read_object(POLICY_PATH)
    if data.get("schema") != "AFAQ_ADMISSION_POLICY_V2":
        raise ValueError("unsupported admission v2 policy schema")
    if data.get("enforcement") != "SHADOW":
        raise ValueError("v2 foundation must remain SHADOW until explicitly promoted")
    return data


def load_lifecycle() -> dict[str, Any]:
    data = _read_object(LIFECYCLE_PATH)
    if data.get("schema") != "AFAQ_ENGINE_PRODUCTION_LIFECYCLE_V1":
        raise ValueError("unsupported engine production lifecycle schema")
    states = tuple(data.get("states") or ())
    if states != LIFECYCLE_STATES:
        raise ValueError("lifecycle states do not match canonical ordering")
    if data.get("default_state") != "DECLARED":
        raise ValueError("default lifecycle state must be DECLARED")
    if not isinstance(data.get("engines"), dict):
        raise ValueError("lifecycle engines must be an object")
    return data


def _evidence_level(engine_id: str) -> str:
    path = latest_manifest_path(engine_id)
    if not path.exists():
        return "E0"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return "E0"
    value = str(data.get("evidence_level") or "E0")
    return value if value in EVIDENCE_LEVELS else "E0"


def _current_source_commit() -> str | None:
    env_sha = (os.getenv("GITHUB_SHA") or "").strip().lower()
    if COMMIT_RE.fullmatch(env_sha):
        return env_sha
    try:
        value = subprocess.check_output(
            ["git", "rev-parse", "HEAD"],
            cwd=ROOT,
            text=True,
            stderr=subprocess.DEVNULL,
            timeout=10,
        ).strip().lower()
    except (OSError, subprocess.SubprocessError):
        return None
    return value if COMMIT_RE.fullmatch(value) else None


def _release_identity(environment: str) -> tuple[str | None, list[str]]:
    if not RELEASE_PATH.exists():
        return None, ["RELEASE_CANDIDATE_MISSING"]
    try:
        data = _read_object(RELEASE_PATH)
    except (OSError, json.JSONDecodeError, ValueError):
        return None, ["RELEASE_CANDIDATE_INVALID"]

    reasons: list[str] = []
    allowed_release_keys = {
        "schema",
        "source_commit",
        "artifact_sha256",
        "created_at",
        "promotion",
    }
    if set(data) != allowed_release_keys:
        reasons.append("RELEASE_FIELDS_INVALID")
    if data.get("schema") != "AFAQ_RELEASE_CANDIDATE_V1":
        reasons.append("RELEASE_SCHEMA_INVALID")

    created_at = str(data.get("created_at") or "")
    try:
        parsed_created_at = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
        if parsed_created_at.tzinfo is None:
            raise ValueError("timezone required")
    except ValueError:
        reasons.append("RELEASE_CREATED_AT_INVALID")

    source_commit = str(data.get("source_commit") or "")
    digest = str(data.get("artifact_sha256") or "")
    if not COMMIT_RE.fullmatch(source_commit):
        reasons.append("RELEASE_SOURCE_COMMIT_INVALID")
    else:
        current_source_commit = _current_source_commit()
        if current_source_commit is None:
            reasons.append("CURRENT_SOURCE_COMMIT_UNAVAILABLE")
        elif source_commit != current_source_commit:
            reasons.append(
                f"RELEASE_SOURCE_COMMIT_MISMATCH:{source_commit}:{current_source_commit}"
            )
    if not SHA256_RE.fullmatch(digest):
        reasons.append("RELEASE_ARTIFACT_DIGEST_INVALID")

    promotion = data.get("promotion") or {}
    if not isinstance(promotion, dict):
        reasons.append("RELEASE_PROMOTION_INVALID")
    else:
        if not set(promotion).issubset(
            {"staging_artifact_sha256", "canary_artifact_sha256"}
        ):
            reasons.append("RELEASE_PROMOTION_FIELDS_INVALID")
        required_promotion_fields = ["staging_artifact_sha256"]
        if environment == "production":
            required_promotion_fields.append("canary_artifact_sha256")

        for name in required_promotion_fields:
            value = str(promotion.get(name) or "")
            if not SHA256_RE.fullmatch(value):
                reasons.append(f"PROMOTION_DIGEST_MISSING_OR_INVALID:{name}")
            elif SHA256_RE.fullmatch(digest) and value != digest:
                reasons.append(f"ARTIFACT_DIGEST_CHANGED_DURING_PROMOTION:{name}")

        for name in ("staging_artifact_sha256", "canary_artifact_sha256"):
            if name in required_promotion_fields or promotion.get(name) is None:
                continue
            value = str(promotion.get(name) or "")
            if not SHA256_RE.fullmatch(value):
                reasons.append(f"PROMOTION_DIGEST_INVALID:{name}")
            elif SHA256_RE.fullmatch(digest) and value != digest:
                reasons.append(f"ARTIFACT_DIGEST_CHANGED_DURING_PROMOTION:{name}")

    return (digest if SHA256_RE.fullmatch(digest) else None), reasons


def _state_at_least(actual: str, minimum: str) -> bool:
    if actual == "RETIRED" or actual not in LIFECYCLE_STATES:
        return False
    return LIFECYCLE_STATES.index(actual) >= LIFECYCLE_STATES.index(minimum)


def _scope_from_roots(
    roots: list[str],
    lifecycle_entries: dict[str, Any],
    declared_ids: set[str],
) -> tuple[list[str], list[str]]:
    reasons: list[str] = []
    seen: set[str] = set()
    pending = list(roots)

    while pending:
        engine_id = pending.pop()
        if engine_id in seen:
            continue
        seen.add(engine_id)
        if engine_id not in declared_ids:
            reasons.append(f"UNKNOWN_ENGINE:{engine_id}")
            continue
        entry = lifecycle_entries.get(engine_id) or {}
        dependencies = entry.get("dependencies") or []
        if not isinstance(dependencies, list):
            reasons.append(f"DEPENDENCIES_INVALID:{engine_id}")
            continue
        for dependency in dependencies:
            dependency_id = str(dependency or "")
            if not dependency_id:
                reasons.append(f"DEPENDENCY_ID_INVALID:{engine_id}")
                continue
            if dependency_id not in lifecycle_entries:
                reasons.append(f"DEPENDENCY_LIFECYCLE_MISSING:{engine_id}:{dependency_id}")
            pending.append(dependency_id)

    return sorted(seen), reasons


def evaluate(environment: str) -> ShadowDecision:
    policy = load_policy()
    lifecycle = load_lifecycle()
    env = (policy.get("environments") or {}).get(environment)
    if not isinstance(env, dict):
        raise ValueError(f"unknown v2 environment: {environment}")

    declarations = {
        str(row.get("engine_id")): row
        for row in load_declarations().get("engines") or []
        if isinstance(row, dict) and row.get("engine_id")
    }
    entries = lifecycle["engines"]

    reasons: list[str] = []
    for engine_id, entry in entries.items():
        if engine_id not in declarations:
            reasons.append(f"LIFECYCLE_UNKNOWN_ENGINE:{engine_id}")
        if not isinstance(entry, dict):
            reasons.append(f"LIFECYCLE_ENTRY_INVALID:{engine_id}")
            continue
        state = str(entry.get("state") or lifecycle["default_state"])
        if state not in LIFECYCLE_STATES:
            reasons.append(f"LIFECYCLE_STATE_INVALID:{engine_id}:{state}")

    root_states = set(env.get("root_engine_states") or [])
    roots = sorted(
        engine_id
        for engine_id, entry in entries.items()
        if isinstance(entry, dict)
        and str(entry.get("state") or lifecycle["default_state"]) in root_states
    )
    if not roots:
        reasons.append("NO_PRODUCTION_ROOTS")

    scope, graph_reasons = _scope_from_roots(roots, entries, set(declarations))
    reasons.extend(graph_reasons)

    required_proof = str(env.get("required_proof_state") or "PROVEN")
    minimum_evidence = str(env.get("minimum_evidence_level") or "E0")
    minimum_dependency_state = str(
        env.get("minimum_dependency_state") or "PRODUCTION_ELIGIBLE"
    )
    if minimum_evidence not in EVIDENCE_LEVELS:
        raise ValueError("invalid minimum evidence level")
    if minimum_dependency_state not in LIFECYCLE_STATES:
        raise ValueError("invalid minimum dependency lifecycle state")

    root_set = set(roots)
    for engine_id in scope:
        declaration = declarations.get(engine_id)
        if declaration is None:
            continue
        entry = entries.get(engine_id) or {}
        state = str(entry.get("state") or lifecycle["default_state"])

        if engine_id not in root_set and not _state_at_least(
            state, minimum_dependency_state
        ):
            reasons.append(
                f"DEPENDENCY_STATE_BELOW_{minimum_dependency_state}:{engine_id}:{state}"
            )

        proof = get_engine_proof_status(declaration)
        if proof.state != required_proof:
            reasons.append(
                f"PROOF_NOT_{required_proof}:{engine_id}:{proof.state}"
            )

        level = _evidence_level(engine_id)
        if EVIDENCE_LEVELS.index(level) < EVIDENCE_LEVELS.index(minimum_evidence):
            reasons.append(
                f"EVIDENCE_BELOW_{minimum_evidence}:{engine_id}:{level}"
            )

    artifact_sha256, release_reasons = _release_identity(environment)
    reasons.extend(release_reasons)

    return ShadowDecision(
        environment=environment,
        decision="ADMITTED" if not reasons else "BLOCKED",
        reasons=tuple(reasons),
        scope=tuple(scope),
        artifact_sha256=artifact_sha256,
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--environment",
        choices=("production_canary", "production"),
        default="production",
    )
    parser.add_argument("--report-only", action="store_true")
    parser.add_argument(
        "--output",
        default="var/admission-v2/shadow-decision.json",
    )
    args = parser.parse_args()

    decision = evaluate(args.environment)
    out = ROOT / args.output
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(decision.as_dict(), ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(decision.as_dict(), ensure_ascii=False, indent=2))
    if args.report_only:
        return 0
    return 0 if decision.admitted else 1


if __name__ == "__main__":
    raise SystemExit(main())
