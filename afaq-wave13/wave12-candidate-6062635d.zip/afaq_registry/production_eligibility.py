"""Production eligibility preflight.

This gate never promotes lifecycle state. It evaluates whether QUALIFIED engines
have the minimum preconditions to be considered for PRODUCTION_ELIGIBLE.
Production/canary admission remains governed by admission_v2.
"""
from __future__ import annotations

import argparse
import json
import re
import hashlib
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .loader import load_declarations
from .proof import get_engine_proof_status, latest_manifest_path

ROOT = Path(__file__).resolve().parents[1]
LIFECYCLE_PATH = ROOT / "afaq_registry" / "declarations" / "engine-production-lifecycle.json"
RELEASE_PATH = ROOT / "var" / "release-candidates" / "latest.json"
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
COMMIT_RE = re.compile(r"^[0-9a-f]{40}$")


@dataclass(frozen=True)
class EligibilityDecision:
    engine_id: str
    decision: str
    reasons: tuple[str, ...]

    @property
    def eligible(self) -> bool:
        return self.decision == "PRODUCTION_ELIGIBLE_CANDIDATE"

    def as_dict(self) -> dict[str, Any]:
        return {
            "engine_id": self.engine_id,
            "decision": self.decision,
            "reasons": list(self.reasons),
        }


def _read_object(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"expected object: {path}")
    return data


def _current_commit() -> str | None:
    try:
        value = subprocess.check_output(
            ["git", "rev-parse", "HEAD"],
            cwd=ROOT,
            text=True,
            timeout=10,
            stderr=subprocess.DEVNULL,
        ).strip().lower()
    except (OSError, subprocess.SubprocessError):
        return None
    return value if COMMIT_RE.fullmatch(value) else None


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _release_reasons(path: Path) -> list[str]:
    if not path.exists():
        return ["RELEASE_CANDIDATE_MISSING"]
    try:
        data = _read_object(path)
    except (OSError, json.JSONDecodeError, ValueError):
        return ["RELEASE_CANDIDATE_INVALID"]

    reasons: list[str] = []
    if data.get("schema") != "AFAQ_RELEASE_CANDIDATE_V1":
        reasons.append("RELEASE_SCHEMA_INVALID")

    source_commit = str(data.get("source_commit") or "")
    current = _current_commit()
    if not COMMIT_RE.fullmatch(source_commit):
        reasons.append("RELEASE_SOURCE_COMMIT_INVALID")
    elif current is None:
        reasons.append("CURRENT_SOURCE_COMMIT_UNAVAILABLE")
    elif source_commit != current:
        reasons.append(f"RELEASE_SOURCE_COMMIT_MISMATCH:{source_commit}:{current}")

    digest = str(data.get("artifact_sha256") or "")
    if not SHA256_RE.fullmatch(digest):
        reasons.append("RELEASE_ARTIFACT_DIGEST_INVALID")

    evidence_path = path.parent / "runtime-release-evidence.json"
    if not evidence_path.exists():
        reasons.append("RELEASE_EVIDENCE_MISSING")
    else:
        try:
            evidence = _read_object(evidence_path)
        except (OSError, json.JSONDecodeError, ValueError):
            reasons.append("RELEASE_EVIDENCE_INVALID")
        else:
            if evidence.get("schema") != "AFAQ_RUNTIME_RELEASE_EVIDENCE_V1":
                reasons.append("RELEASE_EVIDENCE_SCHEMA_INVALID")
            if str(evidence.get("source_commit") or "") != source_commit:
                reasons.append("RELEASE_EVIDENCE_SOURCE_COMMIT_MISMATCH")
            if str(evidence.get("artifact_sha256") or "") != digest:
                reasons.append("RELEASE_EVIDENCE_ARTIFACT_DIGEST_MISMATCH")
            artifact_name = str(evidence.get("artifact") or "")
            if not artifact_name or Path(artifact_name).name != artifact_name:
                reasons.append("RELEASE_ARTIFACT_NAME_INVALID")
            else:
                artifact_path = path.parent / artifact_name
                if not artifact_path.is_file():
                    reasons.append("RELEASE_ARTIFACT_MISSING")
                elif SHA256_RE.fullmatch(digest) and _sha256_file(artifact_path) != digest:
                    reasons.append("RELEASE_ARTIFACT_DIGEST_MISMATCH")
            if evidence.get("file_sbom_complete") is not True:
                reasons.append("FILE_SBOM_INCOMPLETE")
            if evidence.get("dependency_sbom_complete") is not True:
                reasons.append("DEPENDENCY_SBOM_INCOMPLETE")
            if str(evidence.get("dependency_security_review_state") or "") != "PASS":
                reasons.append("DEPENDENCY_SECURITY_REVIEW_MISSING")
            if str(evidence.get("artifact_attestation_state") or "") != "VERIFIED":
                reasons.append("ARTIFACT_ATTESTATION_MISSING")

    promotion = data.get("promotion")
    if not isinstance(promotion, dict):
        reasons.append("RELEASE_PROMOTION_INVALID")
    else:
        staging = str(promotion.get("staging_artifact_sha256") or "")
        if not SHA256_RE.fullmatch(staging):
            reasons.append("STAGING_ARTIFACT_DIGEST_MISSING_OR_INVALID")
        elif SHA256_RE.fullmatch(digest) and staging != digest:
            reasons.append("STAGING_ARTIFACT_DIGEST_MISMATCH")

    return reasons


def evaluate(engine_id: str, *, release_path: Path = RELEASE_PATH) -> EligibilityDecision:
    declarations = {
        str(row.get("engine_id")): row
        for row in load_declarations().get("engines") or []
        if isinstance(row, dict) and row.get("engine_id")
    }
    lifecycle = _read_object(LIFECYCLE_PATH)
    entry = (lifecycle.get("engines") or {}).get(engine_id) or {}
    reasons: list[str] = []

    if engine_id not in declarations:
        reasons.append("ENGINE_NOT_DECLARED")
        return EligibilityDecision(engine_id, "BLOCKED", tuple(reasons))

    state = str(entry.get("state") or lifecycle.get("default_state") or "DECLARED")
    if state != "QUALIFIED":
        reasons.append(f"LIFECYCLE_NOT_QUALIFIED:{state}")

    review_ref = entry.get("dependency_review") or {}
    closure_state = str(review_ref.get("closure_state") or "")
    if closure_state != "CLOSED":
        reasons.append(f"DEPENDENCY_REVIEW_NOT_CLOSED:{closure_state or 'MISSING'}")

    if "dependencies" not in entry:
        reasons.append("EXPLICIT_DEPENDENCY_REVIEW_MISSING")
    elif not isinstance(entry.get("dependencies"), list):
        reasons.append("DEPENDENCIES_INVALID")
    else:
        for dependency in entry.get("dependencies") or []:
            dep = str(dependency or "")
            if not dep:
                reasons.append("DEPENDENCY_ID_INVALID")
                continue
            if dep not in (lifecycle.get("engines") or {}):
                reasons.append(f"DEPENDENCY_LIFECYCLE_MISSING:{dep}")

    proof = get_engine_proof_status(declarations[engine_id])
    if proof.state != "PROVEN":
        reasons.append(f"PROOF_NOT_PROVEN:{proof.state}")

    manifest_path = latest_manifest_path(engine_id)
    if not manifest_path.exists():
        reasons.append("EVIDENCE_MANIFEST_MISSING")
    else:
        try:
            manifest = _read_object(manifest_path)
        except (OSError, json.JSONDecodeError, ValueError):
            reasons.append("EVIDENCE_MANIFEST_INVALID")
        else:
            if manifest.get("result") != "PASS":
                reasons.append("EVIDENCE_RESULT_NOT_PASS")
            if str(manifest.get("evidence_level") or "") != "E4":
                reasons.append(
                    f"EVIDENCE_NOT_E4:{manifest.get('evidence_level') or 'UNKNOWN'}"
                )

    reasons.extend(_release_reasons(release_path))
    return EligibilityDecision(
        engine_id=engine_id,
        decision="PRODUCTION_ELIGIBLE_CANDIDATE" if not reasons else "BLOCKED",
        reasons=tuple(dict.fromkeys(reasons)),
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--engine", action="append", dest="engines")
    parser.add_argument("--release", type=Path, default=RELEASE_PATH)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--report-only", action="store_true")
    args = parser.parse_args()

    lifecycle = _read_object(LIFECYCLE_PATH)
    engines = args.engines or sorted(
        engine_id
        for engine_id, entry in (lifecycle.get("engines") or {}).items()
        if isinstance(entry, dict) and entry.get("state") == "QUALIFIED"
    )
    decisions = [evaluate(engine_id, release_path=args.release) for engine_id in engines]
    report = {
        "schema": "AFAQ_PRODUCTION_ELIGIBILITY_PREFLIGHT_V1",
        "authority": "NON_PROMOTING_PREFLIGHT",
        "summary": {
            "total": len(decisions),
            "eligible_candidates": sum(row.eligible for row in decisions),
            "blocked": sum(not row.eligible for row in decisions),
        },
        "decisions": [row.as_dict() for row in decisions],
    }
    rendered = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        out = args.output if args.output.is_absolute() else ROOT / args.output
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(rendered, encoding="utf-8")
    print(rendered, end="")
    return 0 if args.report_only or all(row.eligible for row in decisions) else 1


if __name__ == "__main__":
    raise SystemExit(main())
