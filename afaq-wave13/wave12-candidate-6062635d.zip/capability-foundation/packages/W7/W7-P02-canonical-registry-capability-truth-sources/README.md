# W7-P02 — Canonical Registry + Capability Truth Sources

Specification-only foundation descriptor derived from the canonical Epoch 2 W7 definition. No runtime implementation is claimed.
