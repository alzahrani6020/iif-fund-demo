# W7-P04 — Capability State Machine

Specification-only foundation descriptor derived from the canonical Epoch 2 W7 definition. No runtime implementation is claimed.
