# W7-P01 — Architecture Epoch + Master Map + Clean Build Constitution

Specification-only foundation descriptor derived from the canonical Epoch 2 W7 definition. No runtime implementation is claimed.
