# W7-P20 — JobStore Contract + Lease + Idempotency + Resume

Specification-only foundation descriptor derived from the canonical Epoch 2 W7 definition. No runtime implementation is claimed.
