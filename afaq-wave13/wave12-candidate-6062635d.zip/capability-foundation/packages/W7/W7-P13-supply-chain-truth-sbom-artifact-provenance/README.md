# W7-P13 — Supply-Chain Truth + SBOM + Artifact Provenance

Specification-only foundation descriptor derived from the canonical Epoch 2 W7 definition. No runtime implementation is claimed.
