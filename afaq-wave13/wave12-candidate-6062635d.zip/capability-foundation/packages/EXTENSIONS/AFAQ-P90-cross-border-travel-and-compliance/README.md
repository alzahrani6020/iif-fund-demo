# AFAQ-P90 — Cross-Border Travel & Compliance

Status: SPECIFIED / NOT IMPLEMENTED / NOT OPERATIONALLY PROVEN

Passport/document requirements, visa/immigration, entry requirements, customs, sanctions/trade compliance, dangerous-goods policy and cross-border evidence orchestration.

## Shared-capability rule

This package CONSUMES but does not own generic payments, identity, browser/web, notifications, maps/geospatial, translation, document verification, evidence, or sanctions-screening foundations.

## Transaction rule

SEARCH != QUOTE != HOLD != RESERVATION != BOOKING != PAYMENT != FULFILLMENT.

## Freshness rule

Volatile offers, availability, eligibility, ETA, weather, FX, and regulatory observations require explicit observed_at / valid_until / revalidation semantics.
