# AFAQ-P88 — Mobility & Ground Transport

Status: SPECIFIED / NOT IMPLEMENTED / NOT OPERATIONALLY PROVEN

Ground transport, rail/bus/transit, ride hailing, rental, parking, EV/fuel and dispatch orchestration; consumes geospatial and payment capabilities.

## Shared-capability rule

This package CONSUMES but does not own generic payments, identity, browser/web, notifications, maps/geospatial, translation, document verification, evidence, or sanctions-screening foundations.

## Transaction rule

SEARCH != QUOTE != HOLD != RESERVATION != BOOKING != PAYMENT != FULFILLMENT.

## Freshness rule

Volatile offers, availability, eligibility, ETA, weather, FX, and regulatory observations require explicit observed_at / valid_until / revalidation semantics.
