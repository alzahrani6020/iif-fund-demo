# AFAQ-P86 — Travel Discovery & Itinerary

Status: SPECIFIED / NOT IMPLEMENTED / NOT OPERATIONALLY PROVEN

Travel discovery, itinerary assembly, flight/accommodation/activity search orchestration without owning shared payment, identity, maps, translation, notification, or evidence engines.

## Shared-capability rule

This package CONSUMES but does not own generic payments, identity, browser/web, notifications, maps/geospatial, translation, document verification, evidence, or sanctions-screening foundations.

## Transaction rule

SEARCH != QUOTE != HOLD != RESERVATION != BOOKING != PAYMENT != FULFILLMENT.

## Freshness rule

Volatile offers, availability, eligibility, ETA, weather, FX, and regulatory observations require explicit observed_at / valid_until / revalidation semantics.
