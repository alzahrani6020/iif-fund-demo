# AFAQ-P89 — Aviation & Airport Operations

Status: SPECIFIED / NOT IMPLEMENTED / NOT OPERATIONALLY PROVEN

Airport operations, check-in/boarding, baggage, wayfinding, lounge/access and lost-and-found domain capability ownership without duplicating identity, geospatial or payment engines.

## Shared-capability rule

This package CONSUMES but does not own generic payments, identity, browser/web, notifications, maps/geospatial, translation, document verification, evidence, or sanctions-screening foundations.

## Transaction rule

SEARCH != QUOTE != HOLD != RESERVATION != BOOKING != PAYMENT != FULFILLMENT.

## Freshness rule

Volatile offers, availability, eligibility, ETA, weather, FX, and regulatory observations require explicit observed_at / valid_until / revalidation semantics.
