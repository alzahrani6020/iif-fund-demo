# AFAQ-P97 — Strategic Sourcing & Supplier Intelligence

Status: SPECIFIED / DESIGN ONLY. Runtime implementation: NONE.

Canonical owner for multi-market sourcing, manufacturer/distributor resolution, supplier qualification, sourcing mix and disruption resilience.

This package consumes canonical shared capabilities rather than copying their runtime implementations.
