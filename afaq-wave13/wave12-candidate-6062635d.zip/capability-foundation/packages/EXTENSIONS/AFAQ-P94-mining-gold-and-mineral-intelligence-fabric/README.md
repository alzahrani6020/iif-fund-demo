# AFAQ-P94 — Mining, Gold & Mineral Intelligence Fabric

Status: SPECIFIED / DESIGN-CONTRACT REQUIREMENT.

Runtime implementation: NONE.
Implementation authority: NONE.

This package was added after duplicate/ownership review. Generic identity, evidence, provenance, metrology, comparison, privacy, notification, provider-selection, and authority mechanisms remain shared and are not duplicated here.
