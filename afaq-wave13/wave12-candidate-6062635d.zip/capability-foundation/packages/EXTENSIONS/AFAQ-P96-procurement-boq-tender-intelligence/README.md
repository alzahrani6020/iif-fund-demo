# AFAQ-P96 — Procurement / BOQ / Tender Intelligence

Status: SPECIFIED / DESIGN ONLY. Runtime implementation: NONE.

Canonical owner for requirement/BOQ interpretation, tender technical compliance, deviation matrices, commercial observations and procurement decision evidence.

This package consumes canonical shared capabilities rather than copying their runtime implementations.
