# AFAQ-P84 — Health & Care Services

Status: SPECIFIED / DESIGN-CONTRACT REQUIREMENT.

Runtime implementation: NONE.
Implementation authority: NONE.

This extension preserves existing packages and adds a distinct canonical ownership boundary for capabilities that were not cleanly owned in V5.
