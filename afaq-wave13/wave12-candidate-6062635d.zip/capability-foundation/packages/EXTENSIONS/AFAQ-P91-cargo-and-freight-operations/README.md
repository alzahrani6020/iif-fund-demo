# AFAQ-P91 — Cargo & Freight Operations

Status: SPECIFIED / NOT IMPLEMENTED / NOT OPERATIONALLY PROVEN

Air cargo/freight, AWB, rates/schedules, tracking, customs brokerage, shipment insurance and proof-of-delivery orchestration; consumes logistics/maps/payments/evidence.

## Shared-capability rule

This package CONSUMES but does not own generic payments, identity, browser/web, notifications, maps/geospatial, translation, document verification, evidence, or sanctions-screening foundations.

## Transaction rule

SEARCH != QUOTE != HOLD != RESERVATION != BOOKING != PAYMENT != FULFILLMENT.

## Freshness rule

Volatile offers, availability, eligibility, ETA, weather, FX, and regulatory observations require explicit observed_at / valid_until / revalidation semantics.
