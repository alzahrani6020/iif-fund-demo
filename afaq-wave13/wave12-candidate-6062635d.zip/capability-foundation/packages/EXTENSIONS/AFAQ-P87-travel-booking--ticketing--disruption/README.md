# AFAQ-P87 — Travel Booking / Ticketing / Disruption

Status: SPECIFIED / NOT IMPLEMENTED / NOT OPERATIONALLY PROVEN

Transactional travel lifecycle for quote/hold/reservation/booking/payment/ticketing/fulfillment, disruption, reaccommodation, repatriation, insurance and loyalty orchestration; consumes shared money/authority/evidence.

## Shared-capability rule

This package CONSUMES but does not own generic payments, identity, browser/web, notifications, maps/geospatial, translation, document verification, evidence, or sanctions-screening foundations.

## Transaction rule

SEARCH != QUOTE != HOLD != RESERVATION != BOOKING != PAYMENT != FULFILLMENT.

## Freshness rule

Volatile offers, availability, eligibility, ETA, weather, FX, and regulatory observations require explicit observed_at / valid_until / revalidation semantics.
