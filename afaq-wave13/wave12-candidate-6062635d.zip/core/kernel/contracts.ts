/**
 * Shared kernel contracts used across runtime modules.
 */

import type { KernelEntity, KernelResult } from './types.js';

export interface Repository<T extends KernelEntity> {
  findById(id: string): Promise<T | null>;
  save(entity: T): Promise<KernelResult<T>>;
}

export interface Handler<P, R> {
  handle(payload: P): Promise<KernelResult<R>>;
}

export interface Guard<P> {
  evaluate(payload: P): Promise<boolean>;
}
