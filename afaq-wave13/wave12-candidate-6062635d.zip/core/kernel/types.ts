/**
 * Shared kernel primitive types.
 * These are cross-cutting contracts used by runtime modules.
 */

export interface KernelEntity {
  id: string;
  createdAt: string;
  updatedAt: string;
}

export interface KernelResult<T = unknown> {
  ok: boolean;
  data?: T;
  error?: KernelError;
}

export interface KernelError {
  code: string;
  message: string;
  details?: Record<string, unknown>;
}
