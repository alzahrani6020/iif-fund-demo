"""Historical GOV-DEC access is audit/provenance only.

resolve() must never import this module's file readers. Operational
resolution has no historical fallback.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

HISTORICAL_DECISIONS_RELATIVE = "project-records/governance/decisions"
AUDIT_ONLY_TAG = "HISTORICAL_PROVENANCE_AUDIT_ONLY"


class HistoryIsolationError(RuntimeError):
    pass


def operational_lookup_forbidden(*_args: Any, **_kwargs: Any) -> None:
    raise HistoryIsolationError(
        "historical governance has zero operational authority"
    )


def read_historical_for_audit(
    repo_root: str | Path,
    relative_path: str,
) -> dict[str, Any]:
    """Read a historical record for audit/forensics only."""
    root = Path(repo_root)
    rel = relative_path.replace("\\", "/")
    if not rel.startswith(HISTORICAL_DECISIONS_RELATIVE):
        raise HistoryIsolationError("audit reader is limited to historical decision paths")
    path = (root / rel).resolve()
    try:
        path.relative_to((root / HISTORICAL_DECISIONS_RELATIVE).resolve())
    except ValueError as exc:
        raise HistoryIsolationError("path escapes historical decision tree") from exc
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise HistoryIsolationError("historical record is not an object")
    tagged = dict(payload)
    tagged["_record_class"] = AUDIT_ONLY_TAG
    tagged["_operational_authority"] = 0
    return tagged
