"""Verified runtime capability status.

TARGET_ARCHITECTURE != CURRENT_IMPLEMENTED_CAPABILITY.
Design-only Foundation contracts are never claimed as operational.
"""

from __future__ import annotations

from pathlib import Path
from typing import Final

IMPLEMENTED_AND_VERIFIED = "IMPLEMENTED_AND_VERIFIED"
IMPLEMENTED_NOT_VERIFIED = "IMPLEMENTED_NOT_VERIFIED"
PARTIAL = "PARTIAL"
DESIGN_ONLY = "DESIGN_ONLY"
ABSENT = "ABSENT"

# Evidence paths are live source or live tests. project-records maps are
# architecture contracts, not runtime proof.
AUTONOMY_CYCLE: Final[dict[str, dict[str, object]]] = {
    "UNDERSTAND": {
        "status": IMPLEMENTED_AND_VERIFIED,
        "evidence": (
            "afaq_agent_runtime/governed_core.py",
            "afaq_agent_runtime/repository_mapper.py",
            "afaq_agent_runtime/tests/test_governed_core.py",
        ),
    },
    "MODEL_DECOMPOSE": {
        "status": PARTIAL,
        "evidence": (
            "afaq_agent_runtime/developer_agent.py",
            "afaq_agent_runtime/writing_engine.py",
        ),
        "note": "Domain/task classification exists; no general capability decomposer.",
    },
    "DERIVE_REQUIRED_CAPABILITIES": {
        "status": IMPLEMENTED_AND_VERIFIED,
        "evidence": (
            "capability_cycle/planner.py",
            "capability_cycle/tests/test_planner.py",
        ),
        "note": "Derives only IDs present in the live canonical capability catalog.",
    },
    "RESOLVE_EXISTING_CAPABILITIES": {
        "status": IMPLEMENTED_AND_VERIFIED,
        "evidence": (
            "afaq_intelligence_core/package_intelligence/canonical_resolver.py",
            "afaq_intelligence_core/tests/package_intelligence/test_canonical_resolver.py",
            "capability_cycle/planner.py",
        ),
        "note": "Uses CanonicalReferenceResolver; UNKNOWN is fail-closed, not genesis.",
    },
    "COMPOSE": {
        "status": IMPLEMENTED_AND_VERIFIED,
        "evidence": (
            "capability_cycle/planner.py",
            "capability_cycle/tests/test_planner.py",
        ),
        "note": "Composes an existing-capability plan only; does not execute or genesis.",
    },
    "LOAD_ATTACH": {
        "status": PARTIAL,
        "evidence": (
            "afaq_agent_runtime/model_registry.py",
            "capability_cycle/handlers.py",
        ),
        "note": "Handler attach exists for registered capabilities only.",
    },
    "ACQUIRE_GENESIS": {
        "status": DESIGN_ONLY,
        "evidence": (
            "project-records/architecture/v1/AUTHORITY_MODEL.json",
            "capability_cycle/runtime.py",
        ),
        "note": "Genesis remains design-only; descriptor creation is not genesis.",
    },
    "COMPILE_EXECUTION": {
        "status": IMPLEMENTED_AND_VERIFIED,
        "evidence": (
            "afaq_agent_runtime/developer_agent.py",
            "afaq_agent_runtime/permissions.py",
        ),
    },
    "EXECUTE": {
        "status": IMPLEMENTED_AND_VERIFIED,
        "evidence": (
            "afaq_agent_runtime/runtime_server.py",
            "afaq_agent_runtime/command_allowlist.py",
            "afaq_agent_runtime/tests/test_command_allowlist.py",
            "afaq_agent_runtime/orchestrator.py",
            "afaq_agent_runtime/tests/test_orchestrator.py",
        ),
    },
    "OBSERVE": {
        "status": IMPLEMENTED_AND_VERIFIED,
        "evidence": (
            "afaq_agent_runtime/audit_ledger.py",
            "afaq_agent_runtime/developer_agent.py",
        ),
    },
    "REPLAN": {
        "status": IMPLEMENTED_AND_VERIFIED,
        "evidence": (
            "capability_cycle/runtime.py",
            "capability_cycle/tests/test_phase04b_replan.py",
        ),
        "note": "Bounded existing-capability replan; host developer_agent loop remains separate. Not genesis.",
    },
    "VERIFY": {
        "status": IMPLEMENTED_AND_VERIFIED,
        "evidence": (
            "afaq_agent_runtime/decision_analysis.py",
            "scripts/architecture-check.mjs",
        ),
    },
    "RECORD_PERFORMANCE": {
        "status": IMPLEMENTED_AND_VERIFIED,
        "evidence": (
            "capability_cycle/runtime.py",
            "capability_cycle/performance_store.py",
            "capability_cycle/telemetry.py",
            "capability_cycle/tests/test_phase06_performance.py",
        ),
        "note": "Persisted performance evidence is inert; learning/training/promotion remain inactive.",
    },
    "LEARN_IMPROVE": {
        "status": DESIGN_ONLY,
        "evidence": (
            "afaq_agent_runtime/writing_engine.py",
            "owner-packages/WAVE_07_PACKAGE_01/src/governance_foundation.py",
        ),
        "note": "Domain script improve plus work-item design flags; no verified self-training runtime.",
    },
}

DESIGN_ONLY_CAPABILITIES: Final[tuple[str, ...]] = tuple(
    name
    for name, meta in AUTONOMY_CYCLE.items()
    if meta["status"] == DESIGN_ONLY
)


def classify_cycle(repo_root: str | Path | None = None) -> dict[str, str]:
    root = Path(repo_root) if repo_root else None
    out: dict[str, str] = {}
    for name, meta in AUTONOMY_CYCLE.items():
        status = str(meta["status"])
        if root is not None and status == IMPLEMENTED_AND_VERIFIED:
            missing = [
                rel
                for rel in meta["evidence"]  # type: ignore[union-attr]
                if not (root / str(rel)).exists()
            ]
            if missing:
                status = IMPLEMENTED_NOT_VERIFIED
        out[name] = status
    return out


def claim_operational(stage: str) -> bool:
    meta = AUTONOMY_CYCLE.get(stage)
    return bool(meta and meta["status"] == IMPLEMENTED_AND_VERIFIED)
