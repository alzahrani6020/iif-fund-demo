"""Current project and runtime state.

Reads live manifests and verified runtime modules. Historical GOV-DEC
READY/DEFAULT_DENY flags are not consulted.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

LIVE_PACKAGE_MANIFESTS = (
    "owner-packages/WAVE_07_PACKAGE_01_CANONICAL_W7_P01/MANIFEST.json",
    "owner-packages/WAVE_07_PACKAGE_08_CANONICAL_W7_P08/MANIFEST.json",
)

RUNTIME_TOOL_POLICY_ID = "RUNTIME_PERMISSION_MATRIX_AND_COMMAND_ALLOWLIST"
RUNTIME_PERMISSIONS = "afaq_agent_runtime/permissions.py"
RUNTIME_ALLOWLIST = "afaq_agent_runtime/command_allowlist.py"


def current_package_ready(
    repo_root: str | Path,
    package_id: str | None = None,
    *,
    historical_ready: bool | None = None,
) -> dict[str, Any]:
    del historical_ready  # historical READY must not affect current state
    root = Path(repo_root)
    packages: list[dict[str, Any]] = []
    for rel in LIVE_PACKAGE_MANIFESTS:
        path = root / rel
        if not path.is_file():
            continue
        manifest = json.loads(path.read_text(encoding="utf-8"))
        item = {
            "path": rel.replace("\\", "/"),
            "package_id": manifest.get("package_id"),
            "readiness_state": manifest.get("readiness_state"),
        }
        if package_id and item["package_id"] != package_id:
            continue
        packages.append(item)
    return {
        "source": "LIVE_PACKAGE_MANIFEST",
        "historical_ready_consulted": False,
        "packages": packages,
    }


def current_tool_policy(
    repo_root: str | Path,
    *,
    historical_default_deny: bool | None = None,
) -> dict[str, Any]:
    del historical_default_deny  # historical DEFAULT_DENY cannot override
    root = Path(repo_root)
    permissions_present = (root / RUNTIME_PERMISSIONS).is_file()
    allowlist_present = (root / RUNTIME_ALLOWLIST).is_file()
    return {
        "policy_id": RUNTIME_TOOL_POLICY_ID,
        "historical_default_deny_consulted": False,
        "runtime_permissions_present": permissions_present,
        "command_allowlist_present": allowlist_present,
        "source": "VERIFIED_RUNTIME",
    }
