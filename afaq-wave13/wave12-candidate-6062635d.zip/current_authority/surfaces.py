"""Discovered authority surfaces classified from current repository evidence."""

from __future__ import annotations

from typing import Final

AUTHORITY_SURFACES: Final[tuple[dict[str, str], ...]] = (
    {
        "path": "ARCHITECTURE_GOVERNANCE.md",
        "class": "CURRENT_ARCHITECTURE_TRUTH",
        "role": "Mandatory architectural invariants; not a GOV-DEC reader.",
    },
    {
        "path": "AGENTS.md",
        "class": "CURRENT_ARCHITECTURE_TRUTH",
        "role": "Pointer to root architecture governance.",
    },
    {
        "path": "current_authority/",
        "class": "CURRENT_OPERATIONAL_GOVERNANCE",
        "role": "Single current operational resolver.",
    },
    {
        "path": "afaq_intelligence_core/governance/policy.py",
        "class": "CURRENT_RUNTIME_TRUTH",
        "role": "PolicyEngine risk classify; does not read GOV-DECs.",
    },
    {
        "path": "afaq_agent_runtime/permissions.py",
        "class": "CURRENT_RUNTIME_TRUTH",
        "role": "Environment permission matrix for file/tool proposals.",
    },
    {
        "path": "afaq_agent_runtime/command_allowlist.py",
        "class": "CURRENT_RUNTIME_TRUTH",
        "role": "Fail-closed command allowlist.",
    },
    {
        "path": "afaq_agent_runtime/governed_core.py",
        "class": "CURRENT_RUNTIME_TRUTH",
        "role": "Bounded project agent; write path fail-closed.",
    },
    {
        "path": "afaq_agent_runtime/orchestrator.py",
        "class": "CURRENT_RUNTIME_TRUTH",
        "role": "Evidence-first orchestrator over governed core.",
    },
    {
        "path": "afaq_agent_runtime/audit_ledger.py",
        "class": "CURRENT_RUNTIME_TRUTH",
        "role": "Append-only hash-chained audit ledger.",
    },
    {
        "path": "afaq_agent_runtime/checkpoint_engine.py",
        "class": "CURRENT_RUNTIME_TRUTH",
        "role": "Checkpoint/rollback/restore.",
    },
    {
        "path": "backend/src/governance.ts",
        "class": "CURRENT_RUNTIME_TRUTH",
        "role": "Backend classification adapter; never executes APPROVAL_REQUIRED.",
    },
    {
        "path": "backend/src/authorization.ts",
        "class": "CURRENT_RUNTIME_TRUTH",
        "role": "Actor role/permission boundary.",
    },
    {
        "path": "project-records/architecture/v1/AUTHORITY_MODEL.json",
        "class": "CURRENT_ARCHITECTURE_TRUTH",
        "role": "Architecture authority-class contract; not an operational resolver.",
    },
    {
        "path": "owner-packages/WAVE_07_PACKAGE_03/src/authority_model.py",
        "class": "WORK_ITEM_LOCAL",
        "role": "W7-P03 permission wrapper around runtime evaluate_proposal.",
    },
    {
        "path": "owner-packages/WAVE_07_PACKAGE_01/src/governance_foundation.py",
        "class": "WORK_ITEM_LOCAL",
        "role": "W7 package-01 foundation validator; not global authority.",
    },
    {
        "path": "owner-packages/WAVE_07_PACKAGE_04/src/capability_state_machine.py",
        "class": "WORK_ITEM_LOCAL",
        "role": "Work-item capability state transitions.",
    },
    {
        "path": "scripts/architecture-check.mjs",
        "class": "CURRENT_ARCHITECTURE_TRUTH",
        "role": "Read-only structural architecture guard.",
    },
)

HISTORICAL_AUTHORITY_SURFACES: Final[tuple[dict[str, str], ...]] = (
    {
        "path": "project-records/governance/decisions/v1/",
        "class": "HISTORICAL_PROVENANCE",
        "role": "GOV-DEC archive. Audit/provenance only after cutover.",
    },
    {
        "path": "project-records/governance/AFAQ_GOVERNANCE_ENTRY_GATE.md",
        "class": "HISTORICAL_PROVENANCE",
        "role": "Protocol text; not a live operational resolver.",
    },
    {
        "path": "project-records/governance/AFAQ_SLICE_TRANSITION_AND_CLOSURE_PROTOCOL.md",
        "class": "HISTORICAL_PROVENANCE",
        "role": "Protocol text; not a live operational resolver.",
    },
)

CURRENT_TRUTH_SOURCES: Final[tuple[str, ...]] = (
    "ARCHITECTURE_GOVERNANCE.md",
    "current_authority",
    "afaq_agent_runtime/permissions.py",
    "afaq_agent_runtime/command_allowlist.py",
    "afaq_intelligence_core/governance/policy.py",
    "live package MANIFEST.json readiness_state",
    "verified runtime tests",
)
