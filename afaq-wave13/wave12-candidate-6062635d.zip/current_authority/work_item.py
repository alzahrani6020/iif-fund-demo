"""Work-item restrictions are local and never become global governance."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class WorkItemRestriction:
    work_item_id: str
    scope_paths: tuple[str, ...]
    constraint: str
    status: str = "ACTIVE"
    claims_global: bool = False


def _path_in_scope(path: str, scope_paths: tuple[str, ...]) -> bool:
    normalized = path.replace("\\", "/").lstrip("/")
    for scope in scope_paths:
        prefix = scope.replace("\\", "/").rstrip("/")
        if normalized == prefix or normalized.startswith(prefix + "/"):
            return True
    return False


def apply_work_item_restriction(
    restriction: WorkItemRestriction,
    *,
    request_work_item_id: str | None,
    request_path: str | None,
) -> str | None:
    """Return a local constraint or None.

    COMPLETED/OBSOLETE restrictions do not apply.
    A restriction never applies outside its work-item identity and paths.
    claims_global=True is ignored for global effect.
    """
    if restriction.status in {"COMPLETED", "OBSOLETE", "SUPERSEDED"}:
        return None
    if not restriction.work_item_id:
        return None
    if request_work_item_id != restriction.work_item_id:
        return None
    if request_path and restriction.scope_paths:
        if not _path_in_scope(request_path, restriction.scope_paths):
            return None
    if restriction.claims_global and request_work_item_id != restriction.work_item_id:
        return None
    return restriction.constraint
