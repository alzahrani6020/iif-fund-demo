"""Single current operational authority resolver.

Resolution order:
  1. constitutional fail-closed checks
  2. current constitution + verified runtime capability
  3. current project state
  4. work-item local restrictions only when scoped
  5. autonomy-by-default inside the envelope

Historical records supplied to resolve() are ignored.
The resolver never reads project-records/governance/decisions/.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from .constitution import (
    AUTONOMOUS_ROUTINE_ACTIONS,
    CURRENT_UNDEFINED_FAIL_SAFE,
    LEARNING_ACTIONS,
    OWNER_RESERVED_ACTIONS,
    SYSTEM_FORBIDDEN_AUTONOMOUS_ACTIONS,
    invariant_blocks,
)
from .runtime_truth import claim_operational
from .work_item import WorkItemRestriction, apply_work_item_restriction

KNOWN_ACTIONS = (
    AUTONOMOUS_ROUTINE_ACTIONS
    | LEARNING_ACTIONS
    | OWNER_RESERVED_ACTIONS
    | SYSTEM_FORBIDDEN_AUTONOMOUS_ACTIONS
    | {
        "implement",
        "execute_tool",
        "mutate",
        "replace_capability",
        "high_risk_exception",
        "reclassify_high_risk_as_routine",
    }
)

LEARNING_STAGE = {
    "learn": "LEARN_IMPROVE",
    "self_train": "LEARN_IMPROVE",
    "self_upgrade": "LEARN_IMPROVE",
    "self_improve": "LEARN_IMPROVE",
    "capability_discover": "RESOLVE_EXISTING_CAPABILITIES",
    "capability_compose": "COMPOSE",
}


@dataclass(frozen=True)
class AuthorityRequest:
    action: str
    path: str | None = None
    work_item_id: str | None = None
    work_item_restrictions: tuple[WorkItemRestriction, ...] = ()
    historical_records: tuple[Mapping[str, Any], ...] = ()
    autonomous_change_gates: Mapping[str, bool] | None = None
    capability_implemented_and_verified: bool | None = None
    privilege_expansion: bool = False
    high_risk: bool = False
    exact_scope_defined: bool = True
    sandbox_validated: bool = True
    independent_review: bool = True
    regression_validated: bool = True
    rollback_verified: bool = True
    audit_ready: bool = True
    drift_check: bool = True
    within_constitutional_envelope: bool = True


@dataclass(frozen=True)
class Decision:
    outcome: str
    reason: str
    source: str
    historical_records_consulted: int = 0
    details: dict[str, Any] = field(default_factory=dict)


def _gates_pass(request: AuthorityRequest) -> tuple[bool, str | None]:
    if request.privilege_expansion:
        return False, "PRIVILEGE_EXPANSION_REQUIRED"
    if request.high_risk:
        return False, "HIGH_RISK_OWNER_EXCEPTION_REQUIRED"
    if not request.within_constitutional_envelope:
        return False, "CONSTITUTIONAL_BOUNDARY_REACHED"
    if not request.exact_scope_defined:
        return False, "SCOPE_EXCEEDED"
    required = {
        "sandbox_validated": request.sandbox_validated,
        "independent_review": request.independent_review,
        "regression_validated": request.regression_validated,
        "rollback_verified": request.rollback_verified,
        "audit_ready": request.audit_ready,
        "drift_check": request.drift_check,
    }
    if request.autonomous_change_gates:
        required.update({k: bool(v) for k, v in request.autonomous_change_gates.items()})
    if not all(required.values()):
        return False, "VALIDATION_FAILED"
    return True, None


def resolve(request: AuthorityRequest) -> Decision:
    # Historical material is accepted as input and discarded.
    _ignored_history = request.historical_records
    del _ignored_history

    action = (request.action or "").strip()
    if not action:
        return Decision(
            outcome="BLOCK",
            reason="CURRENT_UNDEFINED_FAIL_SAFE",
            source="CONSTITUTION",
            historical_records_consulted=0,
        )

    if action not in KNOWN_ACTIONS:
        return Decision(
            outcome="BLOCK",
            reason=CURRENT_UNDEFINED_FAIL_SAFE,
            source="CONSTITUTION",
            historical_records_consulted=0,
            details={"note": "undefined current action; history is not a fallback"},
        )

    constitution_block = invariant_blocks(action)
    if constitution_block == "IMMUTABLE_CONSTITUTION":
        return Decision(
            outcome="BLOCK",
            reason="IMMUTABLE_CONSTITUTION",
            source="CONSTITUTION",
            historical_records_consulted=0,
            details={"action": action},
        )
    if constitution_block == "OWNER_RESERVED" or action in OWNER_RESERVED_ACTIONS:
        return Decision(
            outcome="OWNER_REQUIRED",
            reason="OWNER_RESERVED",
            source="CONSTITUTION",
            historical_records_consulted=0,
            details={"action": action},
        )

    if action in LEARNING_ACTIONS:
        implemented = request.capability_implemented_and_verified
        if implemented is None:
            implemented = claim_operational(LEARNING_STAGE.get(action, "LEARN_IMPROVE"))
        if not implemented:
            return Decision(
                outcome="BLOCK",
                reason="DESIGN_ONLY_IS_NOT_OPERATIONAL",
                source="RUNTIME_TRUTH",
                historical_records_consulted=0,
            )

    if action in {"capability_discover", "capability_compose"}:
        implemented = request.capability_implemented_and_verified
        if implemented is None:
            implemented = claim_operational(LEARNING_STAGE[action])
        if not implemented:
            return Decision(
                outcome="BLOCK",
                reason="DESIGN_ONLY_IS_NOT_OPERATIONAL",
                source="RUNTIME_TRUTH",
                historical_records_consulted=0,
                details={"note": "autonomy is not a false implementation claim"},
            )

    if action == "routine_governance_change":
        ok, gate_reason = _gates_pass(request)
        if not ok:
            return Decision(
                outcome="BLOCK",
                reason=gate_reason or "VALIDATION_FAILED",
                source="AUTONOMOUS_CHANGE_GATE",
                historical_records_consulted=0,
            )

    if action in {"implement", "execute_tool", "mutate", "replace_capability"}:
        ok, gate_reason = _gates_pass(request)
        if not ok:
            return Decision(
                outcome="BLOCK",
                reason=gate_reason or "VALIDATION_FAILED",
                source="CONSTITUTION",
                historical_records_consulted=0,
            )

    if action in AUTONOMOUS_ROUTINE_ACTIONS or action in {
        "implement",
        "execute_tool",
        "mutate",
        "replace_capability",
    }:
        for restriction in request.work_item_restrictions:
            local = apply_work_item_restriction(
                restriction,
                request_work_item_id=request.work_item_id,
                request_path=request.path,
            )
            if local:
                return Decision(
                    outcome="BLOCK",
                    reason="WORK_ITEM_LOCAL_RESTRICTION",
                    source="WORK_ITEM_LOCAL",
                    historical_records_consulted=0,
                    details={"constraint": local, "work_item_id": restriction.work_item_id},
                )
        return Decision(
            outcome="ALLOW",
            reason="AUTONOMY_BY_DEFAULT_WITHIN_ENVELOPE",
            source="CURRENT_AUTHORITY",
            historical_records_consulted=0,
        )

    return Decision(
        outcome="BLOCK",
        reason=CURRENT_UNDEFINED_FAIL_SAFE,
        source="CONSTITUTION",
        historical_records_consulted=0,
    )
