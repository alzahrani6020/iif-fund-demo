"""Minimal immutable constitutional layer.

Extracted from current architecture invariants and verified runtime
safety mechanisms. Ordinary workflow rules and work-item restrictions
are not constitutional.
"""

from __future__ import annotations

from typing import Final

CONSTITUTIONAL_INVARIANTS: Final[tuple[str, ...]] = (
    "NO_UNSCOPED_MUTATION",
    "NO_SILENT_PRIVILEGE_ESCALATION",
    "FAIL_CLOSED_ON_AUTHORITY_AMBIGUITY",
    "EXACT_SCOPE_REQUIRED",
    "AUDIT_TRAIL_REQUIRED",
    "VERSIONED_STATE_REQUIRED",
    "ROLLBACK_PATH_REQUIRED",
    "SANDBOX_REQUIRED_FOR_SELF_CHANGE",
    "INDEPENDENT_VALIDATION_REQUIRED",
    "REGRESSION_VALIDATION_REQUIRED",
    "DRIFT_DETECTION_REQUIRED",
    "SEPARATION_OF_DUTIES_REQUIRED",
    "GENERATOR_MUST_NOT_SELF_APPROVE",
    "NO_SELF_PROMOTION",
    "ADMIN_DOES_NOT_BYPASS_GOVERNANCE",
    "AUTHENTICATION_IS_NOT_MUTATION_AUTHORIZATION",
    "APPROVAL_REQUIRED_IS_NOT_DIRECT_EXECUTION",
    "WORKSPACE_FILE_MUTATION_BLOCKED",
    "WORKSPACE_FS_MUTATION_BLOCKED",
    "WORKSPACE_EXECUTION_ALLOWLIST_CONTROLLED",
    "CANONICAL_RUNTIME_AUTHORITATIVE_FOR_GOVERNED_EXECUTION",
    "NO_SILENT_PROJECT_ROOT_FALLBACK",
    "NO_AUTONOMOUS_CONSTITUTIONAL_WEAKENING",
    "NO_AUTONOMOUS_PRIVILEGE_EXPANSION",
    "WORK_ITEM_LOCAL_IS_NOT_GLOBAL",
    "NO_HISTORICAL_AUTHORITY_FALLBACK",
    "DESIGN_ONLY_IS_NOT_OPERATIONAL",
)

OWNER_RESERVED_ACTIONS: Final[frozenset[str]] = frozenset(
    {
        "constitutional_change",
        "privilege_expansion",
        "high_risk_exception",
        "promote",
        "disable_audit",
        "disable_rollback",
        "disable_sandbox",
        "bypass_independent_validation",
        "expand_autonomous_authority",
    }
)

SYSTEM_FORBIDDEN_AUTONOMOUS_ACTIONS: Final[frozenset[str]] = frozenset(
    {
        "constitutional_change",
        "privilege_expansion",
        "disable_audit",
        "disable_rollback",
        "disable_sandbox",
        "bypass_independent_validation",
        "expand_autonomous_authority",
        "reclassify_high_risk_as_routine",
        "push",
        "deploy",
    }
)

AUTONOMOUS_ROUTINE_ACTIONS: Final[frozenset[str]] = frozenset(
    {
        "discover",
        "read",
        "analyze",
        "test",
        "routine_governance_change",
        "capability_discover",
        "capability_compose",
        "replan",
        "recoverable_defect_correction",
    }
)

LEARNING_ACTIONS: Final[frozenset[str]] = frozenset(
    {
        "learn",
        "self_train",
        "self_upgrade",
        "self_improve",
    }
)

CURRENT_UNDEFINED_FAIL_SAFE: Final[str] = "CURRENT_UNDEFINED_FAIL_SAFE"


def historical_governance_operational_authority() -> int:
    return 0


def invariant_blocks(action: str) -> str | None:
    if action in OWNER_RESERVED_ACTIONS:
        return "OWNER_RESERVED"
    if action in SYSTEM_FORBIDDEN_AUTONOMOUS_ACTIONS:
        return "IMMUTABLE_CONSTITUTION"
    return None
