"""Current operational authority for AFAQ-GIE.

This package is the single live operational resolver. Historical GOV-DEC
records under project-records/governance/decisions/ are audit/provenance
only and have zero operational authority.
"""

from .constitution import (
    CONSTITUTIONAL_INVARIANTS,
    OWNER_RESERVED_ACTIONS,
    SYSTEM_FORBIDDEN_AUTONOMOUS_ACTIONS,
    historical_governance_operational_authority,
)
from .history import (
    HISTORICAL_DECISIONS_RELATIVE,
    HistoryIsolationError,
    read_historical_for_audit,
)
from .project_state import current_package_ready, current_tool_policy
from .resolver import AuthorityRequest, Decision, resolve
from .runtime_truth import AUTONOMY_CYCLE, claim_operational, classify_cycle
from .work_item import WorkItemRestriction, apply_work_item_restriction

HISTORICAL_GOVERNANCE_OPERATIONAL_AUTHORITY = 0
NO_HISTORICAL_FALLBACK = True
WORK_ITEM_LOCAL_NOT_GLOBAL = True
IMMUTABLE_SAFETY_PRECEDENCE = True
AUTONOMY_BY_DEFAULT_WITHIN_ENVELOPE = True

__all__ = [
    "AUTONOMY_CYCLE",
    "AUTONOMY_BY_DEFAULT_WITHIN_ENVELOPE",
    "CONSTITUTIONAL_INVARIANTS",
    "HISTORICAL_DECISIONS_RELATIVE",
    "HISTORICAL_GOVERNANCE_OPERATIONAL_AUTHORITY",
    "IMMUTABLE_SAFETY_PRECEDENCE",
    "NO_HISTORICAL_FALLBACK",
    "OWNER_RESERVED_ACTIONS",
    "SYSTEM_FORBIDDEN_AUTONOMOUS_ACTIONS",
    "WORK_ITEM_LOCAL_NOT_GLOBAL",
    "AuthorityRequest",
    "Decision",
    "HistoryIsolationError",
    "WorkItemRestriction",
    "apply_work_item_restriction",
    "claim_operational",
    "classify_cycle",
    "current_package_ready",
    "current_tool_policy",
    "historical_governance_operational_authority",
    "read_historical_for_audit",
    "resolve",
]
