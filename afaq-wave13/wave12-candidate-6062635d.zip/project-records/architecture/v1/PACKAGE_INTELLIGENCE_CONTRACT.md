# Package Intelligence Contract v1

**Status:** CONTRACT/DESIGN ONLY — no runtime implementation.
**Canonical contract owner:** Architecture governance
**Plane:** PLANE-07 (Capability & Provider) and PLANE-11 (Assurance & Resilience) intersections
**Scope boundary:** This document defines the contract. Runtime implementation (PackageSelfModel, CapabilityReasoner, Learning, Provider selection, Activation controller, Self-training, Self-upgrade, Genesis, Promotion) belongs to future C1+ work items.

## Core definition

```
PACKAGE INTELLIGENCE = ONE SHARED KERNEL + PACKAGE PROFILE + PACKAGE CONTRACTS + PACKAGE KNOWLEDGE + PACKAGE STATE
```

A `PackageIntelligenceKernel` is a **single shared kernel** providing common primitives. Each package adds its own profile, contracts, knowledge, and state. **There is one shared kernel, not one independent intelligence implementation per package.** No package owns the kernel, and the kernel does not own package-specific semantics.

## Canonical architecture reference model

Package Intelligence does **not** copy the canonical architecture into each package. Instead:

- The **Package Profile** references canonical IDs from `project-records/architecture/v1/`.
- The **Package Intelligence Kernel** reads those references and answers self-model questions.
- Package-local architecture copies are **not** canonical truth.
- Architecture membership ≠ authority inheritance.
- Cross-plane consumption ≠ cross-plane ownership.

Reference chain:

```
Canonical Architecture (PLANE_REGISTRY, COMPONENT_REGISTRY, CONTRACTS, INVARIANTS)
                ↓
        Package Profile
                ↓
      Package Intelligence Kernel
                ↓
            Package
```

## Physical vs logical packages

- **Physical packages** are directories under `owner-packages/` with manifests, source, tests, and evidence.
- **Logical package definitions** are entries such as the 75 W7/W8 definitions in `.bootstrap/REC-EPOCH2-BOOTSTRAP/PACKAGE_BUILD_MATRIX.json`.
- A logical definition is **not** an implemented runtime.
- Current implementation state is not target architecture state.

## Shared kernel responsibilities

The shared kernel provides:

1. Common identity, description, state, maturity, and authority primitives.
2. Standardized Architecture Awareness, Capability Awareness, Dependency Awareness, Provider Awareness, Authority Awareness, State Awareness, Context Awareness, Evidence Awareness, Freshness Awareness, Risk Awareness, Quality Awareness, Failure Awareness, Recovery Awareness, Compatibility Awareness, Benchmark Awareness, Learning Awareness, Improvement Candidate Generation, and Safe Activation / Deactivation Awareness.
3. Evaluation, freshness, risk, quality, and evidence reports using the shared `EvaluationReport` contract (`CTR-EVAL-001`).
4. Structured improvement candidates as proposals, **not** as self-authorizing promotions.

## Package self model

Every package profile must support answering the following questions. Each answer is derived from the **Package Profile Contract** and canonical architecture registries, never from a package-local redefinition.

| Question | Canonical source |
|---|---|
| Who am I? | Package profile `identity.package_id`, `identity.package_version`, `identity.entity_type` |
| Where do I belong in the 12-plane architecture? | `architecture.canonical_plane` → `PLANE_REGISTRY.json`; `architecture.macro_group` → `MACRO_GROUP_REGISTRY.json` |
| What entity type am I? | `identity.entity_type` → `ENTITY_TYPE_TAXONOMY.json` |
| What canonical component do I implement or extend? | `architecture.canonical_component` → `COMPONENT_REGISTRY.json` |
| What do I own? | `boundaries.owns` |
| What do I explicitly not own? | `boundaries.does_not_own` |
| What can I do? | `capability.capabilities[]` with role `PROVIDE`; `boundaries.owns` |
| What can I not do? | `capability.capabilities[]` with role `CONSUME`; `boundaries.does_not_own`; `authority.forbidden_authorities` |
| What capabilities do I provide? | `capability.capabilities[]` filtered by `role == PROVIDE` → `CAPABILITY_PROVIDER_MAP.json` |
| What capabilities do I consume? | `capability.capabilities[]` filtered by `role == CONSUME` → `CAPABILITY_PROVIDER_MAP.json` |
| What contracts do I implement or consume? | `capability.capability_contract_ids[]` → `TRACEABILITY_REGISTRY.json` / `CTR-*` contracts |
| What do I depend on? | `capability.dependencies[]` + `capability.optional_dependencies[]` → package/component IDs |
| Who depends on me? | Reverse lookup in `DEPENDENCY_DAG.json` |
| Which providers and adapters can serve my capabilities? | `provider.providers[]` + `provider.adapters[]` → `CAPABILITY_PROVIDER_MAP.json` + `COMPONENT_REGISTRY.json` |
| What authority do I have? | `authority.authority_ceiling` + `OWNERSHIP_REGISTRY.json` for the package's canonical owner |
| What authority do I explicitly not have? | `authority.forbidden_authorities[]` → `AUTHORITY_MODEL.json` |
| What side effects can I cause? | `side_effect_data_evidence.side_effect_class` |
| What data do I own or access? | `side_effect_data_evidence.data_ownership[]` → `DATA_OWNERSHIP_MAP.json` |
| What evidence supports my claims? | `side_effect_data_evidence.evidence_requirements[]` → `EVIDENCE_PROVENANCE_MAP.json` |
| How fresh is that evidence? | `side_effect_data_evidence.evidence_freshness` |
| What is my implementation state? | `state.implementation_state` → `LIFECYCLE_STATE_MATURITY_MODELS.json` |
| What is my target state? | `state.target_state` → `LIFECYCLE_STATE_MATURITY_MODELS.json` |
| How mature am I? | `state.maturity` → `LIFECYCLE_STATE_MATURITY_MODELS.json` |
| How healthy am I? | `state.health` |
| What is my certification state? | `state.certification_state` |
| What failure modes are known? | `failure_recovery.known_failure_modes[]` |
| How do I recover? | `failure_recovery.recovery_contract` |
| How do I rollback or compensate? | `failure_recovery.rollback_or_compensation_contract` |
| What benchmarks apply to me? | `quality.benchmarks[]` |
| Is a stronger candidate available? | `evolution.stronger_candidate` |
| If yes, is it a true semantic superset? | `evolution.semantic_comparison` |
| What unique valid behavior must be preserved? | `evolution.unique_behavior_to_preserve[]` |
| What compatibility requirements exist? | `capability.conflicts[]`; `evolution.semantic_comparison.compatibility_proof` |
| What migration is required? | `evolution.migration_state`; `evolution.semantic_comparison.migration_plan` |
| What rollback is required? | `evolution.semantic_comparison.rollback_plan` |
| What improvement candidates exist? | `evolution.improvement_candidates[]` |
| What is unknown? | Any field may be `UNKNOWN` |

## Package intelligence modules

1. **Self Identity** — answers "Who am I?"
2. **Self Description** — purpose, owns, does_not_own
3. **Architecture Awareness** — canonical plane, component, macro group, traceability
4. **Capability Awareness** — provided/consumed capabilities and contracts
5. **Dependency Awareness** — forward and reverse dependencies
6. **Provider Awareness** — providers and adapters that can satisfy capabilities
7. **Authority Awareness** — authority ceiling, required/forbidden authorities
8. **State Awareness** — implementation, target, maturity, health, certification
9. **Context Awareness** — runtime/task context (C1+ runtime concern)
10. **Evidence Awareness** — evidence supporting claims
11. **Freshness Awareness** — evidence age/validity
12. **Risk Awareness** — risk classification from side effects, authority, and dependencies
13. **Quality Awareness** — test/evidence coverage
14. **Failure Awareness** — known failure modes
15. **Recovery Awareness** — recovery and rollback contracts
16. **Compatibility Awareness** — conflicts, capability compatibility
17. **Benchmark Awareness** — benchmark results
18. **Learning Awareness** — observed outcomes (C1+ runtime concern)
19. **Improvement Candidate Generation** — proposes candidates, does not promote
20. **Safe Activation / Deactivation Awareness** — activation state machine (C1+ runtime concern)

No module receives independent promotion authority.

## Capability reasoner contract

```
REQUEST
→ interpret
→ contract match (exact / partial / unsupported)
→ dependency check
→ provider candidates
→ compatibility
→ health
→ certification
→ evidence freshness
→ privacy/data constraints
→ side-effect compatibility
→ authority compatibility
→ safe candidate set
→ REQUEST AUTHORIZATION
```

Resolver selection remains **advisory**. Authority is separate and belongs to PLANE-01.

## Stronger candidate / replacement awareness

A package may declare a `stronger_candidate`. Before any replacement or promotion, the Package Intelligence model must answer:

- Is the candidate a **true semantic superset** of the existing capability/package?
- What is the **compatibility proof**?
- What are the **compatibility requirements**?
- Which **consumers** are affected?
- What **unique valid behavior** must be preserved?
- What is the **data/state impact**?
- What is the **authority impact**?
- What is the **migration plan**?
- What is the **rollback plan**?
- What **verification** is required?
- Has **explicit owner/authority authorization** been granted?

Replacement is **not** automatic. A stronger benchmark or implementation does **not** grant promotion authority.

## Valid prior capability preservation

The canonical architecture preserves valid prior capabilities through this workflow:

```
PRESERVE
→ CLASSIFY (entity type)
→ MAP (to canonical plane / component)
→ IDENTIFY OWNER
→ SEMANTIC DEDUP
→ COMPARE (existing vs stronger)
→ ONE OF:
    KEEP
    HARDEN
    EXTEND
    MERGE
    WRAP_PROVIDER
    REPLACE  (only with governed proof)
    DEFER
```

Rules:

- **OLD ≠ AUTOMATIC DELETE**
- **NEW ARCHITECTURE ≠ AUTOMATIC REPLACEMENT OF VALID PRIOR CAPABILITY**
- **STRONGER CANDIDATE ≠ PROVEN SUPERSET**

`REPLACE` requires all of:
1. semantic superset proof
2. compatibility proof
3. all consumers identified
4. unique valid behavior preserved
5. data/state impact known
6. authority impact known
7. migration plan
8. rollback plan
9. verification
10. explicit owner/authority authorization

`DEPRECATION` lifecycle:

```
ACTIVE
→ DEPRECATION_PROPOSED
→ COMPATIBILITY_PERIOD
→ DEPRECATED
→ RETIRED
```

No direct deletion.

## Maturity model

Maturity is evidence-backed and multidimensional:

- contract completeness
- implementation completeness
- test coverage
- security coverage
- failure coverage
- recovery coverage
- provider health
- benchmark quality
- evidence freshness
- runtime reliability
- drift
- historical success

Maturity levels: `EXPERIMENTAL`, `DEVELOPMENT`, `PRE_PRODUCTION`, `PRODUCTION`, `MISSION_CRITICAL`, `UNKNOWN`.

**Invariants:**

- `MATURITY SCORE != AUTHORITY`
- `HIGH BENCHMARK != PROMOTION AUTHORITY`
- `CERTIFICATION != PROMOTION`

## Learning / improvement lifecycle

```
OBSERVE → EXPECTED vs ACTUAL
→ DETECT WEAKNESS
→ DETECT REPEATED FAILURE
→ DETECT STALE KNOWLEDGE
→ DETECT BETTER PROVIDER
→ DETECT BETTER ALGORITHM
→ DETECT BETTER CONTRACT
→ CREATE IMPROVEMENT CANDIDATE

CANDIDATE → SANDBOX → TEST → BENCHMARK → ADVERSARIAL VERIFY → CERTIFY
→ OWNER/AUTHORITY REVIEW → GOVERNED PROMOTION
```

No auto-promotion.

## Permanent authority invariants

- **PACKAGE INTELLIGENCE != AUTHORITY**
- **CAPABILITY REASONER != EXECUTION AUTHORITY**
- **PROVIDER SELECTION != EXECUTION AUTHORIZATION**
- **LEARNING != SELF-AUTHORIZATION**
- **IMPROVEMENT CANDIDATE != SELF-UPGRADE**
- **SELF-IMPROVEMENT != SELF-PROMOTION**
- **MATURITY != AUTHORITY**
- **CERTIFICATION != PROMOTION**
- **BETTER BENCHMARK != PERMISSION TO DEPLOY**
- **ARCHITECTURE MEMBERSHIP != AUTHORITY INHERITANCE**
- **KNOWING MORE != PERMISSION TO DO MORE**

## Boundaries

- This contract does **not** implement a runtime PackageSelfModel.
- This contract does **not** implement a CapabilityReasoner runtime.
- This contract does **not** implement learning, provider selection, activation, self-training, self-upgrade, genesis, or promotion runtimes.
- Those belong to C1+ governed work items.
- A package may propose, compare, and request authorization; it may not authorize itself.
