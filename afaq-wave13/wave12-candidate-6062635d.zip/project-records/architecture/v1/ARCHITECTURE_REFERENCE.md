# AFAQ Ω∞ — Canonical Architecture Reference v1

**Baseline:** `5f3af3e`
**Status:** v1 DEFINED — read-only architecture/contract source of truth
**Scope:** Architecture and contract design only. No runtime implementation.

---

## 1. Executive Architecture

AFAQ-GIE is a governed intelligence-engineering substrate organized into **6 macro groups** and **12 canonical planes**. The architecture separates **authority**, **contract**, **runtime**, **data**, and **evidence** ownership. Shared contracts `ModelRoutingService` and `EvaluationReport` close two canonical-owner gaps without implementation. Stage 2D S04/S05 remain committed and frozen.

## 2. Architecture Constitution

- **PRESERVE FIRST** — new layers are conservative supersets of valid prior contracts.
- **NEW LAYER ≠ REPLACEMENT** — a new plane or service does not automatically own everything before it.
- **CONTRACT_OWNER ≠ RUNTIME_OWNER ≠ DATA_OWNER ≠ PROVIDER_OWNER ≠ AUTHORITY_OWNER ≠ EVIDENCE_OWNER**.
- **SELECTED ≠ AUTHORIZED**, **EVALUATED ≠ CERTIFIED**, **ROUTING ≠ EXECUTION**.
- **SELF-IMPROVEMENT ≠ SELF-PROMOTION**, **LEARNING ≠ SELF-AUTHORIZATION**.
- No implementation scope may bypass `PLAN → CONTRACT → SCOPE → AUTHORIZATION → IMPLEMENT → VERIFY → ACCEPT → COMMIT`.
- Canvases, generated reports, and historical records are **not** canonical source-of-truth.

## 3. Macro Groups

| ID | Name | Planes |
|---|---|---|
| MACRO-A | CONTROL / CONSTITUTION | PLANE-01 |
| MACRO-B | COGNITION / KNOWLEDGE | PLANE-02, PLANE-03, PLANE-04, PLANE-05 |
| MACRO-C | CAPABILITY / WORKFORCE | PLANE-06, PLANE-07 |
| MACRO-D | EVOLUTION / GENESIS | PLANE-08, PLANE-09 |
| MACRO-E | EXECUTION / REALITY | PLANE-10 |
| MACRO-F | ASSURANCE / RECOVERY | PLANE-11, PLANE-12 |

## 4. 12 Canonical Planes

| Plane | Macro | Name | Current | Target |
|---|---|---|---|---|
| PLANE-01 | A | Sovereignty & Constitution | PARTIAL | CERTIFIED |
| PLANE-02 | B | Reality & Epistemic | PARTIAL | CERTIFIED |
| PLANE-03 | B | Intelligence Runtime | IMPLEMENTED | CERTIFIED |
| PLANE-04 | B | Research / Science / Reasoning | IMPLEMENTED | CERTIFIED |
| PLANE-05 | B | Simulation / Foresight / Decision | DESIGN_ONLY | IMPLEMENTED |
| PLANE-06 | C | Workforce & Organization | DESIGN_ONLY | IMPLEMENTED |
| PLANE-07 | C | Capability & Provider | PARTIAL | CERTIFIED |
| PLANE-08 | D | Genesis | DESIGN_ONLY | IMPLEMENTED |
| PLANE-09 | D | Evolution & R&D | PARTIAL | CERTIFIED |
| PLANE-10 | E | Execution & Reality | IMPLEMENTED | CERTIFIED |
| PLANE-11 | F | Assurance & Resilience | IMPLEMENTED | CERTIFIED |
| PLANE-12 | F | Frontier Discovery | DESIGN_ONLY | CONTRACTED |

## 5. Permanent Invariants

- SELF-IMPROVEMENT ≠ SELF-PROMOTION
- CAPABILITY GENESIS ≠ CAPABILITY AUTHORITY
- ARCHITECTURE EVOLUTION ≠ PRODUCTION MUTATION
- BETTER BENCHMARK ≠ PERMISSION TO DEPLOY
- INTELLIGENCE MAY PROPOSE ≠ INTELLIGENCE MAY AUTHORIZE ITSELF
- LEARNING ≠ SELF-AUTHORIZATION
- KNOWING MORE ≠ PERMISSION TO DO MORE
- SHARED CAPABILITY ≠ DOMAIN OWNERSHIP
- PROVIDER IMPLEMENTATION ≠ CONTRACT OWNERSHIP

## 6. ModelRoutingService Contract (C0-01)

- **Plane:** PLANE-07
- **Purpose:** Select a provider/model candidate; never authorize execution.
- **Owns:** capability taxonomy, candidate generation, selection rationale, fallback policy reference, failure model.
- **Does not own:** execution, transport, authorization, result verification, task approval.
- **Invariants:** SELECTED≠AUTHORIZED, AVAILABLE≠CERTIFIED, CERTIFIED≠AUTHORIZED, PROVIDER≠CANONICAL CONTRACT OWNER, ROUTING≠EXECUTION.

See `CTR_MODEL_ROUTING_SERVICE.json` for the full contract.

## 7. EvaluationReport Contract (C0-02)

- **Plane:** PLANE-11
- **Purpose:** Shared interchange/evidence envelope across complementary evaluators.
- **Owns:** report envelope, provenance, findings, metrics, confidence, unknowns.
- **Does not own:** policy authority, task authority, certification authority, promotion authority, mutation authority.
- **Invariants:** EVALUATED≠CERTIFIED, GOOD SCORE≠PROMOTION AUTHORITY, REPORT GENERATED≠RESULT ACCEPTED.

See `CTR_EVALUATION_REPORT.json` for the full contract.

## 8. Package Intelligence Contract v1

**Package Intelligence = SHARED KERNEL + PACKAGE PROFILE + PACKAGE CONTRACTS + PACKAGE KNOWLEDGE + PACKAGE STATE**

The shared kernel provides common primitives; each package adds its own profile, contracts, knowledge, and state. C0-A materializes **only** the contract/design. Runtime implementation (PackageSelfModel, CapabilityReasoner, Learning, Provider selection, Activation controller, Self-training, Self-upgrade, Genesis, Promotion) belongs to future C1+ work items.

## 9. Self-Development Lifecycle

```
DISCOVER → PROPOSE → SPECIFY → BUILD CANDIDATE → ISOLATED SANDBOX → TEST
→ ADVERSARIAL TEST → BENCHMARK → VERIFY → CERTIFY → REQUEST AUTHORIZATION
→ GOVERNED PROMOTION → OBSERVE ACTUAL OUTCOME → ACCEPT / ROLLBACK / RECONCILE
```

No production self-rewrite without explicit authorization.

## 10. Package Architecture Inheritance

Package profiles **reference** the canonical architecture; they do **not** copy or redefine it.

```
Canonical Architecture (PLANE_REGISTRY, COMPONENT_REGISTRY, CONTRACTS, INVARIANTS)
                ↓
        Package Profile
                ↓
      Package Intelligence Kernel
                ↓
            Package
```

Frozen rules:

- **PACKAGE-LOCAL ARCHITECTURE COPY ≠ CANONICAL SOURCE OF TRUTH**
- **ARCHITECTURE MEMBERSHIP ≠ AUTHORITY INHERITANCE**
- **CROSS-PLANE CONSUMPTION ≠ CROSS-PLANE OWNERSHIP**

A package declares:

- `canonical_plane` from `PLANE_REGISTRY.json`
- `canonical_component` from `COMPONENT_REGISTRY.json` (when applicable)
- `architecture_traceability` from `TRACEABILITY_REGISTRY.json`
- `canonical_owner` from the canonical ownership decisions

It does not declare its own planes, macro groups, entity types, or invariants.

### Physical vs logical packages

- **Physical packages** are directories under `owner-packages/` with `MANIFEST.json`, source, tests, and evidence.
- **Logical package definitions** are entries such as the 75 W7/W8 definitions in `.bootstrap/REC-EPOCH2-BOOTSTRAP/PACKAGE_BUILD_MATRIX.json`.
- A logical definition is **not** an implemented runtime.
- Current implementation state is not target architecture state.

### Prior capability preservation

For every valid prior capability:

```
PRESERVE
→ CLASSIFY (entity type)
→ MAP (to canonical plane / component)
→ IDENTIFY CANONICAL OWNER
→ SEMANTIC DEDUP
→ COMPARE (existing vs candidate)
→ DECIDE
```

Allowed decisions:

- `KEEP`
- `HARDEN`
- `EXTEND`
- `MERGE`
- `WRAP_PROVIDER`
- `REPLACE` (governed)
- `DEFER`

`REPLACE` requires all of:

1. true semantic superset proof
2. compatibility proof
3. all consumers identified
4. unique valid behavior preserved
5. data/state impact known
6. authority impact known
7. migration plan
8. rollback plan
9. verification
10. explicit owner/authority authorization

`DEPRECATION` lifecycle:

```
ACTIVE → DEPRECATION_PROPOSED → COMPATIBILITY_PERIOD → DEPRECATED → RETIRED
```

No direct deletion.

## 11. Relationship to Prior Work

- `ARCHITECTURE_GOVERNANCE.md` remains the root mandatory governance.
- `AGENTS.md` remains the external-tool instruction surface.
- `project-records/governance/` documents remain canonical governance.
- `project-records/engine-registry/ENGINE_REGISTRY.md` remains canonical for engine truth.
- `.bootstrap/` artifacts are generated derivatives.
- `canvases/*.canvas.tsx` files are visual summaries, not source-of-truth.

This reference is a conservative superset and reorganization of valid prior architecture content.
