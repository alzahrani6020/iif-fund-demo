# AFAQ Ω∞ — Canonical Architecture Reference v1

**Status:** DEFINED — read-only architecture/contract source of truth.
**Baseline:** `5f3af3e`
**Canonical root:** `project-records/architecture/v1/`
**Scope:** Architecture and contract design only. No runtime implementation. No Stage 2D changes.

## Purpose

This directory is the versioned, single source of truth for:

1. **AFAQ Ω∞ Canonical Architecture Reference v1** — the 12-plane, 6-macro-group architecture.
2. **Package Intelligence Contract v1** — the shared-kernel contract for package self-description.

All other architecture/governance documents in the repository either:
- remain canonical in their own domain (e.g. `ARCHITECTURE_GOVERNANCE.md` for root governance),
- are linked from this reference as supporting or historical evidence, or
- are generated derivatives (e.g. `.bootstrap/` reports, canvases) that do not override canonical truth.

## Single source of truth

- Only files in `project-records/architecture/v1/` define canonical architecture v1 truth.
- `ARCHITECTURE.json` is the machine-readable manifest of the artifact set.
- `ARCHITECTURE_REFERENCE.md` is the human-readable master narrative.
- JSON registries are machine-validatable.
- Canvases and generated reports are visual aids, not canonical.

## Artifact inventory

| # | File | Artifact ID | Class | Canonical contract owner |
|---|------|---------------|-------|--------------------------|
| 1 | `README.md` | `ART-README-001` | CANONICAL | Architecture governance |
| 2 | `ARCHITECTURE.json` | `ART-ARCH-001` | CANONICAL | Architecture governance |
| 3 | `ARCHITECTURE_REFERENCE.md` | `ART-ARCH-002` | CANONICAL | Architecture governance |
| 4 | `ENTITY_TYPE_TAXONOMY.json` | `ART-TAXO-001` | CANONICAL | Architecture governance |
| 5 | `MACRO_GROUP_REGISTRY.json` | `ART-MACRO-001` | CANONICAL | Architecture governance |
| 6 | `PLANE_REGISTRY.json` | `ART-PLANE-001` | CANONICAL | Architecture governance |
| 7 | `PLANE_CONTRACTS.json` | `ART-PLANE-002` | CANONICAL | Architecture governance |
| 8 | `COMPONENT_REGISTRY.json` | `ART-COMP-001` | CANONICAL | Architecture governance |
| 9 | `OWNERSHIP_REGISTRY.json` | `ART-OWN-001` | CANONICAL | Architecture governance |
| 10 | `CAPABILITY_PROVIDER_MAP.json` | `ART-CAP-001` | CANONICAL | Architecture governance |
| 11 | `CTR_MODEL_ROUTING_SERVICE.json` | `CTR-ROUTING-001` | CANONICAL | ModelRoutingService / PLANE-07 |
| 12 | `CTR_EVALUATION_REPORT.json` | `CTR-EVAL-001` | CANONICAL | EvaluationReport / PLANE-11 |
| 13 | `AUTHORITY_MODEL.json` | `ART-AUTH-001` | CANONICAL | Architecture governance |
| 14 | `DEPENDENCY_DAG.json` | `ART-DAG-001` | CANONICAL | W7-P08 Dependency Truth Graph |
| 15 | `DATA_OWNERSHIP_MAP.json` | `ART-DATA-001` | CANONICAL | Architecture governance |
| 16 | `EVIDENCE_PROVENANCE_MAP.json` | `ART-EVID-001` | CANONICAL | Architecture governance |
| 17 | `LIFECYCLE_STATE_MATURITY_MODELS.json` | `ART-STATE-001` | CANONICAL | Architecture governance |
| 18 | `PACKAGE_INTELLIGENCE_CONTRACT.md` | `ART-PKGINT-001` | CANONICAL | Architecture governance |
| 19 | `PACKAGE_PROFILE_CONTRACT.json` | `ART-PKGPROF-001` | CANONICAL | Architecture governance |
| 20 | `INVARIANT_REGISTRY.json` | `ART-INV-001` | CANONICAL | Architecture governance |
| 21 | `TRACEABILITY_REGISTRY.json` | `ART-TRACE-001` | CANONICAL | Architecture governance |
| 22 | `CURRENT_TARGET_MATRIX.json` | `ART-MATRIX-001` | CANONICAL | Architecture governance |
| 23 | `EXPANDED_REFERENCE_LINKAGE.json` | `ART-LINK-001` | DERIVED | NONE |

## Versioning

- `v1/` is immutable once accepted and committed.
- Future revisions require a new governed work item and a new version directory (`v2/`, `v2.1/`, etc.).
- Deprecated IDs are recorded in `TRACEABILITY_REGISTRY.json` with `deprecated_by` but are never reused.

## Boundaries

- **Package Intelligence runtime** (PackageSelfModel, CapabilityReasoner, Learning, Provider selection, Activation controller, Self-training, Self-upgrade, Genesis, Promotion) is **NOT** implemented here. Only the contract/design artifacts are persisted.
- **Stage 2D runtime** is not modified. S04/S05 remain committed at their respective baselines.
- No existing repository file is modified by this work item.
