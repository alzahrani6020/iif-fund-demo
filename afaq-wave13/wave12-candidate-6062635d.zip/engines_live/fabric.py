"""Core live-engine types and invoke path."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Mapping

REPO_ROOT = Path(__file__).resolve().parents[1]


@dataclass(frozen=True)
class LiveInvocationResult:
    engine_id: str
    ok: bool
    live_status: str
    operationally_proven: bool
    runtime_implementation: bool
    capability_packages: tuple[str, ...]
    required_capabilities: tuple[str, ...]
    bound_capabilities: tuple[str, ...]
    missing_capabilities: tuple[str, ...]
    adapter: str
    message: str
    evidence: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "engine_id": self.engine_id,
            "ok": self.ok,
            "live_status": self.live_status,
            "operationally_proven": self.operationally_proven,
            "runtime_implementation": self.runtime_implementation,
            "capability_packages": list(self.capability_packages),
            "required_capabilities": list(self.required_capabilities),
            "bound_capabilities": list(self.bound_capabilities),
            "missing_capabilities": list(self.missing_capabilities),
            "adapter": self.adapter,
            "message": self.message,
            "evidence": self.evidence,
        }


@dataclass
class LiveEngine:
    engine_id: str
    name: str
    kind: str
    live_status: str
    live_path: str
    capability_packages: tuple[str, ...]
    package_paths: tuple[str, ...]
    required_capabilities: tuple[str, ...]
    shared_engine_file: str | None
    canonical: dict[str, Any]
    adapter_name: str
    handler: Callable[[Mapping[str, Any]], dict[str, Any]]
    operationally_proven: bool = False
    runtime_implementation: bool = True

    def invoke(self, payload: Mapping[str, Any] | None = None) -> LiveInvocationResult:
        payload = dict(payload or {})
        raw = self.handler(payload)
        bound = tuple(raw.get("bound_capabilities") or ())
        missing = tuple(raw.get("missing_capabilities") or self.required_capabilities)
        if bound and self.required_capabilities:
            missing = tuple(c for c in self.required_capabilities if c not in bound)
        ok = bool(raw.get("ok", True))
        evidence = dict(raw.get("evidence") or {})
        if "executed" not in evidence:
            evidence["executed"] = bool(raw.get("executed", ok))
        return LiveInvocationResult(
            engine_id=self.engine_id,
            ok=ok,
            live_status=self.live_status,
            operationally_proven=self.operationally_proven,
            runtime_implementation=bool(
                raw.get(
                    "runtime_implementation",
                    self.runtime_implementation,
                )
            ),
            capability_packages=self.capability_packages,
            required_capabilities=self.required_capabilities,
            bound_capabilities=bound,
            missing_capabilities=missing,
            adapter=self.adapter_name,
            message=str(raw.get("message") or "live invocation completed"),
            evidence=evidence,
        )


def _load_package_foundation(path: str | Path) -> dict[str, Any] | None:
    p = Path(path)
    if not p.is_absolute():
        p = REPO_ROOT / p
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def bind_capability_packages(
    package_ids: tuple[str, ...],
    package_paths: tuple[str, ...],
    required: tuple[str, ...],
) -> dict[str, Any]:
    """Bind capability packages declared for an engine; never invent packages."""
    loaded: list[dict[str, Any]] = []
    declared_caps: list[str] = []
    for path in package_paths:
        foundation = _load_package_foundation(path)
        if foundation is None:
            continue
        loaded.append(
            {
                "package_id": foundation.get("package_id")
                or foundation.get("id")
                or Path(path).parent.name,
                "path": str(path),
                "name": foundation.get("name") or foundation.get("package_name"),
                "keys": sorted(foundation.keys())[:40],
            }
        )
        for key in (
            "capabilities",
            "required_capabilities",
            "capability_ids",
            "functions",
            "declared_capabilities",
        ):
            val = foundation.get(key)
            if isinstance(val, list):
                for item in val:
                    if isinstance(item, str):
                        declared_caps.append(item)
                    elif isinstance(item, dict):
                        cid = item.get("id") or item.get("capability_id") or item.get("name")
                        if isinstance(cid, str):
                            declared_caps.append(cid)

    # Prefer explicit required_capabilities from shared-engine; packages supply evidence of binding.
    bound: list[str] = []
    if required:
        # Package presence binds the *engine requirement set* when foundations load successfully.
        if loaded:
            bound = list(required)
        missing = [c for c in required if c not in bound]
    else:
        bound = sorted(set(declared_caps))
        missing = []

    return {
        "packages_loaded": len(loaded),
        "packages": loaded,
        "bound_capabilities": bound,
        "missing_capabilities": missing,
        "declared_from_packages": sorted(set(declared_caps)),
    }


def get_engine(engine_id: str) -> LiveEngine:
    from .registry import LIVE_ENGINE_REGISTRY, build_registry, list_engine_ids

    if not LIVE_ENGINE_REGISTRY:
        build_registry()
    resolved = resolve_engine_id(engine_id)
    eng = LIVE_ENGINE_REGISTRY.get(resolved)
    if eng is None:
        known = ", ".join(list_engine_ids()[:8])
        raise KeyError(
            f"engine not in LIVE_ENGINE_REGISTRY: {engine_id}"
            + (f" (resolved {resolved})" if resolved != engine_id else "")
            + f"; sample: {known}…"
        )
    return eng


_ENGINE_ALIASES = {
    "UND": "ENG-UND-017",
    "RES": "ENG-RES-018",
    "DEV": "ENG-DEV-001",
    "DEC": "ENG-DEC-002",
    "MOD": "ENG-MOD-003",
    "MEM": "ENG-MEM-004",
    "HEAL": "ENG-HEAL-005",
    "ROU": "ENG-ROU-006",
    "WS": "ENG-WS-007",
    "SRV": "ENG-SRV-008",
    "BE": "ENG-BE-009",
    "AUD": "ENG-AUD-010",
    "WR": "ENG-WR-019",
    "GRA": "ENG-GRA-021",
}

_PROTECTED_CAP_PREFIXES = ("CAP-AUDIT-", "CAP-EVAL-", "CAP-TRUTH-")


def resolve_engine_id(engine_id: str) -> str:
    """Resolve short aliases to registry IDs without inventing new engines."""
    from .registry import LIVE_ENGINE_REGISTRY, build_registry

    if not LIVE_ENGINE_REGISTRY:
        build_registry()
    eid = str(engine_id).strip()
    if eid in LIVE_ENGINE_REGISTRY:
        return eid
    alias = _ENGINE_ALIASES.get(eid.upper())
    if alias and alias in LIVE_ENGINE_REGISTRY:
        return alias
    upper = eid.upper()
    if upper.startswith("CAP-") and not upper.startswith(_PROTECTED_CAP_PREFIXES):
        # CAP-001 → ENG-CAP-001
        numbered = "ENG-CAP-" + eid.split("-", 1)[1]
        if numbered in LIVE_ENGINE_REGISTRY:
            return numbered
        prefixed = f"ENG-{eid}"
        if prefixed in LIVE_ENGINE_REGISTRY:
            return prefixed
    return eid


def invoke(engine_id: str, payload: Mapping[str, Any] | None = None) -> LiveInvocationResult:
    return get_engine(engine_id).invoke(payload)
