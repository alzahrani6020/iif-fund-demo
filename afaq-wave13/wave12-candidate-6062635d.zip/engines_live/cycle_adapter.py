"""Legacy engine-first compatibility surface.

The primary Cycle runtime remains task-first.

engine_id belongs here only during migration.
"""

from __future__ import annotations

from pathlib import Path
from typing import (
    Any,
    Mapping,
)

from capability_cycle.cycle_io_adapters import (
    AuditLedgerEvidenceAdapter,
    LocalJsonCycleStateAdapter,
)
from capability_cycle.cycle_ports import (
    CycleStatePort,
    EvidencePort,
)
from capability_cycle.cycle_runner import (
    CycleRunner,
    ExecutionCycleRequest,
)

from .fabric import (
    REPO_ROOT,
    get_engine,
    invoke,
)


def _legacy_result_view(
    result: Any,
) -> dict[str, Any]:
    data = (
        result.as_dict()
        if hasattr(
            result,
            "as_dict",
        )
        else dict(result)
    )

    evidence = dict(
        data.get(
            "evidence"
        )
        or {}
    )

    # Legacy readiness/proof flags are intentionally
    # not promoted into Cycle truth.
    return {
        "ok": bool(
            data.get(
                "ok",
                False,
            )
        ),
        "executed": bool(
            evidence.get(
                "executed",
                data.get(
                    "ok",
                    False,
                ),
            )
        ),
        "engine_id": (
            data.get(
                "engine_id"
            )
        ),
        "adapter": (
            data.get(
                "adapter"
            )
        ),
        "required_capabilities": list(
            data.get(
                "required_capabilities"
            )
            or []
        ),
        "bound_capabilities": list(
            data.get(
                "bound_capabilities"
            )
            or []
        ),
        "missing_capabilities": list(
            data.get(
                "missing_capabilities"
            )
            or []
        ),
        "elapsed_ms": (
            evidence.get(
                "elapsed_ms"
            )
        ),
        "run_path": (
            evidence.get(
                "run_path"
            )
        ),
        "message": (
            data.get(
                "message"
            )
        ),
    }


def invoke_cycle(
    engine_id: str,
    payload: (
        Mapping[str, Any] | None
    ) = None,
    *,
    task: (
        str | None
    ) = None,
    required_capabilities: (
        tuple[str, ...]
    ) = (),
    expected_outcome: (
        Mapping[str, Any] | None
    ) = None,
    context: (
        Mapping[str, Any] | None
    ) = None,
    cycle_id: (
        str | None
    ) = None,
    parent_cycle_id: (
        str | None
    ) = None,
    environment: str = "local",
    var_dir: (
        str | Path | None
    ) = None,
    state_port: (
        CycleStatePort | None
    ) = None,
    evidence_port: (
        EvidencePort | None
    ) = None,
) -> dict[str, Any]:
    engine = get_engine(
        engine_id
    )

    body = dict(
        payload or {}
    )

    local_root = Path(
        var_dir
        or (
            REPO_ROOT
            / "var"
        )
    )

    owns_evidence = (
        evidence_port is None
    )

    active_state = (
        state_port
        or LocalJsonCycleStateAdapter(
            local_root
            / "cycles"
        )
    )

    active_evidence = (
        evidence_port
        or AuditLedgerEvidenceAdapter(
            local_root
            / "aic_audit.db"
        )
    )

    request = ExecutionCycleRequest(
        task=(
            task
            or str(
                body.get(
                    "task"
                )
                or body.get(
                    "instruction"
                )
                or body.get(
                    "query"
                )
                or (
                    "legacy engine invocation: "
                    f"{engine.engine_id}"
                )
            )
        ),
        payload=body,
        context={
            **dict(
                context or {}
            ),
            "migration_adapter": (
                "LEGACY_ENGINE_CYCLE_ADAPTER"
            ),
            "requested_engine_id": (
                engine_id
            ),
        },
        required_capabilities=(
            required_capabilities
            or tuple(
                engine.required_capabilities
            )
        ),
        expected_outcome=dict(
            expected_outcome
            or {}
        ),
        cycle_id=cycle_id,
        parent_cycle_id=(
            parent_cycle_id
        ),
        environment=environment,
    )

    decision = {
        "decision_type": (
            "EXECUTION_RESOURCE_SELECTION"
        ),
        "selection_mode": (
            "LEGACY_DIRECT_ENGINE_COMPATIBILITY"
        ),
        "requested_engine_id": (
            engine_id
        ),
        "selected_engine_id": (
            engine.engine_id
        ),
        "selected_adapter": (
            engine.adapter_name
        ),
        "alternatives_rejected": [],
        "confidence": None,
        "reason": (
            "explicit legacy selection "
            "during Cycle-first migration"
        ),
    }

    runner = CycleRunner(
        state_port=active_state,
        evidence_port=active_evidence,
    )

    try:
        output = runner.run(
            request,
            decision=decision,
            executor=lambda request_body: (
                _legacy_result_view(
                    invoke(
                        engine.engine_id,
                        request_body,
                    )
                )
            ),
        )

        output[
            "compatibility"
        ] = {
            "legacy_engine_api": True,
            "final_cycle_api": False,
        }

        return output

    finally:
        if owns_evidence:
            active_evidence.close()
