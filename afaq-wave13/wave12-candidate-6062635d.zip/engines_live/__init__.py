"""Live engine fabric — seats all registry engines as callable live units.

Live means: importable, invoke()-callable, registered, capability packages bound.
Does not claim operationally_proven or production admission without evidence.
"""

from .fabric import LiveEngine, LiveInvocationResult, invoke, get_engine, resolve_engine_id
from .registry import LIVE_ENGINE_REGISTRY, build_registry, list_engine_ids
from .run_capability import run_capability
from .cycle_adapter import invoke_cycle

# Composition binding is intentionally one-way:
# engines_live -> afaq_agent_runtime capability contract.
# The Agent Runtime never imports engines_live.
from afaq_agent_runtime.capability_port import (
    register_capability_invoker,
    register_capability_runtime_invoker,
)

register_capability_invoker(invoke)
register_capability_runtime_invoker(run_capability)

__all__ = [
    "LiveEngine",
    "LiveInvocationResult",
    "LIVE_ENGINE_REGISTRY",
    "build_registry",
    "list_engine_ids",
    "get_engine",
    "invoke",
    "resolve_engine_id",
    "run_capability",
    "invoke_cycle",
]
