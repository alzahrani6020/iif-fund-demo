"""Dedicated governed runtimes for ENG-CAP-002 and ENG-CAP-003."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

from afaq_agent_runtime.command_allowlist import (
    CommandNotAllowed,
    check_allowed,
    run_allowed,
)
from afaq_agent_runtime.host_sandbox import (
    HostSandboxError,
    run_isolated,
)

REPO_ROOT = Path(__file__).resolve().parents[2]


def _command(payload: Mapping[str, Any]) -> list[str] | str:
    command = payload.get("command")
    if command is None:
        return ["git", "status"]
    if isinstance(command, str):
        return command
    if isinstance(command, (list, tuple)):
        return [str(part) for part in command]
    raise ValueError("command must be a string or argv list")


def _cwd(payload: Mapping[str, Any]) -> str:
    raw = payload.get("cwd")
    if raw is None:
        return str(REPO_ROOT)
    path = Path(str(raw))
    if not path.is_absolute():
        path = REPO_ROOT / path
    resolved = path.resolve()
    try:
        resolved.relative_to(REPO_ROOT.resolve())
    except ValueError as exc:
        raise ValueError("cwd must remain inside repository root") from exc
    if not resolved.is_dir():
        raise ValueError("cwd does not exist or is not a directory")
    return str(resolved)


def _timeout(payload: Mapping[str, Any]) -> int:
    raw = int(payload.get("timeout_seconds") or 30)
    if raw < 1 or raw > 300:
        raise ValueError("timeout_seconds must be between 1 and 300")
    return raw


def make_command_runtime_adapter():
    """ENG-CAP-002: allowlisted command execution through the sandbox boundary."""

    def handler(payload: Mapping[str, Any]) -> dict[str, Any]:
        try:
            command = _command(payload)
            cwd = _cwd(payload)
            timeout = _timeout(payload)
            argv = check_allowed(command)
            result = run_allowed(argv, cwd=cwd, timeout=timeout)
        except (CommandNotAllowed, HostSandboxError, ValueError, OSError) as exc:
            return {
                "ok": False,
                "executed": False,
                "message": f"ENG-CAP-002 command blocked: {type(exc).__name__}: {exc}",
                "evidence": {
                    "policy": "ALLOWLIST_PLUS_SANDBOX",
                    "shell": False,
                    "blocked": True,
                    "error": f"{type(exc).__name__}: {exc}",
                },
            }

        return {
            "ok": bool(result.get("passed")),
            "executed": True,
            "message": "ENG-CAP-002 governed command executed",
            "evidence": {
                "policy": "ALLOWLIST_PLUS_SANDBOX",
                "shell": False,
                "argv": list(result.get("command") or argv),
                "returncode": result.get("returncode"),
                "stdout": result.get("stdout"),
                "stderr": result.get("stderr"),
                "sandbox": dict(result.get("sandbox") or {}),
            },
        }

    return handler


def make_sandbox_runtime_adapter():
    """ENG-CAP-003: isolated execution that cannot bypass the command allowlist."""

    def handler(payload: Mapping[str, Any]) -> dict[str, Any]:
        try:
            command = _command(payload)
            cwd = _cwd(payload)
            timeout = _timeout(payload)
            argv = check_allowed(command)
            result = run_isolated(
                argv,
                cwd=cwd,
                timeout=timeout,
                route_id="allowlist.run_allowed",
            )
        except (CommandNotAllowed, HostSandboxError, ValueError, OSError) as exc:
            return {
                "ok": False,
                "executed": False,
                "message": f"ENG-CAP-003 sandbox execution blocked: {type(exc).__name__}: {exc}",
                "evidence": {
                    "policy": "SANDBOX_REQUIRED",
                    "allowlist_required": True,
                    "shell": False,
                    "blocked": True,
                    "error": f"{type(exc).__name__}: {exc}",
                },
            }

        sandbox = dict(result.get("sandbox") or {})
        isolated = (
            sandbox.get("policy") == "SANDBOX_REQUIRED"
            and sandbox.get("trust_class") == "UNTRUSTED"
            and sandbox.get("cleanup") == "ok"
        )
        return {
            "ok": bool(result.get("passed") and isolated),
            "executed": True,
            "message": "ENG-CAP-003 governed sandbox execution completed",
            "evidence": {
                "policy": "SANDBOX_REQUIRED",
                "allowlist_required": True,
                "shell": False,
                "argv": list(result.get("command") or argv),
                "returncode": result.get("returncode"),
                "stdout": result.get("stdout"),
                "stderr": result.get("stderr"),
                "sandbox": sandbox,
                "isolation_verified": isolated,
            },
        }

    return handler
