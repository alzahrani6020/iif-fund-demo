"""Dedicated context adaptation and approved-capability attachment runtimes."""

from __future__ import annotations

import hashlib
import json
import os
import platform
import shutil
from pathlib import Path
from typing import Any, Mapping

from capability_cycle.handlers import (
    artifact_hash,
    get_active_handler,
    implemented_ids,
)
from current_authority.resolver import AuthorityRequest, resolve


REPO_ROOT = Path(__file__).resolve().parents[2]
_SESSIONS: dict[str, list[str]] = {}


def _digest(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _memory_profile() -> dict[str, Any]:
    meminfo = Path("/proc/meminfo")
    if not meminfo.is_file():
        return {"total_bytes": None, "available_bytes": None, "source": "UNAVAILABLE"}
    values: dict[str, int] = {}
    try:
        for line in meminfo.read_text(encoding="utf-8").splitlines():
            if ":" not in line:
                continue
            key, rest = line.split(":", 1)
            token = rest.strip().split()[0]
            values[key] = int(token) * 1024
    except (OSError, ValueError, IndexError):
        return {"total_bytes": None, "available_bytes": None, "source": "UNAVAILABLE"}
    return {
        "total_bytes": values.get("MemTotal"),
        "available_bytes": values.get("MemAvailable"),
        "source": "/proc/meminfo",
    }


def _environment_profile(payload: Mapping[str, Any]) -> dict[str, Any]:
    memory = _memory_profile()
    disk = shutil.disk_usage(REPO_ROOT)
    supplied = payload.get("resources") or {}
    if not isinstance(supplied, Mapping):
        raise ValueError("resources must be an object")
    cpu_pressure = supplied.get("cpu_pressure")
    memory_pressure = supplied.get("memory_pressure")
    network_latency_ms = supplied.get("network_latency_ms")
    for name, value in (
        ("cpu_pressure", cpu_pressure),
        ("memory_pressure", memory_pressure),
    ):
        if value is not None:
            number = float(value)
            if not 0.0 <= number <= 1.0:
                raise ValueError(f"{name} must be between 0 and 1")
    if network_latency_ms is not None and float(network_latency_ms) < 0:
        raise ValueError("network_latency_ms must be >= 0")

    return {
        "os": {
            "system": platform.system(),
            "release": platform.release(),
            "machine": platform.machine(),
        },
        "runtime": {
            "python": platform.python_version(),
            "process_architecture": platform.architecture()[0],
        },
        "resources": {
            "cpu_count": os.cpu_count(),
            "memory": memory,
            "disk_total_bytes": disk.total,
            "disk_free_bytes": disk.free,
            "cpu_pressure": None if cpu_pressure is None else float(cpu_pressure),
            "memory_pressure": None if memory_pressure is None else float(memory_pressure),
            "network_latency_ms": (
                None if network_latency_ms is None else float(network_latency_ms)
            ),
        },
        "protocols": sorted({
            str(x).lower()
            for x in (payload.get("protocols") or ["http", "https"])
            if str(x).strip()
        }),
        "gpu": {
            "available": bool(supplied.get("gpu_available", False)),
            "profile": str(supplied.get("gpu_profile") or "UNVERIFIED"),
        },
        "cloud_or_device_profile": str(
            payload.get("environment_class") or "LOCAL_OR_CI"
        ),
    }


def make_context_adaptation_runtime_adapter():
    """ENG-CAP-140: observe context and recommend bounded configuration only."""

    def handler(payload: Mapping[str, Any]) -> dict[str, Any]:
        try:
            current = _environment_profile(payload)
            fingerprint = _digest(current)
            previous = payload.get("previous_context")
            change = None
            if isinstance(previous, Mapping):
                previous_digest = str(
                    previous.get("fingerprint") or _digest(dict(previous))
                )
                change = {
                    "changed": previous_digest != fingerprint,
                    "previous_fingerprint": previous_digest,
                    "current_fingerprint": fingerprint,
                }

            resources = current["resources"]
            recommendations = []
            cpu_pressure = resources["cpu_pressure"]
            mem_pressure = resources["memory_pressure"]
            latency = resources["network_latency_ms"]
            if cpu_pressure is not None and cpu_pressure >= 0.8:
                recommendations.append({
                    "parameter": "batch_size",
                    "operation": "REDUCE",
                    "reason": "HIGH_CPU_PRESSURE",
                })
            if mem_pressure is not None and mem_pressure >= 0.8:
                recommendations.append({
                    "parameter": "resolution_or_context_size",
                    "operation": "REDUCE",
                    "reason": "HIGH_MEMORY_PRESSURE",
                })
            if latency is not None and latency >= 250:
                recommendations.append({
                    "parameter": "request_batching_or_timeout",
                    "operation": "ADAPT",
                    "reason": "HIGH_NETWORK_LATENCY",
                })
            report = {
                "context": current,
                "fingerprint": fingerprint,
                "context_change": change,
                "resource_pressure_detected": bool(recommendations),
                "adaptation_recommendations": recommendations,
                "configuration_candidate_only": True,
                "automatic_configuration_apply": False,
                "authority_created": False,
            }
            return {
                "ok": True,
                "executed": True,
                "message": "ENG-CAP-140 environment context evaluated",
                "evidence": {
                    "adaptation": report,
                    "adaptation_digest": _digest(report),
                    "observed_not_invented": True,
                    "authority_preserved": True,
                },
            }
        except Exception as exc:
            return {
                "ok": False,
                "executed": False,
                "message": f"ENG-CAP-140 context adaptation blocked: {type(exc).__name__}: {exc}",
                "evidence": {"error": f"{type(exc).__name__}: {exc}", "fail_closed": True},
            }

    return handler


def _session_id(payload: Mapping[str, Any]) -> str:
    sid = str(payload.get("session_id") or "verify-session").strip()
    if not sid or len(sid) > 128:
        raise ValueError("invalid session_id")
    return sid


def _requested_capabilities(payload: Mapping[str, Any]) -> list[str]:
    raw = payload.get("capability_ids")
    if raw is None:
        raw = ["CAP-AUDIT-001"]
    if not isinstance(raw, (list, tuple)) or not raw:
        raise ValueError("capability_ids must be a non-empty list")
    return list(dict.fromkeys(str(x).strip() for x in raw if str(x).strip()))


def _approved_descriptor(capability_id: str, expected_hash: str | None = None) -> dict[str, Any]:
    if capability_id not in set(implemented_ids()):
        raise ValueError(f"capability not implemented: {capability_id}")
    handler = get_active_handler(capability_id)
    digest = artifact_hash(capability_id)
    if handler is None or not callable(handler) or not digest:
        raise ValueError(f"capability is not healthy/attachable: {capability_id}")
    if expected_hash and expected_hash != digest:
        raise ValueError(f"artifact hash mismatch: {capability_id}")
    authority = resolve(
        AuthorityRequest(
            action="execute_tool",
            path=f"capability_attach:{capability_id}",
            capability_implemented_and_verified=True,
        )
    )
    if authority.outcome != "ALLOW":
        raise PermissionError(
            f"attachment authority denied: {authority.outcome}:{authority.reason}"
        )
    return {
        "capability_id": capability_id,
        "artifact_hash": digest,
        "handler_callable": True,
        "health": "READY",
        "authority": {
            "outcome": authority.outcome,
            "reason": authority.reason,
            "source": authority.source,
        },
    }


def make_capability_loader_runtime_adapter():
    """ENG-CAP-142: session-attach approved capabilities; never import arbitrary code."""

    def handler(payload: Mapping[str, Any]) -> dict[str, Any]:
        try:
            action = str(payload.get("action") or "status").strip().lower()
            sid = _session_id(payload)
            if action == "discover":
                ids = list(implemented_ids())
                report = {
                    "session_id": sid,
                    "implemented_capability_count": len(ids),
                    "implemented_capability_ids": ids,
                    "dynamic_import": False,
                }
            elif action == "attach":
                requested = _requested_capabilities(payload)
                expected = payload.get("expected_artifact_hashes") or {}
                if not isinstance(expected, Mapping):
                    raise ValueError("expected_artifact_hashes must be an object")
                descriptors = [
                    _approved_descriptor(
                        cid,
                        str(expected.get(cid)) if expected.get(cid) else None,
                    )
                    for cid in requested
                ]
                attached = list(_SESSIONS.get(sid, []))
                for cid in requested:
                    if cid not in attached:
                        attached.append(cid)
                _SESSIONS[sid] = attached
                report = {
                    "session_id": sid,
                    "action": "attach",
                    "dependency_load_order": requested,
                    "attached_capability_ids": list(attached),
                    "descriptors": descriptors,
                    "version_compatibility_gate": "ARTIFACT_HASH",
                    "health_after_load": "READY",
                    "ephemeral_session": True,
                    "global_handler_registry_modified": False,
                    "dynamic_import": False,
                }
            elif action == "detach":
                requested = _requested_capabilities(payload)
                attached = list(_SESSIONS.get(sid, []))
                detached = [cid for cid in requested if cid in attached]
                attached = [cid for cid in attached if cid not in set(detached)]
                if attached:
                    _SESSIONS[sid] = attached
                else:
                    _SESSIONS.pop(sid, None)
                report = {
                    "session_id": sid,
                    "action": "detach",
                    "detached_capability_ids": detached,
                    "attached_capability_ids": attached,
                    "safe_cleanup": True,
                    "global_handler_registry_modified": False,
                }
            elif action == "cleanup":
                previous = list(_SESSIONS.pop(sid, []))
                report = {
                    "session_id": sid,
                    "action": "cleanup",
                    "detached_capability_ids": previous,
                    "attached_capability_ids": [],
                    "safe_cleanup": True,
                    "global_handler_registry_modified": False,
                }
            elif action == "status":
                report = {
                    "session_id": sid,
                    "action": "status",
                    "attached_capability_ids": list(_SESSIONS.get(sid, [])),
                    "ephemeral_session": True,
                    "global_handler_registry_modified": False,
                }
            else:
                raise ValueError("unsupported loader action")

            return {
                "ok": True,
                "executed": True,
                "message": f"ENG-CAP-142 loader action={action}",
                "evidence": {
                    "loader": report,
                    "loader_digest": _digest(report),
                    "owner_policy_aware": True,
                    "arbitrary_code_loading": False,
                    "authority_preserved": True,
                },
            }
        except Exception as exc:
            return {
                "ok": False,
                "executed": False,
                "message": f"ENG-CAP-142 loader blocked: {type(exc).__name__}: {exc}",
                "evidence": {"error": f"{type(exc).__name__}: {exc}", "fail_closed": True},
            }

    return handler
