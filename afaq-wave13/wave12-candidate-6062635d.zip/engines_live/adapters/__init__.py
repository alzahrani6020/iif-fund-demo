"""Adapter package — wave-6 runtime + CAP domain parity."""

from .runtime import RUNTIME_ADAPTERS
from .cap_domain import make_cap_domain_adapter

__all__ = ["RUNTIME_ADAPTERS", "make_cap_domain_adapter"]
