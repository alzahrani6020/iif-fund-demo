"""Dedicated frontier-discovery runtime for ENG-CAP-154."""

from __future__ import annotations

import hashlib
import json
import re
from typing import Any, Mapping

from capability_cycle.handlers import implemented_ids


_ALLOWED_KINDS = {"technology", "model", "tool", "method"}


def _digest(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _norm(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")


def _score(value: Any, name: str) -> float:
    if isinstance(value, bool):
        raise ValueError(f"{name} must be numeric")
    try:
        out = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be numeric") from exc
    if not 0.0 <= out <= 1.0:
        raise ValueError(f"{name} must be between 0 and 1")
    return out


def make_frontier_discovery_runtime_adapter():
    """ENG-CAP-154: turn evidence-backed emerging signals into gap candidates."""

    def handler(payload: Mapping[str, Any]) -> dict[str, Any]:
        try:
            raw = payload.get("signals")
            if raw is None:
                raw = [
                    {
                        "signal_id": "probe-frontier-1",
                        "kind": "tool",
                        "name": "Example Emerging Tool",
                        "summary": "Evidence-backed tool signal for deterministic runtime verification.",
                        "relevance": 0.9,
                        "maturity": 0.7,
                        "adoption": 0.6,
                        "capability_id": "CAP-EMERGING-PROBE-001",
                        "evidence_refs": ["probe:frontier:1"],
                    }
                ]
            if not isinstance(raw, list) or not raw:
                raise ValueError("signals must be a non-empty list")

            implemented = set(implemented_ids())
            normalized: list[dict[str, Any]] = []
            for index, item in enumerate(raw):
                if not isinstance(item, Mapping):
                    raise ValueError("each frontier signal must be an object")
                kind = str(item.get("kind") or "").strip().lower()
                if kind not in _ALLOWED_KINDS:
                    raise ValueError(f"unsupported frontier kind: {kind}")
                name = str(item.get("name") or "").strip()
                if not name:
                    raise ValueError("frontier signal requires name")
                evidence_refs = sorted({
                    str(x) for x in (item.get("evidence_refs") or []) if str(x).strip()
                })
                if not evidence_refs:
                    raise ValueError("frontier signal requires evidence_refs")
                capability_id = str(
                    item.get("capability_id")
                    or f"CAP-FRONTIER-{_norm(name).upper()[:48]}"
                ).strip()
                relevance = _score(item.get("relevance"), "relevance")
                maturity = _score(item.get("maturity"), "maturity")
                adoption = _score(item.get("adoption"), "adoption")
                novelty = capability_id not in implemented
                priority = round(
                    0.50 * relevance + 0.30 * maturity + 0.20 * adoption,
                    6,
                )
                row = {
                    "signal_id": str(item.get("signal_id") or f"signal-{index+1}"),
                    "kind": kind,
                    "name": name,
                    "summary": str(item.get("summary") or "").strip(),
                    "capability_id": capability_id,
                    "relevance": relevance,
                    "maturity": maturity,
                    "adoption": adoption,
                    "novel_capability": novelty,
                    "priority_score": priority,
                    "evidence_refs": evidence_refs,
                }
                row["signal_digest"] = _digest(row)
                normalized.append(row)

            normalized.sort(
                key=lambda x: (
                    -x["priority_score"],
                    x["capability_id"],
                    x["signal_id"],
                )
            )
            gap_candidates = [
                {
                    "capability_id": row["capability_id"],
                    "signal_id": row["signal_id"],
                    "kind": row["kind"],
                    "name": row["name"],
                    "priority_score": row["priority_score"],
                    "maturity_signal": row["maturity"],
                    "adoption_signal": row["adoption"],
                    "evidence_refs": row["evidence_refs"],
                    "gap_state": "FRONTIER_GAP_CANDIDATE",
                    "requires_gap_proof": True,
                    "automatic_registration": False,
                    "automatic_activation": False,
                }
                for row in normalized
                if row["novel_capability"] and row["relevance"] > 0
            ]
            report = {
                "signals": normalized,
                "frontier_map": {
                    kind: [row["signal_id"] for row in normalized if row["kind"] == kind]
                    for kind in sorted(_ALLOWED_KINDS)
                },
                "gap_candidates": gap_candidates,
                "research_queue": [
                    {
                        "signal_id": row["signal_id"],
                        "capability_id": row["capability_id"],
                        "priority_score": row["priority_score"],
                    }
                    for row in normalized
                    if row["relevance"] >= 0.5
                ],
                "automatic_registration": False,
                "automatic_activation": False,
                "authority_created": False,
            }
            return {
                "ok": True,
                "executed": True,
                "message": f"ENG-CAP-154 analyzed {len(normalized)} frontier signals",
                "evidence": {
                    "frontier": report,
                    "frontier_digest": _digest(report),
                    "evidence_backed": True,
                    "authority_preserved": True,
                },
            }
        except Exception as exc:
            return {
                "ok": False,
                "executed": False,
                "message": f"ENG-CAP-154 frontier discovery blocked: {type(exc).__name__}: {exc}",
                "evidence": {"error": f"{type(exc).__name__}: {exc}", "fail_closed": True},
            }

    return handler
