"""Reviewed benchmark-target policy for ENG-CAP-093.

This finite set is part of the explicit dependency closure. Any change requires
a dependency-review and proof-contract update.
"""

ENG_093_BENCHMARK_TARGETS = frozenset({
    "ENG-CAP-005",
    "ENG-CAP-006",
    "ENG-CAP-091",
    "ENG-CAP-142",
    "ENG-CAP-143",
    "ENG-CAP-153",
    "ENG-CAP-154",
    "ENG-CAP-155",
    "ENG-CAP-156",
    "ENG-CAP-157",
    "ENG-CAP-158",
})
