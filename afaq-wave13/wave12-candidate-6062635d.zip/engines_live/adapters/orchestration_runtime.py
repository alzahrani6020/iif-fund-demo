"""Dedicated orchestration runtimes for ENG-CAP-137/138/139."""

from __future__ import annotations

import hashlib
import json
from collections import Counter, defaultdict
from typing import Any, Mapping

from capability_cycle.planner import Requirement, plan_capabilities
from capability_cycle.runtime import compile_graph, execute_plan


def _digest(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _capability_ids(payload: Mapping[str, Any]) -> tuple[str, ...]:
    raw = payload.get("capability_ids") or ("CAP-AUDIT-001", "CAP-TRUTH-001")
    if not isinstance(raw, (list, tuple)):
        raise ValueError("capability_ids must be a list or tuple")
    ids = tuple(dict.fromkeys(str(x) for x in raw if str(x).strip()))
    if not ids:
        raise ValueError("at least one capability_id is required")
    return ids


def make_composition_runtime_adapter():
    """ENG-CAP-137: compose only existing, implemented capabilities."""

    def handler(payload: Mapping[str, Any]) -> dict[str, Any]:
        try:
            ids = _capability_ids(payload)
            plan = plan_capabilities(Requirement(explicit_capability_ids=ids))
            graph = compile_graph(plan)
        except Exception as exc:
            return {
                "ok": False,
                "executed": False,
                "message": f"ENG-CAP-137 composition failed: {type(exc).__name__}: {exc}",
                "evidence": {"error": f"{type(exc).__name__}: {exc}"},
            }

        ok = plan.status == "COMPOSED" and graph.compiled and not plan.missing
        result = {
            "required_ids": list(plan.required_ids),
            "resolved": list(plan.resolved),
            "missing": list(plan.missing),
            "graph_nodes": list(graph.nodes),
            "graph_reason": graph.reason,
            "temporary_registration": False,
            "genesis_attempted": False,
        }
        return {
            "ok": ok,
            "executed": True,
            "message": "ENG-CAP-137 composed existing capabilities" if ok else plan.reason,
            "evidence": {
                "composition": result,
                "composition_digest": _digest(result),
                "existing_only": True,
                "authority_created": False,
            },
        }

    return handler


def make_mission_graph_runtime_adapter():
    """ENG-CAP-138: compile and execute a bounded mission graph."""

    def handler(payload: Mapping[str, Any]) -> dict[str, Any]:
        try:
            ids = _capability_ids(payload)
            payloads = payload.get("payloads") or {}
            if not isinstance(payloads, Mapping):
                raise ValueError("payloads must be a mapping")
            result = execute_plan(
                Requirement(explicit_capability_ids=ids),
                payloads={str(k): dict(v) for k, v in payloads.items() if isinstance(v, Mapping)},
                max_retries=min(max(int(payload.get("max_retries") or 2), 0), 2),
            )
        except Exception as exc:
            return {
                "ok": False,
                "executed": False,
                "message": f"ENG-CAP-138 mission graph failed: {type(exc).__name__}: {exc}",
                "evidence": {"error": f"{type(exc).__name__}: {exc}"},
            }

        graph = result.graph
        mission = result.mission_verification
        ok = bool(
            result.status == "PASSED"
            and graph is not None
            and graph.compiled
            and mission is not None
            and mission.status == "VERIFIED"
        )
        evidence = {
            "status": result.status,
            "reason": result.reason,
            "graph": {
                "nodes": list(graph.nodes) if graph else [],
                "compiled": bool(graph and graph.compiled),
                "reason": graph.reason if graph else None,
            },
            "retries": result.retries,
            "replan_records": list(result.replan_records),
            "mission_verification": mission.as_dict() if mission else None,
            "performance_record_ids": list(result.performance_record_ids),
            "bounded_replan": result.retries <= 2,
        }
        evidence["mission_digest"] = _digest(evidence)
        return {
            "ok": ok,
            "executed": True,
            "message": "ENG-CAP-138 mission graph verified" if ok else result.reason,
            "evidence": evidence,
        }

    return handler


def make_result_fusion_runtime_adapter():
    """ENG-CAP-139: evidence-preserving deterministic result fusion."""

    def handler(payload: Mapping[str, Any]) -> dict[str, Any]:
        raw = payload.get("results")
        if raw is None:
            raw = [
                {"source": "a", "value": "PASS", "confidence": 0.9},
                {"source": "b", "value": "PASS", "confidence": 0.8},
                {"source": "c", "value": "REVIEW", "confidence": 0.6},
            ]
        if not isinstance(raw, list) or not raw:
            return {
                "ok": False,
                "executed": False,
                "message": "ENG-CAP-139 requires non-empty results",
                "evidence": {"reason": "RESULTS_REQUIRED"},
            }

        normalized = []
        for index, item in enumerate(raw):
            if not isinstance(item, Mapping):
                return {
                    "ok": False,
                    "executed": False,
                    "message": "ENG-CAP-139 result item must be an object",
                    "evidence": {"index": index},
                }
            source = str(item.get("source") or f"source-{index+1}")
            value = item.get("value")
            confidence = float(item.get("confidence", 0.5))
            confidence = max(0.0, min(1.0, confidence))
            normalized.append({
                "source": source,
                "value": value,
                "confidence": confidence,
                "evidence_refs": list(item.get("evidence_refs") or []),
            })

        groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for item in normalized:
            key = json.dumps(item["value"], ensure_ascii=False, sort_keys=True, default=str)
            groups[key].append(item)

        ranked = sorted(
            groups.items(),
            key=lambda kv: (
                -len(kv[1]),
                -sum(x["confidence"] for x in kv[1]),
                kv[0],
            ),
        )
        winner_key, winner_items = ranked[0]
        winner_value = json.loads(winner_key)
        total = len(normalized)
        consensus = len(winner_items) / total
        conflicts = len(groups) > 1
        minorities = [
            {
                "value": json.loads(key),
                "sources": [x["source"] for x in items],
                "confidence_weight": round(sum(x["confidence"] for x in items), 6),
            }
            for key, items in ranked[1:]
        ]
        fused = {
            "value": winner_value,
            "consensus": round(consensus, 6),
            "conflict_detected": conflicts,
            "uncertainty": round(1.0 - consensus, 6),
            "supporting_sources": [x["source"] for x in winner_items],
            "minority_results": minorities,
            "source_lineage": normalized,
        }
        return {
            "ok": True,
            "executed": True,
            "message": "ENG-CAP-139 fused results with disagreement preserved",
            "evidence": {
                "fusion": fused,
                "fusion_digest": _digest(fused),
                "minority_preserved": True,
                "uncertainty_propagated": True,
            },
        }

    return handler
