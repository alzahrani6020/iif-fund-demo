"""Dedicated operational adapters for ENG-CAP-005 / ENG-CAP-006."""

from __future__ import annotations

import hashlib
import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from afaq_agent_runtime.capability_foundation_core import (
    execute_foundation_engine,
)
from engines_live.authority_gate import require_execute_allow

REPO_ROOT = Path(__file__).resolve().parents[2]
RUNS_DIR = REPO_ROOT / "var" / "engine_runs"


def _load_shared(path: str | None) -> dict[str, Any] | None:
    if not path:
        return None

    full = REPO_ROOT / path

    try:
        return json.loads(full.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def _write_evidence(
    engine_id: str,
    result: Mapping[str, Any],
) -> str:
    run_id = f"RUN-{uuid.uuid4().hex[:12]}"

    directory = RUNS_DIR / engine_id
    directory.mkdir(parents=True, exist_ok=True)

    path = directory / f"{run_id}.json"
    tmp = directory / f"{run_id}.json.tmp"

    document = {
        "run_id": run_id,
        "engine_id": engine_id,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "runtime_kind": "DEDICATED_CAPABILITY_FOUNDATION",
        "result": dict(result),
    }

    tmp.write_text(
        json.dumps(
            document,
            ensure_ascii=False,
            indent=2,
            default=str,
        ) + "\n",
        encoding="utf-8",
    )

    os.replace(tmp, path)

    return str(path.relative_to(REPO_ROOT))


def make_capability_foundation_adapter(
    *,
    engine_id: str,
    shared_engine_file: str | None,
):
    if engine_id not in {"ENG-CAP-005", "ENG-CAP-006"}:
        raise ValueError(
            f"unsupported dedicated foundation engine: {engine_id}"
        )

    def handler(payload: Mapping[str, Any]) -> dict[str, Any]:

        gate = require_execute_allow(engine_id=engine_id)

        if not gate.allowed:
            return {
                "ok": False,
                "executed": False,
                "runtime_implementation": True,
                "message": (
                    f"{engine_id} BLOCKED by authority: "
                    f"{gate.decision.reason}"
                ),
                "bound_capabilities": [],
                "missing_capabilities": [],
                "evidence": {
                    "authority": gate.as_dict(),
                    "runtime_kind":
                        "DEDICATED_CAPABILITY_FOUNDATION",
                },
            }

        shared = _load_shared(shared_engine_file)

        try:
            result = execute_foundation_engine(
                engine_id,
                dict(payload),
                shared,
            )
        except Exception as exc:
            return {
                "ok": False,
                "executed": False,
                "runtime_implementation": True,
                "message": (
                    f"{engine_id} dedicated runtime failed: "
                    f"{type(exc).__name__}: {exc}"
                ),
                "bound_capabilities": [],
                "missing_capabilities": [],
                "evidence": {
                    "authority": gate.as_dict(),
                    "runtime_kind":
                        "DEDICATED_CAPABILITY_FOUNDATION",
                    "error":
                        f"{type(exc).__name__}: {exc}",
                },
            }

        result_bytes = json.dumps(
            result,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            default=str,
        ).encode("utf-8")
        artifact_digest = hashlib.sha256(result_bytes).hexdigest()

        evidence = {
            "authority": gate.as_dict(),
            "runtime_kind":
                "DEDICATED_CAPABILITY_FOUNDATION",
            "shared_engine_loaded": shared is not None,
            "result": result,
            "result_sha256": artifact_digest,
            "steps": [
                {
                    "capability": "foundation_runtime_result",
                    "status": "EXECUTED",
                    "executed": True,
                    "artifact_digest": artifact_digest,
                }
            ],
        }

        run_path = _write_evidence(
            engine_id,
            evidence,
        )
        evidence["run_path"] = run_path

        return {
            "ok": bool(result.get("ok", True)),
            "executed": True,
            "runtime_implementation": True,
            "message": (
                f"{engine_id} dedicated capability "
                "foundation runtime executed"
            ),
            "bound_capabilities":
                list(result.get("bound_capabilities") or []),
            "missing_capabilities":
                list(result.get("missing_capabilities") or []),
            "evidence": evidence,
        }

    return handler
