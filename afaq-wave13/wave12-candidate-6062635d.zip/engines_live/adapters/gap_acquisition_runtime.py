"""Dedicated gap-acquisition orchestrator for ENG-CAP-143.

Searches AFAQ-owned runtime truth before proposing a genesis handoff.
External providers are evidence-only and can never resolve a capability gap.
The adapter never self-authorizes, registers, activates, or promotes a capability.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Mapping

from capability_cycle.handlers import candidate_ids, implemented_ids
from capability_cycle.planner import Requirement, plan_capabilities
from web_acquisition.gap_proof import prove_gap
from afaq_registry.loader import load_registry

REPO_ROOT = Path(__file__).resolve().parents[2]
PROVIDER_REGISTRY = REPO_ROOT / "provider_adapters" / "RUNTIME_REGISTRY.json"


def _digest(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _requested_ids(payload: Mapping[str, Any]) -> tuple[str, ...]:
    raw = payload.get("required_capability_ids")
    if raw is None:
        raw = payload.get("capability_ids")
    if raw is None:
        raw = ("CAP-NOT-REAL-999",)
    if not isinstance(raw, (list, tuple)):
        raise ValueError("required_capability_ids must be a list or tuple")
    ids = tuple(dict.fromkeys(str(x).strip() for x in raw if str(x).strip()))
    if not ids:
        raise ValueError("at least one required capability id is required")
    return ids


def _load_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def _package_matches(requested: tuple[str, ...]) -> list[dict[str, Any]]:
    merged = load_registry()
    wanted = set(requested)
    matches: list[dict[str, Any]] = []
    for engine in merged.get("engines") or []:
        if not isinstance(engine, Mapping):
            continue
        required = {
            str(x)
            for x in (engine.get("required_capabilities") or [])
            if isinstance(x, str)
        }
        overlap = sorted(wanted & required)
        if not overlap:
            continue
        matches.append({
            "engine_id": engine.get("engine_id"),
            "capability_ids": overlap,
            "package_ids": list(engine.get("capability_packages") or []),
            "runtime_implementation": bool(engine.get("runtime_implementation")),
        })
    return matches


def _provider_candidates() -> list[dict[str, Any]]:
    runtime = _load_json(PROVIDER_REGISTRY)
    providers = runtime.get("providers") or {}
    if not isinstance(providers, Mapping):
        return []
    out = []
    for provider_id, record in providers.items():
        if not isinstance(record, Mapping):
            continue
        out.append({
            "provider_id": str(provider_id),
            "verified": bool(record.get("verified")),
            "status": record.get("status"),
            "capabilities": list(record.get("capabilities") or []),
        })
    return out


def make_gap_acquisition_runtime_adapter():
    """ENG-CAP-143: prove gaps and return a governed resolution/handoff path."""

    def handler(payload: Mapping[str, Any]) -> dict[str, Any]:
        try:
            requested = _requested_ids(payload)
            implemented = set(implemented_ids())
            existing = sorted(set(requested) & implemented)
            missing = sorted(set(requested) - implemented)

            package_matches = _package_matches(requested)
            providers = _provider_candidates()
            verified_providers = [p for p in providers if p["verified"]]
            candidates = sorted(set(requested) & set(candidate_ids()))

            composition = plan_capabilities(
                Requirement(explicit_capability_ids=requested)
            )
            composition_satisfies = (
                composition.status == "COMPOSED"
                and not composition.missing
                and set(composition.required_ids) == set(requested)
            )

            checks = {
                "reuse": {
                    "checked": True,
                    "satisfies_requirement": not missing,
                    "evidence_refs": [
                        "handlers:" + hashlib.sha256(
                            ",".join(sorted(implemented)).encode("utf-8")
                        ).hexdigest()
                    ],
                },
                "composition": {
                    "checked": True,
                    "satisfies_requirement": composition_satisfies,
                    "evidence_refs": [
                        "composition:" + _digest({
                            "status": composition.status,
                            "required_ids": list(composition.required_ids),
                            "missing": list(composition.missing),
                        })
                    ],
                },
                "provider": {
                    "checked": True,
                    # External providers are observation-only. They can inform
                    # evidence, but they are never allowed to satisfy an AFAQ
                    # capability gap. AFAQ must reuse, compose, or build its
                    # own capability artifact.
                    "satisfies_requirement": False,
                    "evidence_refs": [
                        "provider-registry-observed-only:" + _digest(providers)
                    ],
                },
                "extension": {
                    "checked": True,
                    "satisfies_requirement": bool(candidates),
                    "evidence_refs": [
                        "candidate-registry:" + _digest(candidates)
                    ],
                },
            }
            proof = prove_gap(checks)

            if not missing:
                resolution = "EXISTING_CAPABILITY"
            elif composition_satisfies:
                resolution = "EXISTING_COMPOSITION"
            elif candidates:
                resolution = "EXISTING_UNACTIVATED_CANDIDATE"
            elif proof.state == "REAL_GAP_PROVEN":
                resolution = "GENESIS_HANDOFF_REQUIRED"
            else:
                resolution = "UNRESOLVED"

            handoff = {
                "requested_capability_ids": list(requested),
                "existing_capability_ids": existing,
                "missing_capability_ids": missing,
                "package_matches": package_matches,
                "verified_provider_candidates": verified_providers,
                "external_provider_candidates_observed": verified_providers,
                "external_provider_resolution_allowed": False,
                "registered_candidate_ids": candidates,
                "gap_proof": proof.as_dict(),
                "resolution": resolution,
                "new_capability_contract_generation": resolution == "GENESIS_HANDOFF_REQUIRED",
                "implementation_candidate_request": resolution == "GENESIS_HANDOFF_REQUIRED",
                "sandbox_handoff_required": resolution == "GENESIS_HANDOFF_REQUIRED",
                "benchmark_handoff_required": resolution == "GENESIS_HANDOFF_REQUIRED",
                "security_review_handoff_required": resolution == "GENESIS_HANDOFF_REQUIRED",
                "recovery_test_handoff_required": resolution == "GENESIS_HANDOFF_REQUIRED",
                "registration_handoff_required": resolution == "GENESIS_HANDOFF_REQUIRED",
                "automatic_registration": False,
                "automatic_activation": False,
                "automatic_production_admission": False,
                "mission_resume_allowed": resolution in {
                    "EXISTING_CAPABILITY",
                    "EXISTING_COMPOSITION",
                },
            }
            ok = proof.state in {"NO_REAL_GAP", "REAL_GAP_PROVEN"}
            return {
                "ok": ok,
                "executed": True,
                "message": f"ENG-CAP-143 resolution={resolution}",
                "evidence": {
                    "handoff": handoff,
                    "handoff_digest": _digest(handoff),
                    "authority_created": False,
                    "genesis_executed": False,
                    "fail_closed": True,
                },
            }
        except Exception as exc:
            return {
                "ok": False,
                "executed": False,
                "message": f"ENG-CAP-143 gap acquisition failed: {type(exc).__name__}: {exc}",
                "evidence": {"error": f"{type(exc).__name__}: {exc}"},
            }

    return handler
