"""Fail-closed identity resolution runtimes for ENG-CAP-159/160."""
from __future__ import annotations
import re
import unicodedata
from typing import Any, Mapping
from urllib.parse import urlparse

IDENTITY_STATES = ("VERIFIED", "AMBIGUOUS", "CONTRADICTED", "INSUFFICIENT_EVIDENCE")
_DIACRITICS = re.compile(r"[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED]")
_NON_WORD = re.compile(r"[\W_]+", re.UNICODE)

def _norm(value: Any) -> str:
    text = unicodedata.normalize("NFKC", str(value or "")).casefold().strip().replace("\u0640", "")
    text = _DIACRITICS.sub("", text)
    for old, new in (("\u0622","\u0627"),("\u0623","\u0627"),("\u0625","\u0627"),("\u0671","\u0627"),
                     ("\u0649","\u064A"),("\u0624","\u0648"),("\u0626","\u064A")):
        text = text.replace(old, new)
    return _NON_WORD.sub("", text)

def _list(value: Any) -> list[str]:
    if value is None: return []
    if not isinstance(value, list): raise ValueError("expected a list")
    return [str(x).strip() for x in value if str(x).strip()]

def _fail(engine: str, kind: str, message: str) -> dict[str, Any]:
    return {"ok":False,"executed":False,"message":f"{engine} {message}",
            "evidence":{"failure_class":kind,"fail_closed":True,
                        "authority_preserved":True,"automatic_persistence":False}}

def _people(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list): raise ValueError("candidates must be a list")
    out=[]
    for raw in value:
        if not isinstance(raw, Mapping): raise ValueError("each candidate must be an object")
        pid=str(raw.get("person_id") or "").strip(); name=str(raw.get("canonical_name") or "").strip()
        if not pid or not name: raise ValueError("person_id and canonical_name are required")
        q=raw.get("qualifiers") or {}
        if not isinstance(q, Mapping): raise ValueError("qualifiers must be an object")
        out.append({"person_id":pid,"canonical_name":name,"aliases":_list(raw.get("aliases")),
                    "qualifiers":{str(k):str(v) for k,v in q.items() if str(k).strip() and str(v).strip()},
                    "evidence_refs":_list(raw.get("evidence_refs"))})
    return out

def make_person_identity_resolver_adapter():
    def handler(payload: Mapping[str, Any]) -> dict[str, Any]:
        if not isinstance(payload, Mapping): return _fail("ENG-CAP-159","INVALID_PAYLOAD","payload must be an object")
        mention=str(payload.get("mention") or payload.get("name") or "").strip()
        if not mention: return _fail("ENG-CAP-159","MISSING_MENTION","person mention is required")
        try: candidates=_people(payload.get("candidates"))
        except ValueError as exc: return _fail("ENG-CAP-159","INVALID_CANDIDATES",str(exc))
        if not candidates: return _fail("ENG-CAP-159","EMPTY_CANDIDATES","candidate set is empty")
        context=payload.get("context") or {}
        if not isinstance(context, Mapping): return _fail("ENG-CAP-159","INVALID_CONTEXT","context must be an object")
        key=_norm(mention); matches=[]; hitmap={}
        for c in candidates:
            hits=[n for n in [c["canonical_name"],*c["aliases"]] if _norm(n)==key]
            if hits: matches.append(c); hitmap[c["person_id"]]=hits
        if not matches:
            resolution={"state":"INSUFFICIENT_EVIDENCE","mention":mention,"normalized_input":key,
                        "person_id":None,"canonical_name":None,"candidate_count":0,
                        "ambiguity_candidates":[],"matched_aliases":[]}
            return {"ok":False,"executed":True,"message":"ENG-CAP-159 identity unresolved",
                    "evidence":{"resolution":resolution,"language_agnostic_alias_matching":True,
                                "unsupported_transliteration_inference":False,"fail_closed":True,
                                "authority_preserved":True,"automatic_persistence":False}}
        matched={}; conflicts={}
        for c in matches:
            pid=c["person_id"]; matched[pid]=0; conflicts[pid]=0
            for k,v in context.items():
                if str(k) not in c["qualifiers"] or not str(v).strip(): continue
                if _norm(c["qualifiers"][str(k)])==_norm(v): matched[pid]+=1
                else: conflicts[pid]+=1
        viable=[c for c in matches if conflicts[c["person_id"]]==0]; selected=None
        if context and not viable: state="CONTRADICTED"
        else:
            pool=viable or matches
            if context:
                top=max(matched[c["person_id"]] for c in pool)
                if top>0: pool=[c for c in pool if matched[c["person_id"]]==top]
            if len(pool)>1: state="AMBIGUOUS"
            elif pool[0]["evidence_refs"]: state="VERIFIED"; selected=pool[0]
            else: state="INSUFFICIENT_EVIDENCE"
        resolution={"state":state,"mention":mention,"normalized_input":key,
                    "person_id":selected["person_id"] if selected else None,
                    "canonical_name":selected["canonical_name"] if selected else None,
                    "candidate_count":len(matches),
                    "ambiguity_candidates":[{"person_id":c["person_id"],"canonical_name":c["canonical_name"]} for c in matches] if state=="AMBIGUOUS" else [],
                    "matched_aliases":hitmap.get(selected["person_id"],[]) if selected else [],
                    "evidence_refs":selected["evidence_refs"] if selected else [],
                    "context_matches":matched,"context_conflicts":conflicts}
        return {"ok":state=="VERIFIED","executed":True,"message":f"ENG-CAP-159 identity state={state}",
                "evidence":{"resolution":resolution,"language_agnostic_alias_matching":True,
                            "unsupported_transliteration_inference":False,"fail_closed":state!="VERIFIED",
                            "authority_preserved":True,"automatic_persistence":False}}
    return handler

def _host(value: Any) -> str:
    raw=str(value or "").strip().lower()
    if not raw: return ""
    parsed=urlparse(raw if "://" in raw else "https://"+raw)
    host=(parsed.hostname or "").strip(".").lower()
    return host[4:] if host.startswith("www.") else host

def _publishers(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value,list): raise ValueError("candidates must be a list")
    out=[]
    for raw in value:
        if not isinstance(raw,Mapping): raise ValueError("each candidate must be an object")
        pid=str(raw.get("publisher_id") or "").strip(); name=str(raw.get("canonical_name") or "").strip()
        if not pid or not name: raise ValueError("publisher_id and canonical_name are required")
        out.append({"publisher_id":pid,"canonical_name":name,"aliases":_list(raw.get("aliases")),
                    "domains":[d for d in (_host(x) for x in _list(raw.get("domains"))) if d],
                    "evidence_refs":_list(raw.get("evidence_refs"))})
    return out

def make_publisher_identity_resolver_adapter():
    def handler(payload: Mapping[str, Any]) -> dict[str, Any]:
        if not isinstance(payload,Mapping): return _fail("ENG-CAP-160","INVALID_PAYLOAD","payload must be an object")
        source=payload.get("source")
        if not isinstance(source,Mapping): return _fail("ENG-CAP-160","INVALID_SOURCE","source must be an object")
        try: candidates=_publishers(payload.get("candidates"))
        except ValueError as exc: return _fail("ENG-CAP-160","INVALID_CANDIDATES",str(exc))
        if not candidates: return _fail("ENG-CAP-160","EMPTY_CANDIDATES","candidate set is empty")
        label=str(source.get("publisher") or source.get("publisher_name") or source.get("site_name") or source.get("name") or "").strip()
        host=_host(source.get("url") or source.get("domain")); label_key=_norm(label)
        alias_ids=set(); domain_ids=set(); by_id={c["publisher_id"]:c for c in candidates}
        for c in candidates:
            if label_key and any(_norm(n)==label_key for n in [c["canonical_name"],*c["aliases"]]): alias_ids.add(c["publisher_id"])
            if host and any(host==d or host.endswith("."+d) for d in c["domains"]): domain_ids.add(c["publisher_id"])
        if alias_ids and domain_ids and not (alias_ids & domain_ids): state="CONTRADICTED"; pool=alias_ids|domain_ids
        elif alias_ids and domain_ids: pool=alias_ids&domain_ids; state="VERIFIED" if len(pool)==1 else "AMBIGUOUS"
        else:
            pool=alias_ids or domain_ids
            state="INSUFFICIENT_EVIDENCE" if not pool else ("AMBIGUOUS" if len(pool)>1 else "VERIFIED")
        selected=by_id[next(iter(pool))] if state=="VERIFIED" else None
        if selected is not None and not selected["evidence_refs"]: state="INSUFFICIENT_EVIDENCE"; selected=None
        identity={"state":state,"publisher_id":selected["publisher_id"] if selected else None,
                  "canonical_name":selected["canonical_name"] if selected else None,
                  "independent_publisher_key":selected["publisher_id"] if selected else None,
                  "evidence_refs":selected["evidence_refs"] if selected else [],
                  "source_signals":{"label":label or None,"normalized_label":label_key or None,"host":host or None,
                                    "alias_candidate_ids":sorted(alias_ids),"domain_candidate_ids":sorted(domain_ids)},
                  "ambiguity_candidates":sorted(pool) if state in {"AMBIGUOUS","CONTRADICTED"} else []}
        return {"ok":state=="VERIFIED","executed":True,"message":f"ENG-CAP-160 publisher identity state={state}",
                "evidence":{"publisher_identity":identity,"canonical_publisher_independence_enforced":True,
                            "domain_subdomain_normalization":True,"fail_closed":state!="VERIFIED",
                            "authority_preserved":True,"automatic_persistence":False}}
    return handler
