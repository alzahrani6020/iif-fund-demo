"""Dedicated comparative benchmark observatory for ENG-CAP-155."""

from __future__ import annotations

import hashlib
import json
import statistics
from typing import Any, Mapping


METRICS = (
    "quality",
    "latency_ms",
    "cost",
    "coverage",
    "reliability",
    "resource_efficiency",
)


def _digest(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _number(value: Any, *, name: str, minimum: float = 0.0) -> float:
    if isinstance(value, bool):
        raise ValueError(f"{name} must be numeric")
    try:
        out = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be numeric") from exc
    if out < minimum:
        raise ValueError(f"{name} must be >= {minimum}")
    return out


def _normalize_observation(item: Mapping[str, Any], index: int) -> dict[str, Any]:
    subject = str(item.get("subject") or "").strip()
    if subject not in {"baseline", "candidate"}:
        raise ValueError("benchmark observation subject must be baseline or candidate")
    case_id = str(item.get("case_id") or f"case-{index+1}")
    evidence_refs = tuple(str(x) for x in (item.get("evidence_refs") or ()) if str(x).strip())
    if not evidence_refs:
        raise ValueError("benchmark observation requires evidence_refs")
    metrics = item.get("metrics")
    if not isinstance(metrics, Mapping):
        raise ValueError("benchmark observation requires metrics")
    normalized = {
        "quality": _number(metrics.get("quality"), name="quality"),
        "latency_ms": _number(metrics.get("latency_ms"), name="latency_ms"),
        "cost": _number(metrics.get("cost"), name="cost"),
        "coverage": _number(metrics.get("coverage"), name="coverage"),
        "reliability": _number(metrics.get("reliability"), name="reliability"),
        "resource_efficiency": _number(metrics.get("resource_efficiency"), name="resource_efficiency"),
    }
    for key in ("quality", "coverage", "reliability", "resource_efficiency"):
        if normalized[key] > 1.0:
            raise ValueError(f"{key} must be between 0 and 1")
    return {
        "case_id": case_id,
        "subject": subject,
        "metrics": normalized,
        "evidence_refs": list(evidence_refs),
        "observation_digest": _digest({
            "case_id": case_id,
            "subject": subject,
            "metrics": normalized,
            "evidence_refs": list(evidence_refs),
        }),
    }


def _median(rows: list[dict[str, Any]], metric: str) -> float:
    return round(statistics.median(row["metrics"][metric] for row in rows), 6)


def make_benchmark_observatory_runtime_adapter():
    """ENG-CAP-155: reproducible evidence-backed capability comparison."""

    def handler(payload: Mapping[str, Any]) -> dict[str, Any]:
        try:
            raw = payload.get("observations")
            if raw is None:
                raw = [
                    {
                        "case_id": "probe-1",
                        "subject": "baseline",
                        "metrics": {
                            "quality": 0.90,
                            "latency_ms": 100,
                            "cost": 1.0,
                            "coverage": 0.90,
                            "reliability": 0.99,
                            "resource_efficiency": 0.80,
                        },
                        "evidence_refs": ["probe:baseline"],
                    },
                    {
                        "case_id": "probe-1",
                        "subject": "candidate",
                        "metrics": {
                            "quality": 0.92,
                            "latency_ms": 90,
                            "cost": 0.9,
                            "coverage": 0.91,
                            "reliability": 0.99,
                            "resource_efficiency": 0.82,
                        },
                        "evidence_refs": ["probe:candidate"],
                    },
                ]
            if not isinstance(raw, list) or not raw:
                raise ValueError("observations must be a non-empty list")
            rows = [_normalize_observation(x, i) for i, x in enumerate(raw) if isinstance(x, Mapping)]
            baseline = [x for x in rows if x["subject"] == "baseline"]
            candidate = [x for x in rows if x["subject"] == "candidate"]
            if not baseline or not candidate:
                raise ValueError("both baseline and candidate observations are required")
            baseline_cases = {x["case_id"] for x in baseline}
            candidate_cases = {x["case_id"] for x in candidate}
            if baseline_cases != candidate_cases:
                raise ValueError("baseline and candidate case sets must match")

            medians = {
                "baseline": {metric: _median(baseline, metric) for metric in METRICS},
                "candidate": {metric: _median(candidate, metric) for metric in METRICS},
            }
            comparison: dict[str, Any] = {}
            deficits: list[str] = []
            advantages: list[str] = []
            for metric in METRICS:
                b = medians["baseline"][metric]
                c = medians["candidate"][metric]
                lower_is_better = metric in {"latency_ms", "cost"}
                delta = round(c - b, 6)
                if c == b:
                    state = "EQUAL"
                elif (c < b) if lower_is_better else (c > b):
                    state = "CANDIDATE_BETTER"
                    advantages.append(metric)
                else:
                    state = "CANDIDATE_WORSE"
                    deficits.append(metric)
                comparison[metric] = {
                    "baseline": b,
                    "candidate": c,
                    "delta": delta,
                    "state": state,
                    "direction": "LOWER_IS_BETTER" if lower_is_better else "HIGHER_IS_BETTER",
                }

            reproducibility = {
                "case_ids": sorted(baseline_cases),
                "observation_digests": sorted(x["observation_digest"] for x in rows),
                "evidence_refs": sorted({
                    ref for row in rows for ref in row["evidence_refs"]
                }),
            }
            report = {
                "benchmark_definition": {
                    "metrics": list(METRICS),
                    "paired_cases_required": True,
                    "evidence_required": True,
                },
                "medians": medians,
                "comparison": comparison,
                "deficits": deficits,
                "advantages": advantages,
                "gap_detected": bool(deficits),
                "regression_signal": bool(deficits),
                "overtake_signal": bool(advantages) and not deficits,
                "improvement_candidates": [
                    {"metric": metric, "reason": "CANDIDATE_BELOW_BASELINE"}
                    for metric in deficits
                ],
                "reproducibility": reproducibility,
            }
            return {
                "ok": True,
                "executed": True,
                "message": "ENG-CAP-155 benchmark comparison completed",
                "evidence": {
                    "benchmark": report,
                    "benchmark_digest": _digest(report),
                    "caller_callable_execution": False,
                    "evidence_backed": True,
                },
            }
        except Exception as exc:
            return {
                "ok": False,
                "executed": False,
                "message": f"ENG-CAP-155 benchmark blocked: {type(exc).__name__}: {exc}",
                "evidence": {"error": f"{type(exc).__name__}: {exc}", "fail_closed": True},
            }

    return handler
