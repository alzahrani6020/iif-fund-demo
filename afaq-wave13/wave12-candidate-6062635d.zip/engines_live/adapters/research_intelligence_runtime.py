"""Dedicated evidence-verification and research-synthesis runtimes."""

from __future__ import annotations

import hashlib
import json
from typing import Any, Mapping

from engines_live.adapters.identity_resolution_runtime import make_publisher_identity_resolver_adapter

from afaq_agent_runtime.research_intelligence import (
    research_readiness,
    research_topic,
    run_research_gates,
)


def _digest(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _topic(payload: Mapping[str, Any]) -> str:
    topic = str(
        payload.get("topic")
        or payload.get("query")
        or payload.get("text")
        or "engine verification"
    ).strip()
    if not topic:
        raise ValueError("topic is required")
    return topic


def _sources(payload: Mapping[str, Any], topic: str) -> list[dict[str, Any]]:
    raw = payload.get("sources")
    if raw is None:
        return [
            {
                "id": "official-1",
                "title": f"{topic} official report",
                "publisher": "AFAQ Test Authority",
                "kind": "official",
                "published": "2026",
                "author": "Verification Team",
                "text": (
                    f"According to the 2026 report, {topic} reached 95 percent coverage. "
                    f"The report states that {topic} is evidence-backed."
                ),
            },
            {
                "id": "reference-1",
                "title": f"{topic} reference review",
                "publisher": "Independent Reference",
                "kind": "reference",
                "published": "2026",
                "author": "Review Team",
                "text": (
                    f"A 2026 study reports that {topic} reached 95 percent coverage. "
                    f"The evidence says {topic} is evidence-backed."
                ),
            },
        ]
    if not isinstance(raw, list):
        raise ValueError("sources must be a list")
    return [dict(x) for x in raw if isinstance(x, Mapping)]


def _research(payload: Mapping[str, Any]) -> tuple[str, dict[str, Any], list[str], dict[str, Any]]:
    topic = _topic(payload)
    report = research_topic(topic, _sources(payload, topic))
    failures = run_research_gates(report, topic)
    readiness = research_readiness(report, failures)
    return topic, report, failures, readiness


def make_evidence_verification_runtime_adapter():
    """ENG-CAP-147: verify evidence without promoting unresolved claims."""

    def handler(payload: Mapping[str, Any]) -> dict[str, Any]:
        try:
            topic, report, failures, readiness = _research(payload)
        except Exception as exc:
            return {
                "ok": False,
                "executed": False,
                "message": f"ENG-CAP-147 verification failed: {type(exc).__name__}: {exc}",
                "evidence": {"error": f"{type(exc).__name__}: {exc}"},
            }

        analysis = dict(report.get("analysis") or {})
        conflicts = list(analysis.get("conflicts") or [])
        sources = list(report.get("sources") or [])
        facts = list(report.get("facts") or [])
        publisher_candidates = payload.get("publisher_candidates")
        publisher_identity_rows = []
        if isinstance(publisher_candidates, list) and publisher_candidates:
            publisher_resolver = make_publisher_identity_resolver_adapter()
            verified_publisher_keys = set()
            for source in sources:
                if not isinstance(source, Mapping):
                    continue
                identity_result = publisher_resolver({
                    "source": source,
                    "candidates": publisher_candidates,
                })
                identity = dict((identity_result.get("evidence") or {}).get("publisher_identity") or {})
                publisher_identity_rows.append({
                    "source_id": source.get("id"),
                    "state": identity.get("state"),
                    "publisher_id": identity.get("publisher_id"),
                    "canonical_name": identity.get("canonical_name"),
                    "independent_publisher_key": identity.get("independent_publisher_key"),
                })
                if identity_result.get("ok") and identity.get("independent_publisher_key"):
                    verified_publisher_keys.add(str(identity["independent_publisher_key"]))
            source_publishers = verified_publisher_keys
            publisher_identity_mode = "ENG-CAP-160_VERIFIED"
        else:
            source_publishers = {
                str(source.get("publisher") or "").strip().lower()
                for source in sources
                if isinstance(source, Mapping) and str(source.get("publisher") or "").strip()
            }
            publisher_identity_mode = "LEGACY_LABEL_FALLBACK_UNVERIFIED"
        verified_sources = [
            s for s in sources
            if isinstance(s, Mapping)
            and (s.get("verification") or {}).get("uncertainty") in {"low", "medium"}
        ]
        if not readiness.get("ready"):
            state = "INSUFFICIENT_EVIDENCE"
        elif conflicts:
            state = "CONTESTED"
        else:
            state = "SUPPORTED"

        result = {
            "topic": topic,
            "verification_state": state,
            "source_count": len(sources),
            "verified_source_count": len(verified_sources),
            "independent_publisher_count": len(source_publishers),
            "publisher_identity_mode": publisher_identity_mode,
            "publisher_identity_rows": publisher_identity_rows,
            "facts": facts,
            "consensus": list(analysis.get("consensus") or []),
            "contradictions": conflicts,
            "coverage": analysis.get("coverage"),
            "confidence": dict(report.get("confidence") or {}),
            "residual_uncertainty": list(report.get("open_questions") or []),
            "gate_failures": list(failures),
            "readiness": readiness,
        }
        return {
            "ok": bool(readiness.get("ready")),
            "executed": True,
            "message": f"ENG-CAP-147 evidence state={state}",
            "evidence": {
                "verification": result,
                "verification_digest": _digest(result),
                "claim_promotion_allowed": state == "SUPPORTED",
                "authority_preserved": True,
            },
        }

    return handler


def make_research_synthesis_runtime_adapter():
    """ENG-CAP-148: synthesize verified research while preserving unknowns."""

    def handler(payload: Mapping[str, Any]) -> dict[str, Any]:
        try:
            topic, report, failures, readiness = _research(payload)
        except Exception as exc:
            return {
                "ok": False,
                "executed": False,
                "message": f"ENG-CAP-148 synthesis failed: {type(exc).__name__}: {exc}",
                "evidence": {"error": f"{type(exc).__name__}: {exc}"},
            }

        sources = list(report.get("sources") or [])
        facts = list(report.get("facts") or [])
        source_by_id = {
            str(s.get("id")): {
                "title": s.get("title"),
                "publisher": s.get("publisher"),
                "verification": s.get("verification"),
            }
            for s in sources
            if isinstance(s, Mapping) and s.get("id")
        }
        evidence_map = [
            {
                "claim": fact.get("claim"),
                "source_id": fact.get("source_id"),
                "source": source_by_id.get(str(fact.get("source_id"))),
                "uncertainty": fact.get("uncertainty"),
            }
            for fact in facts
            if isinstance(fact, Mapping)
        ]
        synthesis = {
            "topic": topic,
            "known": [fact.get("claim") for fact in facts if isinstance(fact, Mapping)],
            "unknown": list(report.get("open_questions") or []),
            "evidence_map": evidence_map,
            "analysis": dict(report.get("analysis") or {}),
            "confidence": dict(report.get("confidence") or {}),
            "question_coverage": (report.get("analysis") or {}).get("coverage"),
            "gate_failures": list(failures),
            "readiness": readiness,
            "knowledge_update_candidate": bool(readiness.get("ready")),
            "world_model_update_candidate": bool(readiness.get("ready")),
            "automatic_persistence": False,
        }
        return {
            "ok": bool(readiness.get("ready")),
            "executed": True,
            "message": "ENG-CAP-148 research synthesis completed",
            "evidence": {
                "synthesis": synthesis,
                "synthesis_digest": _digest(synthesis),
                "uncertainty_preserved": True,
                "provenance_preserved": True,
                "automatic_persistence": False,
            },
        }

    return handler
