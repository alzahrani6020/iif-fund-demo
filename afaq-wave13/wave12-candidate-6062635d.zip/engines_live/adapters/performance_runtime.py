"""Dedicated performance adapters for ENG-CAP-093/141/152."""

from __future__ import annotations

from typing import Any, Mapping

from capability_cycle.performance_lab import (
    benchmark_engines,
    latest_benchmark_metrics,
    performance_store,
    persist_benchmark,
    persist_profile,
    profile_from_payload,
    recommend_subject,
    record_selection_feedback,
)
from capability_cycle.performance_profiler import benchmark_executor
from capability_cycle.benchmark_suite import cases_from_payload, run_benchmark_suite
from capability_cycle.performance_primitives import (
    bottleneck_localization,
    detect_performance_regression,
    latency_budget_check,
    quality_cost_latency_optimizer,
)
from .performance_benchmark_policy import ENG_093_BENCHMARK_TARGETS


def _store(payload: Mapping[str, Any]):
    path = payload.get("store_path")
    return performance_store(str(path) if path else None)


def execute_093(payload: Mapping[str, Any]) -> dict[str, Any]:
    action = str(payload.get("action") or "profile_declared").lower()

    if action == "profile_declared":
        profile = profile_from_payload(payload)
        persisted = None
        if bool(payload.get("persist", True)):
            store = _store(payload)
            try:
                persisted = persist_profile(profile, store=store)
            finally:
                store.close()
        return {
            "ok": True,
            "executed": True,
            "message": "ENG-CAP-093 model profile completed",
            "evidence": {
                "profile": profile.as_dict(),
                "profile_hash": profile.profile_hash,
                "persisted": persisted,
                "operational_claim": "PROFILE_MEASURED_OR_DECLARED_WITH_PROVENANCE",
                "production_admission": False,
            },
            "runtime_implementation": True,
        }

    if action == "benchmark_engines":
        baseline = str(payload.get("baseline_engine_id") or "")
        candidate = str(payload.get("candidate_engine_id") or "")
        cases_raw = payload.get("cases") or ()
        if not baseline or not candidate or not isinstance(cases_raw, (list, tuple)):
            return {
                "ok": False,
                "executed": False,
                "message": "baseline_engine_id, candidate_engine_id and cases required",
                "evidence": {"failure_class": "INVALID_BENCHMARK_REQUEST"},
                "runtime_implementation": True,
            }
        cases = tuple(dict(case) for case in cases_raw if isinstance(case, Mapping))
        report = benchmark_engines(
            baseline_engine_id=baseline,
            candidate_engine_id=candidate,
            cases=cases,
            evidence_refs=tuple(str(x) for x in (payload.get("evidence_refs") or ())),
        )
        persisted: list[dict[str, Any]] = []
        if bool(payload.get("persist", True)):
            store = _store(payload)
            try:
                persisted.append(persist_benchmark(report.baseline, store=store))
                persisted.append(persist_benchmark(report.candidate, store=store))
            finally:
                store.close()
        return {
            "ok": True,
            "executed": True,
            "message": "ENG-CAP-093 comparative benchmark completed",
            "evidence": {
                "benchmark": report.as_dict(),
                "persisted": persisted,
                "marketing_claim_not_evidence": True,
                "production_admission": False,
            },
            "runtime_implementation": True,
        }

    if action == "run_suite":
        target_engine_id = str(payload.get("target_engine_id") or "")
        suite_cases = cases_from_payload(payload.get("cases"))
        if not target_engine_id or not suite_cases:
            return {
                "ok": False,
                "executed": False,
                "message": "target_engine_id and benchmark cases required",
                "evidence": {"failure_class": "INVALID_BENCHMARK_SUITE_REQUEST"},
                "runtime_implementation": True,
            }
        if target_engine_id not in ENG_093_BENCHMARK_TARGETS:
            return {
                "ok": False,
                "executed": False,
                "message": "target_engine_id is outside the reviewed ENG-CAP-093 benchmark allowlist",
                "evidence": {
                    "failure_class": "BENCHMARK_TARGET_NOT_REVIEWED",
                    "target_engine_id": target_engine_id,
                    "reviewed_targets": sorted(ENG_093_BENCHMARK_TARGETS),
                },
                "runtime_implementation": True,
            }

        def executor(case_payload: Mapping[str, Any]) -> Mapping[str, Any]:
            from engines_live import invoke
            result = invoke(target_engine_id, dict(case_payload))
            data = result.as_dict()
            return {
                "ok": bool(data.get("ok")),
                "message": data.get("message"),
                "evidence": data.get("evidence"),
                "runtime_implementation": data.get("runtime_implementation"),
            }

        suite = run_benchmark_suite(
            subject_id=target_engine_id,
            executor=executor,
            cases=suite_cases,
            minimum_pass_rate=float(payload.get("minimum_pass_rate") or 1.0),
        )
        return {
            "ok": suite.state == "BENCHMARK_PASSED",
            "executed": True,
            "message": f"ENG-CAP-093 suite {suite.state}",
            "evidence": {
                "suite": suite.as_dict(),
                "marketing_claim_not_evidence": True,
                "production_admission": False,
            },
            "runtime_implementation": True,
        }

    return {
        "ok": False,
        "executed": False,
        "message": f"unsupported ENG-CAP-093 action: {action}",
        "evidence": {"failure_class": "UNSUPPORTED_ACTION"},
        "runtime_implementation": True,
    }


def execute_141(payload: Mapping[str, Any]) -> dict[str, Any]:
    action = str(payload.get("action") or "history").lower()
    subject_id = str(payload.get("subject_id") or "")

    if action == "history":
        if not subject_id:
            return {
                "ok": False,
                "executed": False,
                "message": "subject_id required",
                "evidence": {"failure_class": "MISSING_SUBJECT_ID"},
                "runtime_implementation": True,
            }
        store = _store(payload)
        try:
            profiles = store.list_model_performance_profiles(subject_id)
            benchmarks = store.list_runtime_benchmarks(subject_id)
            feedback = store.list_selection_feedback(subject_id)
        finally:
            store.close()
        return {
            "ok": True,
            "executed": True,
            "message": "ENG-CAP-141 performance history loaded",
            "evidence": {
                "subject_id": subject_id,
                "profiles": profiles,
                "benchmarks": benchmarks,
                "selection_feedback": feedback,
                "learning_activated": False,
                "routing_mutated": False,
            },
            "runtime_implementation": True,
        }

    if action == "selection_feedback":
        if not subject_id:
            return {
                "ok": False,
                "executed": False,
                "message": "subject_id required",
                "evidence": {"failure_class": "MISSING_SUBJECT_ID"},
                "runtime_implementation": True,
            }
        store = _store(payload)
        try:
            persisted = record_selection_feedback(
                store=store,
                selected_subject=subject_id,
                outcome=str(payload.get("outcome") or "UNKNOWN"),
                mission_type=str(payload["mission_type"]) if payload.get("mission_type") else None,
                score=float(payload["score"]) if payload.get("score") is not None else None,
                evidence_refs=tuple(str(x) for x in (payload.get("evidence_refs") or ())),
                environment=payload.get("environment") if isinstance(payload.get("environment"), Mapping) else {},
            )
        finally:
            store.close()
        return {
            "ok": True,
            "executed": True,
            "message": "ENG-CAP-141 selection feedback recorded",
            "evidence": {
                "feedback": persisted,
                "learning_activated": False,
                "routing_mutated": False,
            },
            "runtime_implementation": True,
        }

    if action == "latest_metrics":
        if not subject_id:
            return {
                "ok": False,
                "executed": False,
                "message": "subject_id required",
                "evidence": {"failure_class": "MISSING_SUBJECT_ID"},
                "runtime_implementation": True,
            }
        store = _store(payload)
        try:
            metrics = latest_benchmark_metrics(store, subject_id)
        finally:
            store.close()
        return {
            "ok": metrics is not None,
            "executed": True,
            "message": "ENG-CAP-141 latest benchmark metrics resolved",
            "evidence": {
                "subject_id": subject_id,
                "metrics": metrics,
                "history_present": metrics is not None,
            },
            "runtime_implementation": True,
        }

    return {
        "ok": False,
        "executed": False,
        "message": f"unsupported ENG-CAP-141 action: {action}",
        "evidence": {"failure_class": "UNSUPPORTED_ACTION"},
        "runtime_implementation": True,
    }


def execute_152(payload: Mapping[str, Any]) -> dict[str, Any]:
    action = str(payload.get("action") or "recommend").lower()

    if action == "budget_check":
        metrics = payload.get("metrics") if isinstance(payload.get("metrics"), Mapping) else {}
        has_budget = any(
            payload.get(name) is not None
            for name in ("p95_budget_ms", "p99_budget_ms", "ttft_budget_ms")
        )
        if not metrics or not has_budget:
            return {
                "ok": False,
                "executed": False,
                "message": "metrics and at least one latency budget are required",
                "evidence": {"failure_class": "INVALID_BUDGET_REQUEST"},
                "runtime_implementation": True,
            }
        decision = latency_budget_check(
            metrics,
            p95_budget_ms=float(payload["p95_budget_ms"]) if payload.get("p95_budget_ms") is not None else None,
            p99_budget_ms=float(payload["p99_budget_ms"]) if payload.get("p99_budget_ms") is not None else None,
            ttft_budget_ms=float(payload["ttft_budget_ms"]) if payload.get("ttft_budget_ms") is not None else None,
        )
        return {
            "ok": decision["state"] == "WITHIN_BUDGET",
            "executed": True,
            "message": f"ENG-CAP-152 latency budget {decision['state']}",
            "evidence": {"budget": decision, "routing_mutated": False},
            "runtime_implementation": True,
        }

    if action == "regression":
        baseline = payload.get("baseline") if isinstance(payload.get("baseline"), Mapping) else {}
        current = payload.get("current") if isinstance(payload.get("current"), Mapping) else {}
        decision = detect_performance_regression(baseline, current)
        return {
            "ok": decision["state"] != "REGRESSION_DETECTED",
            "executed": True,
            "message": f"ENG-CAP-152 regression {decision['state']}",
            "evidence": {"regression": decision, "routing_mutated": False},
            "runtime_implementation": True,
        }

    if action == "bottleneck":
        steps_raw = payload.get("steps") or ()
        steps = tuple(dict(x) for x in steps_raw if isinstance(x, Mapping))
        decision = bottleneck_localization(steps)
        return {
            "ok": decision["state"] == "LOCALIZED",
            "executed": True,
            "message": f"ENG-CAP-152 bottleneck {decision['state']}",
            "evidence": {"bottleneck": decision, "routing_mutated": False},
            "runtime_implementation": True,
        }

    if action == "optimize":
        candidates_raw = payload.get("candidates") or ()
        candidates = tuple(dict(x) for x in candidates_raw if isinstance(x, Mapping))
        decision = quality_cost_latency_optimizer(
            candidates,
            quality_floor=float(payload.get("quality_floor") or 0.0),
            success_floor=float(payload.get("success_floor") or 0.0),
            latency_ceiling_ms=float(payload["latency_ceiling_ms"]) if payload.get("latency_ceiling_ms") is not None else None,
            cost_ceiling=float(payload["cost_ceiling"]) if payload.get("cost_ceiling") is not None else None,
        )
        return {
            "ok": decision["state"] == "OPTIMUM_CANDIDATE_AVAILABLE",
            "executed": True,
            "message": f"ENG-CAP-152 optimizer {decision['state']}",
            "evidence": {
                "optimization": decision,
                "authority_granted": False,
                "routing_mutated": False,
            },
            "runtime_implementation": True,
        }

    if action != "recommend":
        return {
            "ok": False,
            "executed": False,
            "message": f"unsupported ENG-CAP-152 action: {action}",
            "evidence": {"failure_class": "UNSUPPORTED_ACTION"},
            "runtime_implementation": True,
        }

    raw_candidates = payload.get("candidates") or ()
    if not isinstance(raw_candidates, (list, tuple)):
        raw_candidates = ()
    candidates = tuple(dict(x) for x in raw_candidates if isinstance(x, Mapping))
    decision = recommend_subject(
        candidates,
        max_p95_ms=float(payload["max_p95_ms"]) if payload.get("max_p95_ms") is not None else None,
        min_success_rate=float(payload.get("min_success_rate") or 0.0),
        max_unit_cost=float(payload["max_unit_cost"]) if payload.get("max_unit_cost") is not None else None,
        quality_floor=float(payload.get("quality_floor") or 0.0),
    )
    return {
        "ok": decision["state"] == "RECOMMENDATION_AVAILABLE",
        "executed": True,
        "message": "ENG-CAP-152 advisory performance recommendation completed",
        "evidence": {
            "recommendation": decision,
            "authority_granted": False,
            "routing_mutated": False,
            "operationally_proven": False,
        },
        "runtime_implementation": True,
    }


def make_performance_adapter(engine_id: str):
    handlers = {
        "ENG-CAP-093": execute_093,
        "ENG-CAP-141": execute_141,
        "ENG-CAP-152": execute_152,
    }
    if engine_id not in handlers:
        raise ValueError(f"unsupported performance engine: {engine_id}")

    def handler(payload: Mapping[str, Any]) -> dict[str, Any]:
        return handlers[engine_id](payload)

    return handler
