"""Dedicated runtime adapter for ENG-CAP-158 AFAQ Governed Core Engine."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

from afaq_agent_runtime.governed_core import GovernedProjectAgent
from afaq_agent_runtime.side_effects import SideEffectClassification, classify_action


_ACTIONS = {"files", "read", "search", "edit", "run", "status", "diff", "map"}


def make_governed_core_adapter():
    def handler(payload: Mapping[str, Any]) -> dict[str, Any]:
        action = str(payload.get("action") or "").strip().lower()
        if action not in _ACTIONS:
            return {
                "ok": False,
                "executed": False,
                "runtime_implementation": True,
                "message": f"unsupported governed-core action: {action}",
                "bound_capabilities": sorted(_ACTIONS),
                "missing_capabilities": [],
                "evidence": {"failure_class": "UNSUPPORTED_ACTION"},
            }

        root = str(payload.get("root") or "").strip()
        if not root:
            return {
                "ok": False,
                "executed": False,
                "runtime_implementation": True,
                "message": "governed project root is required",
                "bound_capabilities": sorted(_ACTIONS),
                "missing_capabilities": [],
                "evidence": {"failure_class": "PROJECT_ROOT_REQUIRED"},
            }

        effect = classify_action(action, dict(payload))
        if (
            action in {"edit", "run"}
            and effect is SideEffectClassification.WRITE
            and not bool(payload.get("_approved_by_job"))
        ):
            return {
                "ok": False,
                "executed": False,
                "runtime_implementation": True,
                "message": "governed job approval is required",
                "bound_capabilities": sorted(_ACTIONS),
                "missing_capabilities": [],
                "evidence": {
                    "failure_class": "APPROVAL_REQUIRED",
                    "side_effect": effect.value,
                },
            }

        try:
            agent = GovernedProjectAgent(Path(root))
            if action == "files":
                value = agent.files(limit=int(payload.get("limit", 500)))
            elif action == "read":
                value = agent.read(str(payload["path"]))
            elif action == "search":
                value = agent.search(
                    str(payload["query"]),
                    limit=int(payload.get("limit", 50)),
                )
            elif action == "edit":
                value = agent.edit(
                    str(payload["path"]),
                    str(payload["old"]),
                    str(payload["new"]),
                    approved=bool(payload.get("_approved_by_job")),
                )
            elif action == "run":
                value = agent.run(str(payload["command"]))
            elif action == "status":
                value = agent.git_status()
            elif action == "diff":
                value = agent.git_diff()
            else:
                value = agent.map_repository()
        except Exception as exc:  # fail closed; HTTP boundary redacts diagnostics
            return {
                "ok": False,
                "executed": False,
                "runtime_implementation": True,
                "message": f"governed-core execution failed: {type(exc).__name__}: {exc}",
                "bound_capabilities": sorted(_ACTIONS),
                "missing_capabilities": [],
                "evidence": {
                    "failure_class": "GOVERNED_CORE_EXECUTION_FAILED",
                    "error": f"{type(exc).__name__}: {exc}",
                },
            }

        return {
            "ok": True,
            "executed": True,
            "runtime_implementation": True,
            "message": f"ENG-CAP-158 executed governed action {action}",
            "bound_capabilities": sorted(_ACTIONS),
            "missing_capabilities": [],
            "evidence": {
                "action": action,
                "result": value,
                "mission_verified": (
                    effect is SideEffectClassification.READ_ONLY
                ),
                "evidence_refs": [f"governed-core:{action}"],
                "side_effect": effect.value,
            },
        }

    return handler
