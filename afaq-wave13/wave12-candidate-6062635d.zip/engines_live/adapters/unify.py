"""Normalize any specialized/domain adapter into one evidence schema.

Wave-6 (19) and CAP (rest) both emit the same runtime_adapter shape.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Callable, Mapping

from .runtime import Adapter, _err, _ok

REPO_ROOT = Path(__file__).resolve().parents[2]

# Explicit routes for the original 19 specialized adapters.
WAVE6_ROUTES: dict[str, str] = {
    "ENG-UND-017": "understanding",
    "ENG-RES-018": "research",
    "ENG-WR-019": "writing",
    "ENG-WR-020": "writing",
    "ENG-GRA-021": "graphics",
    "ENG-GRA-022": "graphics",
    "ENG-DEV-001": "developer",
    "ENG-DEC-002": "decision",
    "ENG-MOD-003": "model",
    "ENG-MEM-004": "memory",
    "ENG-HEAL-005": "heal",
    "ENG-ROU-006": "orchestr",
    "ENG-WS-007": "workspace",
    "ENG-SRV-008": "orchestr",
    "ENG-BE-009": "backend",
    "ENG-AUD-010": "audit",
    "ENG-LEG-011": "orchestr",
    "ENG-LEG-012": "orchestr",
    "ENG-SHD-013": "gateway",
}


def _digest(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _load_shared(shared_engine_file: str | None) -> dict[str, Any] | None:
    if not shared_engine_file:
        return None
    path = REPO_ROOT / shared_engine_file
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def _load_packages(package_paths: tuple[str, ...]) -> list[dict[str, Any]]:
    loaded: list[dict[str, Any]] = []
    for rel in package_paths:
        path = REPO_ROOT / rel if not Path(rel).is_absolute() else Path(rel)
        if not path.is_file():
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        loaded.append(
            {
                "path": str(rel),
                "package_id": data.get("package_id") or data.get("id") or path.parent.name,
                "name": data.get("name") or data.get("package_name"),
            }
        )
    return loaded


def unify_adapter(
    *,
    engine_id: str,
    name: str,
    required_capabilities: tuple[str, ...],
    shared_engine_file: str | None,
    capability_packages: tuple[str, ...],
    package_paths: tuple[str, ...],
    specialized: Adapter,
    route: str | None = None,
    family: str = "unified",
) -> Adapter:
    """Wrap a specialized callable so evidence matches CAP domain adapters."""

    def handler(payload: Mapping[str, Any]) -> dict[str, Any]:
        shared = _load_shared(shared_engine_file)
        packages = _load_packages(package_paths)
        resolved_route = route or WAVE6_ROUTES.get(engine_id) or "governed"
        try:
            raw = specialized(payload)
        except Exception as exc:  # noqa: BLE001
            return _err(
                f"{engine_id} unified runtime failed: {type(exc).__name__}: {exc}",
                {
                    "route": resolved_route,
                    "family": family,
                    "error": f"{type(exc).__name__}: {exc}",
                },
            )

        ok = bool(raw.get("ok", True))
        raw_ev = dict(raw.get("evidence") or {})
        domain = {
            "module": raw_ev.get("module")
            or raw_ev.get("class")
            or raw_ev.get("path")
            or f"engines_live.adapters#{engine_id}",
            "entry": raw_ev.get("entry") or raw_ev.get("class") or "invoke",
            "specialized_result": {
                k: v
                for k, v in raw_ev.items()
                if k
                not in {
                    "executed",
                    "route",
                    "domain",
                    "parity_with_wave6",
                    "family",
                }
            },
        }
        # Prefer richer domain block if adapter already emitted one (CAP domain).
        if isinstance(raw_ev.get("domain"), dict):
            domain = dict(raw_ev["domain"])

        evidence = {
            "executed": bool(raw.get("executed", ok)),
            "route": raw_ev.get("route") or resolved_route,
            "family": family,
            "shared_engine_loaded": shared is not None or bool(raw_ev.get("shared_engine_loaded")),
            "packages_loaded": len(packages)
            if packages
            else int(raw_ev.get("packages_loaded") or 0),
            "package_ids": list(capability_packages),
            "required_capabilities": list(required_capabilities),
            "domain": domain,
            "domain_digest": _digest(domain),
            "parity_with_wave6": True,
            "unified_runtime": True,
        }
        if not ok:
            return _err(str(raw.get("message") or f"{engine_id} failed"), evidence)
        return _ok(
            str(raw.get("message") or f"{engine_id} unified runtime EXECUTED"),
            evidence,
            bound_capabilities=list(
                raw.get("bound_capabilities") or required_capabilities
            ),
            missing_capabilities=list(raw.get("missing_capabilities") or []),
        )

    return handler
