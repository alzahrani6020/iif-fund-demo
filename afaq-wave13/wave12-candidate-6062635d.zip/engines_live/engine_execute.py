"""Full live engine execution — runs all capability steps and persists evidence."""

from __future__ import annotations

import json
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from .authority_gate import require_execute_allow
from .capability_runtime import execute_capability
from .fabric import REPO_ROOT, bind_capability_packages

RUNS_DIR = REPO_ROOT / "var" / "engine_runs"


def _derive_capabilities(
    *,
    required: tuple[str, ...],
    shared: dict[str, Any] | None,
    canonical: dict[str, Any],
    packages: tuple[str, ...],
    name: str,
) -> list[str]:
    caps: list[str] = list(required)
    if not caps and shared:
        rc = shared.get("required_capabilities") or []
        if isinstance(rc, list):
            caps = [str(x) for x in rc if isinstance(x, str)]
    if not caps:
        # Derive executable surface from engine identity + packages (no invented IDs).
        caps = [
            "contract_check",
            "capability_bind",
            "evidence_emit",
            "result_compose",
        ]
        if packages:
            caps.insert(0, "package_resolve")
        # Name-token ops keep execution specific without inventing foreign IDs.
        lower = name.lower()
        for token, op in (
            ("browser", "browser_navigation"),
            ("command", "allowlisted_execution"),
            ("sandbox", "isolated_compute"),
            ("storage", "object_storage"),
            ("model", "model_route"),
            ("research", "discover"),
            ("analytics", "compose_analysis"),
            ("identity", "authority_compatibility"),
            ("payment", "transaction_contract"),
            ("message", "event_dispatch"),
            ("schedule", "scheduler_tick"),
            ("map", "geospatial_resolve"),
            ("market", "campaign_plan"),
            ("crm", "customer_resolve"),
            ("erp", "supply_resolve"),
        ):
            if token in lower and op not in caps:
                caps.append(op)
    # Deduplicate preserving order
    seen: set[str] = set()
    out: list[str] = []
    for c in caps:
        if c not in seen:
            seen.add(c)
            out.append(c)
    return out


def execute_cap_engine(
    *,
    engine_id: str,
    name: str,
    capability_packages: tuple[str, ...],
    package_paths: tuple[str, ...],
    required_capabilities: tuple[str, ...],
    shared_engine_file: str | None,
    canonical: dict[str, Any],
    payload: Mapping[str, Any],
) -> dict[str, Any]:
    started = time.perf_counter()
    gate = require_execute_allow(engine_id=engine_id)
    if not gate.allowed:
        run_id = f"RUN-{uuid.uuid4().hex[:12]}"
        blocked = {
            "ok": False,
            "executed": False,
            "message": f"{engine_id} BLOCKED by authority: {gate.decision.reason}",
            "bound_capabilities": [],
            "missing_capabilities": list(required_capabilities),
            "evidence": {
                "run_id": run_id,
                "engine_name": name,
                "action": "execute",
                "authority": gate.as_dict(),
                "steps": [],
                "provider_execution": "NOT_INVOKED",
                "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
        }
        out_dir = RUNS_DIR / engine_id
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / f"{run_id}.json"
        out_path.write_text(json.dumps(blocked, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        blocked["evidence"]["run_path"] = str(out_path.relative_to(REPO_ROOT))
        return blocked

    shared: dict[str, Any] | None = None
    if shared_engine_file:
        path = REPO_ROOT / shared_engine_file
        if path.is_file():
            try:
                shared = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                shared = None

    caps = _derive_capabilities(
        required=required_capabilities,
        shared=shared,
        canonical=canonical,
        packages=capability_packages,
        name=name,
    )
    binding = bind_capability_packages(
        capability_packages, package_paths, tuple(caps)
    )

    contracts = {}
    if shared and isinstance(shared.get("contracts"), dict):
        contracts = shared["contracts"]

    context: dict[str, Any] = {
        "capability_packages": list(capability_packages),
        "required_capabilities": caps,
        "provider_candidates": (shared or {}).get("provider_candidates")
        or [
            {"name": p, "status": "UNVERIFIED_PROVIDER_CANDIDATE"}
            if isinstance(p, str)
            else p
            for p in (canonical.get("provider_candidates") or [])
        ],
        "contracts": contracts,
        "contract_names": list(contracts.keys()) if contracts else [],
        "binding": binding,
        "_session_store": {},
    }

    # Ensure merged names are registered in capability_cycle HANDLERS for platform parity.
    try:
        from capability_cycle.merged_handlers import capability_id, ensure_merged_handlers_registered
        from capability_cycle.handlers import get_active_handler

        ensure_merged_handlers_registered(write_map=False)
    except Exception:
        capability_id = None  # type: ignore[assignment]
        get_active_handler = None  # type: ignore[assignment]

    steps: list[dict[str, Any]] = []
    for cap in caps:
        step = execute_capability(
            cap,
            engine_id=engine_id,
            payload=payload,
            context=context,
        )
        # Parity: also exercise capability_cycle handler when registered.
        if capability_id and get_active_handler:
            try:
                cid = capability_id(cap)
                handler = get_active_handler(cid)
                if handler is not None:
                    hres = handler({"engine_id": engine_id, "capability": cap, **dict(payload)})
                    step["cycle_handler"] = {
                        "capability_id": cid,
                        "ok": bool(hres.get("ok")),
                        "digest": hres.get("digest"),
                    }
            except Exception as exc:  # noqa: BLE001
                step["cycle_handler"] = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
        steps.append(step)

    # Provider seat (fail-closed unless allowlisted)
    provider_evidence: dict[str, Any] = {"status": "NOT_INVOKED"}
    try:
        from provider_adapters import invoke_provider

        candidates = context.get("provider_candidates") or []
        if candidates:
            first = candidates[0]
            pid = first.get("name") if isinstance(first, dict) else str(first)
            # normalize to allowlist key style
            key = str(pid).lower().replace(" ", "_").replace("/", "_")[:64]
            provider_evidence = invoke_provider(key, operation="probe", payload={"engine_id": engine_id})
    except Exception as exc:  # noqa: BLE001
        provider_evidence = {"status": "ERROR", "error": f"{type(exc).__name__}: {exc}"}

    executed_n = sum(1 for s in steps if s.get("executed"))
    run_id = f"RUN-{uuid.uuid4().hex[:12]}"
    result = {
        "ok": executed_n == len(steps) and len(steps) > 0,
        "executed": executed_n == len(steps) and len(steps) > 0,
        "message": (
            f"{engine_id} EXECUTED {executed_n}/{len(steps)} capability steps"
        ),
        "bound_capabilities": [s["capability"] for s in steps if s.get("executed")],
        "missing_capabilities": [s["capability"] for s in steps if not s.get("executed")],
        "evidence": {
            "run_id": run_id,
            "engine_name": name,
            "action": "execute",
            "authority": gate.as_dict(),
            "classification": canonical.get("classification")
            or (shared or {}).get("classification"),
            "canonical_state_was": canonical.get("state"),
            "shared_engine_loaded": shared is not None,
            "packages_loaded": binding["packages_loaded"],
            "package_ids": list(capability_packages),
            "steps": steps,
            "provider_execution": provider_evidence,
            "platform": {
                "org": "Afaq Creative",
                "org_domain": "https://afaq-global.com/",
                "product": "Saudi SaaS",
                "product_domain": "https://saudi-saas.com/",
                "engine_fabric": "AFAQ-GIE",
            },
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        },
    }

    out_dir = RUNS_DIR / engine_id
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{run_id}.json"
    out_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    result["evidence"]["run_path"] = str(out_path.relative_to(REPO_ROOT))
    return result
