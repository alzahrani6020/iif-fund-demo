"""Execute every live engine and persist activation observations/evidence."""
from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from afaq_registry.loader import OBSERVATIONS_PATH, load_observations  # noqa: E402
from engines_live.activate import main as refresh_observations  # noqa: E402
from engines_live.fabric import invoke  # noqa: E402
from engines_live.registry import LIVE_ENGINE_REGISTRY, build_registry  # noqa: E402


def activate_all() -> dict:
    build_registry()
    refresh_observations()
    build_registry()

    activated_on = datetime.now(timezone.utc).isoformat()
    rows = []
    ok_n = 0
    fail_n = 0

    for eid in sorted(LIVE_ENGINE_REGISTRY):
        engine = LIVE_ENGINE_REGISTRY[eid]
        row = {
            "engine_id": eid,
            "name": engine.name,
            "kind": engine.kind,
            "live_status": engine.live_status,
            "activated": False,
            "executed": False,
            "ready_for_full_work": False,
        }
        if engine.live_status != "ACTIVE":
            row["error"] = f"not ACTIVE: {engine.live_status!r}"
            fail_n += 1
            rows.append(row)
            continue
        try:
            result = invoke(
                eid,
                {
                    "action": "execute",
                    "activation": True,
                    "text": f"activation execute {eid}",
                    "topic": f"activation execute {eid}",
                    "query": eid,
                    "op": "put",
                    "key": f"activation:{eid}",
                    "value": {"activated_on": activated_on},
                },
            )
            evidence = result.evidence or {}
            if evidence.get("steps"):
                executed = all(step.get("executed") for step in evidence["steps"])
            else:
                executed = bool(evidence.get("executed"))
            activated = bool(result.ok and executed)
            row.update({
                "activated": activated,
                "executed": executed,
                "ready_for_full_work": bool(activated and engine.operationally_proven),
                "ok": result.ok,
                "message": result.message,
                "run_path": evidence.get("run_path"),
                "activated_on": activated_on if activated else None,
            })
            if activated:
                ok_n += 1
            else:
                fail_n += 1
                row["error"] = "activation invoke did not fully execute"
        except Exception as exc:  # noqa: BLE001
            fail_n += 1
            row["error"] = f"{type(exc).__name__}: {exc}"
        rows.append(row)

    total = len(rows)
    all_activated = fail_n == 0 and ok_n == total and total > 0
    ledger = {
        "schema": "ENGINE_ACTIVATION_LEDGER_V2",
        "activated_on": activated_on,
        "total": total,
        "activated": ok_n,
        "failed": fail_n,
        "all_activated": all_activated,
        "engines": rows,
    }

    evidence_dir = REPO_ROOT / "project-records" / "engine-registry"
    ledger_path = evidence_dir / "ENGINE_ACTIVATION_LEDGER.json"
    ledger_path.write_text(
        json.dumps(ledger, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    previous = load_observations()
    by_result = {row["engine_id"]: row for row in rows}
    observations = []
    for eid, engine in sorted(LIVE_ENGINE_REGISTRY.items()):
        result = by_result.get(eid, {})
        observations.append({
            "engine_id": eid,
            "live_status": engine.live_status,
            "activated": bool(result.get("activated")),
            "activated_on": result.get("activated_on"),
            "runtime_implementation": bool(engine.runtime_implementation),
            "state": "ACTIVATED" if result.get("activated") else "VERIFICATION_FAILED",
        })
    OBSERVATIONS_PATH.write_text(
        json.dumps({
            "schema": "AFAQ_REGISTRY_RUNTIME_STATE_V1",
            "observed_on": activated_on,
            "engines": observations,
            "capability_packages": list(previous.get("capability_packages") or []),
        }, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    print(json.dumps({
        "total": total,
        "activated": ok_n,
        "failed": fail_n,
        "all_activated": all_activated,
        "ledger": str(ledger_path),
        "activated_on": activated_on,
    }, ensure_ascii=False, indent=2))
    return ledger


def main() -> int:
    ledger = activate_all()
    return 0 if ledger["all_activated"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
