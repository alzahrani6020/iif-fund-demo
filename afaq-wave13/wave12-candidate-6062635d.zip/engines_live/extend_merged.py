"""Backward-compatible facade for the authoritative registry mutation API.

New code imports from afaq_registry.mutate. This module contains no registry
state and performs no mutation by itself.
"""
from afaq_registry.mutate import (  # noqa: F401
    add_capability,
    add_engine,
    ensure_extensibility_block,
    link_capability_to_engine,
    main,
)

if __name__ == "__main__":
    raise SystemExit(main())
