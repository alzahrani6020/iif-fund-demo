"""Authority gate for live engine execution."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from current_authority.resolver import AuthorityRequest, Decision, resolve


@dataclass(frozen=True)
class GateResult:
    allowed: bool
    decision: Decision

    def as_dict(self) -> dict[str, Any]:
        return {
            "allowed": self.allowed,
            "outcome": self.decision.outcome,
            "reason": self.decision.reason,
            "source": self.decision.source,
        }


def require_execute_allow(*, engine_id: str, path: str | None = None) -> GateResult:
    decision = resolve(
        AuthorityRequest(
            action="execute_tool",
            path=path or f"engines_live:{engine_id}",
        )
    )
    return GateResult(allowed=(decision.outcome == "ALLOW"), decision=decision)
