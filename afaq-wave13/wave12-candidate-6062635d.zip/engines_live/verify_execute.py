"""Verify every live engine EXECUTES (not bind-only)."""

from __future__ import annotations

import json
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from engines_live.fabric import invoke  # noqa: E402
from engines_live.registry import build_registry  # noqa: E402


def _probe_payload(engine_id: str) -> dict:
    """Return a safe, contract-valid execution probe for specialized engines."""
    common = {
        "text": f"execute probe for {engine_id}",
        "topic": f"execute probe for {engine_id}",
        "query": engine_id,
        "op": "put",
        "key": f"verify:{engine_id}",
        "value": {"probe": True},
    }
    if engine_id == "ENG-CAP-001":
        return {
            **common,
            "url": "https://example.com/",
            "headless": True,
            "capture_network": True,
            "overall_timeout_ms": 30000,
        }
    if engine_id == "ENG-CAP-091":
        return {
            **common,
            "action": "fetch",
            "url": "https://example.com/",
            "timeout_seconds": 15,
        }
    if engine_id == "ENG-CAP-093":
        return {
            **common,
            "action": "profile_declared",
            "subject_id": "ENG-CAP-001",
            "metadata": {
                "subject_id": "ENG-CAP-001",
                "probe": True,
                "source": "verify_execute",
            },
            "persist": False,
        }
    if engine_id == "ENG-CAP-136":
        return {
            **common,
            "instruction": (
                "I want to build a verified technical report for the internal "
                "engineering team; deliverable is a report and scope is analysis only."
            ),
        }
    if engine_id == "ENG-CAP-141":
        return {
            **common,
            "action": "history",
            "subject_id": "ENG-CAP-001",
        }
    if engine_id == "ENG-CAP-142":
        return {
            **common,
            "action": "attach",
            "session_id": "verify-execute",
            "capability_ids": ["CAP-AUDIT-001"],
        }
    if engine_id == "ENG-CAP-152":
        return {
            **common,
            "action": "regression",
            "baseline": {"p95_ms": 100.0, "success_rate": 1.0},
            "current": {"p95_ms": 100.0, "success_rate": 1.0},
        }
    if engine_id == "ENG-CAP-153":
        return {
            **common,
            "action": "compare_snapshots",
            "source_id": "verify-execute",
            "previous": {
                "version": "v1",
                "content": "baseline knowledge state",
                "metadata": {"probe": True},
            },
            "current": {
                "version": "v2",
                "content": "updated knowledge state",
                "metadata": {"probe": True},
            },
        }
    if engine_id == "ENG-CAP-158":
        return {
            **common,
            "action": "status",
            "root": str(REPO_ROOT),
        }
    if engine_id == "ENG-CAP-159":
        return {
            **common,
            "mention": "محمد العتيبي",
            "context": {"employer": "AFAQ"},
            "candidates": [
                {
                    "person_id": "verify-person-159",
                    "canonical_name": "Mohammed Alotaibi",
                    "aliases": ["محمد العتيبي"],
                    "qualifiers": {"employer": "AFAQ"},
                    "evidence_refs": ["verify-execute:ENG-CAP-159"],
                }
            ],
        }
    if engine_id == "ENG-CAP-160":
        return {
            **common,
            "source": {
                "publisher": "AFAQ Verification Publisher",
                "url": "https://verify.afaq.example/probe",
            },
            "candidates": [
                {
                    "publisher_id": "verify-publisher-160",
                    "canonical_name": "AFAQ Verification Publisher",
                    "aliases": [],
                    "domains": ["afaq.example"],
                    "evidence_refs": ["verify-execute:ENG-CAP-160"],
                }
            ],
        }
    return {"action": "execute", **common}


def main() -> int:
    registry = build_registry()
    results = []
    ok_n = 0
    fail_n = 0
    executed_n = 0
    ready_n = 0
    active_n = 0
    for eid in sorted(registry.keys()):
        eng = registry[eid]
        row = {
            "engine_id": eid,
            "ok": False,
            "executed": False,
            "live_status": eng.live_status,
            "ready_for_full_work": eng.live_status == "ACTIVE" and eng.operationally_proven,
        }
        if eng.live_status != "ACTIVE":
            fail_n += 1
            row["error"] = f"live_status is {eng.live_status!r}, required ACTIVE"
            results.append(row)
            continue
        active_n += 1
        try:
            result = invoke(eid, _probe_payload(eid))
            data = result.as_dict()
            row.update(data)
            row["live_status"] = eng.live_status
            ev = data.get("evidence") or {}
            if ev.get("steps"):
                executed = all(s.get("executed") for s in ev["steps"])
            else:
                executed = bool(ev.get("executed"))
            row["executed"] = bool(result.ok and executed)
            row["ready_for_full_work"] = bool(
                row["executed"]
                and eng.operationally_proven
                and eng.runtime_implementation
            )
            if result.ok and row["executed"]:
                ok_n += 1
                executed_n += 1
                if row["ready_for_full_work"]:
                    ready_n += 1
            else:
                fail_n += 1
                row["ok"] = False
                if result.ok and not row["executed"]:
                    row["error"] = "invoke ok but no execution evidence"
        except Exception as exc:  # noqa: BLE001
            fail_n += 1
            row["ok"] = False
            row["error"] = f"{type(exc).__name__}: {exc}"
            row["traceback"] = traceback.format_exc(limit=5)
        results.append(row)

    report = {
        "schema": "LIVE_ENGINE_EXECUTE_VERIFY_V1",
        "verified_on": datetime.now(timezone.utc).isoformat(),
        "total": len(results),
        "ACTIVE": active_n,
        "ok": ok_n,
        "fail": fail_n,
        "executed": executed_n,
        "ready_for_full_work": ready_n,
        "all_ok": fail_n == 0 and ok_n == len(results) and active_n == len(results),
        "all_currently_active_executed": fail_n == 0 and active_n == len(results) and executed_n == len(results),
        "all_production_ready": fail_n == 0 and ready_n == len(results),
        "results": results,
    }
    out = REPO_ROOT / "project-records" / "engine-registry" / "LIVE_ENGINE_EXECUTE_VERIFY.json"
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    summary = {
        k: report[k]
        for k in (
            "total",
            "ACTIVE",
            "ok",
            "fail",
            "executed",
            "ready_for_full_work",
            "all_ok",
            "all_currently_active_executed",
            "all_production_ready",
            "verified_on",
        )
    }
    print(json.dumps(summary, indent=2))
    return 0 if report["all_currently_active_executed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
