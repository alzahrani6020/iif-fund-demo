"""Standalone capability execution entrypoints."""

from __future__ import annotations

import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from .capability_runtime import execute_capability
from .fabric import REPO_ROOT

RUNS_DIR = REPO_ROOT / "var" / "capability_runs"


def run_capability(
    capability: str,
    *,
    payload: Mapping[str, Any] | None = None,
    engine_id: str = "CAP-STANDALONE",
    via_cycle: bool = False,
) -> dict[str, Any]:
    """Execute one capability by name or CAP-* id.

    Default path: engines_live capability runtime (always executable).
    via_cycle=True: also run capability_cycle.execute_plan for the mapped id.
    """
    started = time.perf_counter()
    payload = dict(payload or {})
    context: dict[str, Any] = {
        "capability_packages": [],
        "required_capabilities": [capability],
        "provider_candidates": [],
        "contracts": {},
        "contract_names": [],
        "_session_store": {},
    }
    step = execute_capability(
        capability,
        engine_id=engine_id,
        payload=payload,
        context=context,
    )

    cycle: dict[str, Any] | None = None
    if via_cycle:
        try:
            from capability_cycle.merged_handlers import (
                capability_id,
                ensure_merged_handlers_registered,
            )
            from capability_cycle.planner import Requirement
            from capability_cycle.runtime import execute_plan

            ensure_merged_handlers_registered(write_map=False)
            # Accept raw CAP-* ids or capability names.
            if capability.upper().startswith("CAP-") and capability in (
                "CAP-AUDIT-001",
                "CAP-EVAL-001",
                "CAP-TRUTH-001",
            ):
                cid = capability
            elif capability.upper().startswith("CAP-") and "-" in capability:
                # May already be a mapped id like CAP-LIVENESS-F43C5C4C
                from capability_cycle.handlers import HANDLERS

                cid = capability if capability in HANDLERS else capability_id(capability)
            else:
                cid = capability_id(capability)
            result = execute_plan(
                Requirement(text="", explicit_capability_ids=(cid,)),
                payloads={cid: dict(payload)},
            )
            cycle = {
                "capability_id": cid,
                "status": result.status,
                "reason": result.reason,
                "ok": result.status == "PASSED",
            }
        except Exception as exc:  # noqa: BLE001
            cycle = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}

    out = {
        "ok": bool(step.get("executed")),
        "executed": bool(step.get("executed")),
        "capability": capability,
        "step": step,
        "cycle": cycle,
        "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    safe_name = "".join(c if c.isalnum() or c in "-_" else "_" for c in capability)[:80]
    out_dir = RUNS_DIR / safe_name
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    path = out_dir / f"{stamp}.json"
    path.write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    out["run_path"] = str(path.relative_to(REPO_ROOT))
    return out
