"""Verify every live engine imports and invoke() succeeds structurally."""

from __future__ import annotations

import json
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from engines_live.registry import LIVE_ENGINE_REGISTRY, build_registry  # noqa: E402
from engines_live.fabric import invoke  # noqa: E402


def main() -> int:
    registry = build_registry()
    results = []
    ok_n = 0
    fail_n = 0
    for eid in sorted(registry.keys()):
        row = {"engine_id": eid, "ok": False}
        try:
            result = invoke(eid, {"action": "verify_live", "probe": True})
            row.update(result.as_dict())
            if result.ok:
                ok_n += 1
            else:
                fail_n += 1
        except Exception as exc:  # noqa: BLE001 — collect all failures
            fail_n += 1
            row["ok"] = False
            row["error"] = f"{type(exc).__name__}: {exc}"
            row["traceback"] = traceback.format_exc(limit=5)
        results.append(row)

    report = {
        "schema": "LIVE_ENGINE_VERIFY_V1",
        "verified_on": datetime.now(timezone.utc).isoformat(),
        "total": len(results),
        "ok": ok_n,
        "fail": fail_n,
        "all_ok": fail_n == 0 and ok_n == len(results),
        "results": results,
    }
    out = REPO_ROOT / "project-records" / "engine-registry" / "LIVE_ENGINE_VERIFY.json"
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    summary = {k: report[k] for k in ("total", "ok", "fail", "all_ok", "verified_on")}
    print(json.dumps(summary, indent=2))
    return 0 if report["all_ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
