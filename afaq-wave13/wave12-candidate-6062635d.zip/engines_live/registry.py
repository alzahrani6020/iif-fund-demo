"""Build and expose LIVE_ENGINE_REGISTRY for all unique engine IDs."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .adapters.runtime import RUNTIME_ADAPTERS
from .adapters.cap_domain import make_cap_domain_adapter
from .adapters.capability_foundation import (
    make_capability_foundation_adapter,
)
from .adapters.command_sandbox_runtime import (
    make_command_runtime_adapter,
    make_sandbox_runtime_adapter,
)
from .adapters.web_acquisition import make_web_acquisition_adapter
from .adapters.browser_runtime import make_browser_runtime_adapter
from .adapters.performance_runtime import make_performance_adapter
from .adapters.orchestration_runtime import (
    make_composition_runtime_adapter,
    make_mission_graph_runtime_adapter,
    make_result_fusion_runtime_adapter,
)
from .adapters.governed_core_runtime import make_governed_core_adapter
from .adapters.research_intelligence_runtime import (
    make_evidence_verification_runtime_adapter,
    make_research_synthesis_runtime_adapter,
)
from .adapters.gap_acquisition_runtime import make_gap_acquisition_runtime_adapter
from .adapters.benchmark_observatory_runtime import make_benchmark_observatory_runtime_adapter
from .adapters.continuous_observatory_runtime import make_continuous_observatory_runtime_adapter
from .adapters.frontier_discovery_runtime import make_frontier_discovery_runtime_adapter
from .adapters.portfolio_goal_runtime import (
    make_research_portfolio_runtime_adapter,
    make_goal_formation_runtime_adapter,
)
from .adapters.causal_forecast_runtime import (
    make_falsification_causal_runtime_adapter,
    make_scenario_forecast_runtime_adapter,
)
from .adapters.context_loader_runtime import (
    make_context_adaptation_runtime_adapter,
    make_capability_loader_runtime_adapter,
)
from .adapters.mission_modeling_runtime import make_mission_modeling_runtime_adapter
from .adapters.identity_resolution_runtime import (
    make_person_identity_resolver_adapter,
    make_publisher_identity_resolver_adapter,
)
from .fabric import LiveEngine, REPO_ROOT
from .runtime_wrap import make_runtime_full_handler
from afaq_registry.loader import REGISTRY_PATH, load_registry

MERGED_PATH = REGISTRY_PATH
CANONICAL_PATH = REPO_ROOT / "capability-foundation" / "CANONICAL_ENGINE_REGISTRY_V11.json"

LIVE_ENGINE_REGISTRY: dict[str, LiveEngine] = {}


def _load_merged() -> dict[str, Any]:
    return load_registry()


def _load_canonical_by_id() -> dict[str, dict[str, Any]]:
    data = json.loads(CANONICAL_PATH.read_text(encoding="utf-8"))
    out: dict[str, dict[str, Any]] = {}
    for eng in data.get("engines") or []:
        eid = eng.get("engine_id")
        if isinstance(eid, str):
            out[eid] = eng
    return out


def _shared_truth(
    shared_engine_file: str | None,
) -> dict[str, Any]:
    if not shared_engine_file:
        return {}

    path = REPO_ROOT / shared_engine_file

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}

    return data if isinstance(data, dict) else {}


def _operationally_proven(
    entry: dict[str, Any],
    shared_engine_file: str | None,
    canonical: dict[str, Any] | None = None,
) -> bool:
    """Consume only the central evidence-derived ProofState."""
    del shared_engine_file, canonical
    return entry.get("proof_state") == "PROVEN"


def _runtime_implemented(
    entry: dict[str, Any],
    shared_engine_file: str | None,
) -> bool:
    shared = _shared_truth(shared_engine_file)

    status = str(shared.get("status") or "")

    if "NOT_IMPLEMENTED" in status:
        return False

    value = shared.get("runtime_implementation")

    if isinstance(value, bool):
        return value

    return bool(entry.get("runtime_implementation", False))


def _required_from_shared(shared_engine_file: str | None) -> tuple[str, ...]:
    if not shared_engine_file:
        return ()
    path = REPO_ROOT / shared_engine_file
    if not path.exists():
        return ()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return ()
    rc = data.get("required_capabilities") or []
    if not isinstance(rc, list):
        return ()
    return tuple(str(x) for x in rc if isinstance(x, str))


def build_registry() -> dict[str, LiveEngine]:
    """Seat every merged engine as a live callable unit. Idempotent."""
    merged = _load_merged()
    canonical_by_id = _load_canonical_by_id()
    registry: dict[str, LiveEngine] = {}

    for entry in merged.get("engines") or []:
        eid = entry.get("engine_id")
        if not isinstance(eid, str):
            continue
        name = str(entry.get("name") or eid)
        kind = str(entry.get("kind") or "unknown")
        packages = tuple(entry.get("capability_packages") or ())
        package_paths = tuple(entry.get("package_paths") or ())
        shared = entry.get("shared_engine_file")
        shared_s = str(shared) if shared else None
        canonical = canonical_by_id.get(eid, {})
        # File is source of truth for growth; shared-engine fills gaps only.
        required_entry = tuple(
            str(x) for x in (entry.get("required_capabilities") or []) if isinstance(x, str)
        )
        required = required_entry or _required_from_shared(shared_s)

        proven = _operationally_proven(
            entry,
            shared_s,
            canonical,
        )
        runtime_implemented = _runtime_implemented(
            entry,
            shared_s,
        )

        if eid in {"ENG-CAP-002", "ENG-CAP-003"}:
            runtime_adapter = (
                make_command_runtime_adapter()
                if eid == "ENG-CAP-002"
                else make_sandbox_runtime_adapter()
            )
            handler = make_runtime_full_handler(
                engine_id=eid,
                name=name,
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical or {
                    "engine_id": eid,
                    "name": name,
                    "classification": entry.get("classification"),
                    "state": entry.get("state") or "CURRENTLY_ACTIVE_ACTIVATED",
                },
                runtime_adapter=runtime_adapter,
            )
            registry[eid] = LiveEngine(
                engine_id=eid,
                name=name,
                kind="live_runtime",
                live_status="ACTIVE",
                live_path=(
                    "engines_live/adapters/"
                    f"command_sandbox_runtime.py#{eid}"
                ),
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical,
                adapter_name=(
                    "command_runtime:ENG-CAP-002"
                    if eid == "ENG-CAP-002"
                    else "sandbox_runtime:ENG-CAP-003"
                ),
                handler=handler,
                operationally_proven=proven,
                runtime_implementation=True,
            )
            continue

        if eid in {"ENG-CAP-005", "ENG-CAP-006"}:
            handler = make_capability_foundation_adapter(
                engine_id=eid,
                shared_engine_file=shared_s,
            )

            registry[eid] = LiveEngine(
                engine_id=eid,
                name=name,
                kind="live_runtime",
                live_status="ACTIVE",
                live_path=(
                    "engines_live/adapters/"
                    f"capability_foundation.py#{eid}"
                ),
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical,
                adapter_name=f"capability_foundation:{eid}",
                handler=handler,
                operationally_proven=proven,
                runtime_implementation=True,
            )
            continue

        if eid == "ENG-CAP-001":
            handler = make_runtime_full_handler(
                engine_id=eid,
                name=name,
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical or {
                    "engine_id": eid,
                    "name": name,
                    "classification": entry.get("classification"),
                    "state": entry.get("state") or "CURRENTLY_ACTIVE_ACTIVATED",
                },
                runtime_adapter=make_browser_runtime_adapter(),
            )
            registry[eid] = LiveEngine(
                engine_id=eid,
                name=name,
                kind="live_runtime",
                live_status="ACTIVE",
                live_path="engines_live/adapters/browser_runtime.py#ENG-CAP-001",
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical,
                adapter_name="browser_runtime:ENG-CAP-001",
                handler=handler,
                operationally_proven=proven,
                runtime_implementation=True,
            )
            continue

        if eid == "ENG-CAP-091":
            handler = make_runtime_full_handler(
                engine_id=eid,
                name=name,
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical or {
                    "engine_id": eid,
                    "name": name,
                    "classification": entry.get("classification"),
                    "state": entry.get("state") or "CURRENTLY_ACTIVE_ACTIVATED",
                },
                runtime_adapter=make_web_acquisition_adapter(),
            )
            registry[eid] = LiveEngine(
                engine_id=eid,
                name=name,
                kind="live_runtime",
                live_status="ACTIVE",
                live_path="engines_live/adapters/web_acquisition.py#ENG-CAP-091",
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical,
                adapter_name="web_acquisition:ENG-CAP-091",
                handler=handler,
                operationally_proven=proven,
                runtime_implementation=True,
            )
            continue

        if eid == "ENG-CAP-136":
            handler = make_runtime_full_handler(
                engine_id=eid,
                name=name,
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical or {
                    "engine_id": eid,
                    "name": name,
                    "classification": entry.get("classification"),
                    "state": entry.get("state") or "CURRENTLY_ACTIVE_ACTIVATED",
                },
                runtime_adapter=make_mission_modeling_runtime_adapter(),
            )
            registry[eid] = LiveEngine(
                engine_id=eid,
                name=name,
                kind="live_runtime",
                live_status="ACTIVE",
                live_path="engines_live/adapters/mission_modeling_runtime.py#ENG-CAP-136",
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical,
                adapter_name="mission_modeling_runtime:ENG-CAP-136",
                handler=handler,
                operationally_proven=proven,
                runtime_implementation=True,
            )
            continue

        if eid in {"ENG-CAP-140", "ENG-CAP-142"}:
            runtime_adapter = (
                make_context_adaptation_runtime_adapter()
                if eid == "ENG-CAP-140"
                else make_capability_loader_runtime_adapter()
            )
            handler = make_runtime_full_handler(
                engine_id=eid,
                name=name,
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical or {
                    "engine_id": eid,
                    "name": name,
                    "classification": entry.get("classification"),
                    "state": entry.get("state") or "CURRENTLY_ACTIVE_ACTIVATED",
                },
                runtime_adapter=runtime_adapter,
            )
            registry[eid] = LiveEngine(
                engine_id=eid,
                name=name,
                kind="live_runtime",
                live_status="ACTIVE",
                live_path=f"engines_live/adapters/context_loader_runtime.py#{eid}",
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical,
                adapter_name=(
                    "context_adaptation_runtime:ENG-CAP-140"
                    if eid == "ENG-CAP-140"
                    else "capability_loader_runtime:ENG-CAP-142"
                ),
                handler=handler,
                operationally_proven=proven,
                runtime_implementation=True,
            )
            continue

        if eid in {"ENG-CAP-137", "ENG-CAP-138", "ENG-CAP-139"}:
            runtime_adapter = {
                "ENG-CAP-137": make_composition_runtime_adapter,
                "ENG-CAP-138": make_mission_graph_runtime_adapter,
                "ENG-CAP-139": make_result_fusion_runtime_adapter,
            }[eid]()
            handler = make_runtime_full_handler(
                engine_id=eid,
                name=name,
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical or {
                    "engine_id": eid,
                    "name": name,
                    "classification": entry.get("classification"),
                    "state": entry.get("state") or "CURRENTLY_ACTIVE_ACTIVATED",
                },
                runtime_adapter=runtime_adapter,
            )
            registry[eid] = LiveEngine(
                engine_id=eid,
                name=name,
                kind="live_runtime",
                live_status="ACTIVE",
                live_path=f"engines_live/adapters/orchestration_runtime.py#{eid}",
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical,
                adapter_name={
                    "ENG-CAP-137": "composition_runtime:ENG-CAP-137",
                    "ENG-CAP-138": "mission_graph_runtime:ENG-CAP-138",
                    "ENG-CAP-139": "result_fusion_runtime:ENG-CAP-139",
                }[eid],
                handler=handler,
                operationally_proven=proven,
                runtime_implementation=True,
            )
            continue

        if eid == "ENG-CAP-143":
            handler = make_runtime_full_handler(
                engine_id=eid,
                name=name,
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical or {
                    "engine_id": eid,
                    "name": name,
                    "classification": entry.get("classification"),
                    "state": entry.get("state") or "CURRENTLY_ACTIVE_ACTIVATED",
                },
                runtime_adapter=make_gap_acquisition_runtime_adapter(),
            )
            registry[eid] = LiveEngine(
                engine_id=eid,
                name=name,
                kind="live_runtime",
                live_status="ACTIVE",
                live_path="engines_live/adapters/gap_acquisition_runtime.py#ENG-CAP-143",
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical,
                adapter_name="gap_acquisition_runtime:ENG-CAP-143",
                handler=handler,
                operationally_proven=proven,
                runtime_implementation=True,
            )
            continue

        if eid in {"ENG-CAP-147", "ENG-CAP-148"}:
            runtime_adapter = (
                make_evidence_verification_runtime_adapter()
                if eid == "ENG-CAP-147"
                else make_research_synthesis_runtime_adapter()
            )
            handler = make_runtime_full_handler(
                engine_id=eid,
                name=name,
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical or {
                    "engine_id": eid,
                    "name": name,
                    "classification": entry.get("classification"),
                    "state": entry.get("state") or "CURRENTLY_ACTIVE_ACTIVATED",
                },
                runtime_adapter=runtime_adapter,
            )
            registry[eid] = LiveEngine(
                engine_id=eid,
                name=name,
                kind="live_runtime",
                live_status="ACTIVE",
                live_path=f"engines_live/adapters/research_intelligence_runtime.py#{eid}",
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical,
                adapter_name=(
                    "evidence_verification_runtime:ENG-CAP-147"
                    if eid == "ENG-CAP-147"
                    else "research_synthesis_runtime:ENG-CAP-148"
                ),
                handler=handler,
                operationally_proven=proven,
                runtime_implementation=True,
            )
            continue

        if eid in {"ENG-CAP-149", "ENG-CAP-150"}:
            runtime_adapter = (
                make_falsification_causal_runtime_adapter()
                if eid == "ENG-CAP-149"
                else make_scenario_forecast_runtime_adapter()
            )
            handler = make_runtime_full_handler(
                engine_id=eid,
                name=name,
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical or {
                    "engine_id": eid,
                    "name": name,
                    "classification": entry.get("classification"),
                    "state": entry.get("state") or "CURRENTLY_ACTIVE_ACTIVATED",
                },
                runtime_adapter=runtime_adapter,
            )
            registry[eid] = LiveEngine(
                engine_id=eid,
                name=name,
                kind="live_runtime",
                live_status="ACTIVE",
                live_path=f"engines_live/adapters/causal_forecast_runtime.py#{eid}",
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical,
                adapter_name=(
                    "falsification_causal_runtime:ENG-CAP-149"
                    if eid == "ENG-CAP-149"
                    else "scenario_forecast_runtime:ENG-CAP-150"
                ),
                handler=handler,
                operationally_proven=proven,
                runtime_implementation=True,
            )
            continue

        if eid == "ENG-CAP-153":
            handler = make_runtime_full_handler(
                engine_id=eid,
                name=name,
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical or {
                    "engine_id": eid,
                    "name": name,
                    "classification": entry.get("classification"),
                    "state": entry.get("state") or "CURRENTLY_ACTIVE_ACTIVATED",
                },
                runtime_adapter=make_continuous_observatory_runtime_adapter(),
            )
            registry[eid] = LiveEngine(
                engine_id=eid,
                name=name,
                kind="live_runtime",
                live_status="ACTIVE",
                live_path="engines_live/adapters/continuous_observatory_runtime.py#ENG-CAP-153",
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical,
                adapter_name="continuous_observatory_runtime:ENG-CAP-153",
                handler=handler,
                operationally_proven=proven,
                runtime_implementation=True,
            )
            continue

        if eid == "ENG-CAP-154":
            handler = make_runtime_full_handler(
                engine_id=eid,
                name=name,
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical or {
                    "engine_id": eid,
                    "name": name,
                    "classification": entry.get("classification"),
                    "state": entry.get("state") or "CURRENTLY_ACTIVE_ACTIVATED",
                },
                runtime_adapter=make_frontier_discovery_runtime_adapter(),
            )
            registry[eid] = LiveEngine(
                engine_id=eid,
                name=name,
                kind="live_runtime",
                live_status="ACTIVE",
                live_path="engines_live/adapters/frontier_discovery_runtime.py#ENG-CAP-154",
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical,
                adapter_name="frontier_discovery_runtime:ENG-CAP-154",
                handler=handler,
                operationally_proven=proven,
                runtime_implementation=True,
            )
            continue

        if eid == "ENG-CAP-155":
            handler = make_runtime_full_handler(
                engine_id=eid,
                name=name,
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical or {
                    "engine_id": eid,
                    "name": name,
                    "classification": entry.get("classification"),
                    "state": entry.get("state") or "CURRENTLY_ACTIVE_ACTIVATED",
                },
                runtime_adapter=make_benchmark_observatory_runtime_adapter(),
            )
            registry[eid] = LiveEngine(
                engine_id=eid,
                name=name,
                kind="live_runtime",
                live_status="ACTIVE",
                live_path="engines_live/adapters/benchmark_observatory_runtime.py#ENG-CAP-155",
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical,
                adapter_name="benchmark_observatory_runtime:ENG-CAP-155",
                handler=handler,
                operationally_proven=proven,
                runtime_implementation=True,
            )
            continue

        if eid in {"ENG-CAP-156", "ENG-CAP-157"}:
            runtime_adapter = (
                make_research_portfolio_runtime_adapter()
                if eid == "ENG-CAP-156"
                else make_goal_formation_runtime_adapter()
            )
            handler = make_runtime_full_handler(
                engine_id=eid,
                name=name,
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical or {
                    "engine_id": eid,
                    "name": name,
                    "classification": entry.get("classification"),
                    "state": entry.get("state") or "CURRENTLY_ACTIVE_ACTIVATED",
                },
                runtime_adapter=runtime_adapter,
            )
            registry[eid] = LiveEngine(
                engine_id=eid,
                name=name,
                kind="live_runtime",
                live_status="ACTIVE",
                live_path=f"engines_live/adapters/portfolio_goal_runtime.py#{eid}",
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical,
                adapter_name=(
                    "research_portfolio_runtime:ENG-CAP-156"
                    if eid == "ENG-CAP-156"
                    else "goal_formation_runtime:ENG-CAP-157"
                ),
                handler=handler,
                operationally_proven=proven,
                runtime_implementation=True,
            )
            continue

        if eid == "ENG-CAP-158":
            handler = make_runtime_full_handler(
                engine_id=eid,
                name=name,
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical or {
                    "engine_id": eid,
                    "name": name,
                    "classification": entry.get("classification"),
                    "state": entry.get("state") or "CURRENTLY_ACTIVE_ACTIVATED",
                },
                runtime_adapter=make_governed_core_adapter(),
            )
            registry[eid] = LiveEngine(
                engine_id=eid,
                name=name,
                kind="live_runtime",
                live_status="ACTIVE",
                live_path="engines_live/adapters/governed_core_runtime.py#ENG-CAP-158",
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical,
                adapter_name="governed_core_runtime:ENG-CAP-158",
                handler=handler,
                operationally_proven=proven,
                runtime_implementation=True,
            )
            continue

        if eid in {"ENG-CAP-159", "ENG-CAP-160"}:
            runtime_adapter = (
                make_person_identity_resolver_adapter()
                if eid == "ENG-CAP-159"
                else make_publisher_identity_resolver_adapter()
            )
            handler = make_runtime_full_handler(
                engine_id=eid, name=name, capability_packages=packages,
                package_paths=package_paths, required_capabilities=required,
                shared_engine_file=shared_s, canonical=canonical or {
                    "engine_id": eid, "name": name,
                    "classification": entry.get("classification"),
                    "state": entry.get("state") or "CURRENTLY_ACTIVE_ACTIVATED",
                }, runtime_adapter=runtime_adapter,
            )
            registry[eid] = LiveEngine(
                engine_id=eid, name=name, kind="live_runtime", live_status="ACTIVE",
                live_path=f"engines_live/adapters/identity_resolution_runtime.py#{eid}",
                capability_packages=packages, package_paths=package_paths,
                required_capabilities=required, shared_engine_file=shared_s,
                canonical=canonical,
                adapter_name=(
                    "person_identity_resolver:ENG-CAP-159" if eid == "ENG-CAP-159"
                    else "publisher_identity_resolver:ENG-CAP-160"
                ), handler=handler, operationally_proven=proven,
                runtime_implementation=True,
            )
            continue

        if eid in {"ENG-CAP-093", "ENG-CAP-141", "ENG-CAP-152"}:
            handler = make_runtime_full_handler(
                engine_id=eid,
                name=name,
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical or {
                    "engine_id": eid,
                    "name": name,
                    "classification": entry.get("classification"),
                    "state": entry.get("state") or "CURRENTLY_ACTIVE_ACTIVATED",
                },
                runtime_adapter=make_performance_adapter(eid),
            )
            registry[eid] = LiveEngine(
                engine_id=eid,
                name=name,
                kind="live_runtime",
                live_status="ACTIVE",
                live_path=f"engines_live/adapters/performance_runtime.py#{eid}",
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical,
                adapter_name=f"performance_runtime:{eid}",
                handler=handler,
                operationally_proven=proven,
                runtime_implementation=True,
            )
            continue

        if eid in RUNTIME_ADAPTERS:
            # Owner mandate: ALL engines CURRENTLY ACTIVE and ready for full work.
            # Runtime adapters also run required capability steps under authority.
            live_status = "ACTIVE"
            handler = make_runtime_full_handler(
                engine_id=eid,
                name=name,
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical or {
                    "engine_id": eid,
                    "name": name,
                    "classification": entry.get("classification"),
                    "state": entry.get("state") or "CURRENTLY_ACTIVE_ACTIVATED",
                },
                runtime_adapter=RUNTIME_ADAPTERS[eid],
            )
            adapter_name = f"runtime_full:{eid}"
            live_path = str(entry.get("live_path") or f"engines_live/runtime_wrap.py#{eid}")
            registry[eid] = LiveEngine(
                engine_id=eid,
                name=name,
                kind="live_runtime",
                live_status=live_status,
                live_path=live_path,
                capability_packages=packages,
                package_paths=package_paths,
                required_capabilities=required,
                shared_engine_file=shared_s,
                canonical=canonical,
                adapter_name=adapter_name,
                handler=handler,
                operationally_proven=proven,
                runtime_implementation=runtime_implemented,
            )
            continue

        # CAP / remaining engines: same full path as wave-6
        # (authority + capability steps + domain runtime adapter).
        canon = canonical or {
            "engine_id": eid,
            "name": name,
            "classification": entry.get("classification"),
            "target_packages": list(packages),
            "state": entry.get("state") or "CURRENTLY_ACTIVE_ACTIVATED",
        }
        domain_adapter = make_cap_domain_adapter(
            engine_id=eid,
            name=name,
            required_capabilities=required,
            shared_engine_file=shared_s,
            capability_packages=packages,
            package_paths=package_paths,
            canonical=canon,
        )
        handler = make_runtime_full_handler(
            engine_id=eid,
            name=name,
            capability_packages=packages,
            package_paths=package_paths,
            required_capabilities=required,
            shared_engine_file=shared_s,
            canonical=canon,
            runtime_adapter=domain_adapter,
        )
        live_path = str(entry.get("live_path") or f"engines_live/runtime_wrap.py#{eid}")
        registry[eid] = LiveEngine(
            engine_id=eid,
            name=name,
            kind="live_runtime",
            live_status="ACTIVE",
            live_path=live_path,
            capability_packages=packages,
            package_paths=package_paths,
            required_capabilities=required,
            shared_engine_file=shared_s,
            canonical=canonical,
            adapter_name=f"runtime_full:{eid}",
            handler=handler,
            operationally_proven=proven,
            runtime_implementation=runtime_implemented,
        )

    LIVE_ENGINE_REGISTRY.clear()
    LIVE_ENGINE_REGISTRY.update(registry)
    return LIVE_ENGINE_REGISTRY


def list_engine_ids() -> list[str]:
    if not LIVE_ENGINE_REGISTRY:
        build_registry()
    return sorted(LIVE_ENGINE_REGISTRY.keys())


# Eager build on import so `from engines_live import LIVE_ENGINE_REGISTRY` works.
try:
    from capability_cycle.merged_handlers import ensure_merged_handlers_registered

    ensure_merged_handlers_registered()
except Exception:
    pass

build_registry()
