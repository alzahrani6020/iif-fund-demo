"""Wrap wave-6 runtime adapters with full authority + capability execute."""

from __future__ import annotations

from typing import Any, Callable, Mapping

from .engine_execute import execute_cap_engine

Adapter = Callable[[Mapping[str, Any]], dict[str, Any]]


def make_runtime_full_handler(
    *,
    engine_id: str,
    name: str,
    capability_packages: tuple[str, ...],
    package_paths: tuple[str, ...],
    required_capabilities: tuple[str, ...],
    shared_engine_file: str | None,
    canonical: dict[str, Any],
    runtime_adapter: Adapter,
) -> Adapter:
    """Execute required capabilities, then the live runtime adapter."""

    def handler(payload: Mapping[str, Any]) -> dict[str, Any]:
        cap_result = execute_cap_engine(
            engine_id=engine_id,
            name=name,
            capability_packages=capability_packages,
            package_paths=package_paths,
            required_capabilities=required_capabilities,
            shared_engine_file=shared_engine_file,
            canonical=canonical,
            payload=payload,
        )
        if not cap_result.get("executed") and "BLOCKED by authority" in str(
            cap_result.get("message") or ""
        ):
            return cap_result

        try:
            runtime = runtime_adapter(payload)
        except Exception as exc:  # noqa: BLE001
            runtime = {
                "ok": False,
                "executed": False,
                "message": f"{engine_id} runtime adapter failed: {type(exc).__name__}: {exc}",
                "evidence": {"error": f"{type(exc).__name__}: {exc}"},
            }

        evidence = dict(cap_result.get("evidence") or {})
        evidence["runtime_adapter"] = {
            "ok": bool(runtime.get("ok")),
            "executed": bool(runtime.get("executed", runtime.get("ok"))),
            "message": runtime.get("message"),
            "evidence": dict(runtime.get("evidence") or {}),
        }
        steps = list(evidence.get("steps") or [])
        cap_ok = bool(cap_result.get("ok") and cap_result.get("executed"))
        rt_ok = bool(runtime.get("ok") and runtime.get("executed", runtime.get("ok")))
        ok = cap_ok and rt_ok
        bound = list(cap_result.get("bound_capabilities") or [])
        missing = list(cap_result.get("missing_capabilities") or [])
        return {
            "ok": ok,
            "executed": ok,
            "message": (
                f"{engine_id} EXECUTED {len(steps)} capability steps + runtime (ok)"
                if rt_ok
                else str(
                    runtime.get("message")
                    or f"{engine_id} runtime adapter failed"
                )
            ),
            "bound_capabilities": bound,
            "missing_capabilities": missing,
            "evidence": evidence,
        }

    return handler
