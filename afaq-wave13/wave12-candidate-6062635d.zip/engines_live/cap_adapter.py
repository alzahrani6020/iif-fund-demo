"""Capability-foundation engine adapter — live EXECUTE path.

Default action is execute (real capability steps), not bind-only.
"""

from __future__ import annotations

from typing import Any, Mapping

from .engine_execute import execute_cap_engine


def make_cap_handler(
    engine_id: str,
    name: str,
    capability_packages: tuple[str, ...],
    package_paths: tuple[str, ...],
    required_capabilities: tuple[str, ...],
    shared_engine_file: str | None,
    canonical: dict[str, Any],
):
    def handler(payload: Mapping[str, Any]) -> dict[str, Any]:
        action = str(payload.get("action") or "execute")
        if action in ("bind", "bind_and_evaluate"):
            # Still allowed, but routes through execute with bind-focused payload.
            payload = {**dict(payload), "action": "execute", "mode": "bind"}
        return execute_cap_engine(
            engine_id=engine_id,
            name=name,
            capability_packages=capability_packages,
            package_paths=package_paths,
            required_capabilities=required_capabilities,
            shared_engine_file=shared_engine_file,
            canonical=canonical,
            payload=payload,
        )

    return handler
