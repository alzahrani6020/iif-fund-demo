"""Refresh live-engine observations and write audit evidence.

Identity and relationships remain immutable here; only runtime observations
and project-record evidence are updated.
"""
from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from afaq_registry.loader import OBSERVATIONS_PATH, load_observations  # noqa: E402
from engines_live.registry import build_registry  # noqa: E402


def main() -> int:
    registry = build_registry()
    observed_on = datetime.now(timezone.utc).isoformat()
    previous = load_observations()
    previous_by_id = {
        str(row.get("engine_id")): row
        for row in previous.get("engines") or []
        if row.get("engine_id")
    }

    rows = []
    runtime_live = 0
    cap_live = 0
    with_packages = 0
    for engine in sorted(registry.values(), key=lambda e: e.engine_id):
        prior = previous_by_id.get(engine.engine_id, {})
        if engine.kind == "live_runtime":
            runtime_live += 1
        else:
            cap_live += 1
        if engine.capability_packages:
            with_packages += 1
        rows.append({
            "engine_id": engine.engine_id,
            "live_status": engine.live_status,
            "activated": bool(prior.get("activated", False)),
            "activated_on": prior.get("activated_on"),
            "runtime_implementation": bool(engine.runtime_implementation),
            "state": prior.get("state", "OBSERVED"),
        })

    observations = {
        "schema": "AFAQ_REGISTRY_RUNTIME_STATE_V1",
        "observed_on": observed_on,
        "engines": rows,
        "capability_packages": list(previous.get("capability_packages") or []),
    }
    OBSERVATIONS_PATH.parent.mkdir(parents=True, exist_ok=True)
    OBSERVATIONS_PATH.write_text(
        json.dumps(observations, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    evidence_dir = REPO_ROOT / "project-records" / "engine-registry"
    snapshot = {
        "schema": "LIVE_ENGINE_REGISTRY_V2",
        "generated_on": observed_on,
        "total": len(rows),
        "runtime_live": runtime_live,
        "cap_live": cap_live,
        "with_capability_packages": with_packages,
        "engines": [
            {
                "engine_id": e.engine_id,
                "name": e.name,
                "kind": e.kind,
                "live_status": e.live_status,
                "live_path": e.live_path,
                "capability_packages": list(e.capability_packages),
                "required_capabilities": list(e.required_capabilities),
                "adapter": e.adapter_name,
                "runtime_implementation": bool(e.runtime_implementation),
            }
            for e in sorted(registry.values(), key=lambda x: x.engine_id)
        ],
    }
    (evidence_dir / "LIVE_ENGINE_REGISTRY.json").write_text(
        json.dumps(snapshot, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps({
        "observed": len(rows),
        "runtime_live": runtime_live,
        "cap_live": cap_live,
        "observations": str(OBSERVATIONS_PATH),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
