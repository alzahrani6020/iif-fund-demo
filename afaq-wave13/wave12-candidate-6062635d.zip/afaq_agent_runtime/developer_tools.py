"""Developer Agent v2 tools: safe reads and approval-gated writes.

Every path operation is confined to the developer project root. Write-class
tools require a durable ``ApprovalContext`` validated against the approved
proposal scope; the in-memory token alone is no longer sufficient to
authorize mutation.

S05 staging / atomic write helpers:
- ``StagingArea`` stages approved filesystem mutations before applying them
  to live project paths.
- Single-file edit/create uses same-filesystem atomic replacement.
- Create uses exclusive ``O_CREAT | O_EXCL`` semantics and does not overwrite
  an existing target.
- Rename uses atomic single-entry rename where the platform supports it and
  fails closed if the destination already exists.
"""

from __future__ import annotations

import hashlib
import os
import re
import shutil
from pathlib import Path

from afaq_intelligence_core.tools.registry import ToolRegistry, ToolSpec

from .approval_store import (
    ApprovalContext,
    ApprovalScopeExceeded,
    ApprovalStore,
    _canonical_rel_path,
)

MAX_READ_BYTES = 300 * 1024
SKIP_DIRS = {".git", "node_modules", "__pycache__", ".next", "dist", "build", "var", ".venv", "venv"}
BINARY_HINT = re.compile(rb"[\x00-\x08\x0e-\x1f]")


class ApprovalTokenMissing(PermissionError):
    """Raised when a write tool is called without a granted approval token."""


class ProjectBoundary:
    """Path containment guard for one project root."""

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root).resolve()
        if not self.root.is_dir():
            raise ValueError(f"project_root is not a directory: {self.root}")

    def inside(self, path: str | Path) -> Path:
        candidate = Path(path).expanduser().resolve()
        try:
            candidate.relative_to(self.root)
        except ValueError:
            raise PermissionError(
                f"path outside project root: {candidate} (root: {self.root})"
            ) from None
        return candidate

    def relpath(self, path: Path) -> str:
        return str(path.relative_to(self.root))


def _read_raw(path: Path) -> bytes:
    if not path.is_file():
        raise FileNotFoundError(f"not a file: {path}")
    if path.stat().st_size > MAX_READ_BYTES:
        raise ValueError(f"file too large (> {MAX_READ_BYTES} bytes): {path}")
    raw = path.read_bytes()
    if BINARY_HINT.search(raw[:4096]):
        raise ValueError(f"binary file not readable as text: {path}")
    return raw


def _read_text(path: Path) -> str:
    # Strict UTF-8: invalid bytes must fail loudly (the caller's rollback path)
    # instead of being silently corrupted by errors="replace".
    # CRLF is normalized to LF so exact-string edits match regardless of the
    # file's on-disk line endings.
    return _read_raw(path).decode("utf-8").replace("\r\n", "\n")


def _encode_text(content: str, crlf: bool) -> bytes:
    """Encode text preserving the requested EOL style exactly.

    Bytes-level encoding: text-mode would translate LF -> CRLF on Windows and
    turn a one-line patch into a whole-file diff."""
    if crlf:
        # The caller may hand us replacement text that already contains
        # CRLF; converting naively would produce \r\r\n. Normalize first.
        content = content.replace("\r\n", "\n")
        content = content.replace("\n", "\r\n")
    return content.encode("utf-8")


def _write_text(path: Path, content: str, *, crlf: bool) -> None:
    """Write text preserving the file's original EOL style exactly."""
    path.write_bytes(_encode_text(content, crlf))


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _sha256_file(path: Path) -> str:
    return _sha256_bytes(path.read_bytes())


def compute_patched_text(text: str, replacements: list[dict]) -> tuple[str, int]:
    """Apply exact-string replacements to ``text``.

    Returns ``(updated_text, replacement_count)``.

    An empty ``old`` string is defined as append-to-end-of-file.
    """
    applied = 0
    for rep in replacements:
        old, new = rep["old"], rep["new"]
        if old == "":
            if not new:
                raise ValueError("empty append: 'new' must not be empty")
            sep = "" if not text or text.endswith("\n") else "\n"
            text = text + sep + new
            applied += 1
            continue
        occurrences = text.count(old)
        if occurrences == 0:
            raise ValueError(f"patch text not found: {old[:60]!r}")
        if occurrences > 1 and not rep.get("replace_all"):
            raise ValueError(
                f"ambiguous patch text ({occurrences} occurrences): {old[:60]!r}"
            )
        text = text.replace(old, new) if rep.get("replace_all") else text.replace(old, new, 1)
        applied += 1
    return text, applied


class StagingError(RuntimeError):
    """Raised when a staging/validation/apply operation cannot proceed."""


class StagingArea:
    """Bounded staging area for approved DeveloperAgent filesystem mutations.

    S05 semantics:
    - All intended mutations are staged as complete artifacts before any live
      project path is touched.
    - Pre-apply validation checks every operation against its S04 checkpoint
      pre-image and the current live filesystem state.
    - Apply is sequential and best-effort: if operation N fails, operations
      N+1 onward are not attempted.
    - Edit uses same-filesystem atomic replacement (write temp + ``os.replace``).
    - Create uses ``O_CREAT | O_EXCL`` and never overwrites an existing target.
    - Rename uses ``os.rename`` with destination-absence validation.
    - Cleanup removes the per-task staging directory after terminal state.

    S05 does NOT claim:
    - true multi-file transaction atomicity,
    - power-loss durability,
    - crash consistency,
    - cross-process mutation exclusion,
    - cross-filesystem atomicity.
    """

    def __init__(self, staging_root: str | Path, project_root: str | Path) -> None:
        self.staging_root = Path(staging_root)
        self.project_root = Path(project_root).resolve()
        self.staging_root.mkdir(parents=True, exist_ok=True)
        self._entries: list[dict] = []

    @property
    def entries(self) -> list[dict]:
        return list(self._entries)

    def _resolve(self, rel_path: str) -> Path:
        """Resolve a canonical relative path inside ``project_root``."""
        raw = Path(rel_path.replace("\\", "/"))
        if raw.is_absolute():
            target = raw.expanduser().resolve()
        else:
            target = (self.project_root / raw).resolve()
        try:
            target.relative_to(self.project_root)
        except ValueError as exc:
            raise PermissionError(
                f"path outside project root: {rel_path}"
            ) from exc
        return target

    def _staged_path(self, rel_path: str) -> Path:
        return self.staging_root / Path(*rel_path.split("/"))

    @staticmethod
    def _same_filesystem(p1: Path, p2: Path) -> bool:
        try:
            return p1.stat().st_dev == p2.stat().st_dev
        except Exception:  # noqa: BLE001
            return False

    def _stage_bytes(self, rel_path: str, data: bytes) -> Path:
        staged = self._staged_path(rel_path)
        staged.parent.mkdir(parents=True, exist_ok=True)
        # Write to a temp name and atomically rename into the staged path so
        # staged artifact hash checks are not racing a partial write.
        temp = staged.with_suffix(staged.suffix + ".tmp")
        temp.write_bytes(data)
        os.replace(str(temp), str(staged))
        return staged

    def stage_edit(
        self,
        rel_path: str,
        new_content: str | bytes,
        *,
        expected_pre_image_hash: str | None,
    ) -> None:
        """Stage an EDIT operation.

        ``expected_pre_image_hash`` is the S04 checkpoint pre-image hash for
        the live target. ``None`` means the target was expected to be absent.
        """
        target = self._resolve(rel_path)
        if isinstance(new_content, str):
            # Preserve original EOL style of the live target when it exists.
            raw = target.read_bytes() if target.is_file() else b""
            data = _encode_text(new_content, b"\r\n" in raw)
        else:
            data = new_content
        staged = self._stage_bytes(rel_path, data)
        self._entries.append({
            "operation_id": f"op-{len(self._entries)}",
            "action": "edit",
            "path": rel_path,
            "target": target,
            "staged_path": staged,
            "expected_pre_image_hash": expected_pre_image_hash,
            "intended_post_image_hash": _sha256_bytes(data),
        })

    def stage_create(
        self,
        rel_path: str,
        new_content: str | bytes,
    ) -> None:
        """Stage a CREATE operation."""
        target = self._resolve(rel_path)
        if isinstance(new_content, str):
            data = _encode_text(new_content, crlf=False)
        else:
            data = new_content
        staged = self._stage_bytes(rel_path, data)
        self._entries.append({
            "operation_id": f"op-{len(self._entries)}",
            "action": "create",
            "path": rel_path,
            "target": target,
            "staged_path": staged,
            "expected_pre_image_hash": None,
            "intended_post_image_hash": _sha256_bytes(data),
        })

    def stage_rename(
        self,
        source_rel: str,
        dest_rel: str,
        *,
        expected_source_hash: str | None,
        expected_dest_absent: bool = True,
    ) -> None:
        """Stage a RENAME operation.

        ``expected_source_hash`` is the S04 checkpoint hash of the source
        (``None`` if the source was expected absent, which is unusual).
        """
        source = self._resolve(source_rel)
        dest = self._resolve(dest_rel)
        self._entries.append({
            "operation_id": f"op-{len(self._entries)}",
            "action": "rename",
            "path": source_rel,
            "new_path": dest_rel,
            "target": source,
            "new_target": dest,
            "expected_pre_image_hash": expected_source_hash,
            "expected_new_path_absent": expected_dest_absent,
            "intended_post_image_hash": expected_source_hash,
        })

    def validate(self) -> list[dict]:
        """Validate all staged operations against live preconditions.

        Returns a list of failure dicts. An empty list means validation passed.
        Validation performs NO live mutations.
        """
        failures: list[dict] = []
        if not self._same_filesystem(self.staging_root, self.project_root):
            failures.append({
                "reason": "staging root and project root are not on the same filesystem",
            })
            return failures
        for entry in self._entries:
            for failure in self._validate_entry(entry):
                failures.append({
                    "operation_id": entry.get("operation_id"),
                    "path": failure.get("path", entry.get("path")),
                    "reason": failure["reason"],
                })
        return failures

    def _validate_entry(self, entry: dict) -> list[dict]:
        """Validate a single staged entry; return list of failure dicts."""
        failures: list[dict] = []
        action = entry["action"]
        target = entry["target"]

        # Path containment is already enforced in _resolve; this is defense in depth.
        try:
            target.relative_to(self.project_root)
        except ValueError as exc:
            failures.append({"path": entry.get("path"), "reason": f"path outside project root: {exc}"})
            return failures

        if action in ("edit", "create"):
            staged = entry["staged_path"]
            if not staged.is_file():
                failures.append({"path": entry["path"], "reason": f"staged artifact missing: {entry['path']}"})
            else:
                staged_hash = _sha256_file(staged)
                if staged_hash != entry["intended_post_image_hash"]:
                    failures.append({"path": entry["path"], "reason": f"staged artifact hash mismatch for {entry['path']}"})

        if action in ("edit", "rename"):
            expected_hash = entry.get("expected_pre_image_hash")
            if expected_hash is not None:
                if not target.is_file():
                    failures.append({"path": entry["path"], "reason": f"expected file absent: {entry['path']}"})
                else:
                    actual_hash = _sha256_file(target)
                    if actual_hash != expected_hash:
                        failures.append({"path": entry["path"], "reason": f"pre-image hash mismatch for {entry['path']}"})
            else:
                if target.exists():
                    failures.append({"path": entry["path"], "reason": f"expected file absent but exists: {entry['path']}"})

        if action == "create":
            if target.exists():
                failures.append({"path": entry["path"], "reason": f"create target already exists: {entry['path']}"})

        if action == "rename":
            dest = entry["new_target"]
            try:
                dest.relative_to(self.project_root)
            except ValueError as exc:
                failures.append({"path": entry.get("new_path"), "reason": f"destination outside project root: {exc}"})
            if not failures and entry.get("expected_new_path_absent") and dest.exists():
                failures.append({"path": entry["new_path"], "reason": f"rename destination already exists: {entry['new_path']}"})

        return failures

    def apply(self) -> dict:
        """Apply staged operations sequentially.

        Returns a dict with:
        - ``status``: ``full`` or ``partial``
        - ``applied``: list of per-operation result dicts
        - ``failed_index``: index of first failed operation (only when partial)

        If an operation fails, the remaining operations are NOT applied.
        Each operation is re-validated immediately before application to
        minimize the TOCTOU window.
        """
        results: list[dict] = []
        for i, entry in enumerate(self._entries):
            try:
                # Re-validate immediately before touching the live filesystem.
                failures = self._validate_entry(entry)
                if failures:
                    raise StagingError(failures[0]["reason"])
                actual_hash = self._apply_entry(entry)
                results.append({
                    "operation_id": entry["operation_id"],
                    "path": entry["path"],
                    "ok": True,
                    "actual_hash": actual_hash,
                })
            except Exception as exc:  # noqa: BLE001
                reason = f"{type(exc).__name__}: {exc}"
                results.append({
                    "operation_id": entry["operation_id"],
                    "path": entry["path"],
                    "ok": False,
                    "reason": reason,
                })
                return {
                    "status": "partial",
                    "applied": results,
                    "failed_index": i,
                }
        return {"status": "full", "applied": results}

    def _validate_entry(self, entry: dict) -> list[dict]:
        """Validate a single staged entry; return list of failure dicts."""
        failures: list[dict] = []
        action = entry["action"]
        target = entry["target"]

        # Path containment is already enforced in _resolve; this is defense in depth.
        try:
            target.relative_to(self.project_root)
        except ValueError as exc:
            failures.append({"path": entry.get("path"), "reason": f"path outside project root: {exc}"})
            return failures

        if action in ("edit", "create"):
            staged = entry["staged_path"]
            if not staged.is_file():
                failures.append({"path": entry["path"], "reason": f"staged artifact missing: {entry['path']}"})
            else:
                staged_hash = _sha256_file(staged)
                if staged_hash != entry["intended_post_image_hash"]:
                    failures.append({"path": entry["path"], "reason": f"staged artifact hash mismatch for {entry['path']}"})

        if action in ("edit", "rename"):
            expected_hash = entry.get("expected_pre_image_hash")
            if expected_hash is not None:
                if not target.is_file():
                    failures.append({"path": entry["path"], "reason": f"expected file absent: {entry['path']}"})
                else:
                    actual_hash = _sha256_file(target)
                    if actual_hash != expected_hash:
                        failures.append({"path": entry["path"], "reason": f"pre-image hash mismatch for {entry['path']}"})
            else:
                if target.exists():
                    failures.append({"path": entry["path"], "reason": f"expected file absent but exists: {entry['path']}"})

        if action == "create":
            if target.exists():
                failures.append({"path": entry["path"], "reason": f"create target already exists: {entry['path']}"})

        if action == "rename":
            dest = entry["new_target"]
            try:
                dest.relative_to(self.project_root)
            except ValueError as exc:
                failures.append({"path": entry.get("new_path"), "reason": f"destination outside project root: {exc}"})
            if not failures and entry.get("expected_new_path_absent") and dest.exists():
                failures.append({"path": entry["new_path"], "reason": f"rename destination already exists: {entry['new_path']}"})

        return failures

    def _apply_entry(self, entry: dict) -> str:
        action = entry["action"]
        if action == "edit":
            target = entry["target"]
            target.parent.mkdir(parents=True, exist_ok=True)
            # Preserve the staged artifact by copying to a temp file, then
            # atomically replace the live target.
            temp = entry["staged_path"].with_suffix(
                entry["staged_path"].suffix + ".apply"
            )
            shutil.copy2(entry["staged_path"], temp)
            os.replace(str(temp), str(target))
            actual_hash = _sha256_file(target)
            if actual_hash != entry["intended_post_image_hash"]:
                raise StagingError(
                    f"edit verification hash mismatch for {entry['path']}"
                )
            return actual_hash

        if action == "create":
            target = entry["target"]
            target.parent.mkdir(parents=True, exist_ok=True)
            data = entry["staged_path"].read_bytes()
            # O_CREAT | O_EXCL guarantees we do not overwrite an existing target.
            # O_BINARY is required on Windows to prevent \n -> \r\n translation.
            fd = os.open(
                str(target),
                os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_BINARY,
            )
            try:
                os.write(fd, data)
            finally:
                os.close(fd)
            actual_hash = _sha256_file(target)
            if actual_hash != entry["intended_post_image_hash"]:
                # Remove the incorrectly created file if possible.
                if target.exists() and target.is_file():
                    target.unlink()
                raise StagingError(
                    f"create verification hash mismatch for {entry['path']}"
                )
            return actual_hash

        if action == "rename":
            source = entry["target"]
            dest = entry["new_target"]
            dest.parent.mkdir(parents=True, exist_ok=True)
            # Portable fail-closed non-overwriting same-filesystem move:
            #   os.link(source, dest) fails if dest already exists on both
            #   POSIX and Windows (EEXIST / ERROR_ALREADY_EXISTS).
            #   os.unlink(source) then removes the source name.
            # This is NOT an atomic rename. Between link and unlink, both names
            # may exist for the same inode. It does guarantee no overwrite of
            # an unexpected destination and no cross-filesystem copy fallback.
            try:
                os.link(str(source), str(dest))
            except FileExistsError as exc:
                raise StagingError(
                    f"rename destination already exists: {entry['new_path']}"
                ) from exc
            except OSError as exc:
                raise StagingError(
                    f"non-overwriting move failed for {entry['path']}: {exc}"
                ) from exc
            try:
                os.unlink(str(source))
            except OSError as exc:
                # Source removal failed after the destination link was created.
                # The operation is not atomic; leaving both names can confuse
                # downstream recovery. Best-effort undo: remove the destination
                # link we just created so the filesystem returns closer to the
                # pre-mutation state. Report PARTIAL; S04 recovery is invoked
                # by the caller.
                try:
                    os.unlink(str(dest))
                except OSError:
                    pass
                raise StagingError(
                    f"rename source removal failed: {entry['path']}: {exc}"
                ) from exc
            if source.exists():
                raise StagingError(
                    f"rename verification failed: source still exists {entry['path']}"
                )
            if not dest.is_file():
                raise StagingError(
                    f"rename verification failed: destination missing {entry['new_path']}"
                )
            actual_hash = _sha256_file(dest)
            expected_hash = entry.get("intended_post_image_hash")
            if expected_hash is not None and actual_hash != expected_hash:
                raise StagingError(
                    f"rename verification hash mismatch for {entry['new_path']}"
                )
            return actual_hash

        raise StagingError(f"unsupported staging action: {action}")

    def cleanup(self) -> None:
        """Remove the per-task staging directory."""
        if self.staging_root.exists():
            shutil.rmtree(self.staging_root, ignore_errors=True)


def _iter_files(root: Path):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for name in filenames:
            yield Path(dirpath) / name


def register_developer_tools(
    registry: ToolRegistry,
    boundary: ProjectBoundary,
    approvals: ApprovalStore | None = None,
) -> None:
    """Register developer read tools (risk=read) and write tools (risk=write).

    Write tools now require a durable ``ApprovalContext`` validated against the
    approved proposal scope. The in-memory token set remains for compatibility
    but is not sufficient to authorize a mutation.
    """

    approval_tokens: set[str] = set()

    # -- read tools --------------------------------------------------------
    def list_project_files(max_files: int = 500) -> dict:
        files = []
        for path in _iter_files(boundary.root):
            files.append(boundary.relpath(path))
            if len(files) >= max_files:
                break
        return {"root": str(boundary.root), "count": len(files), "files": sorted(files)}

    def read_project_file(path: str) -> dict:
        target = boundary.inside(path if Path(path).is_absolute() else boundary.root / path)
        content = _read_text(target)
        return {"path": boundary.relpath(target), "content": content, "size_bytes": len(content)}

    def search_code(query: str, max_results: int = 50) -> dict:
        results = []
        for path in _iter_files(boundary.root):
            try:
                content = _read_text(path)
            except (ValueError, OSError, UnicodeError):
                continue
            for lineno, line in enumerate(content.splitlines(), 1):
                if query in line:
                    results.append({
                        "path": boundary.relpath(path),
                        "line": lineno,
                        "text": line.strip()[:200],
                    })
                    if len(results) >= max_results:
                        return {"query": query, "count": len(results), "results": results}
        return {"query": query, "count": len(results), "results": results}

    def inspect_file(path: str) -> dict:
        target = boundary.inside(path if Path(path).is_absolute() else boundary.root / path)
        content = _read_text(target)
        lines = content.splitlines()
        return {
            "path": boundary.relpath(target),
            "size_bytes": len(content),
            "line_count": len(lines),
            "first_lines": lines[:40],
        }

    def inspect_git_status() -> dict:
        from .command_allowlist import run_allowed
        result = run_allowed(["git", "status", "--porcelain"], cwd=str(boundary.root))
        return {"passed": result["passed"], "stdout": result["stdout"], "stderr": result["stderr"]}

    def inspect_diff() -> dict:
        from .command_allowlist import run_allowed
        result = run_allowed(["git", "diff"], cwd=str(boundary.root))
        return {"passed": result["passed"], "stdout": result["stdout"], "stderr": result["stderr"]}

    def detect_project_type() -> dict:
        from .repository_mapper import detect_project_type as detect
        return detect(boundary.root)

    def inspect_dependencies() -> dict:
        from .repository_mapper import inspect_dependencies as inspect
        return inspect(boundary.root)

    # -- write tools (gated by durable approval scope) ----------------------
    def _tool_action_to_scope_action(tool_action: str) -> str:
        return {
            "create_file": "create",
            "edit_file": "edit",
            "apply_patch": "edit",
            "rename_file": "rename",
        }.get(tool_action, tool_action)

    def _require_approval(
        context: ApprovalContext | None,
        tool_action: str,
        relative_path: str,
        new_relative_path: str | None = None,
    ) -> None:
        if approvals is None:
            raise ApprovalScopeExceeded(
                f"{tool_action} has no durable approval store; mutation denied"
            )
        if not isinstance(context, ApprovalContext):
            raise ApprovalScopeExceeded(
                f"{tool_action} requires a durable approval context"
            )
        scope_action = _tool_action_to_scope_action(tool_action)
        approvals.validate_scope(context, relative_path, scope_action)
        if tool_action == "rename_file":
            if new_relative_path is None:
                raise ApprovalScopeExceeded(
                    "rename_file requires a target path scope check"
                )
            approvals.validate_scope(context, new_relative_path, scope_action)

    def create_file(path: str, content: str, approval_context: ApprovalContext | None = None) -> dict:
        target = boundary.inside(path if Path(path).is_absolute() else boundary.root / path)
        rel = boundary.relpath(target)
        _require_approval(approval_context, "create_file", rel)
        if target.exists():
            raise FileExistsError(f"refusing to overwrite existing file: {target}")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content.encode("utf-8"))
        return {"path": boundary.relpath(target), "action": "created", "bytes": len(content)}

    def edit_file(path: str, old: str, new: str, approval_context: ApprovalContext | None = None,
                  replace_all: bool = False) -> dict:
        target = boundary.inside(path if Path(path).is_absolute() else boundary.root / path)
        rel = boundary.relpath(target)
        _require_approval(approval_context, "edit_file", rel)
        raw = _read_raw(target)
        crlf = b"\r\n" in raw
        content = raw.decode("utf-8").replace("\r\n", "\n")
        if old == "":
            # Defined append semantics (see apply_patch).
            if not new:
                raise ValueError("empty append: 'new' must not be empty")
            sep = "" if not content or content.endswith("\n") else "\n"
            updated = content + sep + new
            _write_text(target, updated, crlf=crlf)
            return {"path": boundary.relpath(target), "action": "edited", "replacements": 1}
        occurrences = content.count(old)
        if occurrences == 0:
            raise ValueError("old text not found in file")
        if occurrences > 1 and not replace_all:
            raise ValueError(
                f"old text occurs {occurrences} times; refuse ambiguous edit"
            )
        updated, count = compute_patched_text(
            content,
            [{"old": old, "new": new, "replace_all": replace_all}],
        )
        _write_text(target, updated, crlf=crlf)
        return {"path": boundary.relpath(target), "action": "edited", "replacements": count}

    def apply_patch(path: str, replacements: list, approval_context: ApprovalContext | None = None) -> dict:
        """Structured patch: [{"old": str, "new": str, "replace_all": bool}].

        An empty "old" is defined as append-to-end-of-file (the consistent
        idiom of the local coder models), never a substring search.
        """
        target = boundary.inside(path if Path(path).is_absolute() else boundary.root / path)
        rel = boundary.relpath(target)
        _require_approval(approval_context, "apply_patch", rel)
        raw = _read_raw(target)
        crlf = b"\r\n" in raw
        content = raw.decode("utf-8").replace("\r\n", "\n")
        content, applied = compute_patched_text(content, replacements)
        _write_text(target, content, crlf=crlf)
        return {"path": boundary.relpath(target), "action": "patched", "replacements": applied}

    def rename_file(path: str, new_name: str, approval_context: ApprovalContext | None = None) -> dict:
        target = boundary.inside(path if Path(path).is_absolute() else boundary.root / path)
        destination = boundary.inside(new_name if Path(new_name).is_absolute() else boundary.root / new_name)
        rel = boundary.relpath(target)
        rel_dest = boundary.relpath(destination)
        _require_approval(approval_context, "rename_file", rel, rel_dest)
        if destination.exists():
            raise FileExistsError(f"destination already exists: {destination}")
        target.rename(destination)
        return {"path": boundary.relpath(target), "action": "renamed", "to": boundary.relpath(destination)}

    registry.register(ToolSpec("list_project_files", "List files under the project root (bounded)", "read", list_project_files))
    registry.register(ToolSpec("read_project_file", "Read a text file inside the project root", "read", read_project_file))
    registry.register(ToolSpec("search_code", "Search for a literal string in project files", "read", search_code))
    registry.register(ToolSpec("inspect_file", "File overview: size, line count, head", "read", inspect_file))
    registry.register(ToolSpec("inspect_git_status", "git status --porcelain (read-only)", "read", inspect_git_status))
    registry.register(ToolSpec("inspect_diff", "git diff (read-only)", "read", inspect_diff))
    registry.register(ToolSpec("detect_project_type", "Detect project type and config files", "read", detect_project_type))
    registry.register(ToolSpec("inspect_dependencies", "Inspect dependency manifests", "read", inspect_dependencies))

    registry.register(ToolSpec("create_file", "Create a new file (approval-gated)", "write", create_file))
    registry.register(ToolSpec("edit_file", "Exact-string file edit (approval-gated)", "write", edit_file))
    registry.register(ToolSpec("apply_patch", "Structured replacement patch (approval-gated)", "write", apply_patch))
    registry.register(ToolSpec("rename_file", "Rename a file (approval-gated)", "write", rename_file))

    def issue_token(task_id: str) -> str:
        # In-memory tokens are no longer authoritative for mutation, but the
        # helper remains for compatibility with callers that still track them.
        token = f"APPROVED-{task_id}"
        approval_tokens.add(token)
        return token

    def revoke_token(task_id: str) -> None:
        # A granted token must never outlive the task that was approved.
        approval_tokens.discard(f"APPROVED-{task_id}")

    registry.issue_token = issue_token  # runtime-internal helper
    registry.revoke_token = revoke_token  # runtime-internal helper
