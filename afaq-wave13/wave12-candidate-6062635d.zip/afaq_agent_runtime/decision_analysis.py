"""Decision intelligence layer for governed change proposals.

INTERNAL-ONLY, ADVISORY. This module adds analysis depth to the proposal
generation path without changing the canonical proposal contract
(validate_proposal stays byte-identical in behavior) and without creating
any authority: the analysis is model-generated advisory metadata that is
quality-gated, persisted with the developer task, and presented read-only
to the owner. Runtime remains validation/gate/approval authority; the
owner remains decision authority.

Classification (GAP-PQ-1 capability map):
  QUALITY-GATE ONLY : analysis sufficiency, internal consistency, epistemic
                      shape, decision readiness seal
  INTERNAL-ONLY     : the DecisionAnalysis object itself
  DERIVABLE         : decision package composition, blast radius mapping,
                      reversibility from action types, owner attention routing
  FUTURE            : learning/training/generalization/promotion loops
"""

from __future__ import annotations

import re
from typing import Any, Mapping

from .intent_gate import extract_file_paths

# ---------------------------------------------------------------------------
# Adaptive depth: required analysis shape scales with the CHANGE ITSELF
# (breadth + sensitivity), never with repository size. A single-file,
# non-sensitive change needs the base package; a multi-file or sensitive
# change needs the deep package. Depth is deterministic — never an LLM guess.

_ROOT_CAUSE_STATUSES = ("proven", "best_supported", "unknown")
_EVIDENCE_KINDS = ("fact", "observation", "inference")
_BLAST_RADIUS = (
    "local", "module", "multi-module", "domain", "state", "authority",
)
_REVERSIBILITY = ("reversible", "partially_reversible", "irreversible", "unknown")
_CONFIDENCE = ("high", "medium", "low", "unknown")

# Field budgets keep the small local model inside its token ceiling.
_MAX_FIELD_WORDS = 40
_MAX_EVIDENCE = 3
_MAX_ALTERNATIVES = 2

_BASE_REQUIRED = (
    "problem", "root_cause", "evidence", "no_change_considered",
    "minimality", "impact", "reversibility", "verification", "confidence",
)
_DEEP_EXTRA = ("alternatives", "falsification", "counterargument", "dependencies")

# Instruction signals that this is remediation of a defect — only then is an
# UNKNOWN root cause blocking. A pure change request has no defect to
# explain; demanding a proven root cause there would force fabricated
# certainty.
_REMEDIATION_KEYWORDS = (
    "bug", "fix", "error", "fail", "broken", "wrong", "incorrect",
    "off-by-one", "regression", "crash", "defect",
)


def is_remediation_instruction(instruction: str) -> bool:
    text = (instruction or "").lower()
    return any(k in text for k in _REMEDIATION_KEYWORDS)


def _normalize_grounding_text(text: str) -> str:
    """Lowercase, unify path slashes, and collapse call-site spacing.

    Local models quote instruction facts with different whitespace
    (``add(2, 3)`` vs ``add(2,3)``). That is the same fact, not a new claim.
    """
    normalized = (text or "").lower().replace("\\", "/")
    normalized = re.sub(r"\s+", " ", normalized).strip()
    normalized = re.sub(r"\(\s+", "(", normalized)
    normalized = re.sub(r"\s+\)", ")", normalized)
    return re.sub(r",\s+", ",", normalized)


def _grounding_tokens(instruction: str, proposed_paths: list[str]) -> tuple[str, ...]:
    """Distinctive instruction/path tokens that can ground an evidence entry."""
    tokens: list[str] = []
    for token in _normalize_grounding_text(instruction).split():
        if len(token) >= 6:
            tokens.append(token)
    for path in proposed_paths:
        normalized = _normalize_grounding_text(path)
        if normalized:
            tokens.append(normalized)
            base = normalized.rsplit("/", 1)[-1]
            if base and base not in tokens:
                tokens.append(base)
    seen: list[str] = []
    for token in tokens:
        if token and token not in seen:
            seen.append(token)
    return tuple(seen)


def _evidence_is_grounded(
    entry: Mapping[str, Any],
    *,
    instruction: str,
    proposed_paths: list[str],
) -> bool:
    """True when claim or basis quotes the task or names a proposed path.

    The quality gate refuses invented evidence, not local-model punctuation.
    Checking claim+basis together matches the rejection text (which cites
    the claim) and the prompt contract (quote the task or name a repo path).
    """
    tokens = _grounding_tokens(instruction, proposed_paths)
    blob = _normalize_grounding_text(
        f"{entry.get('basis', '')} {entry.get('claim', '')}"
    )
    return any(token in blob for token in tokens)


class DecisionAnalysisError(ValueError):
    """Bounded, user-facing analysis parse/quality failure."""


def _words(text: str) -> int:
    return len(text.split())


def _require_str(obj: Mapping[str, Any], key: str, where: str) -> str:
    value = obj.get(key)
    if not isinstance(value, str) or not value.strip():
        raise DecisionAnalysisError(f"analysis.{where}.{key} must be a non-empty string")
    if _words(value) > _MAX_FIELD_WORDS:
        raise DecisionAnalysisError(
            f"analysis.{where}.{key} exceeds {_MAX_FIELD_WORDS} words"
        )
    return value.strip()


def parse_analysis(
    payload: Any,
    *,
    deep: bool = False,
) -> dict[str, Any]:
    """Validate and normalize the model-generated advisory analysis.

    Raises DecisionAnalysisError with a specific reason. Unknown keys are
    ignored (forward-tolerant); required keys are enforced per adaptive
    depth (deep = multi-file or sensitive change). This is a QUALITY GATE,
    not a canonical contract: the shape is advisory and internal-only.
    """
    if not isinstance(payload, Mapping):
        raise DecisionAnalysisError("analysis must be a JSON object")
    required = _BASE_REQUIRED + (_DEEP_EXTRA if deep else ())
    missing = [k for k in required if k not in payload]
    if missing:
        depth = "deep" if deep else "base"
        raise DecisionAnalysisError(
            f"analysis missing required field(s) for {depth} depth: {missing}"
        )

    analysis: dict[str, Any] = {}

    analysis["problem"] = _require_str(payload, "problem", "")

    root = payload.get("root_cause")
    if not isinstance(root, Mapping):
        raise DecisionAnalysisError("analysis.root_cause must be an object")
    statement = _require_str(root, "statement", "root_cause")
    status = str(root.get("status", "")).strip()
    if status not in _ROOT_CAUSE_STATUSES:
        raise DecisionAnalysisError(
            f"analysis.root_cause.status must be one of {_ROOT_CAUSE_STATUSES}"
        )
    alternatives = root.get("competing_hypotheses") or []
    if not isinstance(alternatives, list) or len(alternatives) > _MAX_EVIDENCE:
        raise DecisionAnalysisError("analysis.root_cause.competing_hypotheses invalid")
    for alt in alternatives:
        if not isinstance(alt, str) or not alt.strip() or _words(alt) > _MAX_FIELD_WORDS:
            raise DecisionAnalysisError(
                "each competing hypothesis must be a non-empty string "
                f"(<= {_MAX_FIELD_WORDS} words)"
            )
    analysis["root_cause"] = {
        "statement": statement,
        "status": status,
        "competing_hypotheses": [a.strip() for a in alternatives],
    }

    evidence = payload.get("evidence")
    if not isinstance(evidence, list) or not evidence:
        raise DecisionAnalysisError("analysis.evidence must be a non-empty list")
    if len(evidence) > _MAX_EVIDENCE:
        raise DecisionAnalysisError(f"analysis.evidence exceeds {_MAX_EVIDENCE} entries")
    norm_evidence = []
    for entry in evidence:
        if not isinstance(entry, Mapping):
            raise DecisionAnalysisError("each evidence entry must be an object")
        claim = _require_str(entry, "claim", "evidence")
        kind = str(entry.get("kind", "")).strip()
        if kind not in _EVIDENCE_KINDS:
            raise DecisionAnalysisError(
                f"evidence kind must be one of {_EVIDENCE_KINDS}"
            )
        basis = _require_str(entry, "basis", "evidence")
        norm_evidence.append({"claim": claim, "kind": kind, "basis": basis})
    analysis["evidence"] = norm_evidence

    no_change = payload.get("no_change_considered")
    if not isinstance(no_change, Mapping):
        raise DecisionAnalysisError("analysis.no_change_considered must be an object")
    considered = no_change.get("considered")
    reason = _require_str(no_change, "reason", "no_change_considered")
    if considered is not True:
        raise DecisionAnalysisError(
            "analysis must explicitly consider the no-change option "
            "(no_change_considered.considered = true with reason)"
        )
    analysis["no_change_considered"] = {"considered": True, "reason": reason}

    minimality = payload.get("minimality")
    if not isinstance(minimality, Mapping):
        raise DecisionAnalysisError("analysis.minimality must be an object")
    is_minimum = minimality.get("is_minimum")
    if not isinstance(is_minimum, bool):
        raise DecisionAnalysisError("analysis.minimality.is_minimum must be boolean")
    justification = _require_str(minimality, "justification", "minimality")
    analysis["minimality"] = {
        "is_minimum": is_minimum,
        "justification": justification,
    }

    impact = payload.get("impact")
    if not isinstance(impact, Mapping):
        raise DecisionAnalysisError("analysis.impact must be an object")
    direct = impact.get("directly_modified")
    if not isinstance(direct, list) or not all(isinstance(p, str) and p.strip() for p in direct):
        raise DecisionAnalysisError("analysis.impact.directly_modified must be a list of paths")
    blast = str(impact.get("blast_radius", "")).strip()
    if blast not in _BLAST_RADIUS:
        raise DecisionAnalysisError(
            f"analysis.impact.blast_radius must be one of {_BLAST_RADIUS}"
        )
    analysis["impact"] = {
        "directly_modified": [p.strip() for p in direct],
        "blast_radius": blast,
    }

    reversibility = str(payload.get("reversibility", "")).strip()
    if reversibility not in _REVERSIBILITY:
        raise DecisionAnalysisError(
            f"analysis.reversibility must be one of {_REVERSIBILITY}"
        )
    analysis["reversibility"] = reversibility

    verification = payload.get("verification")
    if not isinstance(verification, list) or not verification:
        raise DecisionAnalysisError("analysis.verification must be a non-empty list")
    norm_verification = []
    for step in verification:
        if not isinstance(step, str) or not step.strip() or _words(step) > _MAX_FIELD_WORDS:
            raise DecisionAnalysisError(
                "each verification step must be a non-empty string "
                f"(<= {_MAX_FIELD_WORDS} words)"
            )
        norm_verification.append(step.strip())
    analysis["verification"] = norm_verification

    confidence = payload.get("confidence")
    if not isinstance(confidence, Mapping):
        raise DecisionAnalysisError("analysis.confidence must be an object")
    level = str(confidence.get("level", "")).strip()
    if level not in _CONFIDENCE:
        raise DecisionAnalysisError(f"analysis.confidence.level must be one of {_CONFIDENCE}")
    basis = _require_str(confidence, "basis", "confidence")
    limitations = confidence.get("limitations", "")
    if not isinstance(limitations, str):
        raise DecisionAnalysisError("analysis.confidence.limitations must be a string")
    analysis["confidence"] = {
        "level": level,
        "basis": basis,
        "limitations": limitations.strip(),
    }

    # Optional-but-shaped fields (required only at deeper tiers; accepted
    # at any tier when present and well-formed).
    for key in ("assumptions", "uncertainties", "dependencies"):
        value = payload.get(key) or []
        if not isinstance(value, list) or len(value) > _MAX_EVIDENCE:
            raise DecisionAnalysisError(f"analysis.{key} must be a list (<= {_MAX_EVIDENCE})")
        for item in value:
            if not isinstance(item, str) or not item.strip() or _words(item) > _MAX_FIELD_WORDS:
                raise DecisionAnalysisError(
                    f"each analysis.{key} entry must be a non-empty string "
                    f"(<= {_MAX_FIELD_WORDS} words)"
                )
        analysis[key] = [i.strip() for i in value]

    if "alternatives" in required:
        alts = payload.get("alternatives")
        if not isinstance(alts, list) or not alts:
            raise DecisionAnalysisError("analysis.alternatives must be a non-empty list")
        if len(alts) > _MAX_ALTERNATIVES + 1:
            raise DecisionAnalysisError(
                f"analysis.alternatives exceeds {_MAX_ALTERNATIVES + 1} entries"
            )
        norm_alts = []
        for alt in alts:
            if not isinstance(alt, Mapping):
                raise DecisionAnalysisError("each alternative must be an object")
            option = _require_str(alt, "option", "alternatives")
            why = _require_str(alt, "why_not", "alternatives")
            norm_alts.append({"option": option, "why_not": why})
        analysis["alternatives"] = norm_alts

    if "falsification" in required:
        analysis["falsification"] = _require_str(payload, "falsification", "")

    if "counterargument" in required:
        analysis["counterargument"] = _require_str(payload, "counterargument", "")

    return analysis


# ---------------------------------------------------------------------------
# Deterministic quality gates over the parsed analysis + canonical proposal.

def run_quality_gates(
    analysis: Mapping[str, Any],
    proposal: Mapping[str, Any],
    *,
    instruction: str,
) -> list[str]:
    """Return a list of quality-gate failure reasons (empty = pass).

    These gates never weaken canonical validation; they only refuse to
    present an analysis as decision-ready when it is inconsistent with the
    proposal it claims to explain.
    """
    failures: list[str] = []

    proposed_paths = [f["path"] for f in proposal.get("files", [])]

    # Scope fidelity: every proposed file must be NAMED in the task
    # instruction. Proposing an unmentioned file is hallucinated scope —
    # the strongest way a small model drifts into touching code nobody
    # asked it to touch. (The proposal allowlist already blocks writes to
    # nonexistent/unmapped files; this gate blocks *plausible* drift.)
    named = {p.lower() for p in extract_file_paths(instruction)}
    for path in proposed_paths:
        if path.lower() not in named:
            failures.append(
                f"proposal targets '{path}' which is not named in the task instruction"
            )

    declared = list(analysis.get("impact", {}).get("directly_modified", []))
    if sorted(declared) != sorted(proposed_paths):
        failures.append(
            "impact.directly_modified does not match the proposal's file set"
        )

    test_names = {t.get("name", "") for t in proposal.get("tests", [])}
    test_cmds = {
        " ".join(map(str, t.get("command", [])))
        for t in proposal.get("tests", [])
    }
    verification = analysis.get("verification", [])
    grounded = False
    for step in verification:
        if any(name and name in step for name in test_names) or any(
            cmd and cmd in step for cmd in test_cmds
        ):
            grounded = True
            break
    if not grounded:
        failures.append(
            "verification plan does not reference any proposed test"
        )

    # Evidence grounding: an entry is GROUNDED when its claim or basis quotes
    # a concrete fact from the instruction or names a real repository path.
    # Punctuation/spacing variants of the same fact are the same fact.
    # Everything else stays honestly labelled MODEL-ASSERTED downstream.
    for entry in analysis.get("evidence", []):
        if not _evidence_is_grounded(
            entry,
            instruction=instruction,
            proposed_paths=proposed_paths,
        ):
            failures.append(
                "evidence basis is not grounded in the task or repository: "
                + entry.get("claim", "")[:60]
            )

    # Blast radius must be consistent with breadth: claiming 'local' while
    # touching many files is a contradiction, not a style issue.
    breadth = len(proposed_paths)
    claimed = analysis.get("impact", {}).get("blast_radius", "")
    if claimed == "local" and breadth > 2:
        failures.append(
            f"blast_radius 'local' contradicts {breadth} modified files"
        )

    # Minimum-sufficient-change honesty: a proposal that declares itself
    # non-minimum must still justify the broader scope.
    if not analysis.get("minimality", {}).get("justification"):
        failures.append("minimality justification missing")

    return failures


def decision_readiness(
    analysis: Mapping[str, Any],
    gate_failures: list[str],
    *,
    remediation: bool = False,
) -> dict[str, Any]:
    """Decision Integrity Seal over the advisory analysis.

    READY requires: parse succeeded (caller), quality gates clean, at least
    one evidence entry, and explicit uncertainty handling is present as a
    field (it may be empty = NONE DECLARED, which is itself a disclosure).
    An UNKNOWN root cause blocks ONLY remediation tasks: a pure change
    request has no defect whose cause could be proven, and forcing one
    would fabricate certainty.
    """
    blocking = list(gate_failures)
    root_status = analysis.get("root_cause", {}).get("status", "unknown")
    if remediation and root_status == "unknown":
        blocking.append("root cause is UNKNOWN — analysis insufficient")
    if not analysis.get("evidence"):
        blocking.append("no evidence entries")
    ready = not blocking
    return {
        "decision_ready": ready,
        "blocking_items": blocking,
        "seal": {
            "analysis_sufficient": not gate_failures,
            "problem_proven": bool(analysis.get("problem")),
            "evidence_traceable": bool(analysis.get("evidence")),
            "no_change_considered": bool(analysis.get("no_change_considered", {}).get("considered")),
            "minimality_justified": bool(analysis.get("minimality", {}).get("justification")),
            "uncertainties_disclosed": "uncertainties" in analysis,
            "risks_disclosed": True,  # canonical 'risks' field validated separately
            "authority_preserved": True,  # this layer is advisory only
        },
    }


def build_decision_package(
    *,
    instruction: str,
    proposal: Mapping[str, Any],
    analysis: Mapping[str, Any] | None,
    risk: Mapping[str, Any] | None,
    approval: Mapping[str, Any] | None,
) -> dict[str, Any]:
    """Compose the owner-facing decision package from truthfully available
    parts. ABSENT stays ABSENT: anything not derivable is reported as
    UNKNOWN / NOT REPRESENTABLE, never fabricated."""
    package: dict[str, Any] = {
        "decision_snapshot": {
            "problem": (analysis or {}).get("problem", "UNKNOWN"),
            "proposed_change": [
                {"path": f["path"], "action": f["action"]}
                for f in proposal.get("files", [])
            ],
            "expected_benefit": proposal.get("rationale", ""),
            "primary_risk": proposal.get("risks", ""),
            "blast_radius": (analysis or {}).get("impact", {}).get("blast_radius", "UNKNOWN"),
            "reversibility": (analysis or {}).get("reversibility", "UNKNOWN"),
            "risk_level": (risk or {}).get("level", "UNKNOWN"),
            "uncertainty": (
                "; ".join((analysis or {}).get("uncertainties", [])) or "NONE DECLARED"
            ),
        },
        "owner_decision_boundary": {
            "owner_is_deciding": "approve or reject the exact bounded change below",
            "this_approval_authorizes": [
                f"{f['action']} {f['path']}" for f in proposal.get("files", [])
            ],
            "this_approval_does_not_authorize": [
                "any file not listed above",
                "any execution beyond the proposed tests",
                "any schema, authority, or promotion change",
            ],
            "requires_separate_owner_decision": [
                "changes outside the listed files",
                "canonical contract expansion",
                "any promotion or learning deployment",
            ],
        },
        "authority_note": "advisory analysis only — runtime remains validation and approval authority; owner remains decision authority",
    }
    if analysis is None:
        package["analysis"] = "NOT AVAILABLE — canonical proposal only"
        package["decision_readiness"] = {
            "decision_ready": False,
            "blocking_items": ["decision analysis unavailable"],
        }
    else:
        package["analysis"] = analysis
        package["decision_readiness"] = decision_readiness(analysis, [])
    if approval:
        package["approval"] = {
            "approval_id": approval.get("approval_id"),
            "status": approval.get("status"),
            "risk_level": approval.get("risk_level"),
        }
    return package
