from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .orchestrator import AfaqOrchestrator
from .afaq_ai import AfaqAI


def main() -> int:
    parser = argparse.ArgumentParser(prog="afaq-governed-agent")
    parser.add_argument("--root", required=True)
    sub = parser.add_subparsers(dest="cmd", required=True)
    sub.add_parser("files")
    r = sub.add_parser("read"); r.add_argument("path")
    q = sub.add_parser("search"); q.add_argument("query")
    e = sub.add_parser("edit"); e.add_argument("path"); e.add_argument("--old", required=True); e.add_argument("--new", required=True); e.add_argument("--approve", action="store_true")
    x = sub.add_parser("run"); x.add_argument("command")
    sub.add_parser("status"); sub.add_parser("diff"); sub.add_parser("map")
    sub.add_parser("ai-status")
    p_ai = sub.add_parser("ai-plan"); p_ai.add_argument("goal")
    r_ai = sub.add_parser("ai-run"); r_ai.add_argument("goal"); r_ai.add_argument("--approve", action="store_true")
    l_ai = sub.add_parser("ai-learn"); l_ai.add_argument("goal"); l_ai.add_argument("--approve", action="store_true")
    d_ai = sub.add_parser("ai-develop")
    d_ai.add_argument("topic")
    d_ai.add_argument("--sources-json", required=True)
    d_ai.add_argument("--approve", action="store_true")
    grow_ai = sub.add_parser("ai-grow")
    grow_ai.add_argument("--requirement-json", required=True)
    grow_ai.add_argument("--spec-only", action="store_true")
    grow_ai.add_argument("--approve", action="store_true")
    grow_validate = sub.add_parser("ai-grow-validate")
    grow_validate.add_argument("capability_id")
    grow_promote = sub.add_parser("ai-grow-promote")
    grow_promote.add_argument("capability_id")
    grow_promote.add_argument("--requirement-json", required=True)
    grow_promote.add_argument("--review-json", required=True)
    grow_promote.add_argument("--roles-json", required=True)
    grow_promote.add_argument("--test-payload-json", required=True)
    grow_rollback = sub.add_parser("ai-grow-rollback")
    grow_rollback.add_argument("capability_id")
    grow_rollback.add_argument("--operator-id", required=True)
    c_ai = sub.add_parser("ai-capability")
    c_ai.add_argument("action")
    c_ai.add_argument("--args-json", default="{}")
    c_ai.add_argument("--approve", action="store_true")
    g_ai = sub.add_parser("ai-generate")
    g_ai.add_argument("goal")
    g_ai.add_argument("--name")
    g_ai.add_argument("--kind", default="agent", choices=("agent", "model", "finetune", "distillation", "multimodal"))
    k_new = sub.add_parser("api-key-create")
    k_new.add_argument("name")
    k_new.add_argument("--scopes", default="read,plan,run,generate")
    sub.add_parser("api-key-list")
    k_revoke = sub.add_parser("api-key-revoke")
    k_revoke.add_argument("key_id")
    args = parser.parse_args()

    if args.cmd in {
        "ai-status", "ai-plan", "ai-run", "ai-learn", "ai-develop", "ai-grow", "ai-grow-validate", "ai-grow-promote", "ai-grow-rollback", "ai-capability", "ai-generate",
        "api-key-create", "api-key-list", "api-key-revoke",
    }:
        ai = AfaqAI(
            args.root,
            memory_path=Path(args.root) / "var" / "afaq_ai" / "memory.sqlite",
        )
        if args.cmd == "api-key-create":
            scopes = tuple(
                s.strip() for s in str(args.scopes).split(",") if s.strip()
            )
            created = ai.api_keys.create(args.name, scopes=scopes)
            print(json.dumps({
                "key_id": created.key.key_id,
                "name": created.key.name,
                "prefix": created.key.prefix,
                "scopes": list(created.key.scopes),
                "created_at": created.key.created_at,
                "secret": created.secret,
                "warning": "This plaintext AFAQ API key is shown once. Store it securely.",
            }, ensure_ascii=False, indent=2))
            return 0
        if args.cmd == "api-key-list":
            print(json.dumps([
                {
                    "key_id": key.key_id,
                    "name": key.name,
                    "prefix": key.prefix,
                    "scopes": list(key.scopes),
                    "created_at": key.created_at,
                    "revoked": key.revoked,
                }
                for key in ai.api_keys.list()
            ], ensure_ascii=False, indent=2))
            return 0
        if args.cmd == "api-key-revoke":
            ok = ai.api_keys.revoke(args.key_id)
            print(json.dumps({
                "key_id": args.key_id,
                "revoked": ok,
            }, ensure_ascii=False, indent=2))
            return 0 if ok else 2
        if args.cmd == "ai-status":
            result = ai.status()
            print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
            return 0
        if args.cmd == "ai-plan":
            plan = ai.plan(args.goal)
            print(json.dumps(plan.as_dict(), ensure_ascii=False, indent=2, default=str))
            return 0 if plan.executable else 2
        if args.cmd == "ai-learn":
            learned = ai.learn(
                args.goal,
                approved_by_job=args.approve,
            )
            print(json.dumps(
                learned,
                ensure_ascii=False,
                indent=2,
                default=str,
            ))
            return 0 if learned["evaluation"]["success"] else 2
        if args.cmd == "ai-develop":
            try:
                sources = json.loads(args.sources_json)
            except json.JSONDecodeError as exc:
                raise ValueError("--sources-json must be valid JSON") from exc
            if not isinstance(sources, list):
                raise ValueError("--sources-json must decode to a list")
            developed = ai.develop(
                args.topic,
                sources=sources,
                approved_by_job=args.approve,
            )
            print(json.dumps(
                developed,
                ensure_ascii=False,
                indent=2,
                default=str,
            ))
            return 0 if developed.get("status") == "COMPLETE" else 2
        if args.cmd == "ai-grow":
            try:
                requirement = json.loads(args.requirement_json)
            except json.JSONDecodeError as exc:
                raise ValueError("--requirement-json must be valid JSON") from exc
            if not isinstance(requirement, dict):
                raise ValueError("--requirement-json must decode to an object")
            grown = ai.grow_capability(
                requirement,
                implementation=not args.spec_only,
                approved_by_job=args.approve,
            )
            print(json.dumps(
                grown,
                ensure_ascii=False,
                indent=2,
                default=str,
            ))
            return 0 if grown.get("status") == "REGISTERED_CANDIDATE" else 2
        if args.cmd == "ai-grow-validate":
            validation = ai.validate_capability_candidate(args.capability_id)
            print(json.dumps(
                validation,
                ensure_ascii=False,
                indent=2,
                default=str,
            ))
            return 0 if validation.get("status") == "SANDBOX_VALIDATED" else 2
        if args.cmd == "ai-grow-promote":
            try:
                requirement = json.loads(args.requirement_json)
                review = json.loads(args.review_json)
                roles = json.loads(args.roles_json)
                test_payload = json.loads(args.test_payload_json)
            except json.JSONDecodeError as exc:
                raise ValueError("promotion JSON arguments must be valid JSON") from exc
            if not all(isinstance(item, dict) for item in (
                requirement, review, roles, test_payload
            )):
                raise ValueError("promotion JSON arguments must decode to objects")
            promoted = ai.promote_capability(
                args.capability_id,
                requirement=requirement,
                review=review,
                roles=roles,
                test_payload=test_payload,
            )
            print(json.dumps(
                promoted,
                ensure_ascii=False,
                indent=2,
                default=str,
            ))
            return 0 if promoted.get("status") == "ACTIVE_CERTIFIED_CAPABILITY" else 2
        if args.cmd == "ai-grow-rollback":
            rolled_back = ai.rollback_capability(
                args.capability_id,
                operator_id=args.operator_id,
            )
            print(json.dumps(
                rolled_back,
                ensure_ascii=False,
                indent=2,
                default=str,
            ))
            return 0 if rolled_back.get("status") == "ROLLED_BACK" else 2
        if args.cmd == "ai-capability":
            try:
                capability_args = json.loads(args.args_json)
            except json.JSONDecodeError as exc:
                raise ValueError("--args-json must be valid JSON") from exc
            if not isinstance(capability_args, dict):
                raise ValueError("--args-json must decode to an object")
            result = ai.execute_capability(
                args.action,
                capability_args,
                approved_by_job=args.approve,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
            status = ((result.get("result") or {}).get("status"))
            return 0 if status == "COMPLETE" else 2
        if args.cmd == "ai-generate":
            generated = ai.generate_ai(
                args.goal,
                name=args.name,
                kind=args.kind,
            )
            print(json.dumps({
                "name": generated.name,
                "kind": generated.kind,
                "goal": generated.goal,
                "manifest_path": generated.manifest_path,
                "evidence_path": generated.evidence_path,
                "intelligence": generated.intelligence,
                "engine_count": generated.engine_count,
                "capability_count": generated.capability_count,
            }, ensure_ascii=False, indent=2, default=str))
            return 0
        result = ai.run(args.goal, approved_by_job=args.approve)
        print(json.dumps({
            "goal": result.goal,
            "plan": result.plan,
            "executions": list(result.executions),
            "completed": result.completed,
            "blocked": result.blocked,
            "evidence_refs": list(result.evidence_refs),
            "memory_ids": list(result.memory_ids),
        }, ensure_ascii=False, indent=2, default=str))
        return 0 if result.completed else 2

    orch = AfaqOrchestrator(args.root)
    payload = {}
    if args.cmd == "read": payload = {"path": args.path}
    elif args.cmd == "search": payload = {"query": args.query}
    elif args.cmd == "edit": payload = {"path": args.path, "old": args.old, "new": args.new, "approved": args.approve}
    elif args.cmd == "run": payload = {"command": args.command}
    result = orch.execute(args.cmd, payload)
    print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
    return 0 if result.get("status") in {"COMPLETE", "NOT_VERIFIED"} else 2


if __name__ == "__main__":
    raise SystemExit(main())
