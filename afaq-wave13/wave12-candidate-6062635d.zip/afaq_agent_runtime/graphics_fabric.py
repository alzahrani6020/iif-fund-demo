"""Graphics & Diagram Fabric engine — deterministic, offline, advisory.

Builds and critiques SVG graphics as plain validated documents: a strict
document model (build/serialize/parse), vector primitives (rect, circle,
polygon, path, text) with deterministic numeric layout, ordered z-order
layers with validated translate/scale/rotate transforms, a layered flowchart
layout for caller-supplied nodes/edges (stdlib only, no graphviz), a bar
chart from a numeric series with explicit axis bounds, and an honest
critique (off-canvas overflow, invisible elements) with explicit reasons.
Pure stdlib — no model calls, no network, no rendering, no state ownership.
This is an ENGINE, not a store: it plans, lays out, serializes, and reports;
persistence and authority live elsewhere.

Pipeline (each step is independently callable and validated):
  parse_svg_document -> serialize_svg
  primitives / layers -> build_document
  layout_flowchart -> render_flowchart
  bar_chart -> critique_graphics
  run_graphics_gates / graphics_readiness seal the document.

Dedup (engine registry):
  - ENG-UND-017 / ENG-RES-018 / ENG-WR-019 / ENG-WR-020 are TEXT-side
    engines (understanding, evidence, writing, shots). This module is
    GRAPHICS-side: it consumes caller-supplied labels/numbers/series only;
    it never parses intent, sources, drafts, or scene plans and never
    inspects the filesystem. No field, gate, or scorer overlaps.
  - No canonical component is imported: the engine is composable but
    standalone, so it can never pull authority into an advisory path.

ABSENT stays ABSENT: anything not derivable from the supplied geometry is
reported as UNKNOWN (open_questions), never fabricated. Layout is fully
deterministic — sorted tie-breaks, fixed node metrics, no randomness, no
clock. Critique reports reasons; it never edits the document.
"""

from __future__ import annotations

import math
import re
from typing import Any, Mapping
from html import escape

# ---------------------------------------------------------------------------
# Bounded vocabulary and budgets (mirrors writing_engine discipline).

_ELEMENTS = ("svg", "g", "rect", "circle", "polygon", "path", "text", "line")
_SHAPE_TAGS = ("rect", "circle", "polygon", "path", "text", "line")

_MAX_LAYERS = 12
_MAX_ELEMENTS = 200
_MAX_DEPTH = 16
_MAX_LABEL_WORDS = 8
_MAX_TEXT_WORDS = 40
_MAX_POINTS = 64
_MAX_NODES = 40
_MAX_EDGES = 80
_MAX_SERIES = 24

_TRANSFORM_RE = re.compile(
    r"^(translate|scale|rotate)\((-?[\d.]+(?:e-?\d+)?)"
    r"(?:\s*,?\s*(-?[\d.]+(?:e-?\d+)?))?"
    r"(?:\s*,?\s*(-?[\d.]+(?:e-?\d+)?))?\)$",
    re.IGNORECASE,
)


class GraphicsError(ValueError):
    """Bounded, user-facing graphics parse/layout failure."""


def _num(value: Any, where: str) -> float:
    """Validated finite number; bools rejected; numeric strings accepted so
    serialized attributes (e.g. '1.5') round-trip through the parser."""
    if isinstance(value, bool):
        raise GraphicsError(f"graphics.{where} must be a number")
    if isinstance(value, str):
        try:
            number = float(value.strip())
        except ValueError:
            raise GraphicsError(f"graphics.{where} must be a number") from None
    elif isinstance(value, (int, float)):
        number = float(value)
    else:
        raise GraphicsError(f"graphics.{where} must be a number")
    if not math.isfinite(number):
        raise GraphicsError(f"graphics.{where} must be finite")
    return number


def _label(value: Any, where: str) -> str:
    text = str(value).strip()
    if not text:
        raise GraphicsError(f"graphics.{where} must be a non-empty string")
    if len(text.split()) > _MAX_LABEL_WORDS:
        raise GraphicsError(f"graphics.{where} exceeds {_MAX_LABEL_WORDS} words")
    return text


def _fmt(number: float) -> str:
    """Deterministic, compact numeric formatting (integers without '.0')."""
    if number == int(number) and abs(number) < 1e15:
        return str(int(number))
    return repr(round(number, 4))


# ---------------------------------------------------------------------------
# Transforms: validated numbers only, rendered as SVG transform strings.


def translate(dx: Any, dy: Any = 0) -> str:
    return f"translate({_fmt(_num(dx, 'translate.dx'))},{_fmt(_num(dy, 'translate.dy'))})"


def scale(sx: Any, sy: Any | None = None) -> str:
    sx_f = _num(sx, "scale.sx")
    sy_f = sx_f if sy is None else _num(sy, "scale.sy")
    return f"scale({_fmt(sx_f)},{_fmt(sy_f)})"


def rotate(degrees: Any, cx: Any = 0, cy: Any = 0) -> str:
    deg = _num(degrees, "rotate.degrees")
    cx_f = _num(cx, "rotate.cx")
    cy_f = _num(cy, "rotate.cy")
    if cx_f == 0 and cy_f == 0:
        return f"rotate({_fmt(deg)})"
    return f"rotate({_fmt(deg)},{_fmt(cx_f)},{_fmt(cy_f)})"


def _parse_transform(value: str, where: str) -> str:
    match = _TRANSFORM_RE.match(value.strip())
    if not match:
        raise GraphicsError(
            f"graphics.{where} is not a valid transform: {value!r}"
        )
    name, a, b, c = match.groups()
    floats = [_num(float(v), f"{where}.{name}") for v in (a, b, c) if v is not None]
    if name.lower() == "translate" and len(floats) not in (1, 2):
        raise GraphicsError(f"graphics.{where}: translate takes 1..2 numbers")
    if name.lower() == "scale" and len(floats) not in (1, 2):
        raise GraphicsError(f"graphics.{where}: scale takes 1..2 numbers")
    if name.lower() == "rotate" and len(floats) not in (1, 3):
        raise GraphicsError(f"graphics.{where}: rotate takes 1 or 3 numbers")
    return value.strip()


# ---------------------------------------------------------------------------
# Document model: elements are plain dicts {tag, attrs, children, text}.
# build_* validate, parse_svg_document strictly validates, serialize renders.


def _element(tag: str, attrs: Mapping[str, Any] | None = None,
             children: list | None = None, text: str = "") -> dict[str, Any]:
    return {
        "tag": tag,
        "attrs": dict(attrs or {}),
        "children": list(children or []),
        "text": text,
    }


def _paint_attrs(fill: str | None, stroke: str | None,
                 stroke_width: Any | None) -> dict[str, str]:
    attrs: dict[str, str] = {}
    if fill is not None:
        if not isinstance(fill, str) or not fill.strip():
            raise GraphicsError("graphics.fill must be a non-empty string")
        attrs["fill"] = fill.strip()
    if stroke is not None:
        if not isinstance(stroke, str) or not stroke.strip():
            raise GraphicsError("graphics.stroke must be a non-empty string")
        attrs["stroke"] = stroke.strip()
    if stroke_width is not None:
        width = _num(stroke_width, "stroke_width")
        if width <= 0:
            raise GraphicsError("graphics.stroke_width must be > 0")
        attrs["stroke-width"] = _fmt(width)
    return attrs


# ---- primitives (deterministic numeric layout; every number validated) ----


def rect(x: Any, y: Any, width: Any, height: Any, *, fill: str | None = None,
         stroke: str | None = None, stroke_width: Any | None = None,
         transform: str | None = None) -> dict[str, Any]:
    attrs = {"x": _fmt(_num(x, "rect.x")), "y": _fmt(_num(y, "rect.y")),
             "width": _fmt(_num(width, "rect.width")),
             "height": _fmt(_num(height, "rect.height"))}
    attrs.update(_paint_attrs(fill, stroke, stroke_width))
    if transform is not None:
        attrs["transform"] = _parse_transform(transform, "rect.transform")
    return _element("rect", attrs)


def circle(cx: Any, cy: Any, r: Any, *, fill: str | None = None,
           stroke: str | None = None, stroke_width: Any | None = None,
           transform: str | None = None) -> dict[str, Any]:
    radius = _num(r, "circle.r")
    if radius <= 0:
        raise GraphicsError("graphics.circle.r must be > 0")
    attrs = {"cx": _fmt(_num(cx, "circle.cx")), "cy": _fmt(_num(cy, "circle.cy")),
             "r": _fmt(radius)}
    attrs.update(_paint_attrs(fill, stroke, stroke_width))
    if transform is not None:
        attrs["transform"] = _parse_transform(transform, "circle.transform")
    return _element("circle", attrs)


def polygon(points: Any, *, fill: str | None = None, stroke: str | None = None,
            stroke_width: Any | None = None,
            transform: str | None = None) -> dict[str, Any]:
    if not isinstance(points, (list, tuple)) or not points:
        raise GraphicsError("graphics.polygon.points must be a non-empty list")
    if len(points) > _MAX_POINTS:
        raise GraphicsError(f"graphics.polygon.points exceeds {_MAX_POINTS} points")
    parsed: list[tuple[float, float]] = []
    for index, point in enumerate(points):
        if not isinstance(point, (list, tuple)) or len(point) != 2:
            raise GraphicsError(f"graphics.polygon.points[{index}] must be (x, y)")
        parsed.append((_num(point[0], f"points[{index}].x"),
                       _num(point[1], f"points[{index}].y")))
    attrs = {"points": " ".join(f"{_fmt(px)},{_fmt(py)}" for px, py in parsed)}
    attrs.update(_paint_attrs(fill, stroke, stroke_width))
    if transform is not None:
        attrs["transform"] = _parse_transform(transform, "polygon.transform")
    return _element("polygon", attrs)


_PATH_ARITY = {"M": 2, "L": 2, "C": 6, "Z": 0}


def path(commands: Any, *, fill: str | None = None, stroke: str | None = None,
         stroke_width: Any | None = None,
         transform: str | None = None) -> dict[str, Any]:
    """Validated path from explicit commands: ('M', x, y), ('L', x, y),
    ('C', x1,y1,x2,y2,x,y), ('Z',). Must start with M; deterministic order."""
    if not isinstance(commands, (list, tuple)) or not commands:
        raise GraphicsError("graphics.path.commands must be a non-empty list")
    if len(commands) > _MAX_POINTS:
        raise GraphicsError(f"graphics.path.commands exceeds {_MAX_POINTS} commands")
    rendered: list[str] = []
    for index, command in enumerate(commands):
        if not isinstance(command, (list, tuple)) or not command:
            raise GraphicsError(f"graphics.path.commands[{index}] must be a tuple")
        name = str(command[0]).upper()
        if name not in _PATH_ARITY:
            raise GraphicsError(
                f"graphics.path.commands[{index}]: unknown command {command[0]!r}"
            )
        arity = _PATH_ARITY[name]
        if len(command) - 1 != arity:
            raise GraphicsError(
                f"graphics.path.commands[{index}]: {name} takes {arity} numbers"
            )
        if index == 0 and name != "M":
            raise GraphicsError("graphics.path must begin with an M command")
        if name == "Z":
            rendered.append("Z")
        else:
            nums = [_num(v, f"commands[{index}]") for v in command[1:]]
            rendered.append(f"{name}{','.join(_fmt(v) for v in nums)}")
    attrs = {"d": " ".join(rendered)}
    attrs.update(_paint_attrs(fill, stroke, stroke_width))
    if transform is not None:
        attrs["transform"] = _parse_transform(transform, "path.transform")
    return _element("path", attrs)


def text(x: Any, y: Any, content: Any, *, fill: str | None = "currentColor",
         font_size: Any | None = None,
         transform: str | None = None) -> dict[str, Any]:
    value = str(content).strip()
    if not value:
        raise GraphicsError("graphics.text.content must be a non-empty string")
    if len(value.split()) > _MAX_TEXT_WORDS:
        raise GraphicsError(f"graphics.text.content exceeds {_MAX_TEXT_WORDS} words")
    attrs = {"x": _fmt(_num(x, "text.x")), "y": _fmt(_num(y, "text.y"))}
    if font_size is not None:
        size = _num(font_size, "text.font_size")
        if size <= 0:
            raise GraphicsError("graphics.text.font_size must be > 0")
        attrs["font-size"] = _fmt(size)
    attrs.update(_paint_attrs(fill, None, None))
    if transform is not None:
        attrs["transform"] = _parse_transform(transform, "text.transform")
    return _element("text", attrs, text=value)


def line(x1: Any, y1: Any, x2: Any, y2: Any, *, stroke: str | None = None,
         stroke_width: Any | None = None) -> dict[str, Any]:
    attrs = {"x1": _fmt(_num(x1, "line.x1")), "y1": _fmt(_num(y1, "line.y1")),
             "x2": _fmt(_num(x2, "line.x2")), "y2": _fmt(_num(y2, "line.y2"))}
    attrs.update(_paint_attrs(None, stroke or "currentColor", stroke_width))
    return _element("line", attrs)


# ---- layers: ordered bottom-to-top z-order groups ----


def layer(name: Any, elements: Any, *, transform: str | None = None) -> dict[str, Any]:
    value = _label(name, "layer.name")
    if not isinstance(elements, (list, tuple)):
        raise GraphicsError("graphics.layer.elements must be a list")
    if len(elements) > _MAX_ELEMENTS:
        raise GraphicsError(f"graphics.layer.elements exceeds {_MAX_ELEMENTS} entries")
    children = [parse_svg_document(e, root=False) for e in elements]
    attrs: dict[str, str] = {"data-layer": value}
    if transform is not None:
        attrs["transform"] = _parse_transform(transform, "layer.transform")
    return _element("g", attrs, children=children)


def build_document(width: Any, height: Any,
                   layers: Any) -> dict[str, Any]:
    """Compose a full svg document from ordered layers (z-order: first =
    bottom). Validates through parse_svg_document before return."""
    w = _num(width, "document.width")
    h = _num(height, "document.height")
    if w <= 0 or h <= 0:
        raise GraphicsError("graphics.document width/height must be > 0")
    if not isinstance(layers, (list, tuple)) or not layers:
        raise GraphicsError("graphics.document.layers must be a non-empty list")
    if len(layers) > _MAX_LAYERS:
        raise GraphicsError(f"graphics.document.layers exceeds {_MAX_LAYERS} layers")
    children = []
    for index, item in enumerate(layers):
        if not isinstance(item, Mapping) or item.get("tag") != "g":
            raise GraphicsError(
                f"graphics.document.layers[{index}] must come from graphics_fabric.layer()"
            )
        children.append(parse_svg_document(item, root=False))
    return parse_svg_document(_element("svg", {"width": _fmt(w), "height": _fmt(h)},
                                       children=children))


# ---- strict parser and serializer ----

_NUMERIC_ATTRS = ("x", "y", "width", "height", "cx", "cy", "r", "x1", "y1",
                  "x2", "y2", "font-size", "stroke-width")
_ALLOWED_ATTRS = {
    "svg": {"width", "height"},
    "g": {"transform", "data-layer"},
    "rect": {"x", "y", "width", "height", "fill", "stroke", "stroke-width",
             "transform"},
    "circle": {"cx", "cy", "r", "fill", "stroke", "stroke-width", "transform"},
    "polygon": {"points", "fill", "stroke", "stroke-width", "transform"},
    "path": {"d", "fill", "stroke", "stroke-width", "transform"},
    "text": {"x", "y", "fill", "font-size", "transform"},
    "line": {"x1", "y1", "x2", "y2", "stroke", "stroke-width"},
}


def _parse_attrs(tag: str, attrs: Any, where: str) -> dict[str, str]:
    if not isinstance(attrs, Mapping):
        raise GraphicsError(f"graphics.{where}.attrs must be an object")
    allowed = _ALLOWED_ATTRS[tag]
    parsed: dict[str, str] = {}
    for key, value in attrs.items():
        if key not in allowed:
            raise GraphicsError(f"graphics.{where}: attribute {key!r} not allowed on <{tag}>")
        if key in _NUMERIC_ATTRS:
            parsed[key] = _fmt(_num(value, f"{where}.{key}"))
        elif key == "transform":
            parsed[key] = _parse_transform(str(value), f"{where}.transform")
        elif key == "points":
            _validate_points(str(value), f"{where}.points")
            parsed[key] = " ".join(str(value).split())
        elif key == "d":
            _validate_d(str(value), f"{where}.d")
            parsed[key] = " ".join(str(value).split())
        else:
            text_value = str(value).strip()
            if not text_value:
                raise GraphicsError(f"graphics.{where}.{key} must be non-empty")
            if len(text_value.split()) > _MAX_TEXT_WORDS:
                raise GraphicsError(f"graphics.{where}.{key} exceeds {_MAX_TEXT_WORDS} words")
            parsed[key] = text_value
    return parsed


def _validate_points(value: str, where: str) -> None:
    pairs = value.split()
    if not pairs or len(pairs) > _MAX_POINTS:
        raise GraphicsError(f"graphics.{where} must have 1..{_MAX_POINTS} points")
    for pair in pairs:
        parts = pair.split(",")
        if len(parts) != 2:
            raise GraphicsError(f"graphics.{where}: bad point {pair!r}")
        _num(float(parts[0]), where)
        _num(float(parts[1]), where)


def _validate_d(value: str, where: str) -> None:
    tokens = value.split()
    if not tokens:
        raise GraphicsError(f"graphics.{where} must not be empty")
    first = True
    for token in tokens:
        name = token[0].upper()
        if name not in _PATH_ARITY:
            raise GraphicsError(f"graphics.{where}: unknown command {token[0]!r}")
        if first and name != "M":
            raise GraphicsError(f"graphics.{where} must begin with M")
        first = False
        coords = token[1:].replace(",", " ").split()
        if name == "Z":
            if coords:
                raise GraphicsError(f"graphics.{where}: Z takes no numbers")
            continue
        if len(coords) != _PATH_ARITY[name]:
            raise GraphicsError(f"graphics.{where}: {name} takes {_PATH_ARITY[name]} numbers")
        for coord in coords:
            _num(float(coord), where)


def parse_svg_document(payload: Any, *, root: bool = True) -> dict[str, Any]:
    """Strictly validate an SVG document (or subtree when root=False).

    Raises GraphicsError with a specific reason. Tags and attributes are
    limited to the engine's bounded vocabulary; every numeric attribute is
    finite; transforms are validated numbers; unknown keys/attrs are
    REJECTED (graphics is a rendering contract, not a forward-tolerant
    document). Cross-element consistency is the GATE's job, not the parser's.
    """
    if not isinstance(payload, Mapping):
        raise GraphicsError("graphics document must be an object")
    tag = str(payload.get("tag", "")).strip()
    if tag not in _ELEMENTS:
        raise GraphicsError(f"graphics document tag must be one of {_ELEMENTS}")
    if root and tag != "svg":
        raise GraphicsError("graphics document root must be <svg>")

    where = "document" if root else f"<{tag}>"
    attrs = _parse_attrs(tag, payload.get("attrs", {}), where)

    if tag == "svg":
        for required in ("width", "height"):
            if required not in attrs:
                raise GraphicsError(f"graphics document missing {required!r}")
        if float(attrs["width"]) <= 0 or float(attrs["height"]) <= 0:
            raise GraphicsError("graphics document width/height must be > 0")
    required_attrs = {
        "rect": ("x", "y", "width", "height"),
        "circle": ("cx", "cy", "r"),
        "polygon": ("points",),
        "path": ("d",),
        "text": ("x", "y"),
        "line": ("x1", "y1", "x2", "y2"),
    }
    for required in required_attrs.get(tag, ()):
        if required not in attrs:
            raise GraphicsError(f"graphics <{tag}> missing required attribute {required!r}")

    element_text = str(payload.get("text", ""))
    if tag != "text" and element_text.strip():
        raise GraphicsError(f"graphics <{tag}> must not carry text")
    if tag == "text":
        if not element_text.strip():
            raise GraphicsError("graphics <text> must carry non-empty text")
        if len(element_text.split()) > _MAX_TEXT_WORDS:
            raise GraphicsError(f"graphics <text> exceeds {_MAX_TEXT_WORDS} words")

    raw_children = payload.get("children", [])
    if not isinstance(raw_children, (list, tuple)):
        raise GraphicsError(f"graphics {where}.children must be a list")
    if not raw_children and tag == "svg":
        raise GraphicsError("graphics document has no elements — nothing to render")
    if len(raw_children) > _MAX_ELEMENTS:
        raise GraphicsError(f"graphics {where} exceeds {_MAX_ELEMENTS} children")
    if tag != "svg" and raw_children and tag != "g":
        raise GraphicsError(f"graphics <{tag}> must not have children")

    children: list[dict[str, Any]] = []
    for index, child in enumerate(raw_children):
        child_where = f"{where}.children[{index}]"
        if not isinstance(child, Mapping):
            raise GraphicsError(f"graphics {child_where} must be an object")
        child_tag = str(child.get("tag", "")).strip()
        if child_tag not in _ELEMENTS:
            raise GraphicsError(f"graphics {child_where}: bad tag {child_tag!r}")
        if tag not in ("svg", "g"):
            raise GraphicsError(f"graphics {child_where}: only <g> may nest elements")
        children.append(parse_svg_document(child, root=False))

    return {"tag": tag, "attrs": attrs, "children": children, "text": element_text}


def serialize_svg(document: Mapping[str, Any]) -> str:
    """Render a validated document to an SVG string (re-validates first)."""

    def _render(node: dict[str, Any], depth: int) -> str:
        if depth > _MAX_DEPTH:
            raise GraphicsError(f"graphics document exceeds depth {_MAX_DEPTH}")
        indent = "  " * depth
        attrs = "".join(
            f' {key}="{escape(value, quote=True)}"'
            for key, value in node["attrs"].items()
        )
        text_value = node.get("text", "")
        if not node["children"] and not text_value:
            return f"{indent}<{node['tag']}{attrs}/>"
        inner = escape(text_value, quote=False)
        if node["children"]:
            child_xml = "\n".join(
                _render(child, depth + 1) for child in node["children"]
            )
            return (f"{indent}<{node['tag']}{attrs}>{child_xml}"
                    f"\n{indent}</{node['tag']}>")
        return f"{indent}<{node['tag']}{attrs}>{inner}</{node['tag']}>"

    return _render(parse_svg_document(document), 0)


# ---------------------------------------------------------------------------
# Geometry helpers for layout and critique (translation-only transform math;
# rotations/scales are validated but conservatively treated as no-ops for
# bounding boxes, which is stated in the critique reason when relevant).


def _transform_offset(transform: str) -> tuple[float, float]:
    match = _TRANSFORM_RE.match(transform.strip())
    if not match:
        return (0.0, 0.0)
    name, a, b, _ = match.groups()
    if name.lower() != "translate":
        return (0.0, 0.0)
    dx = float(a)
    dy = float(b) if b is not None else 0.0
    return (dx, dy)


def _element_bbox(node: Mapping[str, Any]) -> tuple[float, float, float, float]:
    """(min_x, min_y, max_x, max_y); text measured at ~0.6em per character."""
    tag = node["tag"]
    attrs = node["attrs"]
    ox, oy = (0.0, 0.0)
    if "transform" in attrs:
        ox, oy = _transform_offset(attrs["transform"])
    if tag == "rect":
        x, y = float(attrs["x"]) + ox, float(attrs["y"]) + oy
        return (x, y, x + float(attrs["width"]), y + float(attrs["height"]))
    if tag == "circle":
        cx, cy = float(attrs["cx"]) + ox, float(attrs["cy"]) + oy
        r = float(attrs["r"])
        return (cx - r, cy - r, cx + r, cy + r)
    if tag == "polygon":
        points = [tuple(float(v) for v in p.split(","))
                  for p in attrs["points"].split()]
        xs = [p[0] + ox for p in points]
        ys = [p[1] + oy for p in points]
        return (min(xs), min(ys), max(xs), max(ys))
    if tag == "line":
        xs = [float(attrs["x1"]) + ox, float(attrs["x2"]) + ox]
        ys = [float(attrs["y1"]) + oy, float(attrs["y2"]) + oy]
        return (min(xs), min(ys), max(xs), max(ys))
    if tag == "text":
        size = float(attrs.get("font-size", 16))
        width = 0.6 * size * max(1, len(node.get("text", "")))
        x, y = float(attrs["x"]) + ox, float(attrs["y"]) + oy
        return (x, y - size, x + width, y + 0.25 * size)
    if tag == "path":
        coords: list[tuple[float, float]] = []
        for token in attrs["d"].split():
            name = token[0].upper()
            values = [float(v) for v in token[1:].replace(",", " ").split()]
            if name in ("M", "L"):
                coords.append((values[0], values[1]))
            elif name == "C":
                coords.append((values[4], values[5]))
        xs = [p[0] + ox for p in coords]
        ys = [p[1] + oy for p in coords]
        return (min(xs), min(ys), max(xs), max(ys))
    raise GraphicsError(f"graphics bbox: unsupported tag {tag!r}")


def _walk(node: Mapping[str, Any], path: str = ""):
    yield path, node
    for index, child in enumerate(node.get("children", [])):
        yield from _walk(child, f"{path}/{child['tag']}[{index}]")


# ---------------------------------------------------------------------------
# Flowchart: deterministic layered layout (longest-path layering, sorted
# tie-breaks). Stdlib only — no graphviz.


def _parse_flowchart(nodes: Any, edges: Any) -> tuple[list[dict[str, str]],
                                                      list[tuple[str, str]]]:
    if not isinstance(nodes, (list, tuple)) or not nodes:
        raise GraphicsError("graphics.flowchart.nodes must be a non-empty list")
    if len(nodes) > _MAX_NODES:
        raise GraphicsError(f"graphics.flowchart.nodes exceeds {_MAX_NODES}")
    parsed_nodes: list[dict[str, str]] = []
    seen: set[str] = set()
    for index, node in enumerate(nodes):
        if not isinstance(node, Mapping):
            raise GraphicsError(f"graphics.flowchart.nodes[{index}] must be an object")
        node_id = _label(node.get("id"), f"nodes[{index}].id")
        if node_id in seen:
            raise GraphicsError(f"graphics.flowchart duplicate node id {node_id!r}")
        seen.add(node_id)
        parsed_nodes.append({"id": node_id,
                             "label": _label(node.get("label", node_id),
                                             f"nodes[{index}].label")})
    if not isinstance(edges, (list, tuple)):
        raise GraphicsError("graphics.flowchart.edges must be a list")
    if len(edges) > _MAX_EDGES:
        raise GraphicsError(f"graphics.flowchart.edges exceeds {_MAX_EDGES}")
    parsed_edges: list[tuple[str, str]] = []
    for index, edge in enumerate(edges):
        if not isinstance(edge, Mapping):
            raise GraphicsError(f"graphics.flowchart.edges[{index}] must be an object")
        source = _label(edge.get("from"), f"edges[{index}].from")
        target = _label(edge.get("to"), f"edges[{index}].to")
        if source not in seen:
            raise GraphicsError(f"graphics.flowchart edge source {source!r} unknown")
        if target not in seen:
            raise GraphicsError(f"graphics.flowchart edge target {target!r} unknown")
        parsed_edges.append((source, target))
    return parsed_nodes, parsed_edges


_NODE_W = 120.0
_NODE_H = 40.0
_LAYER_GAP = 90.0
_COL_GAP = 40.0
_MARGIN = 20.0


def layout_flowchart(nodes: Any, edges: Any = ()) -> dict[str, Any]:
    """Layered layout for caller-supplied nodes/edges.

    Deterministic: Kahn topological order with sorted-id tie-breaks; layer =
    longest path from a root; within a layer, left-to-right by sorted id.
    Raises GraphicsError on cycles (no layer assignment exists). Returns the
    layout only — rendering is render_flowchart's job.
    """
    parsed_nodes, parsed_edges = _parse_flowchart(nodes, edges)

    ids = sorted(n["id"] for n in parsed_nodes)
    succ: dict[str, list[str]] = {i: [] for i in ids}
    indeg: dict[str, int] = {i: 0 for i in ids}
    for source, target in parsed_edges:
        succ[source].append(target)
        indeg[target] += 1
    for source in succ:
        succ[source].sort()

    # Kahn with sorted tie-break => deterministic total order.
    ready = sorted(i for i in ids if indeg[i] == 0)
    order: list[str] = []
    indeg_work = dict(indeg)
    while ready:
        current = ready.pop(0)
        order.append(current)
        for nxt in succ[current]:
            indeg_work[nxt] -= 1
            if indeg_work[nxt] == 0:
                ready.append(nxt)
                ready.sort()
    if len(order) != len(ids):
        remaining = sorted(set(ids) - set(order))
        raise GraphicsError(
            f"graphics.flowchart contains a cycle involving: {remaining}"
        )

    # Longest-path layering over the deterministic order.
    layer_of: dict[str, int] = {i: 0 for i in ids}
    for node_id in order:
        for nxt in succ[node_id]:
            layer_of[nxt] = max(layer_of[nxt], layer_of[node_id] + 1)

    by_layer: dict[int, list[str]] = {}
    for node_id in ids:
        by_layer.setdefault(layer_of[node_id], []).append(node_id)
    for members in by_layer.values():
        members.sort()

    positioned: dict[str, dict[str, Any]] = {}
    for depth, members in sorted(by_layer.items()):
        for column, node_id in enumerate(members):
            x = _MARGIN + column * (_NODE_W + _COL_GAP)
            y = _MARGIN + depth * (_NODE_H + _LAYER_GAP)
            node = next(n for n in parsed_nodes if n["id"] == node_id)
            positioned[node_id] = {
                "id": node_id, "label": node["label"], "layer": depth,
                "column": column, "x": x, "y": y,
                "width": _NODE_W, "height": _NODE_H,
            }

    routed: list[dict[str, Any]] = []
    for source, target in parsed_edges:
        s = positioned[source]
        t = positioned[target]
        start = (s["x"] + _NODE_W / 2, s["y"] + _NODE_H)
        end = (t["x"] + _NODE_W / 2, t["y"])
        points = [start]
        if abs(start[1] - end[1]) > 1e-9:
            mid_y = (start[1] + end[1]) / 2
            points.append((start[0], mid_y))
            points.append((end[0], mid_y))
        points.append(end)
        routed.append({"from": source, "to": target,
                       "points": [[round(px, 2), round(py, 2)] for px, py in points]})

    width = _MARGIN * 2 + max(
        (len(members) - 1) * (_NODE_W + _COL_GAP) + _NODE_W
        for members in by_layer.values()
    )
    height = _MARGIN * 2 + max(by_layer) * (_NODE_H + _LAYER_GAP) + _NODE_H
    return {
        "width": round(width, 2),
        "height": round(height, 2),
        "nodes": [positioned[i] for i in ids],
        "edges": routed,
        "open_questions": [] if parsed_edges else [
            "flowchart has no edges — node order is layout order only; intent is UNKNOWN"],
    }


def render_flowchart(layout: Mapping[str, Any], *, node_fill: str = "#ffffff",
                     node_stroke: str = "#333333") -> dict[str, Any]:
    """Render a validated flowchart layout into an svg document."""
    if not isinstance(layout, Mapping):
        raise GraphicsError("graphics.render_flowchart expects a layout object")
    nodes = layout.get("nodes")
    edges = layout.get("edges")
    if not isinstance(nodes, list) or not isinstance(edges, list):
        raise GraphicsError("graphics layout must carry nodes and edges lists")

    edge_elements = []
    for edge in edges:
        if not isinstance(edge, Mapping) or not isinstance(edge.get("points"), list):
            raise GraphicsError("graphics layout edge must carry a points list")
        points = edge["points"]
        if len(points) < 2:
            raise GraphicsError("graphics layout edge needs at least 2 points")
        commands: list[tuple[Any, ...]] = [("M", points[0][0], points[0][1])]
        for point in points[1:]:
            commands.append(("L", point[0], point[1]))
        edge_elements.append(path(commands, fill="none", stroke="#888888",
                                  stroke_width=1.5))

    node_elements = []
    for node in nodes:
        if not isinstance(node, Mapping):
            raise GraphicsError("graphics layout node must be an object")
        x = _num(node.get("x"), "layout.node.x")
        y = _num(node.get("y"), "layout.node.y")
        w = _num(node.get("width", _NODE_W), "layout.node.width")
        h = _num(node.get("height", _NODE_H), "layout.node.height")
        label = str(node.get("label", node.get("id", "")))
        node_elements.append(rect(x, y, w, h, fill=node_fill, stroke=node_stroke,
                                  stroke_width=1.5))
        size = 13.0
        approx = 0.6 * size * len(label)
        node_elements.append(text(x + max(4.0, (w - approx) / 2), y + h / 2 + 4,
                                  label, fill="#111111", font_size=size))

    return build_document(layout.get("width", 400), layout.get("height", 300), [
        layer("edges", edge_elements),
        layer("nodes", node_elements),
    ])


# ---------------------------------------------------------------------------
# Bar chart: numeric series -> svg, explicit axis min/max (never inferred).


def bar_chart(series: Any, *, min_value: Any, max_value: Any,
              width: Any = 640, height: Any = 400,
              bar_color: str = "#4a90d9") -> dict[str, Any]:
    """Deterministic bar chart. Series: list of numbers or {label, value}.
    Axis bounds are EXPLICIT caller obligations (never inferred); every value
    must fall inside [min, max]; labels carry the value verbatim."""
    if not isinstance(series, (list, tuple)) or not series:
        raise GraphicsError("graphics.barchart.series must be a non-empty list")
    if len(series) > _MAX_SERIES:
        raise GraphicsError(f"graphics.barchart.series exceeds {_MAX_SERIES} entries")
    low = _num(min_value, "barchart.min_value")
    high = _num(max_value, "barchart.max_value")
    if high <= low:
        raise GraphicsError("graphics.barchart.max_value must be > min_value")
    w = _num(width, "barchart.width")
    h = _num(height, "barchart.height")
    if w <= 0 or h <= 0:
        raise GraphicsError("graphics.barchart.width/height must be > 0")

    bars: list[dict[str, Any]] = []
    for index, item in enumerate(series):
        if isinstance(item, Mapping):
            value = _num(item.get("value"), f"series[{index}].value")
            label = _label(item.get("label", f"item {index + 1}"),
                           f"series[{index}].label")
        else:
            value = _num(item, f"series[{index}]")
            label = f"item {index + 1}"
        if not low <= value <= high:
            raise GraphicsError(
                f"graphics.barchart series[{index}] value {value} outside axis [{low}, {high}]"
            )
        bars.append({"label": label, "value": value})

    plot_left, plot_bottom = 60.0, h - 40.0
    plot_top, plot_right = 20.0, w - 20.0
    if plot_right <= plot_left or plot_bottom <= plot_top:
        raise GraphicsError("graphics.barchart canvas too small for the plot area")
    span = high - low
    count = len(bars)
    slot = (plot_right - plot_left) / count
    bar_w = slot * 0.6

    elements: list[dict[str, Any]] = [
        # axes (explicit bounds rendered as tick labels)
        line(plot_left, plot_top, plot_left, plot_bottom, stroke="#333333"),
        line(plot_left, plot_bottom, plot_right, plot_bottom, stroke="#333333"),
        text(4, plot_top + 6, _fmt(high), fill="#333333", font_size=11),
        text(4, plot_bottom, _fmt(low), fill="#333333", font_size=11),
    ]
    for index, bar in enumerate(bars):
        x = plot_left + index * slot + (slot - bar_w) / 2
        bar_h = (bar["value"] - low) / span * (plot_bottom - plot_top)
        elements.append(rect(x, plot_bottom - bar_h, bar_w, max(bar_h, 0.5),
                             fill=bar_color))
        elements.append(text(plot_left + index * slot + slot / 2 - 12,
                             plot_bottom + 14, bar["label"][:12],
                             fill="#333333", font_size=10))
        elements.append(text(plot_left + index * slot + slot / 2 - 12,
                             plot_bottom - bar_h - 6, _fmt(bar["value"]),
                             fill="#333333", font_size=10))

    return build_document(w, h, [layer("chart", elements)])


# ---------------------------------------------------------------------------
# Critique: honest findings with explicit reasons. Reports, never edits.


def critique_graphics(document: Mapping[str, Any]) -> list[str]:
    """Check a document for rendering problems. Findings (empty = pass):
      - elements drawn fully/partially outside the canvas (overflow)
      - shape elements with neither fill nor stroke (invisible)
      - non-translate transforms noted as conservative bbox treatment
    Unknowns are reported as UNKNOWN reasons, never guessed."""
    findings: list[str] = []
    try:
        doc = parse_svg_document(document)
    except GraphicsError as exc:
        return [f"document does not parse: {exc}"]

    canvas_w = float(doc["attrs"]["width"])
    canvas_h = float(doc["attrs"]["height"])
    drawable = 0

    for path_str, node in _walk(doc):
        if node["tag"] not in _SHAPE_TAGS:
            continue
        drawable += 1
        where = f"<{node['tag']}> at {path_str or '/svg'}"
        attrs = node["attrs"]
        if node["tag"] in _SHAPE_TAGS:
            has_fill = bool(attrs.get("fill")) and attrs.get("fill") != "none"
            has_stroke = bool(attrs.get("stroke")) and attrs.get("stroke") != "none"
            if not has_fill and not has_stroke:
                findings.append(f"{where} has neither fill nor stroke — it is invisible")
        try:
            min_x, min_y, max_x, max_y = _element_bbox(node)
        except (GraphicsError, ValueError):
            findings.append(f"{where} has a path/points payload this critique cannot bound — extent UNKNOWN")
            continue
        if "transform" in attrs:
            match = _TRANSFORM_RE.match(attrs["transform"].strip())
            if match and match.group(1).lower() != "translate":
                findings.append(
                    f"{where} uses {match.group(1)}() — bounding box treats it as a no-op; extent UNKNOWN"
                )
        off_left = max(0.0, -min_x)
        off_top = max(0.0, -min_y)
        off_right = max(0.0, max_x - canvas_w)
        off_bottom = max(0.0, max_y - canvas_h)
        if off_left or off_top or off_right or off_bottom:
            findings.append(
                f"{where} overflows canvas {canvas_w}x{canvas_h}: "
                f"bbox x[{_fmt(min_x)}..{_fmt(max_x)}] y[{_fmt(min_y)}..{_fmt(max_y)}]"
                + (f" (off left by {_fmt(off_left)})" if off_left else "")
                + (f" (off top by {_fmt(off_top)})" if off_top else "")
                + (f" (off right by {_fmt(off_right)})" if off_right else "")
                + (f" (off bottom by {_fmt(off_bottom)})" if off_bottom else "")
            )

    if drawable == 0:
        findings.append("document contains no drawable elements — UNKNOWN what should render")
    return findings


# ---------------------------------------------------------------------------
# Deterministic gates and readiness seal. Failures are reasons
# (empty = pass); nothing here weakens or replaces canonical validation.


def run_graphics_gates(document: Mapping[str, Any]) -> list[str]:
    """Consistency gates over a graphics document: strict parse; layer names
    unique and ordered; drawable count within budget; visibility and
    overflow findings from critique_graphics. Advisory — reports only."""
    failures: list[str] = []
    try:
        doc = parse_svg_document(document)
    except GraphicsError as exc:
        return [f"document does not parse: {exc}"]

    layers = [c for c in doc["children"] if c["tag"] == "g"]
    names = [c["attrs"].get("data-layer", "") for c in layers]
    if len(set(names)) != len(names):
        failures.append("layer names contain duplicates — z-order is ambiguous")
    drawable = sum(1 for _, node in _walk(doc) if node["tag"] != "g")
    if drawable > _MAX_ELEMENTS:
        failures.append(f"drawable element count {drawable} exceeds budget {_MAX_ELEMENTS}")
    failures.extend(critique_graphics(document))
    return failures


def graphics_readiness(document: Mapping[str, Any],
                       gate_failures: list[str]) -> dict[str, Any]:
    """Graphics readiness seal. READY requires clean gates and at least one
    drawable element inside the canvas — an advisory engine only blesses
    geometry it can actually account for."""
    blocking = list(gate_failures)
    drawable = 0
    try:
        doc = parse_svg_document(document)
        drawable = sum(1 for _, node in _walk(doc) if node["tag"] != "g")
    except GraphicsError as exc:
        blocking.append(f"document does not parse: {exc}")
    if not drawable:
        blocking.append("no drawable elements — nothing to render")
    ready = not blocking
    return {
        "ready": ready,
        "blocking_items": blocking,
        "seal": {
            "parsed": drawable > 0,
            "layers_present": bool(doc.get("children")) if not blocking else False,
            "within_canvas": not any("overflow" in b for b in blocking),
            "all_visible": not any("invisible" in b for b in blocking),
            "gates_clean": not gate_failures,
            "authority_preserved": True,  # advisory engine only
        },
    }
