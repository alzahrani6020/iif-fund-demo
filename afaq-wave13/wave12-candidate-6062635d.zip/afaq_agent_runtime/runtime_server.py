"""HTTP surface for the persistent AIC Agent Runtime (stdlib only).

Binds to 127.0.0.1 only. When ``AIC_RUNTIME_TOKEN`` is set, every request
must send ``Authorization: Bearer <token>``. v1 exposes task submission and
read endpoints plus resume — nothing that writes memory or tools directly.

Endpoints:
    GET  /health                 -> liveness + version
    POST /tasks                  -> {"instruction": ...} -> 202 {"task_id": ...}
    GET  /tasks                  -> list
    GET  /tasks/{id}             -> one task
    GET  /tasks/{id}/events      -> append-only event log
    POST /tasks/{id}/resume      -> resume interrupted/awaiting task
    GET  /monitoring             -> runtime/model/storage monitoring snapshot
    GET  /developer/approvals[?status=]      -> persistent approval queue
    GET  /developer/approvals/{id}           -> one approval record
    POST /developer/approvals/{id}/approve   -> {"reason": ...} decide (actor from header)
    POST /developer/approvals/{id}/reject    -> {"reason": ...} decide (actor from header)
    GET  /developer/audit[?task_id=&limit=]  -> append-only audit ledger reads
    GET  /incidents[?status=&classification=] -> self-healing incident list
    GET  /incidents/{id}                      -> incident detail (state reconciled)
    POST /incidents/scan                      -> run detection, returns new incidents
    POST /incidents/{id}/diagnose             -> root-cause analysis (persisted)
    POST /incidents/{id}/propose              -> governance-gated repair proposal
    GET  /workspace/tree?path=                -> lazy folder listing (Code Workspace)
    GET  /workspace/files                     -> flat file list (Quick Open, bounded)
    GET  /workspace/file?path=                -> file content (boundary-checked)
    POST /workspace/file                      -> disabled (403; use governed developer approval flow)
    POST /workspace/fs                        -> disabled (403; direct mutations fail-closed)
    GET  /workspace/search?q=&regex=          -> project text search
    GET  /workspace/detect                    -> runtime/tool discovery (fixed probes)
    GET  /workspace/git?what=status|diff|log  -> read-only git (allowlisted)
    POST /workspace/run {command}             -> allowlist-validated command only
"""

from __future__ import annotations

import json
import os
import sqlite3
import threading
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from .agent_runtime import RUNTIME_VERSION, AgentRuntime
from .afaq_ai import AfaqAI
from .admission_guard import AdmissionAuthorityGuard, AdmissionGuard
from .command_allowlist import CommandNotAllowed
from .developer_agent import DeveloperAgent
from .model_info import build_models_overview
from .monitoring import collect_monitoring
from .orchestrator import AfaqOrchestrator
from .capability_planner import CapabilityPlanner
from .orchestrator_http import OrchestratorHttpAdapter
from .orchestrator_job_runtime import (
    CapabilityInputsMissing,
    GovernedOrchestratorJobs,
    IdempotencyConflict,
    OrchestratorExecutionUnavailable,
    ShadowExecutionBlocked,
)
from .permissions import normalize_environment
from .self_healing import SelfHealingEngine
from .mission_supervisor import MissionError, MissionSupervisor
from .workspace import WorkspaceBlocked, WorkspaceService
from provider_adapters import provider_readiness
from afaq_registry.admission import AdmissionBlocked, require_admission

_MAX_ACTOR_LEN = 128
_MAX_BODY_BYTES = 1024 * 1024  # 1 MiB cap on request bodies


class _BodyError(ValueError):
    """Malformed or unacceptable request body (content-type/length/size)."""


def _load_runtime_env_file() -> None:
    """Load AIC_HOME/.env.runtime (simple KEY=VALUE lines) if present.

    Only variables that are not already set in the process environment are
    applied, so an explicit export always wins. The file is the durable home
    of AIC_RUNTIME_TOKEN for the runtime process; it is gitignored and must
    never be logged or sent to the browser.
    """
    from .agent_runtime import AIC_HOME
    env_file = AIC_HOME / ".env.runtime"
    try:
        lines = env_file.read_text(encoding="utf-8").splitlines()
    except OSError:
        return
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


def _build_developer_agent(runtime: AgentRuntime) -> DeveloperAgent | None:
    """Enabled only when AIC_DEV_PROJECT_ROOT is set. AIC_DEV_ALLOWED_ROOTS
    (semicolon-separated) permits POSTed project_root overrides inside those
    directories; anything else is refused."""
    root = os.getenv("AIC_DEV_PROJECT_ROOT")
    if not root:
        return None
    return DeveloperAgent(var_dir=runtime.var_dir, project_root=root)


def _allowed_roots() -> list[str]:
    raw = os.getenv("AIC_DEV_ALLOWED_ROOTS", "")
    return [p for p in raw.split(";") if p.strip()]


def _make_workspace(dev: DeveloperAgent, root: str) -> WorkspaceService:
    """Workspace file/command surface bound to one project root.

    Writes and commands are recorded in the same append-only audit ledger the
    Developer Agent uses, attributed to the gateway actor (the admin session).
    """

    def audit(action: str, actor: str, detail: dict) -> None:
        dev.audit.record(
            action,
            task_id=None,
            actor=actor,
            agent_id="aic-workspace",
            environment=normalize_environment(dev.config.environment),
            detail={**detail, "root": root},
        )

    return WorkspaceService(root, audit=audit)


def _build_workspace(dev: DeveloperAgent) -> WorkspaceService:
    return _make_workspace(dev, str(dev.project_root))


def _build_orchestrator() -> AfaqOrchestrator | None:
    """Build the evidence-first orchestrator only from its explicit root."""
    root = (os.getenv("AFAQ_ORCHESTRATOR_ROOT") or "").strip()
    if not root:
        return None
    return AfaqOrchestrator(root)


class _Handler(BaseHTTPRequestHandler):
    runtime: AgentRuntime = None  # injected by serve()
    dev: DeveloperAgent | None = None  # injected by serve() when enabled
    healing: SelfHealingEngine | None = None  # injected by serve() when dev enabled
    workspace: WorkspaceService | None = None  # injected by serve() when dev enabled
    orchestrator_http: OrchestratorHttpAdapter = None  # injected by serve()
    orchestrator_jobs: GovernedOrchestratorJobs | None = None  # injected by serve()
    admission_guard: AdmissionGuard | None = None  # injected by serve()
    owner_console_admission_guard: AdmissionAuthorityGuard | None = None
    mission_supervisor: MissionSupervisor | None = None
    afaq_ai: AfaqAI | None = None
    token: str | None = None
    # Agents for project_root overrides. One instance per root so submit and
    # the later approval execute on the same confined root. The default
    # agent (self.dev) is not stored here.
    _project_agents: dict[str, DeveloperAgent] = {}
    _project_agents_guard: threading.Lock = threading.Lock()

    server_version = f"AICRuntime/{RUNTIME_VERSION}"

    # -- plumbing ---------------------------------------------------------
    def log_message(self, format: str, *args) -> None:  # noqa: A002 - keep quiet
        pass

    def handle_one_request(self) -> None:
        # SQLite write contention (busy/locked) must produce a clean 503, not
        # kill the connection silently mid-request.
        try:
            super().handle_one_request()
        except sqlite3.OperationalError as exc:
            try:
                self._send_json(503, {"success": False, "message": f"storage busy: {exc}"})
            except (BrokenPipeError, ConnectionResetError, OSError):
                pass
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _send_json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _authorized(self) -> bool:
        if not self.token:
            return True
        header = self.headers.get("Authorization", "")
        return header == f"Bearer {self.token}"

    def _read_body(self) -> dict:
        # JSON only: accepting arbitrary content types would let a browser
        # page POST simple-text bodies cross-origin (no-cors) to localhost.
        content_type = (self.headers.get("Content-Type") or "").split(";")[0].strip().lower()
        if content_type != "application/json":
            raise _BodyError("content-type must be application/json")
        raw_length = self.headers.get("Content-Length") or "0"
        if not raw_length.isdigit():
            raise _BodyError("invalid Content-Length")
        length = int(raw_length)
        if length == 0:
            return {}
        if length > _MAX_BODY_BYTES:
            raise _BodyError(f"request body too large (> {_MAX_BODY_BYTES} bytes)")
        raw = self.rfile.read(length).decode("utf-8")
        return json.loads(raw)

    def _actor(self) -> str:
        """Actor identity forwarded by the secure gateway (X-AIC-Actor).

        The runtime binds to localhost and trusts this header only from the
        gateway; the gateway itself derives the value server-side from the
        admin session and never accepts an actor from the browser body.
        """
        raw = (self.headers.get("X-AIC-Actor") or "").strip()
        return raw[:_MAX_ACTOR_LEN] if raw else "unknown"

    # -- routes -----------------------------------------------------------
    def do_GET(self) -> None:  # noqa: N802 - stdlib naming
        if not self._authorized():
            self._send_json(401, {"success": False, "message": "unauthorized"})
            return
        path = urlparse(self.path).path.rstrip("/")
        if path == "/health":
            self._send_json(200, {
                "success": True,
                "version": RUNTIME_VERSION,
                "tasks": len(self.runtime.list_tasks()),
            })
            return
        if path == "/afaq-ai/status":
            if self.afaq_ai is None:
                self._send_json(503, {"success": False, "message": "AFAQ AI local runtime unavailable"})
                return
            self._send_json(200, {"success": True, "data": self.afaq_ai.status()})
            return
        if path == "/monitoring":
            self._send_json(200, {"success": True, "monitoring": self._monitoring()})
            return
        if path == "/capabilities":
            self._send_json(200, {
                "success": True,
                "orchestrator": self.orchestrator_http.describe(),
            })
            return
        if path == "/providers/readiness":
            self._send_json(200, {
                "success": True,
                "provider_readiness": self.orchestrator_http.sanitize_public(
                    provider_readiness()
                ),
            })
            return
        if path == "/orchestrator/jobs":
            if self.orchestrator_jobs is None:
                self._send_json(503, {
                    "success": False,
                    "error": {"code": "ORCHESTRATOR_JOBS_NOT_CONFIGURED"},
                })
                return
            query = parse_qs(urlparse(self.path).query)
            try:
                limit = int((query.get("limit") or ["100"])[0])
            except ValueError:
                limit = 100
            jobs = self.orchestrator_jobs.list(limit)
            self._send_json(200, {
                "success": True,
                "jobs": [
                    self.orchestrator_http.summarize_job(job)
                    for job in jobs
                ],
            })
            return

        if path.startswith("/orchestrator/jobs/"):
            if self.orchestrator_jobs is None:
                self._send_json(503, {
                    "success": False,
                    "error": {"code": "ORCHESTRATOR_JOBS_NOT_CONFIGURED"},
                })
                return
            parts = path.split("/")
            job_id = parts[3]
            job = self.orchestrator_jobs.get(job_id)
            if job is None:
                self._send_json(404, {"success": False, "message": "not found"})
                return
            if len(parts) == 5 and parts[4] == "events":
                events = self.orchestrator_jobs.events(job_id)
                self._send_json(200, {
                    "success": True,
                    "events": self.orchestrator_http.sanitize_public(events),
                })
                return
            if len(parts) == 5 and parts[4] == "steps":
                steps = self.orchestrator_jobs.steps(job_id)
                self._send_json(200, {
                    "success": True,
                    "steps": self.orchestrator_http.sanitize_public(steps),
                })
                return
            self._send_json(200, {
                "success": True,
                "job": self.orchestrator_http.sanitize_public(job),
            })
            return
        if path == "/missions":
            if self.mission_supervisor is None:
                self._send_json(503, {"success": False, "message": "mission supervisor not enabled"})
                return
            self._send_json(200, {"success": True, "missions": self.mission_supervisor.list_missions()})
            return
        if path.startswith("/missions/"):
            if self.mission_supervisor is None:
                self._send_json(503, {"success": False, "message": "mission supervisor not enabled"})
                return
            parts = path.split("/")
            mission_id = parts[2]
            try:
                if len(parts) == 3:
                    self._send_json(200, {"success": True, "mission": self.mission_supervisor.get_mission(mission_id)})
                    return
                if len(parts) == 4 and parts[3] == "decision-package":
                    self._send_json(200, {"success": True, "package": self.mission_supervisor.decision_package(mission_id)})
                    return
                if len(parts) == 4 and parts[3] == "events":
                    self._send_json(200, {"success": True, "events": self.mission_supervisor.events(mission_id)})
                    return
                self._send_json(404, {"success": False, "message": "not found"})
            except KeyError:
                self._send_json(404, {"success": False, "message": "mission not found"})
            return
        if path == "/tasks":
            self._send_json(200, {"success": True, "tasks": self.runtime.list_tasks()})
            return
        if path == "/incidents":
            if self.healing is None:
                self._send_json(404, {"success": False, "message": "self-healing not enabled"})
                return
            query = parse_qs(urlparse(self.path).query)
            status = (query.get("status") or [None])[0]
            classification = (query.get("classification") or [None])[0]
            if status is not None and status not in (
                "open", "diagnosing", "repair_pending_approval", "repairing",
                "repair_failed", "needs_human", "resolved", "no_action",
            ):
                self._send_json(400, {"success": False, "message": "invalid status"})
                return
            incidents = self.healing.store.list(status=status, classification=classification)
            self._send_json(200, {"success": True, "incidents": incidents})
            return
        if path.startswith("/incidents/"):
            if self.healing is None:
                self._send_json(404, {"success": False, "message": "self-healing not enabled"})
                return
            incident_id = path.split("/")[2]
            try:
                incident = self.healing.reconcile(incident_id)
            except KeyError:
                self._send_json(404, {"success": False, "message": "not found"})
                return
            self._send_json(200, {"success": True, "incident": incident})
            return
        if path == "/developer/approvals":
            if self.dev is None:
                self._send_json(404, {"success": False, "message": "developer agent not enabled"})
                return
            query = parse_qs(urlparse(self.path).query)
            status = (query.get("status") or [None])[0]
            if status is not None and status not in (
                "pending", "approved", "rejected", "expired", "cancelled",
            ):
                self._send_json(400, {"success": False, "message": "invalid status"})
                return
            self._send_json(200, {"success": True, "approvals": self.dev.approvals.list(status=status)})
            return
        if path.startswith("/developer/approvals/"):
            if self.dev is None:
                self._send_json(404, {"success": False, "message": "developer agent not enabled"})
                return
            approval_id = path.split("/")[3]
            record = self.dev.approvals.get(approval_id)
            if record is None:
                self._send_json(404, {"success": False, "message": "not found"})
                return
            self._send_json(200, {"success": True, "approval": record})
            return
        if path == "/developer/audit":
            if self.dev is None:
                self._send_json(404, {"success": False, "message": "developer agent not enabled"})
                return
            query = parse_qs(urlparse(self.path).query)
            task_id = (query.get("task_id") or [None])[0]
            try:
                limit = int((query.get("limit") or ["200"])[0])
            except ValueError:
                limit = 200
            limit = max(1, min(limit, 1000))
            self._send_json(200, {
                "success": True,
                "audit": self.dev.audit.list(task_id=task_id, limit=limit),
                "total": self.dev.audit.count(),
            })
            return
        if path == "/developer/tasks":
            if self.dev is None:
                self._send_json(404, {"success": False, "message": "developer agent not enabled"})
                return
            self._send_json(200, {"success": True, "tasks": self.dev.list_tasks()})
            return
        if path == "/developer/models":
            if self.dev is None:
                self._send_json(404, {"success": False, "message": "developer agent not enabled"})
                return
            self._send_json(200, {
                "success": True,
                "models": build_models_overview(self.dev.model_router),
            })
            return
        # ---- Workspace (Code Workspace UI): reads ----
        if path == "/workspace/tree":
            query = parse_qs(urlparse(self.path).query)
            ws = self._workspace_for({"root": (query.get("root") or [""])[0]})
            if ws is None:
                return
            rel = (query.get("path") or [""])[0]
            try:
                self._send_json(200, {"success": True, "tree": ws.tree(rel)})
            except (WorkspaceBlocked, NotADirectoryError) as exc:
                self._send_json(400, {"success": False, "message": str(exc)})
            return
        if path == "/workspace/files":
            query = parse_qs(urlparse(self.path).query)
            ws = self._workspace_for({"root": (query.get("root") or [""])[0]})
            if ws is None:
                return
            self._send_json(200, {"success": True, **ws.files()})
            return
        if path == "/workspace/file":
            query = parse_qs(urlparse(self.path).query)
            ws = self._workspace_for({"root": (query.get("root") or [""])[0]})
            if ws is None:
                return
            rel = (query.get("path") or [""])[0]
            try:
                self._send_json(200, {"success": True, "file": ws.read(rel)})
            except (WorkspaceBlocked, FileNotFoundError, ValueError) as exc:
                code = 404 if isinstance(exc, FileNotFoundError) else 400
                self._send_json(code, {"success": False, "message": str(exc)})
            return
        if path == "/workspace/search":
            query = parse_qs(urlparse(self.path).query)
            ws = self._workspace_for({"root": (query.get("root") or [""])[0]})
            if ws is None:
                return
            q = (query.get("q") or [""])[0]
            regex = (query.get("regex") or [""])[0] in ("1", "true")
            try:
                self._send_json(200, {"success": True, **ws.search(q, regex=regex)})
            except WorkspaceBlocked as exc:
                self._send_json(400, {"success": False, "message": str(exc)})
            return
        if path == "/workspace/detect":
            query = parse_qs(urlparse(self.path).query)
            ws = self._workspace_for({"root": (query.get("root") or [""])[0]})
            if ws is None:
                return
            self._send_json(200, {"success": True, **ws.detect()})
            return
        if path == "/workspace/git":
            query = parse_qs(urlparse(self.path).query)
            ws = self._workspace_for({"root": (query.get("root") or [""])[0]})
            if ws is None:
                return
            what = (query.get("what") or ["status"])[0]
            try:
                self._send_json(200, {"success": True, "git": ws.git(what, actor=self._actor())})
            except WorkspaceBlocked as exc:
                self._send_json(400, {"success": False, "message": str(exc)})
            return
        if path.startswith("/developer/tasks/"):
            if self.dev is None:
                self._send_json(404, {"success": False, "message": "developer agent not enabled"})
                return
            parts = path.split("/")
            task_id = parts[3]
            if len(parts) == 5 and parts[4] == "events":
                events = self.dev.task_events(task_id)
                if not events and self.dev.get_task(task_id) is None:
                    self._send_json(404, {"success": False, "message": "not found"})
                    return
                self._send_json(200, {"success": True, "events": events})
                return
            task = self.dev.get_task(task_id)
            if task is None:
                self._send_json(404, {"success": False, "message": "not found"})
                return
            self._send_json(200, {"success": True, "task": task})
            return
        if path.startswith("/tasks/"):
            parts = path.split("/")
            task_id = parts[2]
            if len(parts) == 4 and parts[3] == "events":
                events = self.runtime.task_events(task_id)
                if not events and self.runtime.get_task(task_id) is None:
                    self._send_json(404, {"success": False, "message": "not found"})
                    return
                self._send_json(200, {"success": True, "events": events})
                return
            task = self.runtime.get_task(task_id)
            if task is None:
                self._send_json(404, {"success": False, "message": "not found"})
                return
            self._send_json(200, {"success": True, "task": task})
            return
        self._send_json(404, {"success": False, "message": "not found"})

    # -- workspace helpers ------------------------------------------------
    def _workspace(self) -> WorkspaceService | None:
        if self.workspace is None:
            self._send_json(404, {
                "success": False,
                "message": "workspace not enabled (developer agent project_root required)",
            })
            return None
        return self.workspace

    def _workspace_for(self, params: dict) -> WorkspaceService | None:
        """Resolve the workspace for a request.

        The configured AIC_DEV_PROJECT_ROOT is the default. An explicit
        ``root`` is accepted only when it sits inside AIC_DEV_ALLOWED_ROOTS
        (same rule as the developer agent's per-request project_root), so E2E
        fixtures and secondary projects never pollute the real user workspace.
        """
        ws = self._workspace()
        if ws is None:
            return None
        requested = str(params.get("root") or "").strip()
        if not requested:
            return ws
        import os.path as _osp
        default_root = str(self.dev.project_root)
        if _osp.normcase(_osp.abspath(requested)) == _osp.normcase(_osp.abspath(default_root)):
            return ws
        requested_abs = _osp.normcase(_osp.abspath(requested))
        for allowed in _allowed_roots():
            allowed_abs = _osp.normcase(_osp.abspath(allowed))
            if requested_abs.startswith(allowed_abs + _osp.sep) or requested_abs == allowed_abs:
                try:
                    return _make_workspace(self.dev, requested)
                except ValueError:
                    break
        self._send_json(403, {
            "success": False,
            "message": "root not permitted (outside AIC_DEV_ALLOWED_ROOTS)",
        })
        return None

    def _submit_orchestrator_job(self, body: dict) -> None:
        if self.orchestrator_jobs is None:
            self._send_json(503, {
                "success": False,
                "error": {"code": "ORCHESTRATOR_JOBS_NOT_CONFIGURED"},
            })
            return

        request = body.get("request")
        context = body.get("context") or {}
        request_id = body.get("request_id")
        if not isinstance(request, str) or not request.strip():
            self._send_json(400, {
                "success": False,
                "error": {"code": "REQUEST_REQUIRED", "message": "request is required"},
            })
            return
        if not isinstance(context, dict):
            self._send_json(400, {
                "success": False,
                "error": {"code": "INVALID_CONTEXT", "message": "context must be a JSON object"},
            })
            return
        if request_id is not None and not isinstance(request_id, str):
            self._send_json(400, {
                "success": False,
                "error": {"code": "INVALID_REQUEST_ID", "message": "request_id must be a string"},
            })
            return

        idempotency_key = (self.headers.get("Idempotency-Key") or "").strip() or None
        try:
            job, created = self.orchestrator_jobs.submit(
                request.strip(),
                context=context,
                request_id=request_id,
                idempotency_key=idempotency_key,
            )
        except CapabilityInputsMissing as exc:
            self._send_json(422, {
                "success": False,
                "error": {
                    "code": "MISSING_CAPABILITY_INPUTS",
                    "message": "the request needs additional concrete inputs before execution",
                    "missing_inputs": [dict(item) for item in exc.missing_inputs],
                },
            })
            return
        except IdempotencyConflict as exc:
            self._send_json(409, {
                "success": False,
                "error": {
                    "code": "IDEMPOTENCY_KEY_CONFLICT",
                    "message": str(exc),
                },
            })
            return
        except OrchestratorExecutionUnavailable as exc:
            self._send_json(503, {
                "success": False,
                "error": {
                    "code": "ORCHESTRATOR_EXECUTION_DISABLED",
                    "message": str(exc),
                },
            })
            return
        except ShadowExecutionBlocked as exc:
            self._send_json(409, {
                "success": False,
                "error": {
                    "code": "SHADOW_MODE_BLOCKS_EXECUTION",
                    "message": str(exc),
                },
            })
            return
        except ValueError as exc:
            self._send_json(422, {
                "success": False,
                "error": {"code": "CAPABILITY_PLAN_INVALID", "message": str(exc)},
            })
            return
        except Exception:
            self._send_json(503, {
                "success": False,
                "error": {
                    "code": "ORCHESTRATOR_JOB_SUBMISSION_UNAVAILABLE",
                    "message": "orchestrator job submission is temporarily unavailable",
                },
            })
            return

        self._send_json(202 if created else 200, {
            "success": True,
            "created": created,
            "job": self.orchestrator_http.sanitize_public(job),
        })

    def do_POST(self) -> None:  # noqa: N802 - stdlib naming
        if not self._authorized():
            self._send_json(401, {"success": False, "message": "unauthorized"})
            return
        path = urlparse(self.path).path.rstrip("/")
        if path == "/admission/owner-console-online/check":
            guard = self.owner_console_admission_guard
            if guard is None:
                self._send_json(503, {
                    "success": False,
                    "error": {"code": "OWNER_CONSOLE_ADMISSION_UNAVAILABLE"},
                })
                return
            admission = guard.authorize(
                classification="OWNER_CONSOLE_ONLINE",
            )
            if not admission.allowed:
                self._send_json(503, {
                    "success": False,
                    "error": {"code": "OWNER_CONSOLE_ADMISSION_BLOCKED"},
                })
                return
            self._send_json(200, {
                "success": True,
                "admitted": True,
                "deployment_path": "owner_console_online",
                "cached": admission.cached,
            })
            return
        if self.admission_guard is not None:
            admission = self.admission_guard.authorize_request(
                method="POST",
                path=path,
            )
            if not admission.allowed:
                self.close_connection = True
                self._send_json(503, {
                    "success": False,
                    "error": {
                        "code": "RUNTIME_ADMISSION_BLOCKED",
                        "message": "runtime mutation is not admitted",
                        "classification": admission.classification,
                        "reason": admission.reason,
                        "cached": admission.cached,
                    },
                })
                return
        try:
            body = self._read_body()
        except json.JSONDecodeError:
            self._send_json(400, {"success": False, "message": "invalid JSON body"})
            return
        except _BodyError as exc:
            self._send_json(400, {"success": False, "message": str(exc)})
            return

        if path == "/missions":
            if self.mission_supervisor is None:
                self._send_json(503, {"success": False, "message": "mission supervisor not enabled"})
                return
            title = body.get("title")
            nodes = body.get("nodes") or []
            if not isinstance(title, str):
                self._send_json(400, {"success": False, "message": "title must be a string"})
                return
            title = title.strip()
            if not isinstance(nodes, list):
                self._send_json(400, {"success": False, "message": "nodes must be an array"})
                return
            try:
                mission = self.mission_supervisor.create_mission(title, nodes, actor=self._actor())
            except MissionError as exc:
                self._send_json(422, {"success": False, "message": str(exc)})
                return
            self._send_json(202, {"success": True, "mission": mission})
            return
        if path.startswith("/missions/"):
            if self.mission_supervisor is None:
                self._send_json(503, {"success": False, "message": "mission supervisor not enabled"})
                return
            parts = path.split("/")
            mission_id = parts[2]
            try:
                if len(parts) == 4 and parts[3] == "tick":
                    self._send_json(200, {"success": True, "mission": self.mission_supervisor.tick(mission_id)})
                    return
                if len(parts) == 4 and parts[3] == "decide":
                    decisions = body.get("decisions") or {}
                    if not isinstance(decisions, dict):
                        self._send_json(400, {"success": False, "message": "decisions must be an object"})
                        return
                    approve_all = body.get("approve_all", False)
                    reject_all = body.get("reject_all", False)
                    if not isinstance(approve_all, bool) or not isinstance(reject_all, bool):
                        self._send_json(400, {"success": False, "message": "approve_all and reject_all must be booleans"})
                        return
                    reason = body.get("reason", "")
                    if not isinstance(reason, str):
                        self._send_json(400, {"success": False, "message": "reason must be a string"})
                        return
                    result = self.mission_supervisor.decide(
                        mission_id, actor=self._actor(), decisions=decisions,
                        approve_all=approve_all,
                        reject_all=reject_all,
                        reason=reason[:500],
                    )
                    self._send_json(200, {"success": True, **result})
                    return
            except KeyError:
                self._send_json(404, {"success": False, "message": "mission not found"})
                return
            except MissionError as exc:
                self._send_json(409, {"success": False, "message": str(exc)})
                return
            except RuntimeError:
                self._send_json(409, {"success": False, "message": "mission decision conflict"})
                return
        if path == "/afaq-ai/infer/stream":
            if self.afaq_ai is None:
                self._send_json(503, {"success": False, "message": "AFAQ AI local runtime unavailable"})
                return
            prompt = str(body.get("prompt") or body.get("goal") or "").strip()
            if not prompt:
                self._send_json(400, {"success": False, "message": "prompt is required"})
                return
            engine_ids = body.get("engine_ids")
            if engine_ids is not None and (
                not isinstance(engine_ids, list)
                or not all(isinstance(item, str) for item in engine_ids)
            ):
                self._send_json(400, {"success": False, "message": "engine_ids must be an array of strings"})
                return
            context = body.get("context")
            if context is not None and not isinstance(context, dict):
                self._send_json(400, {"success": False, "message": "context must be an object"})
                return
            payload = body.get("payload")
            if payload is not None and not isinstance(payload, dict):
                self._send_json(400, {"success": False, "message": "payload must be an object"})
                return
            try:
                timeout_seconds = float(body.get("timeout_seconds") or os.getenv("AFAQ_LOCAL_INFERENCE_TIMEOUT_SECONDS", "300"))
            except (TypeError, ValueError):
                self._send_json(400, {"success": False, "message": "timeout_seconds must be numeric"})
                return

            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache, no-store, must-revalidate, no-transform")
            self.send_header("X-Accel-Buffering", "no")
            self.end_headers()
            stream = self.afaq_ai.infer_local_stream(
                prompt,
                context=context,
                engine_ids=engine_ids,
                payload=payload,
                approved_by_job=bool(body.get("approved_by_job", False)),
                timeout_seconds=timeout_seconds,
            )
            try:
                for event in stream:
                    event_type = str(event.get("type") or "message").replace("\n", "")
                    frame = (
                        f"event: {event_type}\n"
                        f"data: {json.dumps(event, ensure_ascii=False, separators=(',', ':'))}\n\n"
                    )
                    self.wfile.write(frame.encode("utf-8"))
                    self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError):
                close = getattr(stream, "close", None)
                if callable(close):
                    close()
            return

        if path == "/afaq-ai/infer":
            if self.afaq_ai is None:
                self._send_json(503, {"success": False, "message": "AFAQ AI local runtime unavailable"})
                return
            prompt = str(body.get("prompt") or body.get("goal") or "").strip()
            if not prompt:
                self._send_json(400, {"success": False, "message": "prompt is required"})
                return
            engine_ids = body.get("engine_ids")
            if engine_ids is not None and (
                not isinstance(engine_ids, list)
                or not all(isinstance(item, str) for item in engine_ids)
            ):
                self._send_json(400, {"success": False, "message": "engine_ids must be an array of strings"})
                return
            context = body.get("context")
            if context is not None and not isinstance(context, dict):
                self._send_json(400, {"success": False, "message": "context must be an object"})
                return
            payload = body.get("payload")
            if payload is not None and not isinstance(payload, dict):
                self._send_json(400, {"success": False, "message": "payload must be an object"})
                return
            try:
                timeout_seconds = float(body.get("timeout_seconds") or os.getenv("AFAQ_LOCAL_INFERENCE_TIMEOUT_SECONDS", "300"))
            except (TypeError, ValueError):
                self._send_json(400, {"success": False, "message": "timeout_seconds must be numeric"})
                return
            result = self.afaq_ai.infer_local(
                prompt,
                context=context,
                engine_ids=engine_ids,
                payload=payload,
                approved_by_job=bool(body.get("approved_by_job", False)),
                timeout_seconds=timeout_seconds,
            )
            if result.get("success"):
                self._send_json(200, {"success": True, "data": result})
                return
            error = result.get("error") or {}
            code = str(error.get("code") or "LOCAL_INFERENCE_NOT_COMPLETED")
            status = 504 if code == "LOCAL_INFERENCE_TIMEOUT" else 503 if code in {
                "LOCAL_INFERENCE_MEMORY_PRESSURE",
                "LOCAL_INFERENCE_WORKER_ERROR",
                "LOCAL_INFERENCE_WORKER_EXITED",
            } else 409
            self._send_json(status, {"success": False, "error": error, "data": result})
            return

        if path in {"/orchestrator/jobs", "/orchestrator/goal"}:
            self._submit_orchestrator_job(body)
            return

        if path == "/orchestrator/plan":
            response = self.orchestrator_http.plan_goal(body)
            self._send_json(response.status_code, response.payload)
            return

        if path == "/orchestrator/execute":
            response = self.orchestrator_http.execute(body)
            self._send_json(response.status_code, response.payload)
            return

        if path.startswith("/orchestrator/jobs/") and path.endswith(("/approve", "/reject")):
            if self.orchestrator_jobs is None:
                self._send_json(503, {
                    "success": False,
                    "error": {"code": "ORCHESTRATOR_JOBS_NOT_CONFIGURED"},
                })
                return
            parts = path.split("/")
            if len(parts) != 5 or not parts[3]:
                self._send_json(404, {"success": False, "message": "not found"})
                return
            job_id = parts[3]
            decision = parts[4]
            try:
                if decision == "approve":
                    job = self.orchestrator_jobs.approve(job_id)
                else:
                    job = self.orchestrator_jobs.reject(job_id)
            except KeyError:
                self._send_json(404, {"success": False, "message": "not found"})
                return
            except RuntimeError as exc:
                self._send_json(409, {
                    "success": False,
                    "error": {
                        "code": "ORCHESTRATOR_JOB_DECISION_CONFLICT",
                        "message": str(exc),
                    },
                })
                return
            self._send_json(200, {
                "success": True,
                "job": self.orchestrator_http.sanitize_public(job),
            })
            return

        if path == "/tasks":
            instruction = (body.get("instruction") or "").strip()
            if not instruction:
                self._send_json(400, {"success": False, "message": "instruction is required"})
                return
            self._send_json(409, {"success": False, "message": "V1 task submission is disabled"})
            return

        if path.startswith("/tasks/") and path.endswith("/resume"):
            task_id = path.split("/")[2]
            try:
                task = self.runtime.resume(task_id)
            except KeyError:
                self._send_json(404, {"success": False, "message": "not found"})
                return
            except RuntimeError as exc:
                self._send_json(409, {"success": False, "message": str(exc)})
                return
            self._send_json(200, {"success": True, "task": task})
            return

        if path == "/developer/tasks":
            agent = self._developer_agent_for(body)
            if agent is None:
                self._send_json(403, {"success": False, "message": "project_root not permitted (set AIC_DEV_PROJECT_ROOT / AIC_DEV_ALLOWED_ROOTS)"})
                return
            instruction = (body.get("instruction") or "").strip()
            if not instruction:
                self._send_json(400, {"success": False, "message": "instruction is required"})
                return
            model = body.get("model")
            if model is not None and not isinstance(model, str):
                self._send_json(400, {"success": False, "message": "model must be a string"})
                return
            settings = body.get("settings")
            if settings is not None and not isinstance(settings, dict):
                self._send_json(400, {"success": False, "message": "settings must be a JSON object"})
                return
            try:
                task_id = agent.submit(
                    instruction, proposal=body.get("proposal"), actor=self._actor(),
                    model=model, settings=settings,
                )
            except ValueError as exc:
                self._send_json(400, {"success": False, "message": str(exc)})
                return
            self._send_json(202, {"success": True, "task_id": task_id})
            return

        if path == "/incidents/scan":
            if self.healing is None:
                self._send_json(404, {"success": False, "message": "self-healing not enabled"})
                return
            created = self.healing.scan(actor=self._actor())
            self._send_json(200, {"success": True, "created": created})
            return
        if path.startswith("/incidents/") and path.endswith("/diagnose"):
            if self.healing is None:
                self._send_json(404, {"success": False, "message": "self-healing not enabled"})
                return
            incident_id = path.split("/")[2]
            try:
                incident = self.healing.diagnose(incident_id, actor=self._actor())
            except KeyError:
                self._send_json(404, {"success": False, "message": "not found"})
                return
            self._send_json(200, {"success": True, "incident": incident})
            return
        if path.startswith("/incidents/") and path.endswith("/propose"):
            if self.healing is None:
                self._send_json(404, {"success": False, "message": "self-healing not enabled"})
                return
            incident_id = path.split("/")[2]
            proposal = body.get("proposal")
            if proposal is not None and not isinstance(proposal, dict):
                self._send_json(400, {"success": False, "message": "proposal must be a JSON object"})
                return
            try:
                incident = self.healing.propose_repair(
                    incident_id, actor=self._actor(), proposal=proposal,
                )
            except KeyError:
                self._send_json(404, {"success": False, "message": "not found"})
                return
            except (RuntimeError, ValueError) as exc:
                self._send_json(409, {"success": False, "message": str(exc)})
                return
            self._send_json(200, {"success": True, "incident": incident})
            return

        if path.startswith("/developer/approvals/") and path.endswith(("/approve", "/reject")):
            if self.dev is None:
                self._send_json(404, {"success": False, "message": "developer agent not enabled"})
                return
            parts = path.split("/")
            if len(parts) != 5 or not parts[3]:
                self._send_json(404, {"success": False, "message": "not found"})
                return
            approval_id = parts[3]
            decision = parts[4]
            reason = str(body.get("reason") or "")[:500]
            record = self.dev.approvals.get(approval_id)
            if record is None:
                self._send_json(404, {"success": False, "message": "not found"})
                return
            try:
                agent = self._agent_for_task(str(record["task_id"]))
            except KeyError:
                self._send_json(404, {"success": False, "message": "not found"})
                return
            if agent is None:
                self._send_json(403, {
                    "success": False,
                    "message": "project_root not permitted (set AIC_DEV_PROJECT_ROOT / AIC_DEV_ALLOWED_ROOTS)",
                })
                return
            try:
                task = agent.decide_approval(
                    approval_id, decision=decision, actor=self._actor(), reason=reason,
                )
            except KeyError:
                self._send_json(404, {"success": False, "message": "not found"})
                return
            except (RuntimeError, ValueError) as exc:
                self._send_json(409, {"success": False, "message": str(exc)})
                return
            self._send_json(200, {"success": True, "task": task})
            return

        if path.startswith("/developer/tasks/"):
            if self.dev is None:
                self._send_json(404, {"success": False, "message": "developer agent not enabled"})
                return
            parts = path.split("/")
            task_id = parts[3]
            action = parts[4] if len(parts) == 5 else ""
            if action not in {"approve", "reject", "resume"}:
                self._send_json(404, {"success": False, "message": "not found"})
                return
            actor = self._actor()
            reason = str(body.get("reason") or "")[:500]
            try:
                agent = self._agent_for_task(task_id)
            except KeyError:
                self._send_json(404, {"success": False, "message": "not found"})
                return
            if agent is None:
                self._send_json(403, {
                    "success": False,
                    "message": "project_root not permitted (set AIC_DEV_PROJECT_ROOT / AIC_DEV_ALLOWED_ROOTS)",
                })
                return
            try:
                if action == "approve":
                    task = agent.approve(task_id, actor=actor, reason=reason)
                elif action == "reject":
                    task = agent.reject(task_id, actor=actor, reason=reason)
                else:
                    task = agent.resume(task_id, actor=actor)
            except KeyError:
                self._send_json(404, {"success": False, "message": "not found"})
                return
            except RuntimeError as exc:
                self._send_json(409, {"success": False, "message": str(exc)})
                return
            self._send_json(200, {"success": True, "task": task})
            return

        # ---- Workspace (Code Workspace UI): writes / commands ----
        # Direct filesystem mutations are intentionally fail-closed.
        # Writes must go through the governed DeveloperAgent approval flow.
        if path == "/workspace/file":
            self._send_json(403, {
                "success": False,
                "message": (
                    "direct workspace mutations are disabled; "
                    "use the governed developer approval flow"
                ),
            })
            return
        if path == "/workspace/fs":
            self._send_json(403, {
                "success": False,
                "message": (
                    "direct workspace mutations are disabled; "
                    "use the governed developer approval flow"
                ),
            })
            return
        if path == "/workspace/run":
            ws = self._workspace_for(body)
            if ws is None:
                return
            command = body.get("command")
            if not isinstance(command, str):
                self._send_json(400, {"success": False, "message": "command is required"})
                return
            try:
                timeout = int(body.get("timeout") or 180)
            except (TypeError, ValueError):
                timeout = 180
            try:
                result = ws.run(command, actor=self._actor(), timeout=timeout)
            except WorkspaceBlocked as exc:
                self._send_json(403, {"success": False, "message": str(exc)})
                return
            except CommandNotAllowed as exc:
                self._send_json(403, {"success": False, "message": f"أمر محظور بالسياسة: {exc}"})
                return
            self._send_json(200, {"success": True, "run": result})
            return

        self._send_json(404, {"success": False, "message": "not found"})

    def _monitoring(self) -> dict:
        dev = self.dev
        if dev is None:
            return {"health": "unavailable", "reason": "developer agent not enabled"}
        return collect_monitoring(
            dev_store=dev.store,
            approvals_store=dev.approvals,
            audit=dev.audit,
            memory_db_path=dev.var_dir / "aic_memory.db",
            event_db_path=dev.var_dir / "aic_runtime.db",
            ollama_url=dev.config.ollama_url,
            config_environment=normalize_environment(dev.config.environment),
        )

    def _developer_agent_for(self, body: dict) -> DeveloperAgent | None:
        """Resolve the developer agent for a submit request.

        The configured AIC_DEV_PROJECT_ROOT is the default. A body project_root
        is accepted only when it sits inside AIC_DEV_ALLOWED_ROOTS.
        """
        if self.dev is None:
            return None
        return self._agent_for_root((body.get("project_root") or "").strip())

    def _agent_for_task(self, task_id: str) -> DeveloperAgent | None:
        """Agent confined to the project root stored on the task.

        Approval and resume must execute there. Falling back to the process
        default root applies the patch to the wrong tree.
        """
        if self.dev is None:
            return None
        task = self.dev.get_task(task_id)
        if task is None:
            raise KeyError(task_id)
        return self._agent_for_root(str(task.get("project_root") or ""))

    def _agent_for_root(self, requested: str) -> DeveloperAgent | None:
        """Return the cached agent for one permitted project root."""
        if self.dev is None:
            return None
        requested = (requested or "").strip()
        if not requested:
            return self.dev
        import os.path as _osp
        configured = _osp.normcase(str(self.dev.project_root))
        requested_abs = _osp.normcase(_osp.abspath(requested))
        try:
            requested_resolved = _osp.normcase(str(Path(requested).resolve()))
        except OSError:
            requested_resolved = requested_abs
        if requested_abs == _osp.normcase(_osp.abspath(configured)) or requested_resolved == configured:
            return self.dev
        permitted = False
        for allowed in _allowed_roots():
            allowed_abs = _osp.normcase(_osp.abspath(allowed))
            if requested_abs == allowed_abs or requested_abs.startswith(allowed_abs + _osp.sep):
                permitted = True
                break
            try:
                allowed_resolved = _osp.normcase(str(Path(allowed).resolve()))
            except OSError:
                continue
            if (
                requested_resolved == allowed_resolved
                or requested_resolved.startswith(allowed_resolved + _osp.sep)
            ):
                permitted = True
                break
        if not permitted:
            return None
        with self._project_agents_guard:
            cached = self._project_agents.get(requested_resolved)
            if cached is not None:
                return cached
            try:
                agent = DeveloperAgent(
                    var_dir=self.dev.var_dir,
                    project_root=requested,
                    model_router=self.dev.model_router,
                    router=self.dev.router,
                )
            except ValueError:
                return None
            key = _osp.normcase(str(agent.project_root))
            self._project_agents[key] = agent
            return agent


def _port_in_use(host: str, port: int) -> bool:
    import socket
    probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    probe.settimeout(0.5)
    try:
        return probe.connect_ex((host, port)) == 0
    finally:
        probe.close()


def ensure_single_runtime(host: str, port: int) -> None:
    """Refuse to start a duplicate runtime on an already-listening port.

    Proven incident (readiness audit): an orphaned pre-fix process kept
    listening next to the new one and requests were silently load-balanced
    between two different code versions. Failing clearly at startup is the
    cheap fix; a service manager is explicitly out of scope.
    """
    if port and _port_in_use(host, port):
        raise SystemExit(
            f"[aic-runtime] {host}:{port} is already accepting connections — "
            "another AIC runtime is listening there. Refusing to start a "
            "duplicate. Stop the existing process first (or set "
            "AIC_RUNTIME_PORT to a different port)."
        )


def serve(
    host: str = "127.0.0.1",
    port: int | None = None,
    runtime: AgentRuntime | None = None,
) -> ThreadingHTTPServer:
    environment = normalize_environment(
        (runtime.config.environment if runtime is not None else os.getenv("AFAQ_ENVIRONMENT") or "development")
    )
    if environment == "production":
        try:
            require_admission(
                environment="production",
                deployment_path="hosted_runtime_start",
                record=True,
            )
        except AdmissionBlocked as exc:
            raise SystemExit(f"[aic-runtime] production admission blocked: {exc}") from exc
    if port is None:
        port = int(os.getenv("AIC_RUNTIME_PORT", "8787"))
    runtime = runtime or AgentRuntime()
    token = os.getenv("AIC_RUNTIME_TOKEN") or None
    afaq_ai = AfaqAI(
        Path(__file__).resolve().parents[1],
        memory_path=runtime.var_dir / "afaq_ai_memory.db",
    )
    if os.getenv("AFAQ_NATIVE_PRELOAD", "1").strip().lower() not in {"0", "false", "no", "off"}:
        try:
            warm = afaq_ai.warm_local_inference(
                timeout_seconds=float(os.getenv("AFAQ_NATIVE_PRELOAD_TIMEOUT_SECONDS", "180"))
            )
            print(
                "[afaq-native] resident model ready "
                f"(gpu={warm.get('gpu_offload_supported')}, "
                f"layers={warm.get('n_gpu_layers')}, "
                f"load={float(warm.get('model_load_seconds') or 0):.2f}s)"
            )
        except Exception as exc:
            print(f"[afaq-native] preload unavailable: {type(exc).__name__}: {exc}")
    dev = _build_developer_agent(runtime)
    healing = SelfHealingEngine(dev) if dev is not None else None
    mission_supervisor = MissionSupervisor(runtime.var_dir / "mission_supervisor.db", dev) if dev is not None else None
    workspace = _build_workspace(dev) if dev is not None else None
    orchestrator = _build_orchestrator()
    capability_planner = CapabilityPlanner(runtime.planner)
    orchestrator_http = OrchestratorHttpAdapter(
        orchestrator,
        capability_planner=capability_planner,
    )
    orchestrator_jobs = (
        GovernedOrchestratorJobs(
            store_path=runtime.var_dir / "orchestrator_jobs.db",
            planner=capability_planner,
            orchestrator=orchestrator,
            environment=normalize_environment(runtime.config.environment),
        )
        if orchestrator is not None
        else None
    )

    project_agents: dict[str, DeveloperAgent] = {}
    project_agents_guard = threading.Lock()
    handler = type("BoundHandler", (_Handler,), {
        "runtime": runtime, "dev": dev, "healing": healing, "token": token,
        "afaq_ai": afaq_ai,
        "workspace": workspace, "orchestrator_http": orchestrator_http,
        "mission_supervisor": mission_supervisor,
        "orchestrator_jobs": orchestrator_jobs,
        "admission_guard": AdmissionGuard(environment=environment),
        "owner_console_admission_guard": AdmissionAuthorityGuard(
            environment=environment,
            deployment_path="owner_console_online",
        ),
        "_project_agents": project_agents,
        "_project_agents_guard": project_agents_guard,
    })
    server = ThreadingHTTPServer((host, port), handler)

    def _close_project_agents() -> None:
        with project_agents_guard:
            extras = list(project_agents.values())
            project_agents.clear()
        for extra in extras:
            extra.close()
    from . import monitoring as _monitoring
    _monitoring.mark_server_started()
    _orig_shutdown = server.shutdown

    def _shutdown_and_close() -> None:
        # Stop accepting requests before closing stores used by request/job
        # threads. Then drain project-root agents and, when present, the
        # AFAQ AI resources that share this process.
        _orig_shutdown()
        server.server_close()
        _close_project_agents()
        if afaq_ai is None:
            return
        if orchestrator_jobs is not None:
            orchestrator_jobs.close()
        if mission_supervisor is not None:
            mission_supervisor.close()
        if healing is not None:
            healing.close()
        if dev is not None:
            dev.close()
        afaq_ai.close()

    server.shutdown = _shutdown_and_close  # type: ignore[method-assign]

    recovered = runtime.recover()
    if recovered:
        print(f"[aic-runtime] recovered interrupted tasks: {recovered}")
    if orchestrator_jobs is not None:
        recovered_jobs = orchestrator_jobs.recover()
        if recovered_jobs["restarted"] or recovered_jobs["interrupted"]:
            print(f"[afaq-orchestrator] recovered jobs: {recovered_jobs}")
    if dev is not None:
        recovered_dev = dev.recover()
        if recovered_dev:
            print(f"[aic-dev] recovered interrupted dev tasks: {recovered_dev}")
        print(f"[aic-dev] developer agent enabled on {dev.project_root}")
    if mission_supervisor is not None:
        recovered_missions = mission_supervisor.recover()
        mission_supervisor.start()
        if recovered_missions["recovered"]:
            print(f"[aic-mission] recovered missions: {recovered_missions['recovered']}")
        print("[aic-mission] non-blocking mission supervisor enabled")
    if healing is not None:
        try:
            detected = healing.scan()
            if detected:
                print(f"[aic-self-heal] startup scan raised {len(detected)} incident(s): "
                      f"{[i['incident_id'] for i in detected]}")
            else:
                print("[aic-self-heal] startup scan: no new incidents")
        except Exception as exc:  # noqa: BLE001 - scan must never block startup
            print(f"[aic-self-heal] startup scan failed: {type(exc).__name__}: {exc}")

    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    if orchestrator is not None:
        print(
            "[afaq-orchestrator] HTTP surface configured "
            f"(enabled={orchestrator.enabled()}, shadow={orchestrator.shadow()})"
        )
    print(f"[aic-runtime] v{RUNTIME_VERSION} listening on http://{host}:{port}"
          f"{' (token required)' if token else ' (no token set — localhost only)'}")
    return server


def main() -> int:
    _load_runtime_env_file()
    ensure_single_runtime(
        "127.0.0.1", int(os.getenv("AIC_RUNTIME_PORT", "8787"))
    )
    runtime = AgentRuntime()
    server = serve(runtime=runtime)
    try:
        threading.Event().wait()
    except KeyboardInterrupt:
        pass
    finally:
        server.shutdown()
        runtime.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
