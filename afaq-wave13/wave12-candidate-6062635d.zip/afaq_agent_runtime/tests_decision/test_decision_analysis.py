"""Focused tests for the decision-intelligence layer (GAP-PQ-1).

Runs against afaq_agent_runtime.decision_analysis only — no model, no
runtime services, no canonical state. Intentionally OUTSIDE pytest.ini
testpaths so the canonical suite stays at exactly 44 tests.

Run explicitly:

    python -m pytest afaq_agent_runtime/tests_decision -q
"""

from __future__ import annotations

import pytest

from afaq_agent_runtime.decision_analysis import (
    DecisionAnalysisError,
    build_decision_package,
    decision_readiness,
    parse_analysis,
    run_quality_gates,
)


def _valid_analysis(**overrides):
    base = {
        "problem": "Config default is wrong for current hardware",
        "root_cause": {
            "statement": "Default model exceeds available RAM",
            "status": "best_supported",
            "competing_hypotheses": ["Config file corrupted"],
        },
        "evidence": [
            {
                "claim": "Model requires 8GB, host has 6GB",
                "kind": "fact",
                "basis": "hardware_profile.json lists 6GB total",
            }
        ],
        "no_change_considered": {
            "considered": True,
            "reason": "Without the change the runtime cannot load the model",
        },
        "minimality": {
            "is_minimum": True,
            "justification": "Single constant change achieves the goal",
        },
        "impact": {
            "directly_modified": ["config/defaults.json"],
            "blast_radius": "local",
        },
        "reversibility": "reversible",
        "verification": ["Run the unit tests named in the proposal"],
        "confidence": {
            "level": "medium",
            "basis": "Hardware fact plus one config file",
            "limitations": "No runtime load test performed",
        },
        "assumptions": ["defaults.json is the only override source"],
        "uncertainties": [],
        "alternatives": [{"option": "Upgrade RAM", "why_not": "Cost exceeds benefit"}],
        "falsification": "If load still fails with smaller model, cause is elsewhere",
        "counterargument": "Change may mask a deeper config bug",
        "dependencies": [],
    }
    base.update(overrides)
    return base


def _proposal(paths=("config/defaults.json",)):
    return {
        "files": [
            {"path": p, "action": "edit", "description": "adjust default"}
            for p in paths
        ],
        "rationale": "fit model to hardware",
        "risks": "none beyond config scope",
        "tests": [{"name": "unit tests", "command": ["python", "-m", "pytest"]}],
    }


# ---------------------------------------------------------------- parse


def test_parse_valid_deep():
    parsed = parse_analysis(_valid_analysis(), deep=True)
    assert parsed["root_cause"]["status"] == "best_supported"
    assert parsed["impact"]["blast_radius"] == "local"
    assert len(parsed["evidence"]) == 1


def test_parse_rejects_missing_required():
    payload = _valid_analysis()
    del payload["problem"]
    with pytest.raises(DecisionAnalysisError, match="missing required"):
        parse_analysis(payload, deep=True)


def test_parse_rejects_non_object():
    with pytest.raises(DecisionAnalysisError, match="JSON object"):
        parse_analysis(None)
    with pytest.raises(DecisionAnalysisError, match="JSON object"):
        parse_analysis("prose")


def test_parse_rejects_bad_enums():
    payload = _valid_analysis()
    payload["reversibility"] = "mostly"
    with pytest.raises(DecisionAnalysisError, match="reversibility"):
        parse_analysis(payload, deep=True)


def test_parse_rejects_no_change_not_considered():
    payload = _valid_analysis()
    payload["no_change_considered"] = {"considered": False, "reason": "x"}
    with pytest.raises(DecisionAnalysisError, match="no-change"):
        parse_analysis(payload)


def test_parse_depth_deep_requires_alternatives():
    payload = _valid_analysis()
    del payload["alternatives"]
    with pytest.raises(DecisionAnalysisError, match="alternatives"):
        parse_analysis(payload, deep=True)
    # base depth does not require them
    parsed = parse_analysis(payload)
    assert "alternatives" not in parsed


def test_parse_word_cap_enforced():
    payload = _valid_analysis(problem="word " * 60)
    with pytest.raises(DecisionAnalysisError, match="words"):
        parse_analysis(payload)


# ---------------------------------------------------------------- gates


def test_gates_pass_on_consistent_package():
    analysis = parse_analysis(_valid_analysis(), deep=True)
    failures = run_quality_gates(
        analysis, _proposal(), instruction="fix the config default for hardware in config/defaults.json"
    )
    assert failures == []


def test_gates_flag_impact_mismatch():
    payload = _valid_analysis()
    payload["impact"]["directly_modified"] = ["other/file.py"]
    analysis = parse_analysis(payload, deep=True)
    failures = run_quality_gates(
        analysis, _proposal(), instruction="fix the config default in config/defaults.json"
    )
    assert any("file set" in f for f in failures)


def test_gates_flag_ungrounded_verification():
    payload = _valid_analysis(verification=["Someone will check it manually"])
    analysis = parse_analysis(payload, deep=True)
    failures = run_quality_gates(
        analysis, _proposal(), instruction="fix the config default in config/defaults.json"
    )
    assert any("verification" in f for f in failures)


def test_gates_flag_ungrounded_evidence():
    payload = _valid_analysis()
    payload["evidence"] = [
        {"claim": "It feels wrong", "kind": "inference", "basis": "vibes"}
    ]
    analysis = parse_analysis(payload, deep=True)
    failures = run_quality_gates(
        analysis, _proposal(), instruction="fix the config default in config/defaults.json"
    )
    assert any("not grounded" in f for f in failures)


def test_gates_accept_instruction_quote_despite_call_spacing():
    """Local models quote the same task fact with different call spacing
    (add(2,3) vs add(2, 3)) and often put that quote in claim rather than
    basis. The basis here shares no instruction token, so only the claim
    quote can ground the entry."""
    payload = _valid_analysis()
    payload["evidence"] = [
        {
            "claim": "add(2,3) returns 5",
            "kind": "fact",
            "basis": "operands are subtracted today",
        }
    ]
    payload["impact"]["directly_modified"] = ["calc.py"]
    analysis = parse_analysis(payload, deep=True)
    proposal = _proposal(paths=("calc.py",))
    failures = run_quality_gates(
        analysis,
        proposal,
        instruction="fix the add function in calc.py so that add(2, 3) returns 5",
    )
    assert not any("not grounded" in f for f in failures)


def test_gates_accept_basename_path_in_basis():
    payload = _valid_analysis()
    payload["evidence"] = [
        {
            "claim": "operands are subtracted",
            "kind": "observation",
            "basis": "see calc.py return a - b",
        }
    ]
    payload["impact"]["directly_modified"] = ["src/calc.py"]
    analysis = parse_analysis(payload, deep=True)
    failures = run_quality_gates(
        analysis,
        _proposal(paths=("src/calc.py",)),
        instruction="repair the subtraction defect so the sum is five",
    )
    assert not any("not grounded" in f for f in failures)


def test_gates_flag_blast_radius_contradiction():
    payload = _valid_analysis()
    payload["impact"]["blast_radius"] = "local"
    analysis = parse_analysis(payload, deep=True)
    proposal = _proposal(paths=("a.py", "b.py", "c.py"))
    failures = run_quality_gates(analysis, proposal, instruction="change three files")
    assert any("contradicts" in f for f in failures)


def test_gates_flag_off_target_file():
    """A proposal for a file the instruction never named is hallucinated
    scope and must not reach the owner as decision-ready."""
    analysis = parse_analysis(_valid_analysis(), deep=True)
    proposal = _proposal(paths=("app/api/governance/tasks/route.ts",))
    failures = run_quality_gates(
        analysis, proposal,
        instruction="Approval handoff req-1: action=developer_task "
        "resource=scripts/dq/probes/case_a_localized.py reason=CASE A "
        "localized change to scripts/dq/probes/case_a_localized.py only",
    )
    assert any("not named in the task instruction" in f for f in failures)


# ---------------------------------------------------------------- seal


def test_readiness_blocks_unknown_root_cause_for_remediation():
    payload = _valid_analysis()
    payload["root_cause"]["status"] = "unknown"
    analysis = parse_analysis(payload, deep=True)
    seal = decision_readiness(analysis, [], remediation=True)
    assert seal["decision_ready"] is False
    assert any("UNKNOWN" in b for b in seal["blocking_items"])


def test_readiness_allows_unknown_root_cause_for_pure_change():
    """A change request (not a defect remediation) has no root cause to
    prove; UNKNOWN must remain honest there, not fabricated."""
    payload = _valid_analysis()
    payload["root_cause"]["status"] = "unknown"
    analysis = parse_analysis(payload, deep=True)
    seal = decision_readiness(analysis, [], remediation=False)
    assert seal["decision_ready"] is True


def test_readiness_passes_clean_package():
    analysis = parse_analysis(_valid_analysis(), deep=True)
    seal = decision_readiness(analysis, [])
    assert seal["decision_ready"] is True
    assert seal["blocking_items"] == []


# ---------------------------------------------------------------- package


def test_package_composes_truthfully():
    analysis = parse_analysis(_valid_analysis(), deep=True)
    proposal = dict(_proposal())
    proposal["analysis"] = analysis
    package = build_decision_package(
        instruction="fix the config default in config/defaults.json",
        proposal=proposal,
        analysis=analysis,
        risk={"level": "medium", "reasons": []},
        approval={"approval_id": "APR-x", "status": "pending", "risk_level": "medium"},
    )
    snap = package["decision_snapshot"]
    assert snap["problem"].startswith("Config default")
    assert snap["blast_radius"] == "local"
    boundary = package["owner_decision_boundary"]
    assert boundary["this_approval_authorizes"] == ["edit config/defaults.json"]
    assert boundary["this_approval_does_not_authorize"]


def test_package_absent_analysis_stays_absent():
    package = build_decision_package(
        instruction="x",
        proposal=_proposal(),
        analysis=None,
        risk=None,
        approval=None,
    )
    assert package["analysis"] == "NOT AVAILABLE — canonical proposal only"
    assert package["decision_readiness"]["decision_ready"] is False
    assert package["decision_snapshot"]["reversibility"] == "UNKNOWN"


def test_instruction_file_context_includes_named_file(tmp_path):
    from afaq_agent_runtime.developer_agent import _instruction_file_context

    probe = tmp_path / "scripts" / "dq" / "probes" / "probe.py"
    probe.parent.mkdir(parents=True)
    probe.write_text('X = "target"\n', encoding="utf-8")
    (tmp_path / "other.py").write_text("Y = 1\n", encoding="utf-8")
    ctx = _instruction_file_context(
        tmp_path,
        'change scripts/dq/probes/probe.py: replace X with Z; leave everything else alone',
    )
    assert "probe.py" in ctx and 'X = "target"' in ctx
    # the unmentioned file's contents must not leak into the target block
    assert "Y = 1" not in ctx


def test_instruction_file_context_missing_file_is_silent(tmp_path):
    from afaq_agent_runtime.developer_agent import _instruction_file_context

    assert _instruction_file_context(tmp_path, "edit nope/nothere.py now") == ""


# ------------------------------------------------- proposal-gate regression


def test_gate_rejects_disallowed_test_command_without_raising(tmp_path):
    """A disallowed test command is a correctable gate failure (fed back to
    the bounded retry), not an instant task-killing policy event. The
    allowlist itself is untouched."""
    from afaq_agent_runtime.developer_agent import DeveloperAgent
    from afaq_agent_runtime.developer_tools import ProjectBoundary

    (tmp_path / "a.py").write_text("X = 1\n", encoding="utf-8")
    fake = type("FakeAgent", (), {"boundary": ProjectBoundary(tmp_path)})()
    proposal = {
        "files": [{
            "path": "a.py", "action": "edit",
            "replacements": [{"old": "X = 1", "new": "X = 2"}],
        }],
        "tests": [{"name": "frontend", "command": ["npm", "run", "test:frontend"]}],
    }
    ok, reason = DeveloperAgent._proposal_gate(fake, proposal)
    assert ok is False
    assert "invalid:" in reason and "npm" in reason
