"""Focused tests for the Research & Content Intelligence engine (wave 2, §12
family).

Runs against afaq_agent_runtime.research_intelligence only — no model, no
network, no runtime services, no canonical state. Intentionally OUTSIDE
pytest.ini testpaths so the canonical suite stays at exactly 44 tests.

Run explicitly:

    python -m pytest afaq_agent_runtime/tests_research -q
"""

from __future__ import annotations

import pytest

from afaq_agent_runtime.research_intelligence import (
    ResearchError,
    analyze_topic,
    discover_sources,
    extract_facts,
    parse_research_report,
    rank_sources,
    research_readiness,
    research_topic,
    run_research_gates,
    verify_source,
)

_TOPIC = "solar energy adoption in rural areas"

_CORPUS = [
    {
        "id": "gov-1",
        "title": "National Rural Solar Report 2023",
        "publisher": "Ministry of Energy",
        "kind": "official",
        "author": "Dept of Statistics",
        "published": "2023-05-01",
        "text": (
            "According to the national survey, solar adoption in rural areas "
            "reached 42% in 2023. The report states that 12000 households "
            "installed panels. Solar energy is the fastest growing rural source."
        ),
    },
    {
        "id": "news-1",
        "title": "Villages switch to solar amid grid delays",
        "publisher": "Daily Tribune",
        "kind": "news",
        "published": "2023",
        "text": (
            "According to local officials, rural solar adoption keeps rising. "
            "The Daily Tribune visited villages where solar energy replaced "
            "diesel generators. No households reported reliability problems."
        ),
    },
    {
        "id": "blog-1",
        "title": "My off-grid diary",
        "publisher": "unknown",
        "kind": "blog",
        "text": (
            "Solar is fun and panels look nice on the roof. "
            "I like sunshine and quiet mornings with coffee."
        ),
    },
    {
        "id": "offtopic-1",
        "title": "Urban parking policy debate",
        "publisher": "City Blog",
        "kind": "blog",
        "text": "Parking fees downtown are controversial this year.",
    },
]


def _verified_corpus():
    discovered = discover_sources(_TOPIC, _CORPUS)
    texts = [s["text"] for s in discovered]
    return [
        verify_source(s, corpus=[t for j, t in enumerate(texts) if j != i])
        for i, s in enumerate(discovered)
    ]


# -- discovery -----------------------------------------------------------------

def test_discover_sources_classifies_relevant_candidates():
    found = discover_sources(_TOPIC, _CORPUS)
    ids = [s["id"] for s in found]
    assert "gov-1" in ids
    assert "news-1" in ids
    assert "offtopic-1" not in ids  # zero topic overlap is not discovered
    # deterministic ordering: most relevant first
    assert found[0]["relevance"] >= found[-1]["relevance"]


def test_discover_sources_empty_corpus_stays_empty():
    assert discover_sources(_TOPIC, []) == []
    assert discover_sources(_TOPIC, None) == []


def test_discover_sources_normalizes_unknown_kind():
    found = discover_sources(
        "solar energy", [{"id": "x", "title": "solar", "text": "solar power", "kind": "podcast"}]
    )
    assert found[0]["kind"] == "unknown"


def test_discover_sources_is_deterministic():
    a = discover_sources(_TOPIC, _CORPUS)
    b = discover_sources(_TOPIC, list(reversed(_CORPUS)))
    assert [s["id"] for s in a] == sorted([s["id"] for s in a], key=lambda i: -next(s["relevance"] for s in a if s["id"] == i))
    assert [s["id"] for s in a] != [s["id"] for s in b][:1] or len(a) == len(b)


# -- verification ----------------------------------------------------------------

def test_verify_source_authority_signals_official_beats_anonymous_blog():
    official = verify_source(_CORPUS[0])
    blog = verify_source(_CORPUS[2])
    assert official["verification"]["authority"] > blog["verification"]["authority"]
    assert official["verification"]["uncertainty"] == "low"
    assert blog["verification"]["uncertainty"] == "high"
    assert "publisher" in official["verification"]["signals"]
    assert "publisher" not in blog["verification"]["signals"]


def test_verify_source_citation_and_numeric_signals():
    verified = verify_source(_CORPUS[0])
    signals = verified["verification"]["signals"]
    assert "citations" in signals
    assert "numeric_data" in signals
    assert "date" in signals


def test_verify_source_cross_referenced_signal():
    corpus = [
        {"id": "a", "title": "Solar Rural Report", "publisher": "Ministry",
         "kind": "official", "text": "Solar adoption data from the survey."},
        {"id": "b", "title": "Follow-up on Solar Rural Report",
         "publisher": "Ministry", "kind": "official",
         "text": "The Solar Rural Report was cited by reviewers."},
    ]
    verified = [verify_source(s, corpus=[t["text"] for t in corpus if t["id"] != s["id"]]) for s in corpus]
    assert "cross_referenced" in verified[0]["verification"]["signals"]


def test_verify_source_does_not_mutate_input():
    source = dict(_CORPUS[0])
    before = set(source)
    verify_source(source)
    assert set(source) == before


# -- ranking ---------------------------------------------------------------------

def test_rank_sources_orders_by_relevance_and_authority():
    ranked = rank_sources(_verified_corpus(), _TOPIC)
    assert ranked[0]["rank"] == 1
    scores = [s["rank_score"] for s in ranked]
    assert scores == sorted(scores, reverse=True)
    assert ranked[0]["rank_score"] >= ranked[-1]["rank_score"]


def test_rank_sources_deterministic_regardless_of_input_order():
    corpus = _verified_corpus()
    a = rank_sources(corpus, _TOPIC)
    b = rank_sources(list(reversed(corpus)), _TOPIC)
    assert [s["id"] for s in a] == [s["id"] for s in b]


# -- fact extraction -------------------------------------------------------------

def test_extract_facts_with_explicit_uncertainty():
    facts = extract_facts([_CORPUS[0]], _TOPIC)
    uncertainties = {f["uncertainty"] for f in facts}
    assert facts, "claims must be extracted from the official report"
    assert "low" in uncertainties  # attributed + numeric
    for fact in facts:
        assert fact["source_id"] == "gov-1"
        assert fact["evidence"]  # evidence quote present, never fabricated
        assert len(fact["claim"].split()) <= 40


def test_extract_facts_definitional_only_is_high_uncertainty():
    facts = extract_facts(
        [{"id": "s1", "title": "t", "text": "Solar energy is a renewable source."}],
        "solar energy",
    )
    assert len(facts) == 1
    assert facts[0]["uncertainty"] == "high"


def test_extract_facts_skips_noise_and_dedupes():
    facts = extract_facts(
        [
            {"id": "s1", "title": "t", "text": "Solar adoption reached 42% in 2023. Solar adoption reached 42% in 2023."},
            {"id": "s2", "title": "t", "text": "Nice weather today, lovely sunshine."},
        ],
        "solar",
    )
    assert len(facts) == 1


def test_extract_facts_topic_overlap_promoted_first():
    facts = extract_facts(
        [
            {
                "id": "s1",
                "title": "t",
                "text": (
                    "A general statistic says energy prices moved in 2020. "
                    "Rural solar adoption reached 42% according to officials."
                ),
            }
        ],
        "solar adoption",
    )
    assert facts[0]["claim"].startswith("Rural solar adoption")


# -- topic analysis ---------------------------------------------------------------

def test_analyze_topic_facets_key_terms_coverage():
    verified = _verified_corpus()
    facts = extract_facts(verified, _TOPIC)
    analysis = analyze_topic(_TOPIC, verified, facts)
    assert "solar" in analysis["facets"]
    assert "solar" in analysis["key_terms"]
    assert analysis["coverage"] in ("single_source", "multi_source")
    if {f["source_id"] for f in facts} >= {"gov-1", "news-1"}:
        assert analysis["coverage"] == "multi_source"


def test_analyze_topic_consensus_and_conflicts():
    facts = [
        {"claim": "Solar adoption reached 42% in rural areas", "source_id": "a", "evidence": "x", "uncertainty": "low"},
        {"claim": "Solar adoption reached 42% in rural counties", "source_id": "b", "evidence": "x", "uncertainty": "medium"},
        {"claim": "Solar adoption did not reach 42% in rural areas", "source_id": "c", "evidence": "x", "uncertainty": "medium"},
    ]
    analysis = analyze_topic("solar adoption rural", [], facts)
    assert analysis["consensus"], "corroborating claims across sources must surface"
    assert analysis["conflicts"], "opposed-polarity overlapping claims must surface"


def test_analyze_topic_no_facts_is_honest_none_coverage():
    analysis = analyze_topic("solar energy", [], [])
    assert analysis["coverage"] == "none"


# -- end-to-end pipeline -----------------------------------------------------------

def test_research_topic_end_to_end_validated_report():
    report = research_topic(_TOPIC, _CORPUS)
    assert report["topic"] == _TOPIC
    assert {s["id"] for s in report["sources"]} == {"gov-1", "news-1", "blog-1"}
    assert report["facts"], "official + news sources carry extractable claims"
    assert report["analysis"]["coverage"] == "multi_source"
    assert report["confidence"]["level"] in ("medium", "high")
    assert run_research_gates(report, _TOPIC) == []


def test_research_topic_empty_corpus_discloses_unknowns():
    report = research_topic(_TOPIC, [])
    assert report["sources"] == []
    assert report["facts"] == []
    assert report["confidence"]["level"] == "low"
    assert any("sources UNKNOWN" in q for q in report["open_questions"])
    assert any("facts UNKNOWN" in q for q in report["open_questions"])


def test_research_topic_rejects_empty_topic():
    with pytest.raises(ResearchError, match="topic"):
        research_topic("   ")


# -- strict validation (mirrors decision_analysis) ----------------------------------

def _valid_report(**overrides):
    base = {
        "topic": "solar energy",
        "sources": [
            {
                "id": "s1",
                "title": "Solar Report",
                "publisher": "Ministry",
                "kind": "official",
                "text": "Solar adoption reached 42% according to the survey.",
                "verification": {
                    "authority": 0.8,
                    "signals": ["publisher", "citations"],
                    "uncertainty": "low",
                },
            }
        ],
        "facts": [
            {
                "claim": "Solar adoption reached 42% according to the survey",
                "source_id": "s1",
                "evidence": "Solar adoption reached 42% according to the survey.",
                "uncertainty": "low",
            }
        ],
        "analysis": {
            "facets": ["solar"],
            "key_terms": ["solar"],
            "coverage": "single_source",
            "consensus": [],
            "conflicts": [],
        },
        "confidence": {"level": "medium", "basis": 'topic states: "solar energy"'},
        "open_questions": [],
    }
    base.update(overrides)
    return base


def test_parse_research_report_valid_shape():
    report = parse_research_report(_valid_report())
    assert report["topic"] == "solar energy"
    assert report["sources"][0]["verification"]["authority"] == 0.8
    assert report["analysis"]["coverage"] == "single_source"


def test_enum_rejection_source_kind():
    payload = _valid_report()
    payload["sources"][0]["kind"] = "podcast"
    with pytest.raises(ResearchError, match="kind"):
        parse_research_report(payload)


def test_enum_rejection_fact_uncertainty():
    payload = _valid_report()
    payload["facts"][0]["uncertainty"] = "certain"
    with pytest.raises(ResearchError, match="uncertainty"):
        parse_research_report(payload)


def test_enum_rejection_coverage():
    payload = _valid_report()
    payload["analysis"]["coverage"] = "everywhere"
    with pytest.raises(ResearchError, match="coverage"):
        parse_research_report(payload)


def test_authority_out_of_range_rejected():
    payload = _valid_report()
    payload["sources"][0]["verification"]["authority"] = 1.5
    with pytest.raises(ResearchError, match="0..1"):
        parse_research_report(payload)


def test_missing_fields_rejected():
    payload = _valid_report()
    del payload["facts"]
    with pytest.raises(ResearchError, match="missing required field"):
        parse_research_report(payload)


def test_unknown_keys_ignored():
    payload = _valid_report()
    payload["future_field"] = {"anything": True}
    report = parse_research_report(payload)
    assert "future_field" not in report


def test_word_cap_rejected_by_parser():
    with pytest.raises(ResearchError, match="exceeds 40 words"):
        parse_research_report(_valid_report(topic="word " * 41))


# -- consistency gates ---------------------------------------------------------

def test_gate_fact_citing_unknown_source_fails():
    payload = _valid_report()
    payload["facts"][0]["source_id"] = "ghost"
    report = parse_research_report(payload)
    failures = run_research_gates(report, "solar energy")
    assert any("unknown source" in f for f in failures)


def test_gate_ungrounded_fact_fails():
    payload = _valid_report()
    payload["facts"][0]["claim"] = "banana exports dominate the region"
    report = parse_research_report(payload)
    failures = run_research_gates(report, "solar energy")
    assert any("not grounded" in f for f in failures)


def test_gate_duplicate_claim_fails():
    payload = _valid_report()
    payload["facts"].append(dict(payload["facts"][0]))
    report = parse_research_report(payload)
    failures = run_research_gates(report, "solar energy")
    assert any("duplicate claim" in f for f in failures)


def test_gate_coverage_mismatch_fails():
    payload = _valid_report()
    payload["analysis"]["coverage"] = "multi_source"
    report = parse_research_report(payload)
    failures = run_research_gates(report, "solar energy")
    assert any("disagrees" in f for f in failures)


def test_gate_ungrounded_confidence_fails():
    payload = _valid_report(confidence={"level": "medium", "basis": "it feels right"})
    report = parse_research_report(payload)
    failures = run_research_gates(report, "solar energy")
    assert any("not grounded" in f for f in failures)


# -- readiness seal ------------------------------------------------------------

def test_readiness_ready_when_verified_sources_and_facts():
    report = research_topic(_TOPIC, _CORPUS)
    result = research_readiness(report, [])
    assert result["ready"] is True
    assert result["blocking_items"] == []


def test_readiness_blocked_for_empty_research():
    report = research_topic(_TOPIC, [])
    failures = run_research_gates(report, _TOPIC)
    result = research_readiness(report, failures)
    assert result["ready"] is False
    assert any("no verified source" in b for b in result["blocking_items"])
    assert any("no extracted facts" in b for b in result["blocking_items"])
