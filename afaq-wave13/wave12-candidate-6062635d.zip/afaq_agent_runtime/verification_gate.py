from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .side_effects import SideEffectClassification


@dataclass(frozen=True)
class VerificationResult:
    verified: bool
    status: str
    reason: str


def _governed_core_value(result: Any) -> Any:
    if not isinstance(result, dict):
        return result
    evidence = result.get("evidence")
    if isinstance(evidence, dict) and "result" in evidence:
        return evidence["result"]
    return result


class VerificationGate:
    @staticmethod
    def verify(
        action: str,
        result: Any,
        *,
        expected_state: Any = None,
        observed_state: Any = None,
        side_effect: SideEffectClassification | None = None,
    ) -> VerificationResult:
        action = (action or "").lower()
        if result is None:
            return VerificationResult(False, "NOT VERIFIED", "tool returned no result")

        native_actions = {
            "web_fetch", "web_crawl", "web_explore", "remote_verify", "browser_execute",
            "model_profile", "benchmark_engines", "benchmark_suite",
            "performance_history", "performance_latest_metrics", "performance_selection_feedback",
            "performance_recommend",
            "performance_budget_check", "performance_regression",
            "performance_bottleneck", "performance_optimize",
            "mission_model", "capability_compose", "mission_graph", "result_fuse",
            "context_adapt", "capability_discover", "capability_session_status",
            "gap_resolve", "evidence_verify", "research_synthesize",
            "causal_falsify", "scenario_forecast", "continuous_observe",
            "continuous_compare", "frontier_discover", "benchmark_observe",
            "research_portfolio", "goal_form", "engine_invoke",
            "capability_invoke",
        }
        if action in native_actions:
            if not isinstance(result, dict):
                return VerificationResult(
                    False,
                    "NOT VERIFIED",
                    "native capability result must be a mapping",
                )
            if not bool(result.get("executed")):
                return VerificationResult(
                    False,
                    "FAIL",
                    "native capability did not execute",
                )
            if action == "web_explore":
                evidence = result.get("evidence")
                verification = (
                    evidence.get("verification")
                    if isinstance(evidence, dict)
                    else None
                )
                if bool(result.get("mission_verified")):
                    return VerificationResult(
                        True,
                        "PASS",
                        "explicit web exploration mission contract verified",
                    )
                if (
                    isinstance(verification, dict)
                    and verification.get("contract_provided") is True
                ):
                    return VerificationResult(
                        False,
                        "NOT VERIFIED",
                        "explicit web exploration verification contract was not satisfied",
                    )
                if side_effect is SideEffectClassification.EXTERNAL_SIDE_EFFECT:
                    return VerificationResult(
                        False,
                        "NOT VERIFIED",
                        "interactive web exploration requires independent mission verification",
                    )

            if bool(result.get("mission_verified")):
                return VerificationResult(
                    True,
                    "PASS",
                    "native capability mission verification observed",
                )
            if side_effect is SideEffectClassification.EXTERNAL_SIDE_EFFECT:
                return VerificationResult(
                    False,
                    "NOT VERIFIED",
                    "external side effect requires independent mission verification",
                )
            if side_effect is SideEffectClassification.WRITE:
                return VerificationResult(
                    False,
                    "NOT VERIFIED",
                    "write capability requires independent post-condition verification",
                )
            if result.get("claim_level") in {
                "EXECUTED_WITH_EVIDENCE",
                "MISSION_VERIFIED",
            }:
                return VerificationResult(
                    True,
                    "PASS",
                    "read-only native capability execution evidence observed",
                )
            if isinstance(result.get("evidence"), dict) and result.get("evidence"):
                return VerificationResult(
                    True,
                    "PASS",
                    "read-only native capability evidence observed",
                )
            return VerificationResult(
                False,
                "NOT VERIFIED",
                "native capability executed without sufficient verification evidence",
            )

        if action == "run":
            run_result = _governed_core_value(result)
            if not isinstance(run_result, dict) or "passed" not in run_result:
                return VerificationResult(
                    False,
                    "NOT VERIFIED",
                    "run result missing passed flag",
                )

            if not run_result["passed"]:
                return VerificationResult(
                    False,
                    "FAIL",
                    "command returned non-zero exit code",
                )

            if side_effect is SideEffectClassification.READ_ONLY:
                return VerificationResult(
                    True,
                    "PASS",
                    "read-only command return code checked",
                )

            if side_effect is SideEffectClassification.WRITE:
                return VerificationResult(
                    False,
                    "NOT VERIFIED",
                    "write-classified command requires post-condition verification",
                )

            return VerificationResult(
                False,
                "NOT VERIFIED",
                "run side-effect classification is not verifiable",
            )

        if action == "edit":
            edit_result = _governed_core_value(result)
            diff_ok = (
                isinstance(edit_result, str)
                and edit_result.strip().startswith("---")
                and "+++" in edit_result
            )
            if not diff_ok:
                return VerificationResult(False, "NOT VERIFIED", "edit result does not prove a diff")
            if expected_state is None or observed_state is None:
                return VerificationResult(False, "NOT VERIFIED", "edit requires independent post-write read-back")
            if observed_state != expected_state:
                return VerificationResult(False, "NOT VERIFIED", "post-write state does not match expected content")
            return VerificationResult(True, "PASS", "edit diff observed and exact post-write state verified")

        if action in {"files", "read", "search", "status", "diff", "map"}:
            return VerificationResult(True, "PASS", "read-only tool result observed")

        return VerificationResult(False, "NOT VERIFIED", "no verification rule for action")
