"""Governed host-execution isolation boundary.

Callers (runtime_server, developer_agent, workspace, governed_core)
must reach subprocess execution through this module after allowlist
and current authority/policy checks.

ALLOWLIST != SANDBOX
SANDBOX_PASS != CERTIFIED
Trust class is derived from an internal route map, never from caller input.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import tempfile
import time
import uuid
from pathlib import Path
from typing import Any

from capability_cycle.telemetry import redact

ROUTE_TRUST: dict[str, str] = {
    "allowlist.run_allowed": "UNTRUSTED",
}

SANDBOX_REQUIRED = frozenset({"UNTRUSTED", "GENERATED", "EXTERNAL_PROVIDER"})

_ENV_ALLOW = frozenset({
    "PATH",
    "PATHEXT",
    "SYSTEMROOT",
    "SYSTEMDRIVE",
    "WINDIR",
    "COMSPEC",
    "TEMP",
    "TMP",
    "TMPDIR",
    "LANG",
    "LC_ALL",
    "PYTHONIOENCODING",
    "PYTHONUTF8",
    "NUMBER_OF_PROCESSORS",
    "PROCESSOR_ARCHITECTURE",
    "HOME",
    "USERPROFILE",
    "HOMEDRIVE",
    "HOMEPATH",
})
_SECRET_KEY = re.compile(
    r"(password|secret|token|api[_-]?key|authorization|credential|private[_-]?key)",
    re.IGNORECASE,
)

_TELEMETRY: list[dict[str, Any]] = []


class HostSandboxError(RuntimeError):
    pass


def trust_class_for_route(route_id: str) -> str:
    if route_id not in ROUTE_TRUST:
        raise HostSandboxError("unknown execution route fails closed")
    return ROUTE_TRUST[route_id]


def filtered_environ(source: dict[str, str] | None = None) -> dict[str, str]:
    src = source if source is not None else os.environ
    env: dict[str, str] = {}
    for key in _ENV_ALLOW:
        value = src.get(key)
        if value is None or _SECRET_KEY.search(key):
            continue
        env[key] = value
    env["PYTHONIOENCODING"] = "utf-8"
    if "PATH" not in env:
        raise HostSandboxError("sandbox setup failed: PATH missing")
    return env


def telemetry_records() -> tuple[dict[str, Any], ...]:
    return tuple(_TELEMETRY)


def _emit(record: dict[str, Any], *, required: bool = False) -> None:
    try:
        _TELEMETRY.append(redact(record))
    except Exception as exc:
        if required:
            raise HostSandboxError("required sandbox telemetry could not be recorded") from exc
        raise


def run_isolated(
    argv: list[str],
    *,
    cwd: str,
    timeout: int,
    route_id: str,
    requested_trust_class: str | None = None,
    historical_records: Any = None,
) -> dict[str, Any]:
    del historical_records
    started = time.time()
    correlation_id = uuid.uuid4().hex
    trust = trust_class_for_route(route_id)
    if requested_trust_class is not None and requested_trust_class != trust:
        raise HostSandboxError("untrusted trust-class override denied")
    if trust in SANDBOX_REQUIRED or trust == "UNTRUSTED":
        policy = "SANDBOX_REQUIRED"
    elif trust == "TRUSTED_INTERNAL":
        policy = "SANDBOX_OPTIONAL"
    else:
        raise HostSandboxError("unknown trust class fails closed")

    root = Path(cwd)
    if not root.is_dir():
        raise HostSandboxError("sandbox setup failed: cwd missing")

    pycache = None
    try:
        env = filtered_environ()
        pycache = tempfile.mkdtemp(prefix="aic-pycache-")
        env["PYTHONPYCACHEPREFIX"] = pycache
    except HostSandboxError:
        raise
    except OSError as exc:
        raise HostSandboxError("sandbox setup failed") from exc

    result: dict[str, Any] = {}
    try:
        completed = subprocess.run(
            argv,
            cwd=str(root),
            capture_output=True,
            text=True,
            timeout=max(1, int(timeout)),
            encoding="utf-8",
            errors="replace",
            shell=False,
            env=env,
        )
        result = {
            "command": argv,
            "returncode": completed.returncode,
            "stdout": (completed.stdout or "")[-4000:],
            "stderr": (completed.stderr or "")[-4000:],
            "passed": completed.returncode == 0,
            "sandbox": {
                "route_id": route_id,
                "trust_class": trust,
                "policy": policy,
                "correlation_id": correlation_id,
                "outcome": "COMPLETED",
                "timeout_s": timeout,
                "pycache": pycache,
            },
        }
    except subprocess.TimeoutExpired:
        result = {
            "command": argv,
            "returncode": -1,
            "stdout": "",
            "stderr": "timeout",
            "passed": False,
            "sandbox": {
                "route_id": route_id,
                "trust_class": trust,
                "policy": policy,
                "correlation_id": correlation_id,
                "outcome": "TIMEOUT",
                "timeout_s": timeout,
                "pycache": pycache,
            },
        }
    finally:
        cleanup = "ok"
        if pycache:
            try:
                shutil.rmtree(pycache, ignore_errors=False)
            except OSError:
                cleanup = "failed"
                shutil.rmtree(pycache, ignore_errors=True)
        if result.get("sandbox") is not None:
            result["sandbox"]["cleanup"] = cleanup
        _emit(
            {
                "correlation_id": correlation_id,
                "route_id": route_id,
                "execution_identity": argv[:2],
                "trust_class": trust,
                "sandbox_policy": policy,
                "started_at": started,
                "ended_at": time.time(),
                "timeout": timeout,
                "cleanup": cleanup,
            },
            required=True,
        )
    return result
