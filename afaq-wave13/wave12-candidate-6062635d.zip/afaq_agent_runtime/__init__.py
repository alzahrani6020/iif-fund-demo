"""AFAQ Agent Runtime.

The deterministic governed core is importable without optional legacy AIC
packages. Legacy runtime symbols are loaded lazily only when requested.
"""

__version__ = "1.2.0"

from .governed_core import GovernedAgentError, GovernedProjectAgent
from .orchestrator import AfaqOrchestrator, OrchestrationError
from .repository_mapper import map_repository

__all__ = [
    "AfaqAI",
    "AfaqAIResult",
    "AfaqAIEngineSummary",
    "AfaqAIGenerationResult",
    "AfaqNativePlanner",
    "AfaqAIAPI",
    "AfaqAIAPIResponse",
    "AfaqAIAPIKey",
    "AfaqAIAPIKeySecret",
    "AfaqAIAPIKeyStore",
    "AFAQ_AI_API_PREFIX",
    "AfaqOrchestrator",
    "GovernedAgentError",
    "GovernedProjectAgent",
    "OrchestrationError",
    "map_repository",
    # legacy symbols below remain available lazily when their dependencies exist
    "AgentRuntime",
    "ModelUnavailableError",
    "RuntimeRouter",
    "EventLog",
    "ModelRouter",
    "TaskStore",
    "TERMINAL_STATES",
]


def __getattr__(name: str):
    if name in {
        "AfaqAI", "AfaqAIResult", "AfaqAIEngineSummary", "AfaqAIGenerationResult", "AfaqNativePlanner",
        "AfaqAIAPI", "AfaqAIAPIResponse", "AfaqAIAPIKey",
        "AfaqAIAPIKeySecret", "AfaqAIAPIKeyStore", "AFAQ_AI_API_PREFIX",
    }:
        from .afaq_ai import (
            AFAQ_AI_API_PREFIX,
            AfaqAI,
            AfaqAIAPI,
            AfaqAIAPIKey,
            AfaqAIAPIKeySecret,
            AfaqAIAPIKeyStore,
            AfaqAIAPIResponse,
            AfaqAIEngineSummary,
            AfaqAIGenerationResult,
            AfaqAIResult,
            AfaqNativePlanner,
        )
        return {
            "AfaqAI": AfaqAI,
            "AfaqAIResult": AfaqAIResult,
            "AfaqAIEngineSummary": AfaqAIEngineSummary,
            "AfaqAIGenerationResult": AfaqAIGenerationResult,
            "AfaqNativePlanner": AfaqNativePlanner,
            "AfaqAIAPI": AfaqAIAPI,
            "AfaqAIAPIResponse": AfaqAIAPIResponse,
            "AfaqAIAPIKey": AfaqAIAPIKey,
            "AfaqAIAPIKeySecret": AfaqAIAPIKeySecret,
            "AfaqAIAPIKeyStore": AfaqAIAPIKeyStore,
            "AFAQ_AI_API_PREFIX": AFAQ_AI_API_PREFIX,
        }[name]
    if name in {"AgentRuntime", "ModelUnavailableError", "RuntimeRouter"}:
        from .agent_runtime import AgentRuntime, ModelUnavailableError, RuntimeRouter
        return {"AgentRuntime": AgentRuntime, "ModelUnavailableError": ModelUnavailableError, "RuntimeRouter": RuntimeRouter}[name]
    if name == "EventLog":
        from .event_log import EventLog
        return EventLog
    if name == "ModelRouter":
        from .model_router import ModelRouter
        return ModelRouter
    if name in {"TaskStore", "TERMINAL_STATES"}:
        from .task_store import TaskStore, TERMINAL_STATES
        return {"TaskStore": TaskStore, "TERMINAL_STATES": TERMINAL_STATES}[name]
    raise AttributeError(name)
