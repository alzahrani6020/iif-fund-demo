from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from .orchestrator import AfaqOrchestrator, supported_orchestrator_actions
from .capability_planner import (
    CapabilityPlanner,
    capability_catalog,
    supported_plannable_actions,
)
from .side_effects import SideEffectClassification, classify_action


@dataclass(frozen=True)
class HttpResult:
    status_code: int
    payload: dict[str, Any]


class OrchestratorHttpAdapter:
    """Thin HTTP contract adapter for the governed orchestrator.

    Owns request-shape validation and stable HTTP status mapping only.
    Execution, evidence, verification, side-effect classification and
    governance remain owned by AfaqOrchestrator and its collaborators.
    """

    _STATUS_CODES = {
        "COMPLETE": 200,
        "DENIED": 403,
        "SHADOW_BLOCKED": 403,
        "NOT_VERIFIED": 409,
        "FAILED": 500,
    }

    def __init__(
        self,
        orchestrator: AfaqOrchestrator | None,
        *,
        capability_planner: CapabilityPlanner | None = None,
    ):
        self.orchestrator = orchestrator
        self.capability_planner = capability_planner

    def describe(self) -> dict[str, Any]:
        return {
            "configured": self.orchestrator is not None,
            "enabled": AfaqOrchestrator.enabled(),
            "shadow": AfaqOrchestrator.shadow(),
            "orchestrator_actions": list(supported_orchestrator_actions()),
            "goal_plannable_actions": list(supported_plannable_actions()),
            "capability_catalog": list(capability_catalog()),
            "http_execution_policy": "READ_ONLY",
            "goal_execution_mode": "GOVERNED_JOB",
        }

    def plan_goal(self, body: Mapping[str, Any]) -> HttpResult:
        if self.capability_planner is None:
            return HttpResult(
                503,
                {
                    "success": False,
                    "error": {
                        "code": "CAPABILITY_PLANNER_NOT_CONFIGURED",
                        "message": "capability planner is not configured",
                    },
                },
            )
        request = body.get("request")
        context = body.get("context")
        if not isinstance(request, str) or not request.strip():
            return self._bad_request("REQUEST_REQUIRED", "request is required")
        if context is not None and not isinstance(context, Mapping):
            return self._bad_request("INVALID_CONTEXT", "context must be a JSON object")
        try:
            plan = self.capability_planner.plan(
                request.strip(),
                context=dict(context or {}),
            )
        except ValueError as exc:
            return HttpResult(
                422,
                {
                    "success": False,
                    "error": {
                        "code": "CAPABILITY_PLAN_INVALID",
                        "message": str(exc),
                    },
                },
            )
        except Exception:
            return HttpResult(
                503,
                {
                    "success": False,
                    "error": {
                        "code": "CAPABILITY_PLANNER_UNAVAILABLE",
                        "message": "capability planning is temporarily unavailable",
                    },
                },
            )
        return HttpResult(
            200,
            {
                "success": True,
                "plan": plan.as_dict(),
            },
        )

    def execute(self, body: Mapping[str, Any]) -> HttpResult:
        if self.orchestrator is None:
            return HttpResult(
                503,
                {
                    "success": False,
                    "error": {
                        "code": "ORCHESTRATOR_NOT_CONFIGURED",
                        "message": "orchestrator root is not configured",
                    },
                },
            )

        action = body.get("action")
        args = body.get("args", {})
        request_id = body.get("request_id")

        if not isinstance(action, str) or not action.strip():
            return self._bad_request("ACTION_REQUIRED", "action is required")
        if not isinstance(args, Mapping):
            return self._bad_request("INVALID_ARGS", "args must be a JSON object")
        if request_id is not None and not isinstance(request_id, str):
            return self._bad_request(
                "INVALID_REQUEST_ID",
                "request_id must be a string",
            )

        normalized_action = action.strip()
        if normalized_action not in supported_orchestrator_actions():
            return HttpResult(
                403,
                {
                    "success": False,
                    "error": {
                        "code": "UNKNOWN_ACTION",
                        "message": "action is not supported",
                    },
                },
            )

        side_effect = classify_action(normalized_action, dict(args))
        if side_effect is not SideEffectClassification.READ_ONLY:
            return HttpResult(
                403,
                {
                    "success": False,
                    "error": {
                        "code": "HTTP_SIDE_EFFECT_REQUIRES_GOVERNED_EXECUTION",
                        "message": (
                            "this capability is available, but direct synchronous "
                            "HTTP execution is not the correct authority path"
                        ),
                        "side_effect": side_effect.value,
                        "capability_available": True,
                        "recommended_execution_mode": "GOVERNED_JOB",
                        "policy_resolution": (
                            "the governed job runtime decides autonomous execution, "
                            "approval, denial, and verification requirements"
                        ),
                    },
                },
            )

        result = self.orchestrator.execute(
            normalized_action,
            dict(args),
            request_id=request_id,
        )
        orchestration_status = str(result.get("status") or "FAILED")
        status_code = self._STATUS_CODES.get(orchestration_status, 500)
        success = orchestration_status == "COMPLETE"

        public_result = self._sanitize_public_result(result)
        if orchestration_status == "FAILED":
            # Preserve correlation/evidence metadata but do not leak internal
            # exception text through the runtime HTTP boundary.
            public_result.pop("error", None)

        payload: dict[str, Any] = {
            "success": success,
            "orchestration": public_result,
        }
        if orchestration_status == "FAILED":
            payload["error"] = {
                "code": "ORCHESTRATION_FAILED",
                "message": "orchestration failed",
            }

        return HttpResult(status_code, payload)

    @classmethod
    def sanitize_public(cls, value: Any) -> Any:
        """Return a recursively redacted value safe for the HTTP boundary."""
        return cls._sanitize_public_result(value)

    @classmethod
    def summarize_job(cls, job: Mapping[str, Any]) -> dict[str, Any]:
        """Bounded job metadata for list views; excludes context, plan and result."""
        fields = (
            "job_id",
            "request_id",
            "request",
            "state",
            "approval_state",
            "verification_state",
            "error_code",
            "created_at",
            "updated_at",
            "started_at",
            "finished_at",
        )
        return cls.sanitize_public({
            name: job.get(name)
            for name in fields
        })

    @classmethod
    def _sanitize_public_result(cls, value: Any) -> Any:
        """Redact internal diagnostics and common secret-bearing fields."""
        sensitive = {
            "error", "exception", "traceback", "stack", "stacktrace",
            "password", "secret", "client_secret", "api_key",
            "access_token", "refresh_token", "authorization",
            "cookie", "set-cookie",
        }
        if isinstance(value, Mapping):
            return {
                str(key): (
                    "[redacted]"
                    if str(key).lower() in sensitive
                    else cls._sanitize_public_result(child)
                )
                for key, child in value.items()
            }
        if isinstance(value, list):
            return [cls._sanitize_public_result(item) for item in value]
        if isinstance(value, tuple):
            return [cls._sanitize_public_result(item) for item in value]
        return value

    @staticmethod
    def _bad_request(code: str, message: str) -> HttpResult:
        return HttpResult(
            400,
            {
                "success": False,
                "error": {
                    "code": code,
                    "message": message,
                },
            },
        )
