"""Storyboard & Previs engine — deterministic, offline, advisory.

Turns a scene plan (from writing_engine.plan_scenes, ENG-WR-019 output) into a
bounded, validated storyboard & previs package: a deterministic shot list with
composition decisions (framing, camera angle, camera movement), continuity
checking across shots (character / prop / set consistency on caller-declared
fields), and an animatic-style sequencing summary (shot order, durations,
transitions — structural only, no media generation). Pure stdlib — no model
calls, no network, no state ownership. This is an ENGINE, not a store: it
designs, checks, and reports; persistence and authority live elsewhere.

Pipeline (each step is independently callable and validated):
  design_shot -> generate_shot_list -> check_continuity -> build_animatic
  compose_storyboard runs the chain end-to-end.
  run_storyboard_gates / storyboard_readiness seal the storyboard.

Reuse (engine registry, dedup audit):
  - ENG-WR-019 (writing_engine) is TEXT-side: it plans briefs, beats, and
    scene/sequence structure. This module CONSUMES that scene plan (validated
    through writing_engine.parse_scene_plan — the parser is reused, never
    reimplemented) and derives shot-level design from it. It never re-plans
    beats, never re-partitions sequences, and never scores prose.
  - ENG-UND-017 (instruction-side) and ENG-RES-018 (evidence-side) are
    upstream of ENG-WR-019; this engine touches neither.
  - ENG-DEC-002 (decision_analysis) is CHANGE-side (analysis of a proposed
    change to code). Storyboard continuity checking here is SHOT-side
    (consistency of declared shot metadata across a shot list). No field,
    gate, or checker overlaps.
  - No protected canonical component is imported: the engine is composable
    but advisory-only, so it can never pull authority into an advisory path.

ABSENT stays ABSENT: scene plans carry no characters or props, so generated
shots declare none — continuity checking then verifies only what is declared
(set consistency) and reports characters/props as UNKNOWN in open_questions,
never fabricated. All composition choices come from bounded, inspectable
rules over the plan text and shot position; nothing is "creative". This
engine designs structure only — it never generates media.
"""

from __future__ import annotations

from typing import Any, Iterable, Mapping

from .writing_engine import parse_scene_plan

# ---------------------------------------------------------------------------
# Bounded vocabulary and budgets (mirrors decision_analysis discipline).

_FRAMINGS = ("extreme_close_up", "close_up", "medium", "wide", "establishing")
_ANGLES = ("eye_level", "low", "high", "overhead", "dutch")
_MOVEMENTS = ("static", "pan", "tilt", "track", "dolly", "zoom", "handheld")
_TRANSITIONS = ("cut", "dissolve", "fade", "wipe")
_ISSUE_KINDS = ("character_intro", "prop_continuity", "set_continuity")
_SEVERITIES = ("error", "warning")
_CONFIDENCE_LEVELS = ("low", "medium", "high")

_MAX_FIELD_WORDS = 40
_MAX_SHOTS = 40
_MAX_NAMES = 6
_MAX_ISSUES = 10
_MAX_OPEN_QUESTIONS = 5
_MIN_DURATION = 2
_MAX_DURATION = 15

# Duration baseline per framing (seconds); bounded by _MIN/_MAX_DURATION.
_DURATION_BY_FRAMING = {
    "establishing": 8,
    "wide": 6,
    "medium": 4,
    "close_up": 3,
    "extreme_close_up": 2,
}

# Wording that tilts the camera angle / framing by bounded deterministic rule.
_MENACE_WORDS = ("obstacle", "threat", "conflict", "confront", "menace",
                 "danger", "chase", "argument", "对抗", "خطر")
_OVERVIEW_WORDS = ("overview", "reveal", "establish", "survey", "introduce",
                   "نظرة")
_DECISIVE_WORDS = ("climax", "decisive", "reveal", "決定的", "ذروة")


class StoryboardError(ValueError):
    """Bounded, user-facing storyboard parse/quality failure."""


def _words(text: str) -> int:
    return len(text.split())


def _short(text: str, where: str) -> str:
    value = text.strip()
    if not value:
        raise StoryboardError(f"storyboard.{where} must be a non-empty string")
    if _words(value) > _MAX_FIELD_WORDS:
        raise StoryboardError(
            f"storyboard.{where} exceeds {_MAX_FIELD_WORDS} words"
        )
    return value


def _bounded(text: str) -> str:
    """Bound free text to the word cap (used for composed, not validated, text)."""
    return " ".join((text or "").split()[:_MAX_FIELD_WORDS])


def _name_list(value: Any, where: str) -> list[str]:
    if not isinstance(value, list):
        raise StoryboardError(f"storyboard.{where} must be a list")
    if len(value) > _MAX_NAMES:
        raise StoryboardError(f"storyboard.{where} exceeds {_MAX_NAMES} entries")
    out: list[str] = []
    seen: set[str] = set()
    for item in value:
        name = _short(str(item), where)
        key = name.lower()
        if key not in seen:
            seen.add(key)
            out.append(name)
    return out


def _int_in(value: Any, where: str, low: int, high: int) -> int:
    try:
        number = int(value)
    except (TypeError, ValueError):
        raise StoryboardError(f"storyboard.{where} must be an integer") from None
    if not low <= number <= high:
        raise StoryboardError(
            f"storyboard.{where} must be within {low}..{high}"
        )
    return number


def _enum(value: Any, where: str, choices: tuple[str, ...]) -> str:
    name = str(value).strip()
    if name not in choices:
        raise StoryboardError(
            f"storyboard.{where} must be one of {choices}"
        )
    return name


# ---------------------------------------------------------------------------
# Strict parse / validate (mirrors decision_analysis parse discipline).
# Unknown keys are ignored (forward-tolerant); required keys and enums are
# enforced; every free-text field is capped at _MAX_FIELD_WORDS words.


def _parse_shot(value: Any, index: int) -> dict[str, Any]:
    where = f"shots[{index}]"
    if not isinstance(value, Mapping):
        raise StoryboardError(f"storyboard.{where} must be an object")
    shot: dict[str, Any] = {
        "shot_id": _short(str(value.get("shot_id", "")), f"{where}.shot_id"),
        "order": _int_in(value.get("order"), f"{where}.order", 1, _MAX_SHOTS),
        "sequence_order": _int_in(
            value.get("sequence_order"), f"{where}.sequence_order", 1, 999
        ),
        "purpose": _short(str(value.get("purpose", "")), f"{where}.purpose"),
        "framing": _enum(value.get("framing"), f"{where}.framing", _FRAMINGS),
        "angle": _enum(value.get("angle"), f"{where}.angle", _ANGLES),
        "movement": _enum(
            value.get("movement"), f"{where}.movement", _MOVEMENTS
        ),
        "duration_seconds": _int_in(
            value.get("duration_seconds"),
            f"{where}.duration_seconds",
            _MIN_DURATION,
            _MAX_DURATION,
        ),
    }
    for optional in ("setting", "transition_in"):
        if value.get(optional) is not None:
            shot[optional] = _short(str(value[optional]), f"{where}.{optional}")
    for optional in ("characters", "props"):
        if value.get(optional) is not None:
            shot[optional] = _name_list(value[optional], f"{where}.{optional}")
    return shot


def _parse_issue(value: Any, index: int) -> dict[str, Any]:
    where = f"continuity[{index}]"
    if not isinstance(value, Mapping):
        raise StoryboardError(f"storyboard.{where} must be an object")
    return {
        "kind": _enum(value.get("kind"), f"{where}.kind", _ISSUE_KINDS),
        "severity": _enum(value.get("severity"), f"{where}.severity", _SEVERITIES),
        "shot_id": _short(str(value.get("shot_id", "")), f"{where}.shot_id"),
        "detail": _short(str(value.get("detail", "")), f"{where}.detail"),
    }


def _parse_confidence(value: Any) -> dict[str, str]:
    if not isinstance(value, Mapping):
        raise StoryboardError("storyboard.confidence must be an object")
    level = _enum(value.get("level"), "confidence.level", _CONFIDENCE_LEVELS)
    return {
        "level": level,
        "basis": _short(str(value.get("basis", "")), "confidence.basis"),
    }


def parse_shot_list(payload: Any) -> dict[str, Any]:
    """Validate and normalize a full storyboard object.

    Raises StoryboardError with a specific reason. Unknown keys are ignored;
    required keys and enums are enforced; free-text fields are word-capped.
    Cross-field consistency (shot <-> plan linkage, animatic coverage,
    continuity errors) is the GATE's job, not the parser's.
    """
    if not isinstance(payload, Mapping):
        raise StoryboardError("storyboard must be a JSON object")
    required = ("shots", "animatic", "continuity", "confidence", "open_questions")
    missing = [k for k in required if k not in payload]
    if missing:
        raise StoryboardError(
            f"storyboard missing required field(s): {missing}"
        )

    shots = payload.get("shots")
    if not isinstance(shots, list):
        raise StoryboardError("storyboard.shots must be a list")
    if not shots:
        raise StoryboardError("storyboard.shots must not be empty")
    if len(shots) > _MAX_SHOTS:
        raise StoryboardError(f"storyboard.shots exceeds {_MAX_SHOTS} entries")
    parsed_shots = [_parse_shot(s, i) for i, s in enumerate(shots)]

    animatic = parse_animatic(payload.get("animatic"))

    continuity = payload.get("continuity")
    if not isinstance(continuity, list):
        raise StoryboardError("storyboard.continuity must be a list")
    if len(continuity) > _MAX_ISSUES:
        raise StoryboardError(
            f"storyboard.continuity exceeds {_MAX_ISSUES} entries"
        )

    open_questions = payload.get("open_questions")
    if not isinstance(open_questions, list):
        raise StoryboardError("storyboard.open_questions must be a list")
    if len(open_questions) > _MAX_OPEN_QUESTIONS:
        raise StoryboardError(
            f"storyboard.open_questions exceeds {_MAX_OPEN_QUESTIONS} entries"
        )

    return {
        "shots": parsed_shots,
        "animatic": animatic,
        "continuity": [_parse_issue(c, i) for i, c in enumerate(continuity)],
        "confidence": _parse_confidence(payload.get("confidence")),
        "open_questions": [_short(str(q), "open_questions") for q in open_questions],
    }


def parse_animatic(payload: Any) -> dict[str, Any]:
    """Validate and normalize an animatic sequencing summary."""
    if not isinstance(payload, Mapping):
        raise StoryboardError("storyboard.animatic must be a JSON object")
    required = ("shots", "total_duration_seconds")
    missing = [k for k in required if k not in payload]
    if missing:
        raise StoryboardError(
            f"storyboard.animatic missing required field(s): {missing}"
        )
    entries = payload.get("shots")
    if not isinstance(entries, list):
        raise StoryboardError("storyboard.animatic.shots must be a list")
    if not entries:
        raise StoryboardError("storyboard.animatic.shots must not be empty")
    parsed_entries: list[dict[str, Any]] = []
    for index, entry in enumerate(entries):
        where = f"animatic.shots[{index}]"
        if not isinstance(entry, Mapping):
            raise StoryboardError(f"storyboard.{where} must be an object")
        start = _int_in(entry.get("start_seconds"), f"{where}.start_seconds", 0, 100000)
        duration = _int_in(
            entry.get("duration_seconds"), f"{where}.duration_seconds",
            _MIN_DURATION, _MAX_DURATION,
        )
        end = _int_in(entry.get("end_seconds"), f"{where}.end_seconds", 0, 100000)
        parsed_entries.append({
            "shot_id": _short(str(entry.get("shot_id", "")), f"{where}.shot_id"),
            "order": _int_in(entry.get("order"), f"{where}.order", 1, _MAX_SHOTS),
            "transition_in": _enum(
                entry.get("transition_in"), f"{where}.transition_in", _TRANSITIONS
            ),
            "start_seconds": start,
            "duration_seconds": duration,
            "end_seconds": end,
        })
    total = _int_in(
        payload.get("total_duration_seconds"),
        "animatic.total_duration_seconds", 1, 100000,
    )
    return {"shots": parsed_entries, "total_duration_seconds": total}


# ---------------------------------------------------------------------------
# 1. Shot composition rules: bounded, deterministic, inspectable. Every choice
#    is a function of shot position and plan wording — nothing is "creative".

def design_shot(
    *,
    shot_index: int,
    shot_count_in_sequence: int,
    sequence_index: int,
    sequence_count: int,
    purpose: str,
    setting: str = "",
) -> dict[str, Any]:
    """Decide framing / angle / movement / duration for one shot.

    Rules (first decisive match wins, all inspectable):
      framing   — first shot of the first sequence -> establishing;
                  purpose carries decisive/climax wording -> close_up;
                  a single-beat sequence -> medium; the first shot of any
                  other sequence -> wide; the final shot of the final
                  sequence -> wide; otherwise -> medium
      angle     — establishing framing or overview wording -> high;
                  menace/obstacle wording -> low; otherwise -> eye_level
      movement  — establishing or close framing -> static; the last shot of
                  a sequence -> dolly (a closing push-in that also overrides
                  the wide pan); wide -> pan; otherwise -> static
      duration  — baseline per framing, clamped to 2..15 seconds
    """
    purpose_l = (purpose or "").lower()
    decisive = any(w in purpose_l for w in _DECISIVE_WORDS)

    if sequence_index == 0 and shot_index == 0:
        framing = "establishing"
    elif decisive:
        framing = "close_up"
    elif shot_count_in_sequence == 1:
        framing = "medium"
    elif shot_index == 0:
        framing = "wide"
    elif sequence_index == sequence_count - 1 and shot_index == shot_count_in_sequence - 1:
        framing = "wide"
    else:
        framing = "medium"

    if framing == "establishing" or any(w in purpose_l for w in _OVERVIEW_WORDS):
        angle = "high"
    elif any(w in purpose_l for w in _MENACE_WORDS):
        angle = "low"
    else:
        angle = "eye_level"

    if framing in ("establishing", "close_up", "extreme_close_up"):
        movement = "static"
    elif shot_index == shot_count_in_sequence - 1:
        movement = "dolly"  # closing push-in overrides the wide pan
    elif framing == "wide":
        movement = "pan"
    else:
        movement = "static"

    duration = _DURATION_BY_FRAMING[framing]
    duration = max(_MIN_DURATION, min(_MAX_DURATION, duration))

    shot: dict[str, Any] = {
        "framing": framing,
        "angle": angle,
        "movement": movement,
        "duration_seconds": duration,
    }
    if setting:
        shot["setting"] = _bounded(setting)
    return shot


# ---------------------------------------------------------------------------
# 2. Shot list generation: one shot per beat covered, derived from a validated
#    ENG-WR-019 scene plan. Never re-plans beats or sequences.

def generate_shot_list(scene_plan: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Derive a deterministic, validated shot list from a scene plan.

    The plan is validated through writing_engine.parse_scene_plan (reused,
    not reimplemented). Each covered beat becomes exactly one shot, in plan
    order; shot composition comes from design_shot; the sequence's setting is
    carried verbatim. Scene plans carry no characters or props, so generated
    shots declare none — ABSENT stays ABSENT.
    """
    if not isinstance(scene_plan, Mapping):
        raise StoryboardError(
            "storyboard.generate_shot_list expects a scene plan object"
        )
    try:
        plan = parse_scene_plan(scene_plan)
    except ValueError as exc:
        raise StoryboardError(f"storyboard scene plan invalid: {exc}") from exc
    sequences = sorted(plan["sequences"], key=lambda s: s["order"])
    total_beats = sum(len(s["beats_covered"]) for s in sequences)
    if total_beats > _MAX_SHOTS:
        raise StoryboardError(
            f"storyboard needs {total_beats} shots, exceeds {_MAX_SHOTS} shots budget"
        )

    shots: list[dict[str, Any]] = []
    order = 0
    sequence_count = len(sequences)
    for sequence_index, sequence in enumerate(sequences):
        beats = sequence["beats_covered"]
        shot_count = len(beats)
        for shot_index, beat in enumerate(beats):
            order += 1
            purpose = _bounded(
                f"cover beat {beat} of sequence {sequence['order']}: "
                f"{sequence['purpose']}"
            )
            decision = design_shot(
                shot_index=shot_index,
                shot_count_in_sequence=shot_count,
                sequence_index=sequence_index,
                sequence_count=sequence_count,
                purpose=purpose,
                setting=sequence["setting"],
            )
            shots.append({
                "shot_id": f"S{order}",
                "order": order,
                "sequence_order": sequence["order"],
                "purpose": purpose,
                **decision,
            })
    return [_parse_shot(s, i) for i, s in enumerate(shots)]


# ---------------------------------------------------------------------------
# 3. Continuity checking across shots (character / prop / set consistency).
#    Only declared fields are checked; undeclared metadata is skipped, never
#    assumed. Issues are advisory findings with explicit reasons.

def check_continuity(shots: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
    """Check cross-shot consistency on caller-declared metadata.

    Rules (each inspectable; nothing here invents characters, props, or sets):
      set_continuity    — inside one sequence, a declared setting change away
                          from the sequence's first declared setting is an
                          error (locations do not teleport mid-sequence)
      prop_continuity   — between consecutive shots in the same sequence with
                          the same setting and the same declared participants,
                          a prop present in the earlier shot but absent in the
                          later one is an error (props do not vanish)
      character_intro   — a character whose first appearance is not in an
                          establishing or wide shot is a warning (no
                          establishing coverage before introduction)
    Fields that are not declared are not checked: a shot without a props list
    makes no prop claims, so it can contradict nothing.
    """
    parsed = [_parse_shot(s, i) for i, s in enumerate(shots or [])]
    issues: list[dict[str, Any]] = []

    # -- set continuity within a sequence
    by_sequence: dict[int, list[dict[str, Any]]] = {}
    for shot in parsed:
        by_sequence.setdefault(shot["sequence_order"], []).append(shot)
    for sequence_order, group in by_sequence.items():
        declared = [s for s in group if s.get("setting")]
        if len(declared) < 2:
            continue
        base_setting = declared[0]["setting"]
        for shot in declared[1:]:
            if shot["setting"] != base_setting:
                issues.append({
                    "kind": "set_continuity",
                    "severity": "error",
                    "shot_id": shot["shot_id"],
                    "detail": _bounded(
                        f"sequence {sequence_order}: setting changes from "
                        f"'{base_setting}' to '{shot['setting']}' mid-sequence"
                    ),
                })
                break  # one finding per sequence is enough

    # -- prop continuity between consecutive shots in the same setting
    for earlier, later in zip(parsed, parsed[1:]):
        if earlier["sequence_order"] != later["sequence_order"]:
            continue
        if earlier.get("setting") and later.get("setting") \
                and earlier["setting"] != later["setting"]:
            continue
        participants_same = (
            "characters" in earlier
            and "characters" in later
            and {c.lower() for c in earlier["characters"]}
                == {c.lower() for c in later["characters"]}
        )
        if not participants_same:
            continue
        earlier_props = {p.lower() for p in earlier.get("props", [])}
        later_props = {p.lower() for p in later.get("props", [])}
        for vanished in sorted(earlier_props - later_props):
            issues.append({
                "kind": "prop_continuity",
                "severity": "error",
                "shot_id": later["shot_id"],
                "detail": _bounded(
                    f"prop '{vanished}' present in {earlier['shot_id']} but "
                    f"missing in {later['shot_id']} with the same setting "
                    f"and participants"
                ),
            })

    # -- character introduction coverage
    seen_characters: set[str] = set()
    for shot in parsed:
        for name in shot.get("characters", []):
            key = name.lower()
            if key not in seen_characters:
                seen_characters.add(key)
                if shot["order"] > 1 and shot["framing"] not in ("establishing", "wide"):
                    issues.append({
                        "kind": "character_intro",
                        "severity": "warning",
                        "shot_id": shot["shot_id"],
                        "detail": _bounded(
                            f"character '{name}' first appears in a "
                            f"{shot['framing']} shot; no establishing or "
                            f"wide coverage before introduction"
                        ),
                    })
    return issues[:_MAX_ISSUES]


# ---------------------------------------------------------------------------
# 4. Animatic-style sequencing summary: shot order, durations, transitions.
#    Structural only — no media, no timing beyond whole-second budgeting.

def build_animatic(shots: Iterable[Mapping[str, Any]]) -> dict[str, Any]:
    """Sequence shots into an animatic-style timing summary.

    Transitions are chosen by bounded rules: the first shot opens with a cut;
    consecutive shots inside one sequence cut; a sequence boundary dissolves;
    entering the final sequence fades. Timings are cumulative whole seconds
    from each shot's declared duration. Returns a validated summary covering
    every shot exactly once, in order.
    """
    parsed = [_parse_shot(s, i) for i, s in enumerate(shots or [])]
    if not parsed:
        raise StoryboardError("storyboard.build_animatic expects at least one shot")

    sequence_orders = []
    for shot in parsed:
        if shot["sequence_order"] not in sequence_orders:
            sequence_orders.append(shot["sequence_order"])
    last_sequence = sequence_orders[-1]

    entries: list[dict[str, Any]] = []
    cursor = 0
    for index, shot in enumerate(parsed):
        if index == 0:
            transition = "cut"
        elif shot["sequence_order"] == parsed[index - 1]["sequence_order"]:
            transition = "cut"
        elif shot["sequence_order"] == last_sequence:
            transition = "fade"
        else:
            transition = "dissolve"
        duration = shot["duration_seconds"]
        entries.append({
            "shot_id": shot["shot_id"],
            "order": shot["order"],
            "transition_in": transition,
            "start_seconds": cursor,
            "duration_seconds": duration,
            "end_seconds": cursor + duration,
        })
        cursor += duration

    return parse_animatic({
        "shots": entries,
        "total_duration_seconds": cursor,
    })


# ---------------------------------------------------------------------------
# End-to-end composition: scene plan -> shots -> continuity -> animatic ->
# grounded confidence + honest open_questions.

def _storyboard_confidence(continuity: list[dict[str, Any]],
                           shot_count: int,
                           plan: Mapping[str, Any]) -> dict[str, str]:
    errors = sum(1 for i in continuity if i.get("severity") == "error")
    if errors:
        level = "low"
    elif continuity:
        level = "medium"
    else:
        level = "high"
    anchor = ""
    sequences = plan.get("sequences") or []
    if sequences and isinstance(sequences[0], Mapping):
        anchor = " ".join(str(sequences[0].get("purpose", "")).split()[:8])
    basis = _bounded(
        f'from plan sequence 1: "{anchor}" — composed into {shot_count} '
        f"shots; continuity check reported {len(continuity)} issue(s)"
    )
    return {"level": level, "basis": basis}


def compose_storyboard(
    scene_plan: Mapping[str, Any],
    *,
    title: str = "",
) -> dict[str, Any]:
    """Run the full deterministic storyboard & previs pipeline.

    generate shots -> check continuity -> build animatic -> validate. The
    returned storyboard always passes parse_shot_list. Anything the scene
    plan does not declare (characters, props, real locations) is reported as
    UNKNOWN in open_questions, never fabricated.
    """
    if not isinstance(scene_plan, Mapping):
        raise StoryboardError(
            "storyboard.compose_storyboard expects a scene plan object"
        )
    # Validates the plan up front (parser reused from ENG-WR-019); generation
    # revalidates — the pipeline never runs on an invalid plan.
    try:
        plan = parse_scene_plan(scene_plan)
    except ValueError as exc:
        raise StoryboardError(f"storyboard scene plan invalid: {exc}") from exc
    if title and _words(title) > _MAX_FIELD_WORDS:
        raise StoryboardError(
            f"storyboard.title exceeds {_MAX_FIELD_WORDS} words"
        )

    shots = generate_shot_list(scene_plan)
    continuity = check_continuity(shots)
    animatic = build_animatic(shots)

    open_questions: list[str] = [
        "characters UNKNOWN — scene plan declares none; character continuity "
        "checking needs caller-annotated shots",
        "props UNKNOWN — scene plan declares none; prop continuity checking "
        "needs caller-annotated shots",
        "locations UNKNOWN — sequence settings are structural hints, not "
        "named places; set consistency is checked on declared values only",
    ]

    return parse_shot_list({
        "shots": shots,
        "animatic": animatic,
        "continuity": continuity,
        "confidence": _storyboard_confidence(continuity, len(shots), plan),
        "open_questions": open_questions[:_MAX_OPEN_QUESTIONS],
    })


# ---------------------------------------------------------------------------
# Deterministic consistency gates over the storyboard + the scene plan it
# claims to visualize. Failures are reasons (empty = pass); nothing here
# weakens or replaces canonical validation.

def run_storyboard_gates(
    storyboard: Mapping[str, Any],
    scene_plan: Mapping[str, Any],
) -> list[str]:
    """Consistency gates: every shot links to a real plan sequence; shot
    orders are unique and contiguous; the animatic covers every shot exactly
    once with matching total duration; continuity errors block; the
    confidence basis is grounded in the plan."""
    failures: list[str] = []
    if not isinstance(storyboard, Mapping):
        return ["storyboard must be an object"]
    if not isinstance(scene_plan, Mapping):
        return ["scene plan must be an object"]

    try:
        plan = parse_scene_plan(scene_plan)
    except ValueError as exc:
        return [f"scene plan is invalid: {exc}"]
    plan_sequences = {s["order"] for s in plan["sequences"]}

    shots = [s for s in storyboard.get("shots", []) if isinstance(s, Mapping)]
    if not shots:
        return ["storyboard has no shots"]

    orders = [s.get("order") for s in shots]
    if len(set(orders)) != len(orders):
        failures.append("shot orders contain duplicates")
    if sorted(int(o) for o in orders) != list(range(1, len(orders) + 1)):
        failures.append("shot orders are not contiguous 1..n")
    for shot in shots:
        sequence_order = shot.get("sequence_order")
        if sequence_order not in plan_sequences:
            failures.append(
                f"shot '{str(shot.get('shot_id', '?'))}' links to unknown "
                f"sequence {sequence_order}"
            )

    animatic = storyboard.get("animatic", {})
    animatic_shots = [
        s for s in animatic.get("shots", []) if isinstance(s, Mapping)
    ]
    animatic_ids = [s.get("shot_id") for s in animatic_shots]
    shot_ids = [s.get("shot_id") for s in shots]
    if sorted(animatic_ids) != sorted(shot_ids):
        failures.append("animatic does not cover exactly the storyboard shots")
    else:
        animatic_order = [s.get("shot_id") for s in animatic_shots]
        if animatic_order != shot_ids:
            failures.append("animatic order does not match shot order")
        declared_total = animatic.get("total_duration_seconds")
        computed_total = sum(
            int(s.get("duration_seconds", 0)) for s in animatic_shots
        )
        if declared_total != computed_total:
            failures.append(
                f"animatic total {declared_total}s disagrees with shot "
                f"durations sum {computed_total}s"
            )

    for issue in storyboard.get("continuity", []):
        if isinstance(issue, Mapping) and issue.get("severity") == "error":
            failures.append(
                f"continuity error at {issue.get('shot_id', '?')}: "
                f"{str(issue.get('detail', ''))[:60]}"
            )

    plan_text = " ".join(
        [str(s.get("purpose", "")) for s in plan["sequences"]]
        + [str(s.get("setting", "")) for s in plan["sequences"]]
    ).lower()
    basis = str(storyboard.get("confidence", {}).get("basis", "")).lower()
    grounded = any(
        token in basis for token in plan_text.split() if len(token) >= 6
    )
    if not grounded and plan["sequences"]:
        grounded = str(plan["sequences"][0]["order"]) in basis
    if not grounded:
        failures.append(
            "confidence basis is not grounded in the scene plan"
        )

    return failures


def storyboard_readiness(
    storyboard: Mapping[str, Any],
    gate_failures: list[str],
) -> dict[str, Any]:
    """Storyboard readiness seal. READY requires clean gates and at least one
    shot — a storyboard without shots is a visualization of nothing."""
    blocking = list(gate_failures)
    if not isinstance(storyboard, Mapping):
        return {
            "ready": False,
            "blocking_items": blocking + ["storyboard must be an object"],
            "seal": {"authority_preserved": True},
        }
    shots = storyboard.get("shots") or []
    animatic = storyboard.get("animatic") or {}
    if not shots:
        blocking.append("no shots — storyboard has no visual plan")
    if shots and not animatic.get("shots"):
        blocking.append("no animatic — shots are not sequenced")
    ready = not blocking
    return {
        "ready": ready,
        "blocking_items": blocking,
        "seal": {
            "shots_planned": bool(shots),
            "animatic_built": bool(animatic.get("shots")),
            "continuity_checked": isinstance(storyboard.get("continuity"), list),
            "gates_clean": not gate_failures,
            "authority_preserved": True,  # advisory engine only
        },
    }
