"""Focused tests for the Project Understanding engine (wave 1, §11 family).

Runs against afaq_agent_runtime.project_understanding only — no model, no
runtime services, no canonical state. Intentionally OUTSIDE pytest.ini
testpaths so the canonical suite stays at exactly 44 tests.

Run explicitly:

    python -m pytest afaq_agent_runtime/tests_understanding -q
"""

from __future__ import annotations

import pytest

from afaq_agent_runtime.intent_gate import classify_intent
from afaq_agent_runtime.project_understanding import (
    UnderstandingError,
    parse_understanding,
    run_understanding_gates,
    understand_project,
    understanding_readiness,
)

_REPO_MAP = {"project_types": ["python", "node"]}

_AUTH_INSTRUCTION = (
    "I want to add user authentication. "
    "Deliverable: authentication module for the team, within 2 weeks."
)


def _valid_understanding(**overrides):
    base = {
        "intent": {"kind": "development_task", "reason": "test fixture"},
        "goals": ["add user authentication"],
        "audience": "internal",
        "platform_hints": ["python"],
        "constraints": ["within 2 weeks"],
        "deliverables": ["authentication module"],
        "decomposition": ["inspect", "implement", "verify"],
        "confidence": {"level": "medium", "basis": 'instruction states: "add user authentication"'},
        "open_questions": [],
    }
    base.update(overrides)
    return base


# -- valid parse / extraction ------------------------------------------------

def test_understand_project_valid_shape():
    u = understand_project(_AUTH_INSTRUCTION, _REPO_MAP)
    assert u["intent"]["kind"] == "development_task"
    assert u["goals"] == ["I want to add user authentication"]
    assert u["audience"] == "internal"
    assert "python" in u["platform_hints"] and "node" in u["platform_hints"]
    assert any("within 2 weeks" in c for c in u["constraints"])
    assert len(u["deliverables"]) == 1
    assert 2 <= len(u["decomposition"]) <= 5
    assert u["confidence"]["level"] == "high"
    assert u["open_questions"] == []


def test_intent_is_reused_from_intent_gate():
    instruction = "Add multiply(a, b) to calc.py and run pytest"
    u = understand_project(instruction)
    expected = classify_intent(instruction)
    assert u["intent"]["kind"] == expected.kind
    assert u["intent"]["reason"] == expected.reason


def test_honest_unknowns_for_vague_input():
    u = understand_project("maybe improve things sometime")
    assert u["goals"] == []
    assert u["audience"] == "unknown"
    assert u["confidence"]["level"] == "low"
    joined = " ".join(u["open_questions"])
    assert "goals UNKNOWN" in joined
    assert "audience UNKNOWN" in joined
    assert u["open_questions"]  # honest disclosure, never fabricated


def test_word_cap_truncates_long_clauses():
    long_goal = "I want to " + " ".join(f"step{i}" for i in range(60))
    u = understand_project(long_goal)
    for goal in u["goals"]:
        assert len(goal.split()) <= 40
    for step in u["decomposition"]:
        assert len(step.split()) <= 40


# -- strict validation (mirrors decision_analysis) ----------------------------

def test_enum_rejection_audience():
    with pytest.raises(UnderstandingError, match="audience"):
        parse_understanding(_valid_understanding(audience="alien"))


def test_enum_rejection_confidence_level():
    with pytest.raises(UnderstandingError, match="confidence.level"):
        parse_understanding(
            _valid_understanding(confidence={"level": "certain", "basis": "x"})
        )


def test_enum_rejection_intent_kind():
    with pytest.raises(UnderstandingError, match="intent.kind"):
        parse_understanding(
            _valid_understanding(intent={"kind": "magic", "reason": "x"})
        )


def test_missing_fields_rejected():
    payload = _valid_understanding()
    del payload["constraints"]
    with pytest.raises(UnderstandingError, match="missing required field"):
        parse_understanding(payload)


def test_word_cap_rejected_by_parser():
    with pytest.raises(UnderstandingError, match="exceeds 40 words"):
        parse_understanding(_valid_understanding(goals=["word " * 41]))


def test_unknown_keys_ignored():
    payload = _valid_understanding()
    payload["future_field"] = {"anything": True}
    u = parse_understanding(payload)
    assert "future_field" not in u


def test_decomposition_step_count_enforced():
    with pytest.raises(UnderstandingError, match="decomposition"):
        parse_understanding(_valid_understanding(decomposition=["only one"]))
    with pytest.raises(UnderstandingError, match="decomposition"):
        parse_understanding(
            _valid_understanding(decomposition=[f"s{i}" for i in range(6)])
        )


# -- consistency gates ---------------------------------------------------------

def test_gate_contradictory_deliverable_fails():
    u = _valid_understanding(
        goals=["improve login performance"],
        deliverables=["monthly billing invoice pdf"],
    )
    failures = run_understanding_gates(u, "improve login performance")
    assert any("does not relate to any named goal" in f for f in failures)


def test_gate_deliverable_without_goal_fails():
    u = _valid_understanding(goals=[], deliverables=["standalone report"])
    failures = run_understanding_gates(u, "standalone report")
    assert any("no named goal" in f for f in failures)


def test_gate_duplicate_steps_fail():
    u = _valid_understanding(decomposition=["Do the work", "do the work", "Verify"])
    failures = run_understanding_gates(u, "add user authentication")
    assert any("duplicate" in f for f in failures)


def test_gate_ungrounded_confidence_fails():
    u = _valid_understanding(
        confidence={"level": "medium", "basis": "the model feels confident"},
        platform_hints=[],
    )
    failures = run_understanding_gates(u, "add tests to calc.py")
    assert any("not grounded" in f for f in failures)


def test_gates_pass_on_coherent_understanding():
    u = understand_project(_AUTH_INSTRUCTION, _REPO_MAP)
    assert run_understanding_gates(u, _AUTH_INSTRUCTION) == []


# -- readiness seal ------------------------------------------------------------

def test_readiness_ready_when_clean():
    u = understand_project(_AUTH_INSTRUCTION, _REPO_MAP)
    result = understanding_readiness(u, [])
    assert result["ready"] is True
    assert result["blocking_items"] == []


def test_readiness_blocked_by_failures_and_missing_goals():
    u = understand_project("مرحبا")
    failures = run_understanding_gates(u, "مرحبا")
    result = understanding_readiness(u, failures)
    assert result["ready"] is False
    assert result["blocking_items"]
    assert any("no named goals" in b for b in result["blocking_items"])
