from __future__ import annotations

from enum import Enum
import shlex


class SideEffectClassification(str, Enum):
    READ_ONLY = "READ_ONLY"
    WRITE = "WRITE"
    EXTERNAL_SIDE_EFFECT = "EXTERNAL_SIDE_EFFECT"
    UNKNOWN = "UNKNOWN"


_READ_ACTIONS = {
    "files", "read", "search", "status", "diff", "map",
    "web_fetch", "web_crawl", "remote_verify",
    "performance_history", "performance_latest_metrics", "performance_recommend",
    "performance_budget_check", "performance_regression",
    "performance_bottleneck", "performance_optimize",
    "mission_model", "capability_compose", "result_fuse", "context_adapt",
    "capability_discover", "capability_session_status", "gap_resolve",
    "evidence_verify", "research_synthesize", "causal_falsify",
    "scenario_forecast", "continuous_observe", "continuous_compare",
    "frontier_discover", "benchmark_observe", "research_portfolio",
    "goal_form",
}
_EXTERNAL_CAPABILITY_ACTIONS = {
    "browser_execute",
    "benchmark_engines",
    "benchmark_suite",
    "mission_graph",
    "engine_invoke",
    "capability_invoke",
}


def classify_action(action: str, args: dict | None = None) -> SideEffectClassification:
    action = (action or "").strip().lower()
    args = args or {}
    if action == "web_explore":
        if (
            bool(args.get("require_interaction"))
            or bool(args.get("require_authenticated_state"))
            or bool(args.get("require_side_effect"))
            or bool(args.get("browser_actions"))
        ):
            return SideEffectClassification.EXTERNAL_SIDE_EFFECT
        return SideEffectClassification.READ_ONLY
    if action in _READ_ACTIONS:
        return SideEffectClassification.READ_ONLY
    if action == "performance_selection_feedback":
        return SideEffectClassification.WRITE
    if action == "model_profile":
        return (
            SideEffectClassification.WRITE
            if bool(args.get("persist", True))
            else SideEffectClassification.READ_ONLY
        )
    if action in _EXTERNAL_CAPABILITY_ACTIONS:
        return SideEffectClassification.EXTERNAL_SIDE_EFFECT
    if action == "edit":
        return SideEffectClassification.WRITE
    if action == "run":
        command = str(args.get("command", "")).strip()
        if not command:
            return SideEffectClassification.UNKNOWN
        try:
            argv = shlex.split(command, posix=False)
        except ValueError:
            return SideEffectClassification.UNKNOWN
        if not argv:
            return SideEffectClassification.UNKNOWN
        exe = argv[0].replace("\\", "/").rsplit("/", 1)[-1].lower().removesuffix(".exe")
        if exe == "git" and len(argv) > 1 and argv[1] in {"status", "diff", "log", "show", "rev-parse", "branch", "blame"}:
            return SideEffectClassification.READ_ONLY
        if exe in {"powershell", "pwsh"}:
            return SideEffectClassification.READ_ONLY
        if exe in {"java", "javac"} and len(argv) == 2 and argv[1] in {"-version", "--version"}:
            return SideEffectClassification.READ_ONLY
        if exe in {"python", "python3", "py", "npm", "pnpm", "yarn", "npx"}:
            # tests/builds can create local artifacts, caches or reports.
            return SideEffectClassification.WRITE
        return SideEffectClassification.UNKNOWN
    return SideEffectClassification.UNKNOWN
