"""Request-time admission guard for canonical runtime mutations."""
from __future__ import annotations

import re
import threading
import time
from dataclasses import dataclass, replace
from typing import Any, Callable

from afaq_registry.admission import (
    AdmissionBlocked,
    admission_cache_identity,
    require_admission,
)

_RUNTIME_MUTATION_PATH = "runtime_mutation_api"


@dataclass(frozen=True)
class RouteClassification:
    name: str
    admission_required: bool


@dataclass(frozen=True)
class AdmissionResult:
    classification: str
    admission_required: bool
    allowed: bool
    reason: str
    cached: bool = False


@dataclass
class _CacheEntry:
    expires_at: float
    identity: str
    result: AdmissionResult


class AdmissionCache:
    """Thread-safe single-flight cache for Admission Authority results."""

    def __init__(
        self,
        ttl_seconds: float = 30.0,
        *,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        if ttl_seconds < 0:
            raise ValueError("ttl_seconds must be non-negative")
        self.ttl_seconds = float(ttl_seconds)
        self._clock = clock
        self._lock = threading.RLock()
        self._entry: _CacheEntry | None = None

    def get_or_refresh(
        self,
        refresh: Callable[[], AdmissionResult],
        *,
        identity: str,
    ) -> AdmissionResult:
        with self._lock:
            now = self._clock()
            if (
                self._entry is not None
                and now < self._entry.expires_at
                and self._entry.identity == identity
            ):
                return replace(self._entry.result, cached=True)
            result = refresh()
            self._entry = _CacheEntry(
                expires_at=now + self.ttl_seconds,
                identity=identity,
                result=replace(result, cached=False),
            )
            return result

    def invalidate(self) -> None:
        with self._lock:
            self._entry = None


_EXACT_MUTATIONS = {
    "/orchestrator/jobs",
    "/orchestrator/goal",
    "/orchestrator/execute",
    "/tasks",
    "/developer/tasks",
    "/incidents/scan",
    "/workspace/run",
}

_MUTATION_PATTERNS = (
    re.compile(r"^/orchestrator/jobs/[^/]+/(approve|reject)$"),
    re.compile(r"^/tasks/[^/]+/resume$"),
    re.compile(r"^/developer/tasks/[^/]+/(approve|reject|resume)$"),
    re.compile(r"^/developer/approvals/[^/]+/(approve|reject)$"),
    re.compile(r"^/incidents/[^/]+/(diagnose|propose)$"),
)

_EXACT_NON_MUTATING_POST = {
    "/orchestrator/plan",
    "/workspace/file",
    "/workspace/fs",
}


def classify_route(method: str, path: str) -> RouteClassification:
    normalized_method = method.upper().strip()
    normalized_path = path.rstrip("/") or "/"

    if normalized_method != "POST":
        return RouteClassification("READ_ONLY_OR_NON_POST", False)

    if normalized_path in _EXACT_NON_MUTATING_POST:
        if normalized_path == "/orchestrator/plan":
            return RouteClassification("READ_ONLY_PLANNING", False)
        return RouteClassification("HARD_BLOCKED_DIRECT_MUTATION", False)

    if normalized_path in _EXACT_MUTATIONS:
        return RouteClassification("RUNTIME_MUTATION", True)

    if any(pattern.fullmatch(normalized_path) for pattern in _MUTATION_PATTERNS):
        return RouteClassification("RUNTIME_MUTATION", True)

    return RouteClassification("UNCLASSIFIED_POST", False)


class AdmissionAuthorityGuard:
    """Identity-aware fail-closed guard for one canonical deployment path."""

    def __init__(
        self,
        *,
        environment: str,
        deployment_path: str,
        cache_ttl_seconds: float = 30.0,
        authority: Callable[..., Any] = require_admission,
        identity_provider: Callable[[], str] = admission_cache_identity,
        cache: AdmissionCache | None = None,
    ) -> None:
        self.environment = environment
        self.deployment_path = deployment_path
        self._authority = authority
        self._identity_provider = identity_provider
        self.cache = cache or AdmissionCache(cache_ttl_seconds)

    def authorize(self, *, classification: str = "DEPLOYMENT_ADMISSION") -> AdmissionResult:
        if self.environment != "production":
            return AdmissionResult(
                classification=classification,
                admission_required=True,
                allowed=True,
                reason="NON_PRODUCTION_RUNTIME",
            )

        try:
            identity = self._identity_provider()
        except Exception as exc:
            return AdmissionResult(
                classification=classification,
                admission_required=True,
                allowed=False,
                reason=(
                    "ADMISSION_CACHE_IDENTITY_ERROR:"
                    f"{type(exc).__name__}:{exc}"
                ),
            )

        def refresh() -> AdmissionResult:
            try:
                self._authority(
                    environment=self.environment,
                    deployment_path=self.deployment_path,
                    record=True,
                )
            except AdmissionBlocked as exc:
                return AdmissionResult(
                    classification=classification,
                    admission_required=True,
                    allowed=False,
                    reason=str(exc),
                )
            except Exception as exc:
                return AdmissionResult(
                    classification=classification,
                    admission_required=True,
                    allowed=False,
                    reason=(
                        "ADMISSION_AUTHORITY_ERROR:"
                        f"{type(exc).__name__}:{exc}"
                    ),
                )
            return AdmissionResult(
                classification=classification,
                admission_required=True,
                allowed=True,
                reason="ADMITTED",
            )

        return self.cache.get_or_refresh(refresh, identity=identity)

    def invalidate(self) -> None:
        self.cache.invalidate()


class AdmissionGuard:
    """Route classifier plus production guard for runtime mutations."""

    def __init__(
        self,
        *,
        environment: str,
        cache_ttl_seconds: float = 30.0,
        authority: Callable[..., Any] = require_admission,
        identity_provider: Callable[[], str] = admission_cache_identity,
        cache: AdmissionCache | None = None,
    ) -> None:
        self.environment = environment
        self._authority_guard = AdmissionAuthorityGuard(
            environment=environment,
            deployment_path=_RUNTIME_MUTATION_PATH,
            cache_ttl_seconds=cache_ttl_seconds,
            authority=authority,
            identity_provider=identity_provider,
            cache=cache,
        )
        self.cache = self._authority_guard.cache

    def classify(self, method: str, path: str) -> RouteClassification:
        return classify_route(method, path)

    def authorize_request(self, *, method: str, path: str) -> AdmissionResult:
        classification = self.classify(method, path)
        if not classification.admission_required:
            return AdmissionResult(
                classification=classification.name,
                admission_required=False,
                allowed=True,
                reason="ADMISSION_NOT_REQUIRED",
            )
        return self._authority_guard.authorize(
            classification=classification.name,
        )

    def invalidate(self) -> None:
        self._authority_guard.invalidate()
