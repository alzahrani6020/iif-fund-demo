"""Focused tests for the Graphics & Diagram Fabric engine (wave 5, media
family §15). Runs against afaq_agent_runtime.graphics_fabric only — no
model, no network, no runtime services, no canonical state. Intentionally
OUTSIDE pytest.ini testpaths so the canonical suite stays at exactly 44
tests.

Run explicitly:

    python -m pytest -q afaq_agent_runtime/tests_graphics/
"""

from __future__ import annotations

import pytest

from afaq_agent_runtime.graphics_fabric import (
    GraphicsError,
    bar_chart,
    build_document,
    circle,
    critique_graphics,
    graphics_readiness,
    layer,
    layout_flowchart,
    line,
    parse_svg_document,
    path,
    polygon,
    rect,
    render_flowchart,
    rotate,
    run_graphics_gates,
    scale,
    serialize_svg,
    text,
    translate,
)


def _doc(elements=None, width=200, height=200, layers=None):
    return build_document(
        width, height,
        layers if layers is not None else [layer("base", elements or [rect(10, 10, 50, 50, fill="#fff")])],
    )


# ---------------------------------------------------------------------------
# primitives and numeric validation


def test_rect_builds_validated_element():
    el = rect(1, 2, 30, 40, fill="red", stroke="black", stroke_width=2)
    assert el["tag"] == "rect"
    assert el["attrs"]["width"] == "30"
    assert parse_svg_document(el, root=False)["attrs"]["fill"] == "red"


@pytest.mark.parametrize("bad", ["x", None, True, float("nan"), float("inf")])
def test_rect_rejects_non_numeric(bad):
    with pytest.raises(GraphicsError):
        rect(bad, 0, 10, 10)


def test_circle_requires_positive_radius():
    with pytest.raises(GraphicsError):
        circle(0, 0, 0)
    with pytest.raises(GraphicsError):
        circle(0, 0, -3)


def test_polygon_validates_point_pairs():
    el = polygon([(0, 0), (10, 0), (5, 8)], fill="none", stroke="black")
    assert el["attrs"]["points"] == "0,0 10,0 5,8"
    with pytest.raises(GraphicsError):
        polygon([(0, 0), (10,)])
    with pytest.raises(GraphicsError):
        polygon([])


def test_path_requires_leading_move_and_valid_arity():
    el = path([("M", 0, 0), ("L", 10, 10), ("C", 1, 2, 3, 4, 5, 6), ("Z",)],
              stroke="black", fill="none")
    assert el["attrs"]["d"].startswith("M0,0")
    with pytest.raises(GraphicsError):
        path([("L", 0, 0)])
    with pytest.raises(GraphicsError):
        path([("M", 0, 0), ("C", 1, 2, 3)])
    with pytest.raises(GraphicsError):
        path([("M", 0, 0), ("Q", 1, 2)])


def test_text_capped_and_positioned():
    el = text(5, 20, "hello world", font_size=12)
    assert el["text"] == "hello world"
    with pytest.raises(GraphicsError):
        text(0, 0, "   ")
    with pytest.raises(GraphicsError):
        text(0, 0, "word " * 60)


def test_line_defaults_to_visible_stroke():
    el = line(0, 0, 10, 10)
    assert el["attrs"]["stroke"] == "currentColor"


# ---------------------------------------------------------------------------
# transforms


def test_transforms_render_validated_strings():
    assert translate(10, -5) == "translate(10,-5)"
    assert scale(2) == "scale(2,2)"
    assert rotate(90) == "rotate(90)"
    assert rotate(45, 10, 20) == "rotate(45,10,20)"
    with pytest.raises(GraphicsError):
        translate("left")
    with pytest.raises(GraphicsError):
        rotate(float("inf"))
    with pytest.raises(GraphicsError):
        rect(0, 0, 1, 1, transform="skewX(10)")  # not in vocabulary


# ---------------------------------------------------------------------------
# document model: strict parse + serialize round-trip


def test_parse_rejects_unknown_tag_and_attribute():
    with pytest.raises(GraphicsError):
        parse_svg_document({"tag": "image", "attrs": {}})
    with pytest.raises(GraphicsError):
        parse_svg_document({"tag": "rect", "attrs": {"x": 0, "y": 0, "width": 1,
                                                      "height": 1, "onclick": "x()"}})


def test_parse_enforces_root_svg_and_required_attrs():
    with pytest.raises(GraphicsError):
        parse_svg_document(rect(0, 0, 1, 1))  # root must be svg
    with pytest.raises(GraphicsError):
        parse_svg_document({"tag": "svg", "attrs": {"width": 100},
                            "children": [layer("a", [rect(0, 0, 1, 1)])]})
    with pytest.raises(GraphicsError):
        parse_svg_document({"tag": "svg", "attrs": {"width": 0, "height": 10},
                            "children": [layer("a", [rect(0, 0, 1, 1)])]})


def test_parse_rejects_text_on_shapes_and_nesting_under_shapes():
    shape = rect(0, 0, 1, 1)
    shape["text"] = "nope"
    with pytest.raises(GraphicsError):
        parse_svg_document(shape, root=False)
    with pytest.raises(GraphicsError):
        parse_svg_document({"tag": "g", "attrs": {}, "children": [
            {"tag": "g", "attrs": {}, "children": [  # only one level of g
                {"tag": "g", "attrs": {}, "children": []}]}]})


def test_serialize_round_trips_through_parse():
    doc = _doc()
    svg = serialize_svg(doc)
    assert svg.startswith('<svg width="200" height="200">')
    assert 'data-layer="base"' in svg
    reparsed = parse_svg_document(doc)
    assert serialize_svg(reparsed) == svg


def test_serialize_escapes_text():
    doc = _doc([text(5, 5, 'a<b & "c"', fill="black")])
    svg = serialize_svg(doc)
    assert "a&lt;b &amp; \"c\"" in svg
    assert "<b" not in svg


def test_build_document_requires_layers_and_positive_canvas():
    with pytest.raises(GraphicsError):
        build_document(100, 100, [])
    with pytest.raises(GraphicsError):
        build_document(-1, 100, [layer("a", [rect(0, 0, 1, 1)])])
    with pytest.raises(GraphicsError):
        build_document(100, 100, [rect(0, 0, 1, 1)])  # not a layer


def test_z_order_preserved_bottom_to_top():
    doc = _doc(layers=[layer("bottom", [rect(0, 0, 5, 5)]),
                       layer("top", [rect(1, 1, 5, 5)])])
    assert doc["children"][0]["attrs"]["data-layer"] == "bottom"
    assert doc["children"][1]["attrs"]["data-layer"] == "top"


# ---------------------------------------------------------------------------
# flowchart layout


def test_flowchart_layers_by_longest_path():
    layout = layout_flowchart(
        [{"id": "a", "label": "A"}, {"id": "b", "label": "B"},
         {"id": "c", "label": "C"}, {"id": "d", "label": "D"}],
        [{"from": "a", "to": "b"}, {"from": "b", "to": "c"},
         {"from": "a", "to": "c"}, {"from": "c", "to": "d"}],
    )
    by_id = {n["id"]: n for n in layout["nodes"]}
    assert by_id["a"]["layer"] == 0
    assert by_id["b"]["layer"] == 1
    assert by_id["c"]["layer"] == 2  # longest path a->b->c
    assert by_id["d"]["layer"] == 3
    # deterministic positions: deeper layer is lower on canvas
    assert by_id["a"]["y"] < by_id["d"]["y"]


def test_flowchart_deterministic_tie_break():
    nodes = [{"id": i} for i in ("zeta", "alpha", "mid")]
    edges = [{"from": "alpha", "to": "mid"}, {"from": "zeta", "to": "mid"}]
    first = layout_flowchart(nodes, edges)
    second = layout_flowchart(nodes, edges)
    assert first == second
    mid_layer = [n for n in first["nodes"] if n["id"] == "mid"][0]["layer"] == 1


def test_flowchart_cycle_rejected_with_reason():
    with pytest.raises(GraphicsError, match="cycle"):
        layout_flowchart([{"id": "a"}, {"id": "b"}],
                         [{"from": "a", "to": "b"}, {"from": "b", "to": "a"}])


def test_flowchart_validates_references_and_duplicates():
    with pytest.raises(GraphicsError):
        layout_flowchart([{"id": "a"}], [{"from": "a", "to": "ghost"}])
    with pytest.raises(GraphicsError):
        layout_flowchart([{"id": "a"}, {"id": "a"}])
    with pytest.raises(GraphicsError):
        layout_flowchart([], [])


def test_flowchart_edges_route_out_of_source_into_target():
    layout = layout_flowchart([{"id": "a"}, {"id": "b"}],
                              [{"from": "a", "to": "b"}])
    edge = layout["edges"][0]
    a = {n["id"]: n for n in layout["nodes"]}
    assert edge["points"][0] == [a["a"]["x"] + 60, a["a"]["y"] + 40]
    assert edge["points"][-1] == [a["b"]["x"] + 60, a["b"]["y"]]


def test_render_flowchart_produces_ready_document():
    layout = layout_flowchart([{"id": "a", "label": "Start"},
                               {"id": "b", "label": "End"}],
                              [{"from": "a", "to": "b"}])
    doc = render_flowchart(layout)
    assert run_graphics_gates(doc) == []
    assert graphics_readiness(doc, [])["ready"] is True


# ---------------------------------------------------------------------------
# bar chart


def test_bar_chart_requires_explicit_ordered_bounds():
    with pytest.raises(GraphicsError):
        bar_chart([1, 2], min_value=5, max_value=0)
    with pytest.raises(GraphicsError):
        bar_chart([1, 2], min_value=0, max_value=0)


def test_bar_chart_rejects_values_outside_axis():
    with pytest.raises(GraphicsError, match="outside axis"):
        bar_chart([1, 99], min_value=0, max_value=10)


def test_bar_chart_rejects_non_numeric_and_empty():
    with pytest.raises(GraphicsError):
        bar_chart(["a", "b"], min_value=0, max_value=10)
    with pytest.raises(GraphicsError):
        bar_chart([], min_value=0, max_value=10)


def test_bar_chart_deterministic_and_zero_height_at_min():
    chart = bar_chart([{"label": "x", "value": 0}, {"label": "y", "value": 10}],
                      min_value=0, max_value=10, width=400, height=300)
    assert serialize_svg(chart) == serialize_svg(
        bar_chart([{"label": "x", "value": 0}, {"label": "y", "value": 10}],
                  min_value=0, max_value=10, width=400, height=300))
    assert run_graphics_gates(chart) == []


# ---------------------------------------------------------------------------
# critique


def test_critique_flags_invisible_shapes():
    doc = _doc([rect(0, 0, 10, 10)])  # no fill, no stroke
    findings = critique_graphics(doc)
    assert any("invisible" in f for f in findings)


def test_critique_flags_overflow_with_reason():
    doc = _doc([rect(150, 10, 100, 50, fill="red")], width=200, height=200)
    findings = critique_graphics(doc)
    assert any("overflow" in f and "off right" in f for f in findings)


def test_critique_honors_translate_transform_in_bbox():
    off = _doc([rect(150, 10, 100, 50, fill="red",
                     transform=translate(-120, 0))], width=200, height=200)
    assert critique_graphics(off) == []
    on = _doc([rect(10, 10, 50, 50, fill="red",
                    transform=translate(500, 0))], width=200, height=200)
    assert any("overflow" in f for f in critique_graphics(on))


def test_critique_notes_non_translate_transform_extent_unknown():
    doc = _doc([rect(10, 10, 50, 50, fill="red",
                     transform=rotate(30, 10, 10))], width=200, height=200)
    assert any("UNKNOWN" in f for f in critique_graphics(doc))


def test_critique_unparseable_document_reports_reason():
    findings = critique_graphics({"tag": "nope", "attrs": {}})
    assert len(findings) == 1 and "does not parse" in findings[0]


def test_critique_clean_document_passes():
    assert critique_graphics(_doc()) == []


# ---------------------------------------------------------------------------
# gates and readiness seal


def test_gates_flag_duplicate_layer_names():
    doc = _doc(layers=[layer("dup", [rect(0, 0, 5, 5, fill="red")]),
                       layer("dup", [circle(50, 50, 5, fill="blue")])])
    assert any("layer names" in f for f in run_graphics_gates(doc))


def test_gates_collect_parse_failure_as_single_reason():
    failures = run_graphics_gates({"tag": "rect", "attrs": {}})
    assert len(failures) == 1 and "does not parse" in failures[0]


def test_readiness_seal_blocks_on_failures():
    doc = _doc([rect(0, 0, 10, 10)])  # invisible
    seal = graphics_readiness(doc, run_graphics_gates(doc))
    assert seal["ready"] is False
    assert seal["seal"]["authority_preserved"] is True
    assert any("invisible" in b for b in seal["blocking_items"])


def test_readiness_seal_unblocks_clean_document():
    doc = _doc()
    seal = graphics_readiness(doc, [])
    assert seal["ready"] is True
    assert seal["blocking_items"] == []
    assert seal["seal"]["gates_clean"] is True
    assert seal["seal"]["within_canvas"] is True
    assert seal["seal"]["all_visible"] is True


def test_readiness_blocks_unparseable_document():
    seal = graphics_readiness({"tag": "svg", "attrs": {}}, [])
    assert seal["ready"] is False
    assert any("does not parse" in b for b in seal["blocking_items"])
