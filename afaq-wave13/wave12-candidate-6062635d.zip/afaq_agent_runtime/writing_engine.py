"""Writing & Script engine — deterministic, offline, advisory.

Turns an understanding object (from project_understanding), an optional
research report (from research_intelligence), and optional draft script text
into a bounded, validated writing plan and an honest scored critique:
creative/content brief generation, narrative arc / beat-sheet structure
(structural planning, never prose generation), scene/sequence planning, and
script evaluation + improvement feedback with explicit reasons. Pure stdlib —
no model calls, no network, no state ownership. This is an ENGINE, not a
store: it plans, scores, and reports; persistence and authority live
elsewhere.

Pipeline (each step is independently callable and validated):
  generate_brief -> build_structure -> plan_scenes
                 -> evaluate_script -> improve_script
  run_writing_gates / writing_readiness seal the writing plan.

Reuse (engine registry, dedup audit):
  - ENG-UND-017 (project_understanding) is INSTRUCTION-side: it classifies
    intent and extracts goals/audience/constraints. This module CONSUMES that
    output (it never re-classifies intent and never inspects the filesystem)
    to derive a writing brief.
  - ENG-RES-018 (research_intelligence) is EVIDENCE-side: it extracts facts
    with uncertainty. This module consumes its facts/key_terms as optional
    grounding material for briefs and evaluation. It never re-verifies
    sources or re-extracts claims.
  - ENG-DEC-002 (decision_analysis) is CHANGE-side (analysis of a proposed
    change to code). Writing evaluation here is TEXT-side (critique of a
    draft against a brief). No field, gate, or scorer overlaps.
  - No canonical component is imported: the engine is composable but
    standalone, so it can never pull authority into an advisory path.

ABSENT stays ABSENT: anything not derivable from the supplied understanding,
research report, or draft text is reported as UNKNOWN (open_questions),
never fabricated. This engine plans structure and scores drafts — it never
generates prose, so it can never hallucinate content.
"""

from __future__ import annotations

import re
from typing import Any, Iterable, Mapping

# ---------------------------------------------------------------------------
# Bounded vocabulary and budgets (mirrors decision_analysis discipline).

_CONTENT_TYPES = (
    "article", "story", "video_script", "presentation", "documentation",
    "social", "unknown",
)
_AUDIENCES = ("internal", "owner", "technical", "general", "unknown")
_TONES = ("formal", "conversational", "neutral", "instructional", "storytelling")
_LENGTH_TARGETS = ("short", "medium", "long")
_CONFIDENCE_LEVELS = ("low", "medium", "high")
_ARCS = ("three_act", "five_act", "sequential", "inverted_pyramid", "listicle")
_DIMENSIONS = ("alignment", "structure", "readability", "dialogue", "grounding")

_MAX_FIELD_WORDS = 40
_MAX_GOALS = 3
_MAX_KEY_MESSAGES = 3
_MAX_CONSTRAINTS = 3
_MAX_BEATS = 12
_MAX_SEQUENCES = 8
_MAX_SUGGESTIONS = 6
_MAX_OPEN_QUESTIONS = 5
_MIN_BEATS = 3
_MIN_SEQUENCES = 2
_TARGET_WORDS = {"short": 300, "medium": 800, "long": 2000}

# ---------------------------------------------------------------------------
# Deterministic signals (no model, keyword/structure only).

_CLAUSE_SPLIT = re.compile(r"[.!؟?\n]+|؛|;")
_TOKEN_SPLIT = re.compile(r"[^\w]+")
_WORD = re.compile(r"\w+", re.UNICODE)

# Content-token stoplist (English + Arabic function words).
_STOPWORDS = frozenset(
    "the and for with that this from into about what when where which are was were "
    "has have had will its their his her them they then than such also more most "
    "not no never without can may must should would could "
    "هذا هذه ذلك التي الذي الذين في من على إلى عن ما أن ان إن كان كانت يكون "
    "تم يتم بعد قبل عند كل بعض غير بين فوق تحت أو او ثم لقد ليس ليست لا لم لن"
    .split()
)

# Story-flavored wording selects arc-shaped structures; informational wording
# selects informational arcs. First decisive match wins, in listed order.
_CONTENT_TYPE_SIGNALS = (
    ("video_script", (r"\bvideo\b", r"\bscript\b", r"\bepisode\b", r"فيديو", r"حلقة", r"مشهد")),
    ("story", (r"\bstory\b", r"\bnarrative\b", r"\bnovel\b", r"\bfiction\b", r"قصة", r"رواية", r"حكاية")),
    ("presentation", (r"\bpresentation\b", r"\bslides?\b", r"\bdeck\b", r"عرض", r"شرائح", r"تقديم")),
    ("article", (r"\barticle\b", r"\bblog\b", r"\bpost\b", r"\bessay\b", r"مقال", r"مدونة")),
    ("documentation", (r"\bdocumentation\b", r"\bdocs\b", r"\bguide\b", r"\bmanual\b", r"توثيق", r"دليل", r"وثيقة")),
    ("social", (r"\bsocial\b", r"\btweet\b", r"\bpost\b", r"\bcaption\b", r"منشور", r"تغريدة")),
)

# Beat purposes are structural roles, not prose. A beat names what a section
# must accomplish so a human (or a later generative step) can write it.
_BEAT_ROLES = (
    "hook", "setup", "inciting_incident", "rising_action", "midpoint",
    "complication", "climax", "resolution", "call_to_action", "context",
    "evidence", "takeaway",
)

_ARC_BEATS: dict[str, tuple[str, ...]] = {
    "three_act": ("hook", "setup", "inciting_incident", "rising_action",
                  "midpoint", "complication", "climax", "resolution"),
    "five_act": ("hook", "setup", "inciting_incident", "rising_action",
                 "midpoint", "complication", "climax", "resolution",
                 "takeaway", "call_to_action"),
    "sequential": ("context", "setup", "evidence", "rising_action",
                   "evidence", "takeaway", "call_to_action"),
    "inverted_pyramid": ("hook", "evidence", "context", "evidence",
                         "complication", "takeaway"),
    "listicle": ("hook", "context", "evidence", "evidence", "evidence",
                 "takeaway", "call_to_action"),
}

_DIALOGUE_LINE = re.compile(
    r'^\s*(?:[-–—]\s*)?[\w\u0600-\u06FF .]{0,30}[:\：]\s*["“«\'\u2018]?'
)


class WritingError(ValueError):
    """Bounded, user-facing writing parse/quality failure."""


def _words(text: str) -> int:
    return len(text.split())


def _short(text: str, where: str) -> str:
    value = text.strip()
    if not value:
        raise WritingError(f"writing.{where} must be a non-empty string")
    if _words(value) > _MAX_FIELD_WORDS:
        raise WritingError(
            f"writing.{where} exceeds {_MAX_FIELD_WORDS} words"
        )
    return value


def _string_list(value: Any, where: str, cap: int) -> list[str]:
    if not isinstance(value, list):
        raise WritingError(f"writing.{where} must be a list")
    if len(value) > cap:
        raise WritingError(f"writing.{where} exceeds {cap} entries")
    out = []
    for item in value:
        out.append(_short(str(item), where))
    return out


def _tokens(text: str) -> set[str]:
    return {
        t for t in _TOKEN_SPLIT.split(text.lower())
        if len(t) >= 3 and t not in _STOPWORDS
    }


def _norm(text: str) -> str:
    return " ".join(text.lower().split())


# ---------------------------------------------------------------------------
# Strict parse / validate (mirrors decision_analysis parse discipline).
# Unknown keys are ignored (forward-tolerant); required keys and enums are
# enforced; every free-text field is capped at _MAX_FIELD_WORDS words.


def _parse_confidence(value: Any) -> dict[str, str]:
    if not isinstance(value, Mapping):
        raise WritingError("writing.confidence must be an object")
    level = str(value.get("level", "")).strip()
    if level not in _CONFIDENCE_LEVELS:
        raise WritingError(
            f"writing.confidence.level must be one of {_CONFIDENCE_LEVELS}"
        )
    return {
        "level": level,
        "basis": _short(str(value.get("basis", "")), "confidence.basis"),
    }


def _parse_beat(value: Any, index: int) -> dict[str, Any]:
    where = f"beats[{index}]"
    if not isinstance(value, Mapping):
        raise WritingError(f"writing.{where} must be an object")
    role = str(value.get("role", "")).strip()
    if role not in _BEAT_ROLES:
        raise WritingError(
            f"writing.{where}.role must be one of {_BEAT_ROLES}"
        )
    try:
        order = int(value.get("order"))
    except (TypeError, ValueError):
        raise WritingError(f"writing.{where}.order must be an integer") from None
    return {
        "order": order,
        "role": role,
        "purpose": _short(str(value.get("purpose", "")), f"{where}.purpose"),
    }


def _parse_sequence(value: Any, index: int) -> dict[str, Any]:
    where = f"sequences[{index}]"
    if not isinstance(value, Mapping):
        raise WritingError(f"writing.{where} must be an object")
    try:
        order = int(value.get("order"))
    except (TypeError, ValueError):
        raise WritingError(f"writing.{where}.order must be an integer") from None
    beats_covered = value.get("beats_covered")
    if not isinstance(beats_covered, list):
        raise WritingError(f"writing.{where}.beats_covered must be a list")
    if not beats_covered:
        raise WritingError(f"writing.{where}.beats_covered must not be empty")
    return {
        "order": order,
        "purpose": _short(str(value.get("purpose", "")), f"{where}.purpose"),
        "setting": _short(str(value.get("setting", "")), f"{where}.setting"),
        "beats_covered": [int(b) for b in beats_covered],
    }


def parse_writing_brief(payload: Any) -> dict[str, Any]:
    """Validate and normalize a writing brief.

    Raises WritingError with a specific reason. Unknown keys are ignored;
    required keys and enums are enforced; every free-text field is capped at
    _MAX_FIELD_WORDS words. Cross-field consistency is the GATE's job, not
    the parser's.
    """
    if not isinstance(payload, Mapping):
        raise WritingError("writing brief must be a JSON object")
    required = (
        "title", "content_type", "audience", "goals", "key_messages",
        "constraints", "tone", "target_length", "confidence", "open_questions",
    )
    missing = [k for k in required if k not in payload]
    if missing:
        raise WritingError(
            f"writing brief missing required field(s): {missing}"
        )

    brief: dict[str, Any] = {
        "title": _short(str(payload.get("title", "")), "title"),
    }
    content_type = str(payload.get("content_type", "")).strip()
    if content_type not in _CONTENT_TYPES:
        raise WritingError(
            f"writing.content_type must be one of {_CONTENT_TYPES}"
        )
    brief["content_type"] = content_type

    audience = str(payload.get("audience", "")).strip()
    if audience not in _AUDIENCES:
        raise WritingError(f"writing.audience must be one of {_AUDIENCES}")
    brief["audience"] = audience

    brief["goals"] = _string_list(payload.get("goals"), "goals", _MAX_GOALS)
    brief["key_messages"] = _string_list(
        payload.get("key_messages"), "key_messages", _MAX_KEY_MESSAGES
    )
    brief["constraints"] = _string_list(
        payload.get("constraints"), "constraints", _MAX_CONSTRAINTS
    )

    tone = str(payload.get("tone", "")).strip()
    if tone not in _TONES:
        raise WritingError(f"writing.tone must be one of {_TONES}")
    brief["tone"] = tone

    target_length = str(payload.get("target_length", "")).strip()
    if target_length not in _LENGTH_TARGETS:
        raise WritingError(
            f"writing.target_length must be one of {_LENGTH_TARGETS}"
        )
    brief["target_length"] = target_length

    brief["confidence"] = _parse_confidence(payload.get("confidence"))
    brief["open_questions"] = _string_list(
        payload.get("open_questions"), "open_questions", _MAX_OPEN_QUESTIONS
    )
    return brief


def parse_structure(payload: Any) -> dict[str, Any]:
    """Validate and normalize a narrative structure (arc + beat sheet)."""
    if not isinstance(payload, Mapping):
        raise WritingError("writing structure must be a JSON object")
    required = ("content_type", "arc", "beats")
    missing = [k for k in required if k not in payload]
    if missing:
        raise WritingError(
            f"writing structure missing required field(s): {missing}"
        )
    content_type = str(payload.get("content_type", "")).strip()
    if content_type not in _CONTENT_TYPES:
        raise WritingError(
            f"writing.content_type must be one of {_CONTENT_TYPES}"
        )
    arc = str(payload.get("arc", "")).strip()
    if arc not in _ARCS:
        raise WritingError(f"writing.arc must be one of {_ARCS}")
    beats = payload.get("beats")
    if not isinstance(beats, list):
        raise WritingError("writing.beats must be a list")
    if not (_MIN_BEATS <= len(beats) <= _MAX_BEATS):
        raise WritingError(
            f"writing.beats must have {_MIN_BEATS}..{_MAX_BEATS} entries"
        )
    return {
        "content_type": content_type,
        "arc": arc,
        "beats": [_parse_beat(b, i) for i, b in enumerate(beats)],
    }


def parse_scene_plan(payload: Any) -> dict[str, Any]:
    """Validate and normalize a scene/sequence plan."""
    if not isinstance(payload, Mapping):
        raise WritingError("writing scene plan must be a JSON object")
    required = ("content_type", "sequences")
    missing = [k for k in required if k not in payload]
    if missing:
        raise WritingError(
            f"writing scene plan missing required field(s): {missing}"
        )
    content_type = str(payload.get("content_type", "")).strip()
    if content_type not in _CONTENT_TYPES:
        raise WritingError(
            f"writing.content_type must be one of {_CONTENT_TYPES}"
        )
    sequences = payload.get("sequences")
    if not isinstance(sequences, list):
        raise WritingError("writing.sequences must be a list")
    if not (_MIN_SEQUENCES <= len(sequences) <= _MAX_SEQUENCES):
        raise WritingError(
            f"writing.sequences must have {_MIN_SEQUENCES}..{_MAX_SEQUENCES} entries"
        )
    return {
        "content_type": content_type,
        "sequences": [_parse_sequence(s, i) for i, s in enumerate(sequences)],
    }


def parse_evaluation(payload: Any) -> dict[str, Any]:
    """Validate and normalize a script evaluation."""
    if not isinstance(payload, Mapping):
        raise WritingError("writing evaluation must be a JSON object")
    required = ("overall_score", "dimensions", "suggestions", "confidence",
                "open_questions")
    missing = [k for k in required if k not in payload]
    if missing:
        raise WritingError(
            f"writing evaluation missing required field(s): {missing}"
        )
    try:
        overall = int(payload.get("overall_score"))
    except (TypeError, ValueError):
        raise WritingError("writing.overall_score must be an integer") from None
    if not 0 <= overall <= 100:
        raise WritingError("writing.overall_score must be within 0..100")

    dimensions = payload.get("dimensions")
    if not isinstance(dimensions, list):
        raise WritingError("writing.dimensions must be a list")
    parsed_dimensions = []
    for index, dimension in enumerate(dimensions):
        where = f"dimensions[{index}]"
        if not isinstance(dimension, Mapping):
            raise WritingError(f"writing.{where} must be an object")
        name = str(dimension.get("name", "")).strip()
        if name not in _DIMENSIONS:
            raise WritingError(
                f"writing.{where}.name must be one of {_DIMENSIONS}"
            )
        try:
            score = int(dimension.get("score"))
        except (TypeError, ValueError):
            raise WritingError(
                f"writing.{where}.score must be an integer"
            ) from None
        if not 0 <= score <= 100:
            raise WritingError(f"writing.{where}.score must be within 0..100")
        parsed_dimensions.append({
            "name": name,
            "score": score,
            "reasons": _string_list(
                dimension.get("reasons"), f"{where}.reasons", _MAX_SUGGESTIONS
            ) or ["no specific reason recorded"],
        })

    suggestions = payload.get("suggestions")
    if not isinstance(suggestions, list):
        raise WritingError("writing.suggestions must be a list")
    if len(suggestions) > _MAX_SUGGESTIONS:
        raise WritingError(f"writing.suggestions exceeds {_MAX_SUGGESTIONS} entries")
    parsed_suggestions = []
    for index, suggestion in enumerate(suggestions):
        where = f"suggestions[{index}]"
        if not isinstance(suggestion, Mapping):
            raise WritingError(f"writing.{where} must be an object")
        severity = str(suggestion.get("severity", "")).strip()
        if severity not in ("high", "medium", "low"):
            raise WritingError(
                f"writing.{where}.severity must be one of ('high', 'medium', 'low')"
            )
        parsed_suggestions.append({
            "issue": _short(str(suggestion.get("issue", "")), f"{where}.issue"),
            "suggestion": _short(
                str(suggestion.get("suggestion", "")), f"{where}.suggestion"
            ),
            "reason": _short(str(suggestion.get("reason", "")), f"{where}.reason"),
            "severity": severity,
        })

    return {
        "overall_score": overall,
        "dimensions": parsed_dimensions,
        "suggestions": parsed_suggestions,
        "confidence": _parse_confidence(payload.get("confidence")),
        "open_questions": _string_list(
            payload.get("open_questions"), "open_questions", _MAX_OPEN_QUESTIONS
        ),
    }


# ---------------------------------------------------------------------------
# 1. Brief generation: deterministic derivation from understanding (+ optional
#    research). Consumes ENG-UND-017 output; never re-classifies intent.


def _enum_or(mapping: Mapping[str, Any], key: str, choices: tuple[str, ...],
             default: str) -> str:
    value = str(mapping.get(key, "")).strip()
    return value if value in choices else default


def _content_type_from(understanding: Mapping[str, Any]) -> str:
    haystack = " ".join(
        [str(understanding.get("intent", {}).get("reason", ""))]
        + [str(g) for g in understanding.get("goals", [])]
        + [str(d) for d in understanding.get("deliverables", [])]
    ).lower()
    for content_type, patterns in _CONTENT_TYPE_SIGNALS:
        if any(re.search(p, haystack, re.IGNORECASE) for p in patterns):
            return content_type
    return "unknown"


def _tone_from(understanding: Mapping[str, Any]) -> str:
    audience = str(understanding.get("audience", "unknown"))
    kind = str(understanding.get("intent", {}).get("kind", ""))
    if audience == "technical" or kind == "development_task":
        return "instructional"
    if audience == "general":
        return "conversational"
    if audience == "internal":
        return "neutral"
    return "formal" if audience == "owner" else "neutral"


def _length_from(understanding: Mapping[str, Any]) -> str:
    constraints = " ".join(str(c) for c in understanding.get("constraints", [])).lower()
    if re.search(r"\bshort\b|\bbrief\b|مختصر|قصير", constraints):
        return "short"
    if re.search(r"\blong\b|\bin.?depth\b|مطول|مفصل|شامل", constraints):
        return "long"
    return "medium"


def _brief_confidence(understanding: Mapping[str, Any],
                      research: Mapping[str, Any] | None) -> dict[str, str]:
    level = str(understanding.get("confidence", {}).get("level", "low"))
    if research is not None and research.get("facts"):
        level = {"low": "medium", "medium": "high", "high": "high"}[level]
    basis = str(understanding.get("confidence", {}).get("basis", ""))
    if research is not None and research.get("facts"):
        basis = (basis + "; research facts available").strip("; ")
    basis = " ".join(basis.split()[:_MAX_FIELD_WORDS]) or "brief derived from supplied understanding"
    return {"level": level if level in _CONFIDENCE_LEVELS else "low", "basis": basis}


def generate_brief(
    understanding: Mapping[str, Any],
    research: Mapping[str, Any] | None = None,
    title: str = "",
) -> dict[str, Any]:
    """Derive a validated writing brief from an understanding object.

    Deterministic and offline: goals/audience/constraints are carried over
    verbatim from the understanding (never re-extracted); key messages come
    from research key_terms/consensus when a report is supplied, else from
    the understanding goals; tone/length/content_type are decided by bounded
    rules over the understanding. The result is validated through
    parse_writing_brief before return.
    """
    if not isinstance(understanding, Mapping):
        raise WritingError("writing.generate_brief expects an understanding object")

    goals = [str(g) for g in understanding.get("goals", [])][: _MAX_GOALS]
    key_messages: list[str] = []
    if isinstance(research, Mapping):
        for term in research.get("analysis", {}).get("key_terms", []):
            if len(key_messages) >= _MAX_KEY_MESSAGES:
                break
            key_messages.append(f"research highlights: {term}")
        for consensus in research.get("analysis", {}).get("consensus", [])[: _MAX_KEY_MESSAGES]:
            if len(key_messages) >= _MAX_KEY_MESSAGES:
                break
            key_messages.append(consensus)
    if not key_messages:
        key_messages = [f"deliver on goal: {g}" for g in goals[: _MAX_KEY_MESSAGES]]

    constraints = [str(c) for c in understanding.get("constraints", [])][: _MAX_CONSTRAINTS]

    open_questions = [
        str(q) for q in understanding.get("open_questions", [])
    ][: _MAX_OPEN_QUESTIONS]
    if not goals:
        open_questions.append("goals UNKNOWN — no understanding goals to anchor the brief")

    content_type = _content_type_from(understanding)
    if content_type == "unknown":
        open_questions.append(
            "content_type UNKNOWN — no story/article/video wording found; defaulted"
        )

    brief_title = title.strip() or (
        f"{content_type} brief for: {'; '.join(goals[:1]) or 'unnamed goal'}"
    )

    return parse_writing_brief({
        "title": brief_title,
        "content_type": content_type,
        "audience": _enum_or(understanding, "audience", _AUDIENCES, "unknown"),
        "goals": goals,
        "key_messages": key_messages[: _MAX_KEY_MESSAGES],
        "constraints": constraints,
        "tone": _tone_from(understanding),
        "target_length": _length_from(understanding),
        "confidence": _brief_confidence(understanding, research),
        "open_questions": open_questions[: _MAX_OPEN_QUESTIONS],
    })


# ---------------------------------------------------------------------------
# 2. Narrative arc / beat sheet: structural planning only. Beats name what a
#    section must accomplish — this engine never writes the section.

def build_structure(brief: Mapping[str, Any]) -> dict[str, Any]:
    """Build a deterministic arc + beat sheet for a validated brief.

    Arc choice: content_type "story"/"video_script" -> three_act;
    "article"/"social" -> inverted_pyramid or listicle when list wording
    appears in the goals; "presentation"/"documentation" -> sequential;
    otherwise three_act as the least-assumptive arc. Each beat's purpose is
    a structural instruction ("establish X", "pay off Y") derived from the
    brief's goals and key messages — bounded and inspectable, never prose.
    """
    if not isinstance(brief, Mapping):
        raise WritingError("writing.build_structure expects a brief object")
    brief = parse_writing_brief(brief)

    goals = brief["goals"]
    key_messages = brief["key_messages"]
    subject = goals[0] if goals else brief["title"]
    support = key_messages[0] if key_messages else subject

    content_type = brief["content_type"]
    goals_text = " ".join(goals).lower()
    if content_type in ("story", "video_script"):
        arc = "three_act"
    elif content_type in ("article", "social"):
        arc = "listicle" if re.search(r"\blist\b|\btips?\b|\bways?\b|\bsteps?\b|أفكار|نصائح|خطوات", goals_text) else "inverted_pyramid"
    elif content_type in ("presentation", "documentation"):
        arc = "sequential"
    else:
        arc = "three_act"

    roles = _ARC_BEATS[arc]
    beats: list[dict[str, Any]] = []
    n = len(roles)
    for index, role in enumerate(roles):
        if role in ("hook", "inciting_incident"):
            purpose = f"open with the stakes of: {subject}"
        elif role == "setup":
            purpose = f"establish context and audience for: {subject}"
        elif role == "rising_action":
            purpose = f"develop the core of: {subject}"
        elif role == "midpoint":
            purpose = f"reframe the stakes of: {subject} around: {support}"
        elif role == "complication":
            purpose = f"surface the main obstacle to: {subject}"
        elif role == "climax":
            purpose = f"deliver the decisive moment of: {subject}"
        elif role == "resolution":
            purpose = f"land the outcome of: {subject}"
        elif role == "call_to_action":
            purpose = f"tell the {brief['audience']} audience what to do next about: {subject}"
        elif role == "context":
            purpose = f"give background the {brief['audience']} audience needs for: {subject}"
        elif role == "evidence":
            purpose = f"support: {support}"
        else:  # takeaway
            purpose = f"close by restating the key message: {support}"
        purpose = " ".join(purpose.split()[:_MAX_FIELD_WORDS])
        beats.append({"order": index + 1, "role": role, "purpose": purpose})

    return parse_structure({
        "content_type": content_type,
        "arc": arc,
        "beats": beats,
    })


# ---------------------------------------------------------------------------
# 3. Scene / sequence planning: group beats into ordered sequences with a
#    purpose, a setting hint, and the beats each sequence must cover.

def plan_scenes(
    structure: Mapping[str, Any],
    brief: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Group a beat sheet into 2..8 ordered sequences (structural planning).

    Deterministic partition: consecutive beats are packed into sequences of
    equal size (larger remainder goes to the earlier sequences); each
    sequence's purpose names the roles it covers and the beat purposes it
    carries; the setting hint is structural ("opening context", "main
    development", "closing") — never invented locations. Every beat is
    covered exactly once; coverage is verified by the gate, not assumed.
    """
    if not isinstance(structure, Mapping):
        raise WritingError("writing.plan_scenes expects a structure object")
    structure = parse_structure(structure)
    brief = parse_writing_brief(brief) if isinstance(brief, Mapping) else None

    beats = structure["beats"]
    n = len(beats)
    seq_count = min(_MAX_SEQUENCES, max(_MIN_SEQUENCES, round(n / 2)))
    base, extra = divmod(n, seq_count)

    sequences: list[dict[str, Any]] = []
    cursor = 0
    for seq_index in range(seq_count):
        size = base + (1 if seq_index < extra else 0)
        group = beats[cursor: cursor + size]
        cursor += size
        if not group:
            continue
        roles = [b["role"] for b in group]
        purpose_bits = " + ".join(dict.fromkeys(roles))
        anchor = group[0]["purpose"]
        purpose = f"sequence covers {purpose_bits}; begins: {anchor}"
        purpose = " ".join(purpose.split()[:_MAX_FIELD_WORDS])
        if seq_index == 0:
            setting = "opening context"
        elif seq_index == seq_count - 1:
            setting = "closing"
        else:
            setting = "main development"
        sequences.append({
            "order": seq_index + 1,
            "purpose": purpose,
            "setting": setting,
            "beats_covered": [b["order"] for b in group],
        })

    plan = parse_scene_plan({
        "content_type": structure["content_type"],
        "sequences": sequences,
    })
    if brief is not None:
        plan["audience"] = brief["audience"]
        plan["target_length"] = brief["target_length"]
    return plan


# ---------------------------------------------------------------------------
# 4. Script evaluation: deterministic scored critique with explicit reasons.

def _script_stats(script_text: str) -> dict[str, Any]:
    paragraphs = [p for p in re.split(r"\n\s*\n", script_text) if p.strip()]
    sentences = [
        " ".join(s.split())
        for s in _CLAUSE_SPLIT.split(script_text)
        if s.strip(" ,،\t")
    ]
    words = _WORD.findall(script_text)
    dialogue_lines = [
        line for line in script_text.splitlines()
        if _DIALOGUE_LINE.match(line) and line.strip()
    ]
    return {
        "word_count": len(words),
        "paragraphs": len(paragraphs),
        "sentences": sentences,
        "sentence_count": len(sentences),
        "dialogue_lines": len(dialogue_lines),
        "avg_sentence_words": (
            round(len(words) / len(sentences), 1) if sentences else 0.0
        ),
    }


def _brief_tokens(brief: Mapping[str, Any]) -> set[str]:
    tokens: set[str] = set()
    for field in ("goals", "key_messages", "title"):
        value = brief.get(field)
        if isinstance(value, str):
            tokens |= _tokens(value)
        elif isinstance(value, list):
            for item in value:
                tokens |= _tokens(str(item))
    return tokens


def evaluate_script(
    script_text: str,
    brief: Mapping[str, Any],
    structure: Mapping[str, Any] | None = None,
    research: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Score a draft script against its brief with explicit reasons.

    Five deterministic dimensions, each 0..100 with human-readable reasons:
      alignment    — content-token overlap between brief goals/key messages
                     and the draft; misses are named, not just counted
      structure    — when a beat sheet is supplied: how many beat purposes
                     share tokens with the draft (did the draft actually
                     cover the planned structure?)
      readability  — sentence length discipline and paragraph density
      dialogue     — story/video_script drafts are expected to carry spoken
                     lines; other types are scored neutral (50) so the
                     dimension never punishes non-dialogue formats
      grounding    — when a research report is supplied: fraction of key
                     terms present in the draft; without research, scored
                     neutral with an explicit reason
    overall = rounded mean. Every score below 100 names its reason; nothing
    here edits the draft — improvement feedback is improve_script's job.
    """
    if not isinstance(brief, Mapping):
        raise WritingError("writing.evaluate_script expects a brief object")
    brief = parse_writing_brief(brief)
    script_text = script_text or ""
    if not script_text.strip():
        raise WritingError("writing.evaluate_script expects a non-empty draft")

    stats = _script_stats(script_text)
    script_tokens = _tokens(script_text)
    dimensions: list[dict[str, Any]] = []
    suggestions: list[dict[str, str]] = []

    # -- alignment
    brief_toks = _brief_tokens(brief)
    hit = brief_toks & script_tokens
    alignment = round(100 * len(hit) / len(brief_toks)) if brief_toks else 50
    alignment_reasons: list[str] = []
    if brief_toks:
        alignment_reasons.append(
            f"{len(hit)}/{len(brief_toks)} brief themes appear in the draft"
        )
        missing = sorted(brief_toks - hit)[:3]
        if missing:
            alignment_reasons.append(f"themes not present yet: {', '.join(missing)}")
            suggestions.append({
                "issue": f"draft misses brief themes: {', '.join(missing)}",
                "suggestion": f"work the missing themes into a section addressing: {brief['goals'][0] if brief['goals'] else brief['title']}",
                "reason": "a draft that ignores its brief's goals is off-brief by definition",
                "severity": "high" if alignment < 50 else "medium",
            })
    else:
        alignment_reasons.append("brief carries no content themes; scored neutral")
    dimensions.append({"name": "alignment", "score": min(100, alignment),
                       "reasons": alignment_reasons})

    # -- structure
    structure_reasons: list[str] = []
    if isinstance(structure, Mapping):
        parsed_structure = parse_structure(structure)
        covered = 0
        uncovered: list[str] = []
        for beat in parsed_structure["beats"]:
            if _tokens(beat["purpose"]) & script_tokens:
                covered += 1
            else:
                uncovered.append(beat["role"])
        structure_score = round(100 * covered / len(parsed_structure["beats"]))
        structure_reasons.append(
            f"{covered}/{len(parsed_structure['beats'])} planned beats are visible in the draft"
        )
        if uncovered:
            structure_reasons.append(f"beats with no visible trace: {', '.join(uncovered[:4])}")
            suggestions.append({
                "issue": f"planned beats missing from draft: {', '.join(uncovered[:4])}",
                "suggestion": "add a section per missing beat or revise the beat sheet to match what the draft actually does",
                "reason": "the beat sheet is the contract between plan and draft; silent divergence means the plan is stale",
                "severity": "medium",
            })
    else:
        structure_score = 50
        structure_reasons.append("no beat sheet supplied; structure scored neutral")
    dimensions.append({"name": "structure", "score": structure_score,
                       "reasons": structure_reasons})

    # -- readability
    readability_reasons: list[str] = []
    avg = stats["avg_sentence_words"]
    long_sentences = sum(1 for s in stats["sentences"] if len(s.split()) > 25)
    readability = 100
    if avg > 20:
        readability -= 30
        readability_reasons.append(f"average sentence is {avg} words (>20); tighten")
        suggestions.append({
            "issue": f"long average sentence length ({avg} words)",
            "suggestion": "split sentences longer than 20 words; one idea per sentence",
            "reason": f"long sentences reduce readability for a {brief['audience']} audience",
            "severity": "medium",
        })
    else:
        readability_reasons.append(f"average sentence is {avg} words; within discipline")
    if stats["sentence_count"] and long_sentences / stats["sentence_count"] > 0.2:
        readability -= 20
        readability_reasons.append(
            f"{long_sentences} sentences exceed 25 words (>20% of draft)"
        )
    if stats["paragraphs"] and stats["word_count"] / stats["paragraphs"] > 120:
        readability -= 15
        readability_reasons.append(
            f"paragraphs average {round(stats['word_count'] / stats['paragraphs'])} words; break them up"
        )
        suggestions.append({
            "issue": "overlong paragraphs",
            "suggestion": "keep paragraphs under ~100 words; one point per paragraph",
            "reason": "dense paragraphs lose readers regardless of content quality",
            "severity": "low",
        })
    readability = max(0, readability)
    if len(readability_reasons) == 1:
        readability = 100
    dimensions.append({"name": "readability", "score": readability,
                       "reasons": readability_reasons})

    # -- dialogue
    dialogue_reasons: list[str] = []
    if brief["content_type"] in ("story", "video_script"):
        if stats["sentence_count"]:
            ratio = stats["dialogue_lines"] / max(1, len(script_text.splitlines()))
        else:
            ratio = 0.0
        dialogue_score = min(100, round(200 * ratio)) if ratio < 0.5 else 100
        if stats["dialogue_lines"] == 0:
            dialogue_score = 10
            dialogue_reasons.append("no dialogue lines detected in a dialogue format")
            suggestions.append({
                "issue": "script format carries no dialogue",
                "suggestion": "add spoken lines ('Character: line') for the key beats",
                "reason": f"{brief['content_type']} is performed, not read; without dialogue there is nothing to perform",
                "severity": "high",
            })
        else:
            dialogue_reasons.append(
                f"{stats['dialogue_lines']} dialogue lines detected"
            )
    else:
        dialogue_score = 50
        dialogue_reasons.append(
            f"{brief['content_type']} is not a dialogue format; scored neutral"
        )
    dimensions.append({"name": "dialogue", "score": dialogue_score,
                       "reasons": dialogue_reasons})

    # -- grounding
    grounding_reasons: list[str] = []
    if isinstance(research, Mapping) and research.get("analysis", {}).get("key_terms"):
        key_terms = [str(t) for t in research["analysis"]["key_terms"]]
        present = [t for t in key_terms if t.lower() in script_text.lower()]
        grounding_score = round(100 * len(present) / len(key_terms)) if key_terms else 50
        grounding_reasons.append(
            f"{len(present)}/{len(key_terms)} research key terms present in draft"
        )
        absent = [t for t in key_terms if t not in present][:3]
        if absent:
            grounding_reasons.append(f"grounded terms absent: {', '.join(absent)}")
            low_conf = [f for f in research.get("facts", [])
                        if isinstance(f, Mapping) and f.get("uncertainty") == "low"]
            if low_conf:
                suggestions.append({
                    "issue": f"research-supported terms unused: {', '.join(absent)}",
                    "suggestion": f"anchor a section in the strongest evidence: {low_conf[0]['claim'][:60]}",
                    "reason": "research with low-uncertainty facts was supplied; ignoring it wastes verified evidence",
                    "severity": "low",
                })
    else:
        grounding_score = 50
        grounding_reasons.append("no research key terms supplied; grounding scored neutral")
    dimensions.append({"name": "grounding", "score": grounding_score,
                       "reasons": grounding_reasons})

    # -- length target (folded into alignment reasons, not its own dimension)
    target = _TARGET_WORDS[brief["target_length"]]
    if stats["word_count"] > 2 * target:
        suggestions.append({
            "issue": f"draft is {stats['word_count']} words vs {target}-word {brief['target_length']} target",
            "suggestion": "cut or split the draft; the target length is a brief constraint",
            "reason": "brief constraints are binding on the draft; length is the easiest one to check",
            "severity": "medium",
        })

    overall = round(
        sum(d["score"] for d in dimensions) / len(dimensions)
    )

    open_questions: list[str] = []
    if not isinstance(structure, Mapping):
        open_questions.append("structure UNKNOWN — no beat sheet supplied; structure scored neutral")
    if not isinstance(research, Mapping):
        open_questions.append("grounding UNKNOWN — no research report supplied; grounding scored neutral")

    return parse_evaluation({
        "overall_score": overall,
        "dimensions": dimensions,
        "suggestions": suggestions[: _MAX_SUGGESTIONS],
        "confidence": {
            "level": {"high": "high", "medium": "medium"}.get(
                brief["confidence"]["level"], "low"
            ),
            "basis": f"draft of {stats['word_count']} words scored against brief '{brief['title'][:30]}'",
        },
        "open_questions": open_questions[: _MAX_OPEN_QUESTIONS],
    })


def improve_script(
    script_text: str,
    brief: Mapping[str, Any],
    structure: Mapping[str, Any] | None = None,
    research: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Improvement feedback for a draft: the actionable subset of evaluation.

    Returns the evaluation plus a prioritized action list — highest-severity
    suggestions first, ties broken by dimension order — so a writer can work
    top-down. Feedback only: this engine never rewrites the draft.
    """
    evaluation = evaluate_script(script_text, brief, structure, research)
    severity_rank = {"high": 0, "medium": 1, "low": 2}
    actions = sorted(
        evaluation["suggestions"],
        key=lambda s: (severity_rank[s["severity"]], s["issue"]),
    )
    return {
        "evaluation": evaluation,
        "actions": actions,
        "ready_to_publish": (
            evaluation["overall_score"] >= 80 and not evaluation["suggestions"]
        ),
    }


# ---------------------------------------------------------------------------
# Deterministic consistency gates over a writing document (brief + structure +
# scene plan + optional draft) and the brief it claims to serve. Failures are
# reasons (empty = pass); nothing here weakens or replaces canonical
# validation.

def run_writing_gates(
    document: Mapping[str, Any],
    brief: Mapping[str, Any],
) -> list[str]:
    """Consistency gates: beat purposes relate to brief goals; beat orders are
    unique and contiguous; every beat is covered by exactly one sequence;
    scene plan references this brief's content_type; the brief's confidence
    basis is grounded in the brief itself."""
    failures: list[str] = []
    if not isinstance(document, Mapping):
        return ["document must be an object"]
    if not isinstance(brief, Mapping):
        return ["brief must be an object"]

    goals = [str(g) for g in brief.get("goals", [])]
    goal_tokens: set[str] = set()
    for goal in goals:
        goal_tokens |= _tokens(goal)

    beats = document.get("beats") or []
    if beats:
        orders = [b.get("order") for b in beats if isinstance(b, Mapping)]
        if len(set(orders)) != len(orders):
            failures.append("beat orders contain duplicates")
        if sorted(int(o) for o in orders) != list(range(1, len(orders) + 1)):
            failures.append("beat orders are not contiguous 1..n")
        for beat in beats:
            if not isinstance(beat, Mapping):
                failures.append("beat entry is not an object")
                continue
            purpose_tokens = _tokens(str(beat.get("purpose", "")))
            if goal_tokens and not (
                purpose_tokens & goal_tokens
                or any(t in str(beat.get("purpose", "")).lower() for t in goal_tokens if len(t) >= 4)
            ):
                failures.append(
                    f"beat '{str(beat.get('role', '?'))}' purpose does not relate to any brief goal"
                )

    sequences = document.get("sequences") or []
    if sequences and beats:
        beat_orders = {b.get("order") for b in beats if isinstance(b, Mapping)}
        covered: list[Any] = []
        for sequence in sequences:
            if not isinstance(sequence, Mapping):
                failures.append("sequence entry is not an object")
                continue
            for b in sequence.get("beats_covered", []):
                if b not in beat_orders:
                    failures.append(f"sequence covers unknown beat order {b}")
                covered.append(b)
        duplicates = sorted({b for b in covered if covered.count(b) > 1})
        if duplicates:
            failures.append(f"beats covered more than once: {duplicates}")
        missing = sorted(beat_orders - set(covered))
        if missing:
            failures.append(f"beats not covered by any sequence: {missing}")

    if sequences:
        plan_type = str(document.get("content_type", ""))
        brief_type = str(brief.get("content_type", ""))
        if plan_type and brief_type and plan_type != brief_type:
            failures.append(
                f"plan content_type '{plan_type}' disagrees with brief '{brief_type}'"
            )

    basis = str(brief.get("confidence", {}).get("basis", "")).lower()
    grounded = any(
        token in basis
        for token in " ".join(goals).lower().split()
        if len(token) >= 6
    )
    if not grounded:
        for token in _brief_tokens(brief):
            if len(token) >= 4 and token in basis:
                grounded = True
                break
    if not grounded:
        failures.append(
            "confidence basis is not grounded in the brief's goals or title"
        )

    return failures


def writing_readiness(
    document: Mapping[str, Any],
    gate_failures: list[str],
) -> dict[str, Any]:
    """Writing readiness seal. READY requires clean gates, at least one beat,
    and full beat coverage by sequences — a writing plan without structure is
    a plan to improvise, which this engine refuses to bless."""
    blocking = list(gate_failures)
    if not isinstance(document, Mapping):
        return {
            "ready": False,
            "blocking_items": blocking + ["document must be an object"],
            "seal": {"authority_preserved": True},
        }
    beats = document.get("beats") or []
    sequences = document.get("sequences") or []
    if not beats:
        blocking.append("no beats — writing plan has no structure")
    if beats and not sequences:
        blocking.append("no sequences — beats are not planned into scenes")
    covered = {
        b
        for s in sequences
        if isinstance(s, Mapping)
        for b in s.get("beats_covered", [])
    }
    beat_orders = {b.get("order") for b in beats if isinstance(b, Mapping)}
    if beat_orders and beat_orders - covered:
        blocking.append("beat coverage incomplete — every beat needs a sequence")
    ready = not blocking
    return {
        "ready": ready,
        "blocking_items": blocking,
        "seal": {
            "structure_planned": bool(beats),
            "scenes_planned": bool(sequences),
            "coverage_complete": not (beat_orders - covered),
            "gates_clean": not gate_failures,
            "authority_preserved": True,  # advisory engine only
        },
    }
