"""Canonical AFAQ AI composition layer.

AFAQ AI is not a new isolated model. It composes the existing AFAQ intelligence
core, capability planner, governed runtime, and live engine fabric into one
goal -> plan -> execute -> evidence surface.

AFAQ AI is the primary intelligence system. External model runtimes may be
attached as optional subordinate capabilities, but AFAQ AI does not depend on,
identify as, or default to Ollama or any other model provider.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import threading
from pathlib import Path
from typing import Any, Mapping, Sequence
import base64
import hashlib
import hmac
import json
import secrets


from afaq_intelligence_core import (
    AfaqLearningAgent,
    AgentContext,
    AgentTask,
    Evaluation,
    MemoryEvidence,
    MemoryScope,
    MemoryService,
    MemoryStore,
    MemoryType,
    SqliteMemoryStore,
)

from .capability_planner import CapabilityPlan, CapabilityPlanner, capability_catalog
from .orchestrator import AfaqOrchestrator
from .native_generator import native_generator_status


@dataclass(frozen=True)
class AfaqAIEngineSummary:
    total: int
    active: int
    operationally_proven: int
    runtime_implemented: int


@dataclass(frozen=True)
class AfaqAIResult:
    goal: str
    plan: dict[str, Any]
    executions: tuple[dict[str, Any], ...]
    completed: bool
    blocked: bool
    evidence_refs: tuple[str, ...]
    memory_ids: tuple[str, ...] = ()


@dataclass(frozen=True)
class AfaqAIGenerationResult:
    name: str
    kind: str
    goal: str
    manifest_path: str
    evidence_path: str
    intelligence: str
    engine_count: int
    capability_count: int


@dataclass(frozen=True)
class _NativePlanStep:
    tool: str
    objective: str
    args: dict[str, Any]


class AfaqNativePlanner:
    """Native deterministic planner over AFAQ capabilities."""

    _ACTION_HINTS: dict[str, tuple[str, ...]] = {
        "mission_model": ("mission", "model mission", "نمذجة المهمة", "حلل المهمة", "افهم المهمة"),
        "capability_compose": ("compose capabilities", "تركيب القدرات", "ادمج القدرات"),
        "mission_graph": ("mission graph", "نفذ مهمة مركبة", "مخطط المهمة"),
        "result_fuse": ("fuse results", "دمج النتائج", "ادمج النتائج"),
        "context_adapt": ("context", "environment", "السياق", "البيئة", "الموارد"),
        "capability_discover": ("discover capabilities", "اكتشف القدرات", "اعرض القدرات"),
        "gap_resolve": ("capability gap", "فجوة القدرات", "اثبت الفجوة"),
        "evidence_verify": ("verify evidence", "تحقق من الأدلة", "تدقيق الأدلة"),
        "research_synthesize": ("research synthesis", "تركيب البحث", "لخص البحث", "حلل البحث"),
        "causal_falsify": ("causal", "falsify", "سببية", "دحض الفرضيات", "اختبر الفرضيات"),
        "scenario_forecast": ("forecast", "scenario", "توقع", "سيناريو", "استشراف"),
        "continuous_observe": ("observe source", "راقب المصدر", "رصد المصدر"),
        "continuous_compare": ("compare snapshots", "قارن التغييرات", "كشف التغيير"),
        "frontier_discover": ("frontier", "emerging", "اكتشف الجديد", "التقنيات الناشئة"),
        "benchmark_observe": ("benchmark", "مقارنة معيارية", "اختبار معياري"),
        "research_portfolio": ("research portfolio", "محفظة البحث", "أولويات البحث"),
        "goal_form": ("form goals", "صياغة الأهداف", "اقترح أهداف", "كوّن أهداف"),
        "performance_recommend": ("recommend performance", "اختر الأفضل", "أفضل أداء"),
        "performance_optimize": ("optimize performance", "حسن الأداء", "تحسين الأداء"),
        "web_explore": ("web explore", "استكشف الويب", "استكشف الموقع"),
        "web_fetch": ("fetch url", "اجلب الرابط", "اقرأ الرابط"),
        "browser_execute": ("browser", "متصفح", "افتح الموقع"),
        "engine_invoke": ("engine", "محرك", "نفذ المحرك", "شغل المحرك"),
        "capability_invoke": ("capability", "قدرة", "نفذ القدرة", "شغل القدرة"),
    }

    @staticmethod
    def _tokens(value: str) -> set[str]:
        normalized = "".join(
            ch.lower() if ch.isalnum() else " "
            for ch in str(value)
        )
        return {token for token in normalized.split() if len(token) > 1}

    def plan(self, goal: str, tools: list[str], context: dict | None = None) -> list[_NativePlanStep]:
        goal_tokens = self._tokens(goal)
        rows = []
        if isinstance(context, Mapping):
            rows = context.get("capability_catalog") or (context.get("afaq_ai") or {}).get("capability_catalog") or []
        catalog = {
            str(row.get("action")): row
            for row in rows
            if isinstance(row, Mapping) and row.get("action")
        }

        request_context = {}
        if isinstance(context, Mapping) and isinstance(context.get("request_context"), Mapping):
            request_context = dict(context["request_context"])
        capability_args = request_context.get("capability_args") or {}
        if not isinstance(capability_args, Mapping):
            capability_args = {}

        # Registry capabilities are not flattened into thousands of planner tools.
        # They remain one governed execution primitive, capability_invoke, while
        # the actual capability identity is selected dynamically from registry truth.
        registry_rows = []
        afaq_context = request_context.get("afaq_ai")
        if isinstance(afaq_context, Mapping):
            registry_rows = [
                dict(row)
                for row in (afaq_context.get("capability_catalog") or [])
                if isinstance(row, Mapping)
                and row.get("kind") == "registry_capability"
                and row.get("name")
            ]

        registry_match = None
        if "capability_invoke" in tools and registry_rows:
            ranked_registry = []
            for row in registry_rows:
                name = str(row.get("name") or "")
                capability_id = str(row.get("capability_id") or "")
                score = len(goal_tokens & self._tokens(
                    " ".join([name, capability_id])
                ))
                if name.lower() in str(goal).lower():
                    score += 4
                if capability_id and capability_id.lower() in str(goal).lower():
                    score += 6
                ranked_registry.append((score, name, row))
            ranked_registry.sort(key=lambda item: (-item[0], item[1]))
            if ranked_registry and ranked_registry[0][0] > 0:
                registry_match = ranked_registry[0][2]

        if registry_match is not None:
            explicit = capability_args.get("capability_invoke")
            supplied = dict(explicit) if isinstance(explicit, Mapping) else {}
            supplied.setdefault("capability", str(registry_match["name"]))
            supplied.setdefault("payload", {})
            return [
                _NativePlanStep(
                    tool="capability_invoke",
                    objective=(
                        "Invoke registered AFAQ capability: "
                        + str(registry_match["name"])
                    ),
                    args=supplied,
                )
            ]

        scored = []
        goal_text = str(goal).lower()
        for tool in tools:
            row = dict(catalog.get(tool) or {})
            hints = self._ACTION_HINTS.get(tool, ())
            text = " ".join([tool, str(row.get("purpose") or ""), *hints])
            token_score = len(goal_tokens & self._tokens(text))
            phrase_score = sum(2 for hint in hints if str(hint).lower() in goal_text)
            explicit_score = 4 if tool in capability_args else 0
            scored.append((token_score + phrase_score + explicit_score, tool, row))

        scored.sort(key=lambda item: (-item[0], item[1]))
        selected = [item for item in scored if item[0] > 0][:4]
        if not selected:
            for fallback in ("status", "map", "search", "files"):
                if fallback in tools:
                    selected = [(0, fallback, dict(catalog.get(fallback) or {}))]
                    break
        if not selected and tools:
            selected = [(0, tools[0], dict(catalog.get(tools[0]) or {}))]

        return [
            _NativePlanStep(
                tool=tool,
                objective=str(row.get("purpose") or f"AFAQ native capability: {tool}"),
                args=(
                    dict(capability_args.get(tool) or {})
                    if isinstance(capability_args.get(tool), Mapping)
                    else {}
                ),
            )
            for _, tool, row in selected
        ]



AFAQ_AI_API_PREFIX = "/api/v1/afaq-ai"
_AFAQ_AI_KEY_SCHEMA = "AFAQ_AI_API_KEYS_V1"
_DEFAULT_SCOPES = ("read", "plan", "run", "generate")
_ALLOWED_SCOPES = _DEFAULT_SCOPES + ("promote",)


@dataclass(frozen=True)
class AfaqAIAPIKey:
    key_id: str
    name: str
    prefix: str
    scopes: tuple[str, ...]
    created_at: str
    revoked: bool = False


@dataclass(frozen=True)
class AfaqAIAPIKeySecret:
    key: AfaqAIAPIKey
    secret: str


class AfaqAIAPIKeyStore:
    """Hashed local API-key store for AFAQ AI.

    Plaintext API keys are returned only once by create and are never
    persisted. Verification uses scrypt plus constant-time comparison.
    """

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self._write({"schema": _AFAQ_AI_KEY_SCHEMA, "keys": []})

    def _read(self) -> dict[str, Any]:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise RuntimeError("AFAQ_AI_API_KEY_STORE_UNREADABLE") from exc
        if data.get("schema") != _AFAQ_AI_KEY_SCHEMA or not isinstance(data.get("keys"), list):
            raise RuntimeError("AFAQ_AI_API_KEY_STORE_INVALID")
        return data

    def _write(self, data: Mapping[str, Any]) -> None:
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(dict(data), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        tmp.replace(self.path)

    @staticmethod
    def _derive(secret: str, salt_b64: str) -> str:
        salt = base64.urlsafe_b64decode(salt_b64.encode("ascii"))
        digest = hashlib.scrypt(
            secret.encode("utf-8"),
            salt=salt,
            n=2**14,
            r=8,
            p=1,
            dklen=32,
        )
        return base64.urlsafe_b64encode(digest).decode("ascii")

    @staticmethod
    def _normalize_scopes(scopes: Sequence[str] | None) -> tuple[str, ...]:
        allowed = set(_ALLOWED_SCOPES)
        requested = tuple(dict.fromkeys(
            str(s).strip().lower()
            for s in (scopes or _DEFAULT_SCOPES)
            if str(s).strip()
        ))
        if not requested:
            raise ValueError("at least one API scope is required")
        invalid = sorted(set(requested) - allowed)
        if invalid:
            raise ValueError(f"unsupported API scopes: {invalid}")
        return requested

    def create(
        self,
        name: str,
        *,
        scopes: Sequence[str] | None = None,
    ) -> AfaqAIAPIKeySecret:
        label = str(name or "").strip()
        if not label:
            raise ValueError("API key name is required")
        normalized_scopes = self._normalize_scopes(scopes)
        key_id = "afaq_" + secrets.token_hex(8)
        raw_secret = secrets.token_urlsafe(32)
        secret = f"{key_id}.{raw_secret}"
        prefix = secret[:18]
        salt_b64 = base64.urlsafe_b64encode(secrets.token_bytes(16)).decode("ascii")
        digest_b64 = self._derive(secret, salt_b64)
        created_at = datetime.now(timezone.utc).isoformat()

        data = self._read()
        data["keys"].append({
            "key_id": key_id,
            "name": label,
            "prefix": prefix,
            "scopes": list(normalized_scopes),
            "created_at": created_at,
            "revoked": False,
            "salt": salt_b64,
            "digest": digest_b64,
        })
        self._write(data)
        return AfaqAIAPIKeySecret(
            key=AfaqAIAPIKey(
                key_id=key_id,
                name=label,
                prefix=prefix,
                scopes=normalized_scopes,
                created_at=created_at,
                revoked=False,
            ),
            secret=secret,
        )

    def list(self) -> tuple[AfaqAIAPIKey, ...]:
        rows = []
        for row in self._read()["keys"]:
            rows.append(AfaqAIAPIKey(
                key_id=str(row["key_id"]),
                name=str(row["name"]),
                prefix=str(row["prefix"]),
                scopes=tuple(str(x) for x in row.get("scopes") or ()),
                created_at=str(row["created_at"]),
                revoked=bool(row.get("revoked")),
            ))
        return tuple(rows)

    def revoke(self, key_id: str) -> bool:
        data = self._read()
        changed = False
        for row in data["keys"]:
            if row.get("key_id") == key_id and not row.get("revoked"):
                row["revoked"] = True
                row["revoked_at"] = datetime.now(timezone.utc).isoformat()
                changed = True
        if changed:
            self._write(data)
        return changed

    def verify(self, secret: str, *, required_scope: str) -> AfaqAIAPIKey | None:
        candidate = str(secret or "").strip()
        if "." not in candidate:
            return None
        key_id = candidate.split(".", 1)[0]
        for row in self._read()["keys"]:
            if row.get("key_id") != key_id or row.get("revoked"):
                continue
            scopes = tuple(str(x) for x in row.get("scopes") or ())
            if required_scope not in scopes:
                return None
            expected = str(row.get("digest") or "")
            actual = self._derive(candidate, str(row.get("salt") or ""))
            if not hmac.compare_digest(expected, actual):
                return None
            return AfaqAIAPIKey(
                key_id=key_id,
                name=str(row["name"]),
                prefix=str(row["prefix"]),
                scopes=scopes,
                created_at=str(row["created_at"]),
                revoked=False,
            )
        return None


@dataclass(frozen=True)
class AfaqAIAPIResponse:
    status: int
    body: dict[str, Any]


class AfaqAIAPI:
    """Transport-neutral AFAQ API protected by AFAQ API keys.

    Authentication grants access to an operation only. It never bypasses
    orchestrator governance or write approvals.
    """

    def __init__(
        self,
        ai: "AfaqAI",
        *,
        key_store: AfaqAIAPIKeyStore | None = None,
    ) -> None:
        self.ai = ai
        self.key_store = key_store or AfaqAIAPIKeyStore(
            ai.project_root / "var" / "afaq_ai" / "api_keys.json"
        )

    @staticmethod
    def routes() -> tuple[dict[str, str], ...]:
        return (
            {"method": "GET", "path": f"{AFAQ_AI_API_PREFIX}/health", "scope": "read"},
            {"method": "GET", "path": f"{AFAQ_AI_API_PREFIX}/status", "scope": "read"},
            {"method": "GET", "path": f"{AFAQ_AI_API_PREFIX}/engines", "scope": "read"},
            {"method": "GET", "path": f"{AFAQ_AI_API_PREFIX}/capabilities", "scope": "read"},
            {"method": "GET", "path": f"{AFAQ_AI_API_PREFIX}/memory", "scope": "read"},
            {"method": "POST", "path": f"{AFAQ_AI_API_PREFIX}/plan", "scope": "plan"},
            {"method": "POST", "path": f"{AFAQ_AI_API_PREFIX}/run", "scope": "run"},
            {"method": "POST", "path": f"{AFAQ_AI_API_PREFIX}/learn", "scope": "run"},
            {"method": "POST", "path": f"{AFAQ_AI_API_PREFIX}/develop", "scope": "run"},
            {"method": "POST", "path": f"{AFAQ_AI_API_PREFIX}/grow", "scope": "generate"},
            {"method": "POST", "path": f"{AFAQ_AI_API_PREFIX}/grow/autonomous", "scope": "promote"},
            {"method": "POST", "path": f"{AFAQ_AI_API_PREFIX}/grow/validate", "scope": "generate"},
            {"method": "POST", "path": f"{AFAQ_AI_API_PREFIX}/grow/promote", "scope": "promote"},
            {"method": "POST", "path": f"{AFAQ_AI_API_PREFIX}/grow/rollback", "scope": "promote"},
            {"method": "POST", "path": f"{AFAQ_AI_API_PREFIX}/capability", "scope": "run"},
            {"method": "POST", "path": f"{AFAQ_AI_API_PREFIX}/infer", "scope": "generate"},
            {"method": "POST", "path": f"{AFAQ_AI_API_PREFIX}/generate", "scope": "generate"},
        )

    def _auth(self, api_key: str, scope: str) -> AfaqAIAPIKey | None:
        return self.key_store.verify(api_key, required_scope=scope)

    def handle(
        self,
        method: str,
        path: str,
        *,
        api_key: str,
        body: Mapping[str, Any] | None = None,
    ) -> AfaqAIAPIResponse:
        method = str(method or "").upper()
        path = str(path or "")
        body = dict(body or {})

        route = next(
            (r for r in self.routes() if r["method"] == method and r["path"] == path),
            None,
        )
        if route is None:
            return AfaqAIAPIResponse(404, {
                "success": False,
                "error": {"code": "NOT_FOUND", "message": "AFAQ API route not found"},
            })

        actor = self._auth(api_key, route["scope"])
        if actor is None:
            return AfaqAIAPIResponse(401, {
                "success": False,
                "error": {
                    "code": "INVALID_API_KEY",
                    "message": "AFAQ API key is missing, invalid, revoked, or lacks scope",
                },
            })

        meta = {"apiKeyId": actor.key_id, "scope": route["scope"]}
        try:
            if method == "GET" and path.endswith("/health"):
                data = {
                    "ok": True,
                    "product": "AFAQ AI",
                    "api": "AFAQ API",
                    "prefix": AFAQ_AI_API_PREFIX,
                }
            elif method == "GET" and path.endswith("/status"):
                data = self.ai.status()
            elif method == "GET" and path.endswith("/engines"):
                data = {"engines": list(self.ai.engine_inventory())}
            elif method == "GET" and path.endswith("/capabilities"):
                data = {"capabilities": list(self.ai.capability_inventory())}
            elif method == "GET" and path.endswith("/memory"):
                data = {"memory": list(self.ai.memory_inventory())}
            elif method == "POST" and path.endswith("/plan"):
                goal = str(body.get("goal") or "").strip()
                plan = self.ai.plan(
                    goal,
                    context=body.get("context")
                    if isinstance(body.get("context"), Mapping)
                    else None,
                )
                data = plan.as_dict()
            elif method == "POST" and path.endswith("/run"):
                goal = str(body.get("goal") or "").strip()
                result = self.ai.run(
                    goal,
                    context=body.get("context")
                    if isinstance(body.get("context"), Mapping)
                    else None,
                    approved_by_job=bool(body.get("approved_by_job", False)),
                )
                data = {
                    "goal": result.goal,
                    "plan": result.plan,
                    "executions": list(result.executions),
                    "completed": result.completed,
                    "blocked": result.blocked,
                    "evidence_refs": list(result.evidence_refs),
                    "memory_ids": list(result.memory_ids),
                }
            elif method == "POST" and path.endswith("/learn"):
                goal = str(body.get("goal") or "").strip()
                data = self.ai.learn(
                    goal,
                    context=body.get("context")
                    if isinstance(body.get("context"), Mapping)
                    else None,
                    approved_by_job=bool(body.get("approved_by_job", False)),
                )
            elif method == "POST" and path.endswith("/develop"):
                topic = str(body.get("topic") or "").strip()
                sources = body.get("sources")
                if not isinstance(sources, list):
                    raise ValueError("sources must be an explicit list")
                data = self.ai.develop(
                    topic,
                    sources=sources,
                    approved_by_job=bool(body.get("approved_by_job", False)),
                )
                if data.get("status") != "COMPLETE":
                    return AfaqAIAPIResponse(409, {
                        "success": False,
                        "error": {
                            "code": "DEVELOPMENT_NOT_VERIFIED",
                            "message": str(data.get("reason") or "development not verified"),
                        },
                        "data": data,
                        "meta": meta,
                    })
            elif method == "POST" and path.endswith("/grow/autonomous"):
                requirement = body.get("requirement") or body
                test_payload = body.get("test_payload")
                if not isinstance(requirement, Mapping):
                    raise ValueError("requirement must be an object")
                if test_payload is not None and not isinstance(test_payload, Mapping):
                    raise ValueError("test_payload must be an object")
                data = self.ai.grow_capability_autonomous(
                    requirement,
                    test_payload=test_payload,
                    approved_by_job=bool(body.get("approved_by_job", False)),
                )
            elif method == "POST" and path.endswith("/grow/validate"):
                capability_id = str(body.get("capability_id") or "").strip()
                data = self.ai.validate_capability_candidate(capability_id)
                if data.get("status") != "SANDBOX_VALIDATED":
                    return AfaqAIAPIResponse(409, {
                        "success": False,
                        "error": {
                            "code": "CANDIDATE_SANDBOX_NOT_VALIDATED",
                            "message": str(data.get("reason") or "candidate sandbox validation failed"),
                        },
                        "data": data,
                        "meta": meta,
                    })
            elif method == "POST" and path.endswith("/grow/promote"):
                requirement = body.get("requirement")
                test_payload = body.get("test_payload")
                if not isinstance(requirement, Mapping):
                    raise ValueError("requirement must be an object")
                if not isinstance(test_payload, Mapping):
                    raise ValueError("test_payload must be an object")
                data = self.ai.promote_capability(
                    str(body.get("capability_id") or ""),
                    requirement=requirement,
                    test_payload=test_payload,
                )
                if data.get("status") != "ACTIVE_CERTIFIED_CAPABILITY":
                    return AfaqAIAPIResponse(409, {
                        "success": False,
                        "error": {
                            "code": "CAPABILITY_PROMOTION_NOT_ACTIVE",
                            "message": str(data.get("reason") or "capability promotion did not activate"),
                        },
                        "data": data,
                        "meta": meta,
                    })
            elif method == "POST" and path.endswith("/grow/rollback"):
                data = self.ai.rollback_capability(
                    str(body.get("capability_id") or ""),
                    operator_id=str(body.get("operator_id") or ""),
                )
                if data.get("status") != "ROLLED_BACK":
                    return AfaqAIAPIResponse(409, {
                        "success": False,
                        "error": {
                            "code": "CAPABILITY_ROLLBACK_FAILED",
                            "message": str(data.get("reason") or "capability rollback failed"),
                        },
                        "data": data,
                        "meta": meta,
                    })
            elif method == "POST" and path.endswith("/grow"):
                requirement = body.get("requirement")
                if not isinstance(requirement, Mapping):
                    raise ValueError("requirement must be an object")
                data = self.ai.grow_capability(
                    requirement,
                    implementation=bool(body.get("implementation", True)),
                    approved_by_job=bool(body.get("approved_by_job", False)),
                )
                if data.get("status") != "REGISTERED_CANDIDATE":
                    return AfaqAIAPIResponse(409, {
                        "success": False,
                        "error": {
                            "code": "CAPABILITY_GROWTH_NOT_REGISTERED",
                            "message": str(data.get("reason") or "capability growth not registered"),
                        },
                        "data": data,
                        "meta": meta,
                    })
            elif method == "POST" and path.endswith("/capability"):
                action = str(body.get("action") or "").strip()
                raw_args = body.get("args")
                if raw_args is None:
                    raw_args = {}
                if not isinstance(raw_args, Mapping):
                    raise ValueError("capability args must be an object")
                data = self.ai.execute_capability(
                    action,
                    dict(raw_args),
                    approved_by_job=bool(body.get("approved_by_job", False)),
                )
                execution_status = str(
                    ((data.get("result") or {}).get("status") or "")
                )
                if execution_status != "COMPLETE":
                    return AfaqAIAPIResponse(409, {
                        "success": False,
                        "error": {
                            "code": "CAPABILITY_NOT_VERIFIED",
                            "message": (
                                "Capability request was processed, but final "
                                f"status is {execution_status or 'UNKNOWN'}"
                            ),
                        },
                        "data": data,
                        "meta": meta,
                    })
            elif method == "POST" and path.endswith("/infer"):
                engine_ids = body.get("engine_ids")
                if engine_ids is not None and (
                    not isinstance(engine_ids, list)
                    or not all(isinstance(item, str) for item in engine_ids)
                ):
                    raise ValueError("engine_ids must be an array of registered engine IDs")
                context = body.get("context")
                if context is not None and not isinstance(context, Mapping):
                    raise ValueError("context must be an object")
                payload = body.get("payload")
                if payload is not None and not isinstance(payload, Mapping):
                    raise ValueError("payload must be an object")
                data = self.ai.infer_local(
                    str(body.get("prompt") or body.get("goal") or ""),
                    context=context,
                    engine_ids=engine_ids,
                    payload=payload,
                    approved_by_job=bool(body.get("approved_by_job", False)),
                    timeout_seconds=float(body.get("timeout_seconds") or 300.0),
                )
                if not data.get("success"):
                    error = data.get("error") or {}
                    code = str(error.get("code") or "LOCAL_INFERENCE_NOT_COMPLETED")
                    status = 504 if code == "LOCAL_INFERENCE_TIMEOUT" else 503
                    return AfaqAIAPIResponse(status, {
                        "success": False,
                        "error": {
                            "code": code,
                            "message": str(error.get("message") or "local inference did not complete"),
                        },
                        "data": data,
                        "meta": meta,
                    })
            elif method == "POST" and path.endswith("/generate"):
                goal = str(body.get("goal") or "").strip()
                result = self.ai.generate_ai(
                    goal,
                    name=str(body.get("name") or "").strip() or None,
                    kind=str(body.get("kind") or "agent"),
                )
                data = {
                    "name": result.name,
                    "kind": result.kind,
                    "goal": result.goal,
                    "manifest_path": result.manifest_path,
                    "evidence_path": result.evidence_path,
                    "intelligence": result.intelligence,
                    "engine_count": result.engine_count,
                    "capability_count": result.capability_count,
                }
            else:
                raise RuntimeError("AFAQ_API_ROUTE_DISPATCH_ERROR")
        except ValueError as exc:
            return AfaqAIAPIResponse(422, {
                "success": False,
                "error": {"code": "INVALID_REQUEST", "message": str(exc)},
                "meta": meta,
            })
        except Exception as exc:
            return AfaqAIAPIResponse(500, {
                "success": False,
                "error": {
                    "code": "AFAQ_AI_RUNTIME_ERROR",
                    "message": f"{type(exc).__name__}: {exc}",
                },
                "meta": meta,
            })

        return AfaqAIAPIResponse(200, {
            "success": True,
            "data": data,
            "meta": meta,
        })


def _resolve_step_refs(value: Any, outputs: list[dict[str, Any]]) -> Any:
    if isinstance(value, Mapping):
        if "$from_step" in value:
            index = int(value["$from_step"]) - 1
            if index < 0 or index >= len(outputs):
                raise ValueError("step reference points to unavailable output")
            current: Any = outputs[index]
            for part in str(value.get("path") or "").split("."):
                if not part:
                    continue
                if isinstance(current, Mapping):
                    current = current[part]
                elif isinstance(current, (list, tuple)) and part.isdigit():
                    current = current[int(part)]
                else:
                    raise KeyError(f"step reference path not found: {value.get('path')}")
            return current
        return {str(k): _resolve_step_refs(v, outputs) for k, v in value.items()}
    if isinstance(value, list):
        return [_resolve_step_refs(v, outputs) for v in value]
    if isinstance(value, tuple):
        return tuple(_resolve_step_refs(v, outputs) for v in value)
    return value


class AfaqAI:
    """Top-level AFAQ AI facade over native AFAQ engines and capabilities."""

    def __init__(
        self,
        project_root: str | Path,
        *,
        planner: Any | None = None,
        orchestrator: AfaqOrchestrator | None = None,
        router: Any | None = None,
        config: Any | None = None,
        model_router: Any | None = None,
        memory_path: str | Path | None = None,
    ) -> None:
        self.project_root = Path(project_root).resolve()
        if not self.project_root.is_dir():
            raise ValueError(f"project root not found: {self.project_root}")
        self._resident_inference = None
        self._resident_inference_lock = threading.Lock()

        # Backward-compatible attachment points only. They are not required by
        # AFAQ AI and never become its identity or default intelligence core.
        self.external_router = router
        self.external_config = config
        self.external_model_router = model_router

        self.planner = planner or AfaqNativePlanner()
        self.capability_planner = CapabilityPlanner(self.planner)
        self.orchestrator = orchestrator or AfaqOrchestrator(str(self.project_root))

        self.memory_path = Path(memory_path).resolve() if memory_path else None
        if self.memory_path is not None:
            self.memory_path.parent.mkdir(parents=True, exist_ok=True)
            self.memory = MemoryService(SqliteMemoryStore(self.memory_path))
        else:
            self.memory = MemoryService(MemoryStore())
        self.memory_scope = MemoryScope(
            tenant_id="local",
            project_id=self.project_root.name,
            agent_id="afaq-ai",
            environment="local",
        )

        self.api_keys = AfaqAIAPIKeyStore(
            self.project_root / "var" / "afaq_ai" / "api_keys.json"
        )
        self.api = AfaqAIAPI(self, key_store=self.api_keys)

    def engine_inventory(self) -> tuple[dict[str, Any], ...]:
        # Lazy import is deliberate: importing engines_live performs the outer
        # composition binding into afaq_agent_runtime.capability_port.
        from engines_live import LIVE_ENGINE_REGISTRY, build_registry

        build_registry()
        rows: list[dict[str, Any]] = []
        for engine_id, engine in sorted(LIVE_ENGINE_REGISTRY.items()):
            rows.append(
                {
                    "engine_id": engine_id,
                    "name": engine.name,
                    "kind": engine.kind,
                    "live_status": engine.live_status,
                    "runtime_implementation": bool(engine.runtime_implementation),
                    "operationally_proven": bool(engine.operationally_proven),
                    "capability_packages": list(engine.capability_packages),
                    "required_capabilities": list(engine.required_capabilities),
                    "adapter": engine.adapter_name,
                }
            )
        return tuple(rows)

    def capability_inventory(self) -> tuple[dict[str, Any], ...]:
        """Expose orchestration actions plus every stable registry capability identity."""
        from afaq_registry.loader import load_registry

        registry = load_registry()
        static_rows = [
            {**row, "kind": "orchestrator_action"}
            for row in capability_catalog()
        ]
        engines_by_capability: dict[str, list[str]] = {}
        for engine in registry.get("engines") or []:
            engine_id = str(engine.get("engine_id") or "")
            for name in engine.get("required_capabilities") or []:
                if isinstance(name, str) and name.strip():
                    engines_by_capability.setdefault(name.strip(), []).append(engine_id)

        identities: list[dict[str, Any]] = []
        for item in registry.get("capability_identities") or []:
            if not isinstance(item, Mapping):
                continue
            name = str(item.get("name") or "").strip()
            capability_id = str(item.get("capability_id") or "").strip()
            if not name or not capability_id:
                continue
            identities.append({
                "kind": "registry_capability",
                "name": name,
                "capability_id": capability_id,
                "engine_ids": sorted(set(engines_by_capability.get(name, []))),
                "invocation_action": "capability_invoke",
                "claim_ceiling": "STRUCTURAL_EXECUTION_ONLY_UNLESS_SEPARATELY_VERIFIED",
            })
        return tuple(static_rows + identities)

    def recall(self, goal: str, *, limit: int = 5) -> tuple[dict[str, Any], ...]:
        """Recall active scoped memories relevant to a goal."""
        if limit <= 0:
            return ()
        goal_tokens = AfaqNativePlanner._tokens(goal)
        ranked: list[tuple[int, float, Any]] = []
        for record in self.memory.list_active():
            if record.scope != self.memory_scope:
                continue
            record_tokens = AfaqNativePlanner._tokens(
                json.dumps(dict(record.content), ensure_ascii=False, default=str)
            )
            overlap = len(goal_tokens & record_tokens)
            if overlap <= 0:
                continue
            ranked.append((overlap, record.confidence, record))
        ranked.sort(
            key=lambda item: (item[0], item[1], item[2].created_at),
            reverse=True,
        )
        return tuple(
            {
                "memory_id": record.memory_id,
                "memory_type": record.memory_type.value,
                "content": dict(record.content),
                "confidence": record.confidence,
                "created_at": record.created_at.isoformat(),
            }
            for _, _, record in ranked[:limit]
        )

    def _remember_verified_execution(
        self,
        *,
        goal: str,
        action: str,
        execution: Mapping[str, Any],
    ) -> str | None:
        if str(execution.get("status") or "") != "COMPLETE":
            return None
        verification = execution.get("verification")
        if not isinstance(verification, Mapping) or verification.get("verified") is not True:
            return None
        envelope = execution.get("execution")
        execution_id = (
            str(envelope.get("execution_id") or "")
            if isinstance(envelope, Mapping)
            else ""
        )
        if not execution_id:
            return None
        safe_result = json.loads(json.dumps(
            execution.get("result"),
            ensure_ascii=False,
            default=str,
        ))
        record = self.memory.create(
            memory_type=MemoryType.EXPERIENCE,
            content={
                "goal": goal,
                "action": action,
                "result": safe_result,
                "verification": dict(verification),
                "tags": ["afaq-ai", action],
            },
            evidence=(
                MemoryEvidence(
                    evidence_id=f"EV-{execution_id}",
                    source_ref=f"execution:{execution_id}",
                    confidence=1.0,
                ),
            ),
            scope=self.memory_scope,
            metadata={
                "source": "AFAQ_AI_VERIFIED_EXECUTION",
                "execution_id": execution_id,
            },
            actor="afaq-ai",
        )
        return record.memory_id

    def memory_inventory(self) -> tuple[dict[str, Any], ...]:
        rows = []
        for record in self.memory.list_active():
            if record.scope != self.memory_scope:
                continue
            rows.append({
                "memory_id": record.memory_id,
                "memory_type": record.memory_type.value,
                "confidence": record.confidence,
                "created_at": record.created_at.isoformat(),
                "content": dict(record.content),
            })
        rows.sort(key=lambda row: (row["created_at"], row["memory_id"]), reverse=True)
        return tuple(rows)

    def status(self) -> dict[str, Any]:
        engines = self.engine_inventory()
        summary = AfaqAIEngineSummary(
            total=len(engines),
            active=sum(1 for e in engines if e["live_status"] == "ACTIVE"),
            operationally_proven=sum(1 for e in engines if e["operationally_proven"]),
            runtime_implemented=sum(1 for e in engines if e["runtime_implementation"]),
        )
        return {
            "product": "AFAQ AI",
            "project_root": str(self.project_root),
            "engines": summary.__dict__,
            "capabilities": len(self.capability_inventory()),
            "memory": {
                "active_records": len(self.memory_inventory()),
                "persistent": self.memory_path is not None,
                "path": str(self.memory_path) if self.memory_path is not None else None,
            },
            "orchestrator_enabled": self.orchestrator.enabled(),
            "shadow_mode": self.orchestrator.shadow(),
            "intelligence": {
                "core": "AFAQ_NATIVE",
                "external_model_dependency": False,
                "external_router_attached": self.external_router is not None,
                "local_inference": {
                    **native_generator_status(self.project_root),
                    "mode": "PROCESS_ISOLATED_AFAQ_NATIVE_GGUF",
                    "engine_selection": "LIVE_REGISTRY_DYNAMIC",
                    "worker_recycled_per_request": True,
                    "socket_outbound_policy": "DENY_NON_LOOPBACK",
                },
                "learning_loop": "recall_execute_evaluate_reflect_remember",
            },
            "api": {
                "name": "AFAQ API",
                "prefix": AFAQ_AI_API_PREFIX,
                "routes": list(AfaqAIAPI.routes()),
                "api_key_count": len(self.api_keys.list()),
            },
        }

    def plan(
        self,
        goal: str,
        *,
        context: Mapping[str, Any] | None = None,
    ) -> CapabilityPlan:
        goal = str(goal or "").strip()
        if not goal:
            raise ValueError("goal is required")

        enriched = dict(context or {})
        afaq_context = dict(enriched.get("afaq_ai") or {})
        afaq_context.setdefault("product", "AFAQ AI")
        afaq_context.setdefault("engine_count", len(self.engine_inventory()))
        afaq_context.setdefault("capability_catalog", list(self.capability_inventory()))
        afaq_context.setdefault("recalled_memory", list(self.recall(goal)))
        enriched["afaq_ai"] = afaq_context
        return self.capability_planner.plan(goal, context=enriched)

    def execute_plan(
        self,
        plan: CapabilityPlan,
        *,
        approved_by_job: bool = False,
        remember: bool = True,
    ) -> AfaqAIResult:
        executions: list[dict[str, Any]] = []
        evidence_refs: list[str] = []
        memory_ids: list[str] = []
        blocked = False

        if not plan.executable:
            return AfaqAIResult(
                goal=plan.request,
                plan=plan.as_dict(),
                executions=(),
                completed=False,
                blocked=True,
                evidence_refs=(),
                memory_ids=(),
            )

        for step in plan.steps:
            args = _resolve_step_refs(step.args, executions)
            result = self.orchestrator.execute(
                step.action,
                dict(args),
                approved_by_job=approved_by_job,
            )
            executions.append(result)

            payload = result.get("result")
            if isinstance(payload, Mapping):
                refs = payload.get("evidence_refs")
                if isinstance(refs, (list, tuple)):
                    evidence_refs.extend(str(x) for x in refs if x)

            if remember:
                memory_id = self._remember_verified_execution(
                    goal=plan.request,
                    action=step.action,
                    execution=result,
                )
                if memory_id:
                    memory_ids.append(memory_id)

            if result.get("status") not in {"COMPLETE"}:
                blocked = result.get("status") in {"DENIED", "SHADOW_BLOCKED"}
                break

        completed = len(executions) == len(plan.steps) and all(
            item.get("status") == "COMPLETE" for item in executions
        )
        return AfaqAIResult(
            goal=plan.request,
            plan=plan.as_dict(),
            executions=tuple(executions),
            completed=completed,
            blocked=blocked,
            evidence_refs=tuple(sorted(dict.fromkeys(evidence_refs))),
            memory_ids=tuple(memory_ids),
        )

    def run(
        self,
        goal: str,
        *,
        context: Mapping[str, Any] | None = None,
        approved_by_job: bool = False,
    ) -> AfaqAIResult:
        return self.execute_plan(
            self.plan(goal, context=context),
            approved_by_job=approved_by_job,
        )

    @staticmethod
    def _capability_evidence(execution: Mapping[str, Any]) -> dict[str, Any]:
        result = execution.get("result")
        if not isinstance(result, Mapping):
            return {}
        evidence = result.get("evidence")
        return dict(evidence) if isinstance(evidence, Mapping) else {}

    @staticmethod
    def _confidence_score(value: Any) -> float:
        if isinstance(value, Mapping):
            value = value.get("level")
        level = str(value or "").strip().lower()
        return {"high": 0.9, "medium": 0.7, "low": 0.5}.get(level, 0.5)

    def develop(
        self,
        topic: str,
        *,
        sources: Sequence[Mapping[str, Any]],
        approved_by_job: bool = False,
    ) -> dict[str, Any]:
        """Research -> verify -> synthesize -> knowledge -> goal candidates."""
        topic = str(topic or "").strip()
        if not topic:
            raise ValueError("topic is required")
        if not isinstance(sources, Sequence) or isinstance(sources, (str, bytes)):
            raise ValueError("sources must be an explicit sequence")
        normalized_sources = [
            dict(source) for source in sources if isinstance(source, Mapping)
        ]
        if not normalized_sources:
            raise ValueError("at least one explicit source is required")

        payload = {"topic": topic, "sources": normalized_sources}
        stages: list[dict[str, Any]] = []

        verification_execution = self.orchestrator.execute(
            "evidence_verify",
            payload,
            approved_by_job=approved_by_job,
        )
        stages.append({"stage": "evidence_verify", "execution": verification_execution})
        verification_evidence = self._capability_evidence(verification_execution)
        verification = verification_evidence.get("verification")
        supported = bool(
            verification_execution.get("status") == "COMPLETE"
            and isinstance(verification, Mapping)
            and verification.get("verification_state") == "SUPPORTED"
            and isinstance(verification.get("readiness"), Mapping)
            and verification["readiness"].get("ready") is True
            and verification_evidence.get("claim_promotion_allowed") is True
        )
        if not supported:
            return {
                "status": "NOT_VERIFIED",
                "reason": "research evidence did not reach supported readiness",
                "topic": topic,
                "stages": stages,
                "knowledge_memory_id": None,
                "goal_candidates": [],
            }

        synthesis_execution = self.orchestrator.execute(
            "research_synthesize",
            payload,
            approved_by_job=approved_by_job,
        )
        stages.append({"stage": "research_synthesize", "execution": synthesis_execution})
        synthesis_evidence = self._capability_evidence(synthesis_execution)
        synthesis = synthesis_evidence.get("synthesis")
        synthesis_ready = bool(
            synthesis_execution.get("status") == "COMPLETE"
            and isinstance(synthesis, Mapping)
            and synthesis.get("knowledge_update_candidate") is True
            and isinstance(synthesis.get("readiness"), Mapping)
            and synthesis["readiness"].get("ready") is True
        )
        if not synthesis_ready:
            return {
                "status": "NOT_VERIFIED",
                "reason": "research synthesis is not a knowledge update candidate",
                "topic": topic,
                "stages": stages,
                "knowledge_memory_id": None,
                "goal_candidates": [],
            }

        execution_refs: list[str] = []
        memory_evidence: list[MemoryEvidence] = []
        confidence = self._confidence_score(synthesis.get("confidence"))
        for label, execution in (
            ("verification", verification_execution),
            ("synthesis", synthesis_execution),
        ):
            envelope = execution.get("execution")
            execution_id = (
                str(envelope.get("execution_id") or "")
                if isinstance(envelope, Mapping)
                else ""
            )
            if execution_id:
                execution_refs.append(execution_id)
                memory_evidence.append(
                    MemoryEvidence(
                        evidence_id=f"EV-{label}-{execution_id}",
                        source_ref=f"execution:{execution_id}",
                        confidence=confidence,
                    )
                )
        if not memory_evidence:
            return {
                "status": "NOT_VERIFIED",
                "reason": "verified research has no execution evidence identity",
                "topic": topic,
                "stages": stages,
                "knowledge_memory_id": None,
                "goal_candidates": [],
            }

        knowledge = self.memory.create(
            memory_type=MemoryType.KNOWLEDGE,
            content={
                "topic": topic,
                "known": list(synthesis.get("known") or []),
                "unknown": list(synthesis.get("unknown") or []),
                "evidence_map": list(synthesis.get("evidence_map") or []),
                "analysis": dict(synthesis.get("analysis") or {}),
                "confidence": dict(synthesis.get("confidence") or {}),
                "tags": ["afaq-ai", "research", "knowledge"],
            },
            evidence=tuple(memory_evidence),
            scope=self.memory_scope,
            metadata={
                "source": "AFAQ_AI_RESEARCH_DEVELOPMENT",
                "execution_ids": execution_refs,
            },
            actor="afaq-ai",
        )

        known = [
            str(item).strip()
            for item in (synthesis.get("known") or [])
            if str(item).strip()
        ][:8]
        insights = [
            {
                "insight_id": f"knowledge-{index + 1}",
                "statement": statement,
                "evidence_refs": [f"memory:{knowledge.memory_id}"],
                "confidence": confidence,
                "opportunity_type": "research",
            }
            for index, statement in enumerate(known)
        ]
        if not insights:
            return {
                "status": "PARTIAL",
                "reason": "knowledge stored but no evidence-backed insight was available",
                "topic": topic,
                "stages": stages,
                "knowledge_memory_id": knowledge.memory_id,
                "goal_candidates": [],
            }

        goals_execution = self.orchestrator.execute(
            "goal_form",
            {"insights": insights},
            approved_by_job=approved_by_job,
        )
        stages.append({"stage": "goal_form", "execution": goals_execution})
        goal_evidence = self._capability_evidence(goals_execution)
        goal_formation = goal_evidence.get("goal_formation")
        if (
            goals_execution.get("status") != "COMPLETE"
            or not isinstance(goal_formation, Mapping)
        ):
            return {
                "status": "PARTIAL",
                "reason": "knowledge stored but goal formation was not verified",
                "topic": topic,
                "stages": stages,
                "knowledge_memory_id": knowledge.memory_id,
                "goal_candidates": [],
            }

        return {
            "status": "COMPLETE",
            "reason": "VERIFIED_RESEARCH_PROMOTED_TO_KNOWLEDGE_AND_GOAL_CANDIDATES",
            "topic": topic,
            "stages": stages,
            "knowledge_memory_id": knowledge.memory_id,
            "goal_candidates": list(goal_formation.get("goal_candidates") or []),
            "automatic_goal_activation": False,
            "automatic_capability_activation": False,
        }

    @staticmethod
    def _extract_internal_candidate_source(text: str, capability_id: str) -> str:
        """Extract one bounded Python candidate from AFAQ-native model output."""
        raw = str(text or "").strip()
        if not raw:
            raise ValueError("AFAQ_NATIVE_BUILDER_EMPTY_OUTPUT")
        if "```" in raw:
            blocks = raw.split("```")
            candidates = []
            for i in range(1, len(blocks), 2):
                block = blocks[i].strip()
                if block.lower().startswith("python"):
                    block = block[6:].lstrip("\r\n ")
                if "def handle(" in block:
                    candidates.append(block)
            if candidates:
                raw = candidates[0]
        start = raw.find("def handle(")
        if start < 0:
            raise ValueError("AFAQ_NATIVE_BUILDER_MISSING_HANDLE")
        prefix = raw[:start]
        comment = f"# capability_id: {capability_id}\n"
        source = comment + raw[start:].strip() + "\n"
        if capability_id in prefix and capability_id not in source:
            source = comment + raw[start:].strip() + "\n"
        return source

    def _native_capability_source_generator(
        self,
        requirement: Mapping[str, Any],
    ):
        """Return an AFAQ-native source generator when the resident model is ready."""
        status = native_generator_status(self.project_root)
        if not status.get("available"):
            return None

        def build(parsed: dict[str, Any]) -> str:
            contract = json.dumps(
                {
                    "capability_id": parsed["capability_id"],
                    "purpose": parsed["purpose"],
                    "input_contract": parsed["input_contract"],
                    "output_contract": parsed["output_contract"],
                    "acceptance_criteria": parsed["acceptance_criteria"],
                    "constraints": parsed["constraints"],
                },
                ensure_ascii=False,
                sort_keys=True,
            )
            prompt = (
                "You are the AFAQ internal capability builder. "
                "Generate exactly one self-contained Python implementation for the "
                "contract below. Return only Python source. No markdown. No imports. "
                "The source MUST define def handle(payload): and MUST return data "
                "matching the output contract. It must be deterministic, bounded, "
                "and must not use network, files, subprocesses, credentials, eval, "
                "exec, imports, globals, reflection, or lifecycle/governance APIs. "
                f"The literal capability id {parsed['capability_id']} must appear "
                "in the source.\nCONTRACT:\n" + contract
            )
            result = self.infer_local(
                prompt,
                payload={
                    "temperature": 0.1,
                    "max_tokens": 1200,
                },
                timeout_seconds=300.0,
            )
            if not result.get("success"):
                error = result.get("error") or {}
                raise RuntimeError(
                    "AFAQ_NATIVE_BUILDER_FAILED:"
                    + str(error.get("code") or "UNKNOWN")
                )
            return self._extract_internal_candidate_source(
                str(result.get("text") or ""),
                str(parsed["capability_id"]),
            )

        return build

    def grow_capability(
        self,
        requirement: Mapping[str, Any],
        *,
        implementation: bool = True,
        approved_by_job: bool = False,
    ) -> dict[str, Any]:
        """Prove a real gap, generate a candidate, persist its artifact, then stop."""
        from capability_cycle.genesis import (
            generate_candidate,
            generate_implementation_candidate,
        )

        if not isinstance(requirement, Mapping):
            raise ValueError("requirement must be an object")
        req = dict(requirement)
        capability_id = str(req.get("capability_id") or "").strip()
        if not capability_id.startswith("CAP-"):
            raise ValueError("requirement.capability_id must be an explicit CAP-* identity")

        gap_execution = self.orchestrator.execute(
            "gap_resolve",
            {"required_capability_ids": [capability_id]},
            approved_by_job=approved_by_job,
        )
        gap_evidence = self._capability_evidence(gap_execution)
        handoff = gap_evidence.get("handoff")
        resolution = (
            str(handoff.get("resolution") or "")
            if isinstance(handoff, Mapping)
            else ""
        )
        if gap_execution.get("status") != "COMPLETE":
            return {
                "status": "NOT_VERIFIED",
                "reason": "capability gap resolution did not complete verification",
                "capability_id": capability_id,
                "gap_execution": gap_execution,
            }
        if resolution != "GENESIS_HANDOFF_REQUIRED":
            return {
                "status": "NOT_REQUIRED",
                "reason": resolution or "gap genesis handoff was not proven",
                "capability_id": capability_id,
                "gap_execution": gap_execution,
            }

        builder_fallback_reason = None
        if implementation:
            internal_builder = self._native_capability_source_generator(req)
            if internal_builder is not None:
                try:
                    generated = generate_implementation_candidate(
                        req,
                        internal_source_generator=internal_builder,
                    )
                except Exception as exc:
                    # Fail closed on the model-generated artifact, then fall back
                    # to AFAQ's deterministic internal compiler. No external
                    # generator/provider is ever consulted.
                    builder_fallback_reason = (
                        f"{type(exc).__name__}:{str(exc)[:240]}"
                    )
                    generated = generate_implementation_candidate(req)
            else:
                builder_fallback_reason = "AFAQ_NATIVE_GGUF_UNAVAILABLE"
                generated = generate_implementation_candidate(req)
        else:
            generated = generate_candidate(req)
        if generated.generated is None or generated.candidate is None:
            return {
                "status": "FAILED",
                "reason": "genesis did not return a registered candidate artifact",
                "capability_id": capability_id,
                "gap_execution": gap_execution,
            }

        candidate_dir = (
            self.project_root
            / "var"
            / "afaq_ai"
            / "capability_candidates"
            / capability_id
        )
        candidate_dir.mkdir(parents=True, exist_ok=True)
        suffix = ".py" if implementation else ".json"
        artifact_path = candidate_dir / f"candidate{suffix}"
        artifact_path.write_bytes(generated.generated.artifact)
        actual_hash = hashlib.sha256(artifact_path.read_bytes()).hexdigest()
        if actual_hash != generated.generated.artifact_hash:
            raise RuntimeError("AFAQ_CAPABILITY_CANDIDATE_HASH_MISMATCH")

        evidence = {
            "schema": "AFAQ_AI_CAPABILITY_GROWTH_EVIDENCE_V1",
            "capability_id": capability_id,
            "requirement_id": generated.requirement_id,
            "state": "REGISTERED_CANDIDATE",
            "artifact_class": generated.generated.artifact_class,
            "artifact_sha256": actual_hash,
            "artifact_path": str(artifact_path.relative_to(self.project_root)),
            "gap_resolution": resolution,
            "generator_identity": generated.generated.generator_identity,
            "builder": generated.generated.generation_metadata.get("builder"),
            "model_provider": generated.generated.generation_metadata.get("model_provider"),
            "external_provider_dependency": False,
            "builder_fallback_reason": builder_fallback_reason,
            "implementation_reference": generated.candidate.implementation_reference,
            "registration_evidence": generated.candidate.registration_evidence,
            "automatic_activation": False,
            "automatic_certification": False,
            "automatic_production_admission": False,
            "next_required_stages": [
                "sandbox",
                "independent_review",
                "evaluation",
                "certification",
                "controlled_activation",
            ],
            "created_at": generated.generated.created_at,
        }
        evidence_path = candidate_dir / "growth.evidence.json"
        evidence_path.write_text(
            json.dumps(evidence, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )

        return {
            "status": "REGISTERED_CANDIDATE",
            "reason": generated.reason,
            "capability_id": capability_id,
            "artifact_class": generated.generated.artifact_class,
            "artifact_sha256": actual_hash,
            "artifact_path": str(artifact_path.relative_to(self.project_root)),
            "evidence_path": str(evidence_path.relative_to(self.project_root)),
            "automatic_activation": False,
            "builder": generated.generated.generation_metadata.get("builder"),
            "external_provider_dependency": False,
            "builder_fallback_reason": builder_fallback_reason,
            "gap_execution": gap_execution,
        }

    def grow_capability_autonomous(
        self,
        requirement: Mapping[str, Any],
        *,
        test_payload: Mapping[str, Any] | None = None,
        approved_by_job: bool = False,
    ) -> dict[str, Any]:
        """Build, validate, review, evaluate, certify and activate internally.

        All lifecycle identities are AFAQ-internal and separated. No external
        model provider, code generator, reviewer, certifier, or operator is
        required. Every stage remains fail-closed.
        """
        grown = self.grow_capability(
            requirement,
            implementation=True,
            approved_by_job=approved_by_job,
        )
        if grown.get("status") != "REGISTERED_CANDIDATE":
            return {
                "status": grown.get("status") or "NOT_BUILT",
                "reason": grown.get("reason") or "capability was not built",
                "growth": grown,
                "external_party_required": False,
            }

        payload = (
            dict(test_payload)
            if isinstance(test_payload, Mapping)
            else {"data": {}}
        )
        promoted = self.promote_capability(
            str(grown["capability_id"]),
            requirement=requirement,
            test_payload=payload,
        )
        return {
            "status": promoted.get("status"),
            "reason": promoted.get("reason"),
            "capability_id": grown["capability_id"],
            "growth": grown,
            "promotion": promoted,
            "external_party_required": False,
            "external_provider_dependency": False,
            "autonomous_internal_lifecycle": True,
        }

    def _ensure_candidate_loaded(self, capability_id: str) -> dict[str, Any]:
        """Rehydrate a persisted AFAQ AI candidate into the process-local registry."""
        from capability_cycle.handlers import (
            get_candidate,
            register_candidate,
        )

        capability_id = str(capability_id or "").strip()
        if not capability_id.startswith("CAP-"):
            raise ValueError("capability_id must be an explicit CAP-* identity")
        existing = get_candidate(capability_id)
        if existing is not None:
            return {
                "capability_id": capability_id,
                "artifact_hash": existing.artifact_hash,
                "artifact_class": existing.artifact_class,
                "state": existing.state,
                "rehydrated": False,
            }

        candidate_dir = (
            self.project_root
            / "var"
            / "afaq_ai"
            / "capability_candidates"
            / capability_id
        )
        evidence_path = candidate_dir / "growth.evidence.json"
        if not evidence_path.is_file():
            raise ValueError("persisted candidate growth evidence not found")
        evidence = json.loads(evidence_path.read_text(encoding="utf-8"))
        if evidence.get("schema") != "AFAQ_AI_CAPABILITY_GROWTH_EVIDENCE_V1":
            raise ValueError("unsupported capability growth evidence schema")
        if evidence.get("capability_id") != capability_id:
            raise ValueError("candidate evidence identity mismatch")

        artifact_rel = str(evidence.get("artifact_path") or "")
        artifact_path = self.project_root / artifact_rel
        resolved = artifact_path.resolve()
        candidate_root = candidate_dir.resolve()
        if candidate_root not in resolved.parents or not resolved.is_file():
            raise ValueError("candidate artifact path is invalid")
        artifact = resolved.read_bytes()
        actual_hash = hashlib.sha256(artifact).hexdigest()
        expected_hash = str(evidence.get("artifact_sha256") or "")
        if actual_hash != expected_hash:
            raise ValueError("persisted candidate artifact hash mismatch")

        record = register_candidate({
            "capability_id": capability_id,
            "artifact": artifact,
            "artifact_hash": actual_hash,
            "implementation_reference": str(
                evidence.get("implementation_reference") or ""
            ),
            "registration_evidence": str(
                evidence.get("registration_evidence") or ""
            ),
            "artifact_class": str(evidence.get("artifact_class") or ""),
        })
        return {
            "capability_id": capability_id,
            "artifact_hash": record.artifact_hash,
            "artifact_class": record.artifact_class,
            "state": record.state,
            "rehydrated": True,
        }

    def validate_capability_candidate(self, capability_id: str) -> dict[str, Any]:
        """Sandbox-validate a persisted candidate without review/certification/activation."""
        from capability_cycle.sandbox import validate_candidate

        loaded = self._ensure_candidate_loaded(capability_id)
        result = validate_candidate(capability_id)
        status = "SANDBOX_VALIDATED" if result.validated else "SANDBOX_FAILED"
        candidate_dir = (
            self.project_root
            / "var"
            / "afaq_ai"
            / "capability_candidates"
            / capability_id
        )
        validation = {
            "schema": "AFAQ_AI_CAPABILITY_SANDBOX_EVIDENCE_V1",
            "capability_id": capability_id,
            "artifact_sha256": loaded["artifact_hash"],
            "status": status,
            "executed": result.executed,
            "validated": result.validated,
            "outcome": result.outcome,
            "failure_class": result.failure_class,
            "rehydrated": loaded["rehydrated"],
            "automatic_review": False,
            "automatic_certification": False,
            "automatic_activation": False,
        }
        path = candidate_dir / "sandbox.evidence.json"
        path.write_text(
            json.dumps(validation, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        return {
            **validation,
            "reason": (
                "CANDIDATE_SANDBOX_VALIDATED"
                if result.validated
                else (result.failure_class or "CANDIDATE_SANDBOX_FAILED")
            ),
            "evidence_path": str(path.relative_to(self.project_root)),
        }

    @staticmethod
    def _promotion_roles() -> dict[str, str]:
        """Return fixed, separated AFAQ-internal governance identities."""
        roles = {
            "reviewer_id": "reviewer",
            "evaluator_id": "evaluator",
            "certifier_id": "certifier",
            "operator_id": "operator",
        }
        if len(set(roles.values())) != len(roles):
            raise RuntimeError("AFAQ_INTERNAL_PROMOTION_ROLE_COLLISION")
        return roles

    def promote_capability(
        self,
        capability_id: str,
        *,
        requirement: Mapping[str, Any],
        test_payload: Mapping[str, Any],
    ) -> dict[str, Any]:
        """Promote through separated AFAQ-internal roles, fail-closed."""
        from capability_cycle.certification import (
            certify_candidate_behavior,
            evaluate_candidate_behavior,
            review_candidate,
        )
        from capability_cycle.handlers import (
            activate_candidate,
            candidate_lifecycle_state,
            export_candidate_artifact,
        )
        from capability_cycle.sandbox import (
            execute_candidate_behavior,
            validate_candidate,
        )

        capability_id = str(capability_id or "").strip()
        loaded = self._ensure_candidate_loaded(capability_id)
        role_ids = self._promotion_roles()
        _candidate, blob = export_candidate_artifact(capability_id)
        actual_hash = hashlib.sha256(blob).hexdigest()
        if actual_hash != loaded["artifact_hash"]:
            raise ValueError("candidate artifact identity changed during promotion")

        # Fresh sandbox evidence is mandatory at promotion time.
        sandbox = validate_candidate(capability_id)
        if not sandbox.validated:
            return {
                "status": "SANDBOX_FAILED",
                "reason": sandbox.failure_class or "CANDIDATE_SANDBOX_FAILED",
                "capability_id": capability_id,
                "artifact_sha256": actual_hash,
            }

        # Review is independent by identity, but remains entirely inside AFAQ.
        reviewed = review_candidate(
            capability_id,
            requester=role_ids["reviewer_id"],
        )
        if reviewed.state != "INDEPENDENTLY_REVIEWED":
            return {
                "status": reviewed.state,
                "reason": reviewed.reason,
                "capability_id": capability_id,
                "artifact_sha256": actual_hash,
            }

        contract = dict(requirement)
        if str(contract.get("capability_id") or "") != capability_id:
            raise ValueError("requirement capability_id does not match candidate")
        contract["artifact_hash"] = actual_hash
        test_input = {
            "capability_id": capability_id,
            "requirement_id": str(contract.get("requirement_id") or ""),
            "input_contract": contract.get("input_contract"),
            "test_payload": dict(test_payload),
            "acceptance_criteria_reference": contract.get("acceptance_criteria"),
            "artifact_hash": actual_hash,
        }

        behavior = execute_candidate_behavior(
            capability_id,
            test_input=test_input,
        )
        if behavior.status != "BEHAVIOR_EXECUTED":
            return {
                "status": behavior.status,
                "reason": behavior.failure_reason or behavior.status,
                "capability_id": capability_id,
                "artifact_sha256": actual_hash,
            }

        evaluation = evaluate_candidate_behavior(
            capability_id,
            requirement=contract,
            test_input=test_input,
            requester=role_ids["evaluator_id"],
        )
        if evaluation.status != "PASSED":
            return {
                "status": evaluation.status,
                "reason": evaluation.reason,
                "capability_id": capability_id,
                "artifact_sha256": actual_hash,
                "evaluation_id": evaluation.evaluation_id,
            }

        certification = certify_candidate_behavior(
            capability_id,
            requester=role_ids["certifier_id"],
        )
        activation = activate_candidate(
            capability_id,
            requester=role_ids["operator_id"],
        )
        state = candidate_lifecycle_state(capability_id)
        if state != "ACTIVE_CERTIFIED_CAPABILITY":
            raise RuntimeError("AFAQ_CAPABILITY_POST_ACTIVATION_STATE_MISMATCH")

        candidate_dir = (
            self.project_root
            / "var"
            / "afaq_ai"
            / "capability_candidates"
            / capability_id
        )
        internal_review_ref = (
            f"afaq-internal-review:{capability_id}:{actual_hash[:16]}"
        )
        promotion = {
            "schema": "AFAQ_AI_CAPABILITY_PROMOTION_EVIDENCE_V2",
            "capability_id": capability_id,
            "artifact_sha256": actual_hash,
            "status": state,
            "internal_review": {
                "reviewer_id": role_ids["reviewer_id"],
                "decision": "APPROVED",
                "review_ref": internal_review_ref,
                "artifact_sha256": actual_hash,
                "external_party_required": False,
            },
            "roles": role_ids,
            "role_separation_enforced": True,
            "sandbox_validated": True,
            "behavior_evidence_id": behavior.evidence.behavior_evidence_id,
            "evaluation_id": evaluation.evaluation_id,
            "certification_id": certification.certification_id,
            "activation_id": activation.activation_id,
            "authority_result": activation.authority_result,
            "post_activation_verification": activation.post_activation_verification,
            "external_review_required": False,
            "external_provider_dependency": False,
            "automatic_self_review": False,
            "automatic_self_certification": False,
            "automatic_self_activation": False,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        path = candidate_dir / "promotion.evidence.json"
        path.write_text(
            json.dumps(promotion, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        return {
            **promotion,
            "reason": "AFAQ_INTERNAL_INDEPENDENT_LIFECYCLE_PROMOTION_VERIFIED",
            "evidence_path": str(path.relative_to(self.project_root)),
        }

    def rollback_capability(
        self,
        capability_id: str,
        *,
        operator_id: str,
    ) -> dict[str, Any]:
        """Explicitly remove one candidate activation and persist rollback evidence."""
        from capability_cycle.handlers import deactivate_candidate

        capability_id = str(capability_id or "").strip()
        operator_id = str(operator_id or "").strip()
        if not operator_id:
            raise ValueError("operator_id is required")
        if operator_id.lower() in {"afaq-ai", "generator", "learner"}:
            raise ValueError("AFAQ AI/generator/learner cannot self-authorize rollback")
        result = deactivate_candidate(
            capability_id,
            requester=operator_id,
        )
        candidate_dir = (
            self.project_root
            / "var"
            / "afaq_ai"
            / "capability_candidates"
            / capability_id
        )
        evidence = {
            "schema": "AFAQ_AI_CAPABILITY_ROLLBACK_EVIDENCE_V1",
            **result,
            "operator_id": operator_id,
            "rolled_back_at": datetime.now(timezone.utc).isoformat(),
        }
        path = candidate_dir / "rollback.evidence.json"
        path.write_text(
            json.dumps(evidence, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        return {
            **evidence,
            "reason": "CONTROLLED_CAPABILITY_ROLLBACK_VERIFIED",
            "evidence_path": str(path.relative_to(self.project_root)),
        }

    def learn(
        self,
        goal: str,
        *,
        context: Mapping[str, Any] | None = None,
        approved_by_job: bool = False,
    ) -> dict[str, Any]:
        """Run the native governed learning loop over one AFAQ AI task."""
        goal = str(goal or "").strip()
        if not goal:
            raise ValueError("goal is required")

        def executor(task: AgentTask, recalled_memories: tuple[Any, ...]) -> Mapping[str, Any]:
            plan = self.plan(task.instruction, context=context)
            result = self.execute_plan(
                plan,
                approved_by_job=approved_by_job,
                remember=False,
            )
            return {
                "goal": result.goal,
                "plan": result.plan,
                "executions": list(result.executions),
                "completed": result.completed,
                "blocked": result.blocked,
                "evidence_refs": list(result.evidence_refs),
                "recalled_memory_ids": [
                    record.memory_id for record in recalled_memories
                ],
            }

        def evaluator(task: AgentTask, output: Mapping[str, Any]) -> Evaluation:
            success = bool(output.get("completed"))
            return Evaluation(
                success=success,
                score=1.0 if success else 0.0,
                reason=(
                    "verified AFAQ AI execution completed"
                    if success
                    else "AFAQ AI execution did not complete verification"
                ),
            )

        def reflector(
            task: AgentTask,
            output: Mapping[str, Any],
            evaluation: Evaluation,
        ) -> Mapping[str, Any] | None:
            if not evaluation.success:
                return None
            return {
                "reflection": (
                    "Reuse the verified capability path that completed this "
                    "goal when the same scoped conditions recur."
                ),
                "instruction": task.instruction,
                "evidence_refs": list(output.get("evidence_refs") or []),
                "tags": ["afaq-ai", "verified-learning"],
            }

        agent = AfaqLearningAgent(
            memory=self.memory,
            executor=executor,
            evaluator=evaluator,
            reflector=reflector,
        )
        task = AgentTask(
            instruction=goal,
            context=AgentContext(
                tenant_id=self.memory_scope.tenant_id,
                project_id=self.memory_scope.project_id,
                agent_id=self.memory_scope.agent_id,
                environment=self.memory_scope.environment,
            ),
            metadata={"source": "AFAQ_AI_NATIVE_LEARNING"},
        )
        run = agent.run(task)
        return {
            "run_id": run.run_id,
            "task_id": run.task_id,
            "output": dict(run.output),
            "evaluation": {
                "success": run.evaluation.success,
                "score": run.evaluation.score,
                "reason": run.evaluation.reason,
            },
            "recalled_memory_ids": list(run.recalled_memory_ids),
            "created_memory_ids": list(run.created_memory_ids),
        }

    def execute_capability(
        self,
        action: str,
        args: Mapping[str, Any] | None = None,
        *,
        approved_by_job: bool = False,
    ) -> dict[str, Any]:
        """Execute one registered AFAQ capability through the governed orchestrator."""
        requested = str(action or "").strip()
        normalized = requested.lower()
        inventory = self.capability_inventory()
        catalog = {
            str(item.get("action")): item
            for item in inventory
            if isinstance(item, Mapping) and item.get("action")
        }
        registry_by_name = {
            str(item.get("name")).lower(): item
            for item in inventory
            if isinstance(item, Mapping) and item.get("kind") == "registry_capability"
        }
        registry_by_id = {
            str(item.get("capability_id")).upper(): item
            for item in inventory
            if isinstance(item, Mapping) and item.get("kind") == "registry_capability"
        }
        payload = dict(args or {})

        execution_action = normalized
        if normalized not in catalog:
            identity = registry_by_name.get(normalized) or registry_by_id.get(requested.upper())
            if identity is None:
                raise ValueError(f"capability is not registered in AFAQ: {requested}")
            execution_action = "capability_invoke"
            payload = {
                "capability": str(identity["name"]),
                "payload": payload,
            }
        spec = catalog[execution_action]

        def present(path: str) -> bool:
            current: Any = payload
            for part in str(path).split("."):
                if not isinstance(current, Mapping) or part not in current:
                    return False
                current = current[part]
            return current not in (None, "", [], ())

        missing = [
            str(name)
            for name in (spec.get("required_args") or [])
            if not present(str(name))
        ]
        for group in spec.get("required_any") or []:
            if not any(present(str(name)) for name in group):
                missing.append("one_of:" + "|".join(str(name) for name in group))
        if missing:
            raise ValueError(
                "missing capability arguments: " + ", ".join(missing)
            )

        result = self.orchestrator.execute(
            execution_action,
            payload,
            approved_by_job=approved_by_job,
        )
        memory_id = self._remember_verified_execution(
            goal=f"direct capability: {requested}",
            action=execution_action,
            execution=result,
        )
        return {
            "action": requested,
            "execution_action": execution_action,
            "engine_id": spec.get("engine_id"),
            "side_effect_governed": True,
            "memory_id": memory_id,
            "result": result,
        }


    def _resident_native(self):
        from .local_inference import ResidentLocalInference
        with self._resident_inference_lock:
            if self._resident_inference is None:
                self._resident_inference = ResidentLocalInference(self.project_root)
            return self._resident_inference

    def warm_local_inference(
        self,
        *,
        payload: Mapping[str, Any] | None = None,
        timeout_seconds: float = 180.0,
    ) -> dict[str, Any]:
        """Preload the AFAQ-owned native GGUF model into the resident worker."""
        return self._resident_native().warm(
            payload=payload,
            timeout_seconds=timeout_seconds,
        )

    def close(self) -> None:
        """Release persistent AFAQ AI resources when present."""
        resident = self._resident_inference
        if resident is not None:
            resident.close()
            self._resident_inference = None
        close = getattr(self.memory.store, "close", None)
        if callable(close):
            close()

    def infer_local(
        self,
        prompt: str,
        *,
        context: Mapping[str, Any] | None = None,
        engine_ids: list[str] | tuple[str, ...] | None = None,
        payload: Mapping[str, Any] | None = None,
        approved_by_job: bool = False,
        timeout_seconds: float = 300.0,
    ) -> dict[str, Any]:
        """Run provider-free native AFAQ inference using the local GGUF runtime."""
        prompt = str(prompt or "").strip()
        if not prompt:
            raise ValueError("prompt is required")
        ids = tuple(str(item).strip() for item in (engine_ids or ()) if str(item).strip())
        if ids:
            from .local_inference import run_local_inference
            return run_local_inference(
                self.project_root,
                prompt,
                context=context,
                engine_ids=ids,
                payload=payload,
                approved_by_job=approved_by_job,
                timeout_seconds=timeout_seconds,
            )
        return self._resident_native().infer(
            prompt,
            context=context,
            payload=payload,
            timeout_seconds=timeout_seconds,
        )

    def infer_local_stream(
        self,
        prompt: str,
        *,
        context: Mapping[str, Any] | None = None,
        engine_ids: list[str] | tuple[str, ...] | None = None,
        payload: Mapping[str, Any] | None = None,
        approved_by_job: bool = False,
        timeout_seconds: float = 300.0,
    ):
        """Yield provider-free AFAQ native inference deltas."""
        prompt = str(prompt or "").strip()
        if not prompt:
            raise ValueError("prompt is required")
        ids = tuple(str(item).strip() for item in (engine_ids or ()) if str(item).strip())
        if ids:
            from .local_inference import run_local_inference
            result = run_local_inference(
                self.project_root,
                prompt,
                context=context,
                engine_ids=ids,
                payload=payload,
                approved_by_job=approved_by_job,
                timeout_seconds=timeout_seconds,
            )
            yield {"type": "final", "result": result}
            return
        yield from self._resident_native().stream(
            prompt,
            context=context,
            payload=payload,
            timeout_seconds=timeout_seconds,
        )

    def generate_ai(
        self,
        goal: str,
        *,
        name: str | None = None,
        kind: str = "agent",
    ) -> AfaqAIGenerationResult:
        """Generate a concrete AI-system manifest using AFAQ AI itself.

        The generation prompt is grounded in the live AFAQ engine inventory and
        capability catalog. The result is persisted with evidence and hashes.
        It does not claim trained weights unless a later governed training
        execution produces them.
        """
        goal = str(goal or "").strip()
        if not goal:
            raise ValueError("goal is required")

        allowed_kinds = {"agent", "model", "finetune", "distillation", "multimodal"}
        kind = str(kind or "agent").strip().lower()
        if kind not in allowed_kinds:
            raise ValueError(f"unsupported AI kind: {kind}")

        def safe_name(value: str) -> str:
            cleaned = "".join(
                ch if (ch.isalnum() or ch in "._-") else "-"
                for ch in value.strip()
            ).strip("-")
            return (cleaned[:80] or "generated-ai")

        generated_name = safe_name(name or f"afaq-{kind}")
        engines = self.engine_inventory()
        capabilities = self.capability_inventory()

        goal_tokens = AfaqNativePlanner._tokens(goal)

        def engine_score(engine: Mapping[str, Any]) -> tuple[int, str]:
            text = " ".join([
                str(engine.get("name") or ""),
                " ".join(str(x) for x in engine.get("required_capabilities") or ()),
                " ".join(str(x) for x in engine.get("capability_packages") or ()),
            ])
            return (
                len(goal_tokens & AfaqNativePlanner._tokens(text)),
                str(engine.get("engine_id") or ""),
            )

        ranked_engines = sorted(
            engines,
            key=lambda engine: (-engine_score(engine)[0], engine_score(engine)[1]),
        )
        selected_engines = [e for e in ranked_engines if engine_score(e)[0] > 0][:8]
        if not selected_engines:
            selected_engines = [
                e for e in ranked_engines
                if e.get("live_status") == "ACTIVE"
            ][:4]

        selected_capabilities = []
        for capability in capabilities:
            capability_name = str(
                capability.get("action")
                or capability.get("name")
                or capability.get("capability_id")
                or ""
            )
            text = " ".join([
                capability_name,
                str(capability.get("purpose") or ""),
                " ".join(str(x) for x in capability.get("engine_ids") or ()),
            ])
            if capability_name and goal_tokens & AfaqNativePlanner._tokens(text):
                selected_capabilities.append(capability_name)
        if not selected_capabilities:
            selected_capabilities = [
                str(
                    cap.get("action")
                    or cap.get("name")
                    or cap.get("capability_id")
                )
                for cap in capabilities[:8]
                if cap.get("action") or cap.get("name") or cap.get("capability_id")
            ]

        manifest = {
            "schema": "AFAQ_AI_GENERATED_MANIFEST_V1",
            "name": generated_name,
            "kind": kind,
            "goal": goal,
            "description": f"AFAQ AI generated {kind} system for: {goal}",
            "capabilities": selected_capabilities,
            "engine_plan": [
                {
                    "engine_id": engine["engine_id"],
                    "purpose": engine["name"],
                }
                for engine in selected_engines
            ],
            "architecture": {
                "components": [
                    "AFAQ Intelligence Core",
                    "AFAQ Capability Planner",
                    "AFAQ Governed Orchestrator",
                    "AFAQ Live Engine Fabric",
                    "AFAQ Evidence Layer",
                ],
                "interfaces": ["AFAQ API", "AFAQ Capability Runtime"],
                "memory": ["AFAQ governed memory"],
                "tools": selected_capabilities,
            },
            "intelligence_strategy": {
                "core": "AFAQ_NATIVE",
                "external_model_dependency": False,
                "external_models_role": "optional subordinate capability only",
                "composition": "multi-engine capability orchestration",
            },
            "training": {
                "required": kind in {"model", "finetune", "distillation"},
                "status": "NOT_EXECUTED",
                "authority": "governed AFAQ training pipeline",
            },
            "evaluation": {
                "metrics": [
                    "task_success",
                    "evidence_completeness",
                    "capability_coverage",
                    "regression_rate",
                ],
                "acceptance_criteria": [
                    "all mandatory verification gates pass",
                    "no fabricated capability or engine claims",
                ],
            },
            "deployment": {
                "runtimes": ["local", "remote"],
                "interfaces": ["AFAQ API"],
            },
            "source": {
                "generator": "AFAQ AI",
                "intelligence": "AFAQ_NATIVE",
                "engine_count": len(engines),
                "capability_count": len(capabilities),
            },
        }

        out_dir = self.project_root / "var" / "afaq_ai" / "generated" / manifest["name"]
        out_dir.mkdir(parents=True, exist_ok=True)
        manifest_path = out_dir / "afaq-ai.manifest.json"
        manifest_path.write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )

        digest = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
        evidence = {
            "schema": "AFAQ_AI_GENERATION_EVIDENCE_V1",
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "goal": goal,
            "name": manifest["name"],
            "kind": kind,
            "intelligence": "AFAQ_NATIVE",
            "manifest_sha256": digest,
            "manifest_path": str(manifest_path.relative_to(self.project_root)),
            "engine_count": len(engines),
            "capability_count": len(capabilities),
            "trained_weights_proven": False,
            "note": (
                "AFAQ AI generated the system manifest. Trained weights are not "
                "claimed until a governed training execution produces and verifies them."
            ),
        }
        evidence_path = out_dir / "generation.evidence.json"
        evidence_path.write_text(
            json.dumps(evidence, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )

        return AfaqAIGenerationResult(
            name=manifest["name"],
            kind=kind,
            goal=goal,
            manifest_path=str(manifest_path.relative_to(self.project_root)),
            evidence_path=str(evidence_path.relative_to(self.project_root)),
            intelligence="AFAQ_NATIVE",
            engine_count=len(engines),
            capability_count=len(capabilities),
        )


__all__ = [
    "AfaqAI",
    "AfaqAIResult",
    "AfaqAIEngineSummary",
    "AfaqAIGenerationResult",
    "AfaqAIAPI",
    "AfaqAIAPIResponse",
    "AfaqAIAPIKey",
    "AfaqAIAPIKeySecret",
    "AfaqAIAPIKeyStore",
    "AfaqNativePlanner",
    "AFAQ_AI_API_PREFIX",
]
