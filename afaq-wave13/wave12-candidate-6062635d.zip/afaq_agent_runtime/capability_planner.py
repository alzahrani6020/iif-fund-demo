from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from afaq_intelligence_core.planning.planner import Planner

from .external_capabilities import capability_binding, supported_actions
from .orchestrator import supported_local_actions
from .side_effects import classify_action


_LOCAL_EXECUTOR_ID = "ENG-CAP-158"


def _capability_binding(action: str) -> tuple[str, str]:
    normalized = str(action or "").strip().lower()
    if normalized in supported_local_actions():
        return (_LOCAL_EXECUTOR_ID, normalized)
    return capability_binding(normalized)


def supported_plannable_actions() -> tuple[str, ...]:
    """Natural-language planner surface backed by operational executors."""
    return tuple(sorted(set(supported_actions()).union(supported_local_actions())))


@dataclass(frozen=True)
class CapabilitySpec:
    action: str
    purpose: str
    required_args: tuple[str, ...] = ()
    required_any: tuple[tuple[str, ...], ...] = ()
    output_paths: tuple[str, ...] = ()

    def as_dict(self) -> dict[str, Any]:
        return {
            "action": self.action,
            "engine_id": _capability_binding(self.action)[0],
            "purpose": self.purpose,
            "required_args": list(self.required_args),
            "required_any": [list(group) for group in self.required_any],
            "output_paths": list(self.output_paths),
        }


_CAPABILITY_SPECS: tuple[CapabilitySpec, ...] = (
    CapabilitySpec("files", "List bounded project files from the governed project root.", output_paths=("result",)),
    CapabilitySpec("read", "Read one project file from the governed project root.", ("path",), output_paths=("result",)),
    CapabilitySpec("search", "Search project text for an exact query.", ("query",), output_paths=("result",)),
    CapabilitySpec(
        "edit",
        "Apply one exact governed text replacement inside the project root after job approval.",
        ("path", "old", "new"),
        output_paths=("result.evidence.result",),
    ),
    CapabilitySpec(
        "run",
        "Run one allowlisted local development command through the governed sandbox.",
        ("command",),
        output_paths=("result.evidence.result",),
    ),
    CapabilitySpec("status", "Read git working-tree status.", output_paths=("result",)),
    CapabilitySpec("diff", "Read the current git diff.", output_paths=("result",)),
    CapabilitySpec("map", "Map repository structure using the governed repository mapper.", output_paths=("result",)),
    CapabilitySpec("web_fetch", "Fetch one remote URL and return HTTP/content evidence.", ("url",), output_paths=("result.evidence.fetch",)),
    CapabilitySpec(
        "web_crawl",
        "Explore a site or URL set across multiple pages with crawl evidence.",
        required_any=(("url", "seed_urls", "urls"),),
    ),
    CapabilitySpec(
        "web_explore",
        "Run a composite technology exploration mission with surfaces, APIs, optional browser interaction, evidence, and explicit mission verification.",
        required_any=(("url", "seed_urls", "urls"),),
        output_paths=(
            "result.evidence.exploration",
            "result.evidence.verification",
        ),
    ),
    CapabilitySpec("remote_verify", "Independently verify a remote resource status/content/hash.", ("url",), output_paths=("result.evidence.verification",)),
    CapabilitySpec(
        "browser_execute",
        "Use the governed real browser for interactive browser actions.",
        required_any=(("url", "start_url"),),
        output_paths=("result.evidence.browser",),
    ),
    CapabilitySpec(
        "mission_model",
        "Build an explicit evidence-oriented mission model without creating authority.",
        required_any=(("instruction", "text"),),
        output_paths=("result.evidence.mission_model",),
    ),
    CapabilitySpec(
        "capability_compose",
        "Compose only existing implemented capabilities into a bounded graph.",
        ("capability_ids",),
        output_paths=("result.evidence.composition",),
    ),
    CapabilitySpec(
        "mission_graph",
        "Execute a bounded capability mission graph with mission verification.",
        ("capability_ids",),
        output_paths=("result.evidence.mission_verification",),
    ),
    CapabilitySpec(
        "result_fuse",
        "Fuse multiple results deterministically while preserving disagreement and lineage.",
        ("results",),
        output_paths=("result.evidence.fusion",),
    ),
    CapabilitySpec(
        "context_adapt",
        "Observe runtime context and recommend bounded configuration changes without applying them.",
        output_paths=("result.evidence.adaptation",),
    ),
    CapabilitySpec(
        "capability_discover",
        "Discover implemented and attachable capability IDs without loading arbitrary code.",
        output_paths=("result.evidence.loader",),
    ),
    CapabilitySpec(
        "capability_session_status",
        "Read the capabilities currently attached to one ephemeral capability session.",
        ("session_id",),
        output_paths=("result.evidence.loader",),
    ),
    CapabilitySpec(
        "gap_resolve",
        "Prove whether requested capabilities already exist or require a governed gap handoff.",
        required_any=(("required_capability_ids", "capability_ids"),),
        output_paths=("result.evidence.handoff",),
    ),
    CapabilitySpec(
        "evidence_verify",
        "Verify supplied research evidence without promoting unresolved claims.",
        ("sources",),
        required_any=(("topic", "query", "text"),),
        output_paths=("result.evidence.verification",),
    ),
    CapabilitySpec(
        "research_synthesize",
        "Synthesize supplied research evidence while preserving provenance and unknowns.",
        ("sources",),
        required_any=(("topic", "query", "text"),),
        output_paths=("result.evidence.synthesis",),
    ),
    CapabilitySpec(
        "causal_falsify",
        "Compare competing falsifiable hypotheses and preserve unresolved causal claims.",
        ("hypotheses",),
        output_paths=("result.evidence.falsification",),
    ),
    CapabilitySpec(
        "scenario_forecast",
        "Produce an assumption-explicit scenario forecast with uncertainty and optional backtest.",
        ("baseline", "assumptions"),
        output_paths=("result.evidence.forecast",),
    ),
    CapabilitySpec(
        "continuous_observe",
        "Perform one evidence-backed observation of an approved remote source; no scheduler is created.",
        ("source_id", "url"),
        output_paths=("result.evidence.observation",),
    ),
    CapabilitySpec(
        "continuous_compare",
        "Compare two supplied source snapshots and detect meaningful change.",
        ("source_id", "previous", "current"),
        output_paths=("result.evidence.observation",),
    ),
    CapabilitySpec(
        "frontier_discover",
        "Turn supplied evidence-backed frontier signals into governed capability-gap candidates.",
        ("signals",),
        output_paths=("result.evidence.frontier",),
    ),
    CapabilitySpec(
        "benchmark_observe",
        "Compare paired evidence-backed benchmark observations reproducibly.",
        ("observations",),
        output_paths=("result.evidence.benchmark",),
    ),
    CapabilitySpec(
        "research_portfolio",
        "Coordinate supplied research missions with priorities, stop criteria, and evidence coverage.",
        ("missions",),
        output_paths=("result.evidence.portfolio",),
    ),
    CapabilitySpec(
        "goal_form",
        "Form evidence-linked goal candidates from supplied insights without automatic activation.",
        ("insights",),
        output_paths=("result.evidence.goal_formation",),
    ),
    CapabilitySpec(
        "engine_invoke",
        "Invoke any explicitly selected live AFAQ engine through the governed capability envelope.",
        ("engine_id", "payload"),
        output_paths=("result.evidence",),
    ),
    CapabilitySpec(
        "capability_invoke",
        "Invoke any capability registered in the AFAQ capability identity registry.",
        ("capability", "payload"),
        output_paths=("result.evidence",),
    ),
    CapabilitySpec(
        "model_profile",
        "Profile declared model/runtime characteristics with provenance.",
        ("metadata",),
        required_any=(("subject_id", "metadata.subject_id"),),
        output_paths=("result.evidence.profile", "result.evidence.profile_hash"),
    ),
    CapabilitySpec("benchmark_engines", "Compare two engines using supplied benchmark cases.", ("baseline_engine_id", "candidate_engine_id", "cases")),
    CapabilitySpec("benchmark_suite", "Run a benchmark suite against a target engine.", ("target_engine_id", "cases")),
    CapabilitySpec("performance_history", "Load stored profiles, benchmarks, and selection feedback.", ("subject_id",), output_paths=("result.evidence.profiles", "result.evidence.benchmarks", "result.evidence.selection_feedback")),
    CapabilitySpec("performance_latest_metrics", "Load the latest benchmark metrics for a subject.", ("subject_id",), output_paths=("result.evidence.metrics",)),
    CapabilitySpec(
        "performance_selection_feedback",
        "Record observed selection outcome feedback.",
        ("subject_id",),
        output_paths=("result.evidence.feedback",),
    ),
    CapabilitySpec("performance_recommend", "Recommend the best candidate under quality, reliability, latency, and cost constraints.", ("candidates",), output_paths=("result.evidence.recommendation",)),
    CapabilitySpec(
        "performance_budget_check",
        "Check measured metrics against latency budgets.",
        ("metrics",),
        required_any=(("p95_budget_ms", "p99_budget_ms", "ttft_budget_ms"),),
        output_paths=("result.evidence.budget",),
    ),
    CapabilitySpec(
        "performance_regression",
        "Detect performance regression between baseline and current measurements.",
        ("baseline", "current"),
        output_paths=("result.evidence.regression",),
    ),
    CapabilitySpec(
        "performance_bottleneck",
        "Localize the critical performance bottleneck from step measurements.",
        ("steps",),
        output_paths=("result.evidence.bottleneck",),
    ),
    CapabilitySpec(
        "performance_optimize",
        "Optimize candidate choice across quality, reliability, latency, and cost.",
        ("candidates",),
        output_paths=("result.evidence.optimization",),
    ),
)

_SPEC_BY_ACTION = {spec.action: spec for spec in _CAPABILITY_SPECS}


@dataclass(frozen=True)
class CapabilityPlanStep:
    action: str
    objective: str
    args: dict[str, Any]
    engine_id: str
    side_effect: str
    missing_args: tuple[str, ...]

    @property
    def executable(self) -> bool:
        return not self.missing_args

    def as_dict(self) -> dict[str, Any]:
        return {
            "action": self.action,
            "objective": self.objective,
            "args": dict(self.args),
            "engine_id": self.engine_id,
            "side_effect": self.side_effect,
            "missing_args": list(self.missing_args),
            "executable": self.executable,
        }


@dataclass(frozen=True)
class CapabilityPlan:
    request: str
    steps: tuple[CapabilityPlanStep, ...]
    executable: bool
    requires_governed_execution: bool
    missing_inputs: tuple[dict[str, Any], ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "request": self.request,
            "steps": [step.as_dict() for step in self.steps],
            "executable": self.executable,
            "requires_governed_execution": self.requires_governed_execution,
            "missing_inputs": [dict(item) for item in self.missing_inputs],
        }


def capability_catalog() -> tuple[dict[str, Any], ...]:
    return tuple(spec.as_dict() for spec in _CAPABILITY_SPECS)


def _arg_value(args: Mapping[str, Any], path: str) -> Any:
    current: Any = args
    for part in path.split("."):
        if not isinstance(current, Mapping) or part not in current:
            return None
        current = current[part]
    return current


def _arg_present(args: Mapping[str, Any], path: str) -> bool:
    value = _arg_value(args, path)
    return value not in (None, "", [], ())


def _validate_step_references(
    value: Any,
    *,
    current_step: int,
    prior_actions: tuple[str, ...],
) -> None:
    if isinstance(value, Mapping):
        if "$from_step" in value:
            source = value.get("$from_step")
            path = value.get("path", "")
            if set(value) - {"$from_step", "path"}:
                raise ValueError("step reference contains unsupported fields")
            if not isinstance(source, int) or source < 1 or source >= current_step:
                raise ValueError(
                    f"step reference must target a completed prior step; got {source}"
                )
            if not isinstance(path, str) or not path:
                raise ValueError("step reference path must be a non-empty string")
            parts = [part for part in path.split(".") if part]
            if any(
                not part.replace("_", "").replace("-", "").isalnum()
                and not part.isdigit()
                for part in parts
            ):
                raise ValueError("step reference path contains unsupported characters")

            source_action = prior_actions[source - 1]
            source_spec = _SPEC_BY_ACTION.get(source_action)
            allowed = tuple(source_spec.output_paths) if source_spec else ()
            if not any(
                path == prefix or path.startswith(prefix + ".")
                for prefix in allowed
            ):
                raise ValueError(
                    f"step reference path is not a declared output of {source_action}: {path}"
                )
            return
        for child in value.values():
            _validate_step_references(
                child,
                current_step=current_step,
                prior_actions=prior_actions,
            )
    elif isinstance(value, (list, tuple)):
        for child in value:
            _validate_step_references(
                child,
                current_step=current_step,
                prior_actions=prior_actions,
            )


def _verification_contract(context: Mapping[str, Any] | None) -> dict[str, Any]:
    if not context:
        return {}
    nested = context.get("verification")
    source = nested if isinstance(nested, Mapping) else context
    allowed = (
        "expected_status",
        "expected_sha256",
        "expected_contains",
        "timeout_seconds",
        "allow_private_networks",
    )
    return {
        key: source[key]
        for key in allowed
        if key in source and source[key] not in (None, "")
    }


def _next_step_is_remote_verifier(
    steps: list[CapabilityPlanStep],
    *,
    index: int,
    url: str,
) -> bool:
    if index + 1 >= len(steps):
        return False
    candidate = steps[index + 1]
    return (
        candidate.action == "remote_verify"
        and str(candidate.args.get("url") or "").strip() == url
    )


def _next_step_is_performance_history(
    steps: list[CapabilityPlanStep],
    *,
    index: int,
    subject_id: str,
    store_path: str | None,
) -> bool:
    if index + 1 >= len(steps):
        return False
    candidate = steps[index + 1]
    if candidate.action != "performance_history":
        return False
    if str(candidate.args.get("subject_id") or "") != subject_id:
        return False
    candidate_store = candidate.args.get("store_path")
    return (
        str(candidate_store) if candidate_store is not None else None
    ) == store_path


def _append_deterministic_verifiers(
    steps: list[CapabilityPlanStep],
    *,
    context: Mapping[str, Any] | None,
) -> list[CapabilityPlanStep]:
    """Interleave deterministic proof immediately after the action it proves."""
    contract = _verification_contract(context)
    enriched: list[CapabilityPlanStep] = []

    for index, step in enumerate(steps):
        enriched.append(step)

        if step.action == "browser_execute" and contract:
            url = str(step.args.get("url") or "").strip()
            if url and not _next_step_is_remote_verifier(
                steps,
                index=index,
                url=url,
            ):
                verify_args = {"url": url, **contract}
                enriched.append(
                    CapabilityPlanStep(
                        action="remote_verify",
                        objective="Independently verify the browser post-condition.",
                        args=verify_args,
                        engine_id=_capability_binding("remote_verify")[0],
                        side_effect=classify_action("remote_verify", verify_args).value,
                        missing_args=(),
                    )
                )

        if step.action == "performance_selection_feedback":
            subject_id = str(step.args.get("subject_id") or "").strip()
            raw_store = step.args.get("store_path")
            store_path = str(raw_store) if raw_store is not None else None
            if subject_id and not _next_step_is_performance_history(
                steps,
                index=index,
                subject_id=subject_id,
                store_path=store_path,
            ):
                verify_args: dict[str, Any] = {"subject_id": subject_id}
                if store_path is not None:
                    verify_args["store_path"] = store_path
                enriched.append(
                    CapabilityPlanStep(
                        action="performance_history",
                        objective="Read back the persisted selection feedback.",
                        args=verify_args,
                        engine_id=_capability_binding("performance_history")[0],
                        side_effect=classify_action("performance_history", verify_args).value,
                        missing_args=(),
                    )
                )

    return enriched


class CapabilityPlanner:
    """Translate a natural-language goal into a validated engine-capability plan.

    The AI planner may propose a sequence, but it has no authority. Every
    proposed action is checked against the canonical capability catalog and
    every step is reclassified deterministically before any execution.
    """

    def __init__(self, planner: Planner):
        self.planner = planner

    def plan(self, request: str, *, context: Mapping[str, Any] | None = None) -> CapabilityPlan:
        goal = str(request or "").strip()
        if not goal:
            raise ValueError("request is required")

        catalog = capability_catalog()
        planner_context = {
            "capability_catalog": list(catalog),
            "planning_rules": [
                "Choose the minimum set of capabilities that satisfies the user goal.",
                "Use multiple steps when verification or evidence requires another capability.",
                "Never invent a capability outside the catalog.",
                "Put values explicitly present in the user request into step args.",
                "Treat request_context as authoritative supplied input and reuse matching values in step args.",
                "Do not fabricate values absent from both the user request and request_context; omit them and let validation report missing inputs.",
                "A later step may consume a prior step output with an argument value shaped exactly as {\"$from_step\": 1, \"path\": \"result.evidence.metrics\"}.",
                "Step references may target completed prior steps only; use capability_catalog output_paths when available.",
            ],
        }
        if context:
            planner_context["request_context"] = dict(context)

        raw_steps = self.planner.plan(
            goal,
            list(supported_plannable_actions()),
            context=planner_context,
        )
        if not raw_steps:
            raise ValueError("planner returned no capability steps")

        steps: list[CapabilityPlanStep] = []
        missing_inputs: list[dict[str, Any]] = []
        governed = False

        for step_number, raw in enumerate(raw_steps, 1):
            action = str(raw.tool or "").strip()
            spec = _SPEC_BY_ACTION.get(action)
            if spec is None:
                raise ValueError(f"planner selected unsupported capability: {action}")
            args = dict(raw.args or {})
            if (
                action == "web_explore"
                and "verification" not in args
                and context
                and isinstance(context.get("verification"), Mapping)
            ):
                args["verification"] = dict(context["verification"])
            _validate_step_references(
                args,
                current_step=step_number,
                prior_actions=tuple(step.action for step in steps),
            )
            missing_list = [
                name for name in spec.required_args
                if not _arg_present(args, name)
            ]
            for group in spec.required_any:
                if not any(_arg_present(args, name) for name in group):
                    missing_list.append("one_of:" + "|".join(group))
            missing = tuple(missing_list)
            effect = classify_action(action, args)
            if effect.value != "READ_ONLY":
                governed = True
            step = CapabilityPlanStep(
                action=action,
                objective=str(raw.objective or spec.purpose),
                args=args,
                engine_id=_capability_binding(action)[0],
                side_effect=effect.value,
                missing_args=missing,
            )
            steps.append(step)
            if missing:
                missing_inputs.append({
                    "action": action,
                    "engine_id": _capability_binding(action)[0],
                    "required": list(missing),
                })

        steps = _append_deterministic_verifiers(
            steps,
            context=context,
        )
        return CapabilityPlan(
            request=goal,
            steps=tuple(steps),
            executable=not missing_inputs,
            requires_governed_execution=governed,
            missing_inputs=tuple(missing_inputs),
        )
