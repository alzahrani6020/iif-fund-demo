"""Focused tests for the image generation planning engine (wave 6, §16 family).

Runs against afaq_agent_runtime.image_gen_plan only — no model, no network,
no pixel operations, no runtime services, no canonical state. Intentionally
OUTSIDE pytest.ini testpaths so the canonical suite stays at exactly 44 tests.

Run explicitly:

    python -m pytest afaq_agent_runtime/tests_image_plan -q
"""

from __future__ import annotations

import copy

import pytest

from afaq_agent_runtime.image_gen_plan import (
    ImagePlanError,
    attach_consistency_manifest,
    build_asset_library,
    build_consistency_manifest,
    compose_image_spec,
    critique_specs,
    image_plan_readiness,
    parse_asset_library,
    parse_image_spec,
    plan_edit,
    run_image_gates,
)


def _shot(**overrides):
    base = {
        "shot_id": "S1",
        "order": 1,
        "sequence_order": 1,
        "purpose": "cover the opening beat",
        "framing": "medium",
        "angle": "eye_level",
        "movement": "static",
        "duration_seconds": 4,
    }
    base.update(overrides)
    return base


def _spec(**overrides):
    base = compose_image_spec(_shot())
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# compose_image_spec


def test_compose_from_minimal_shot_is_valid():
    spec = compose_image_spec(_shot())
    assert spec["spec_id"] == "spec-S1"
    assert spec["status"] == "PLANNED"
    assert spec["aspect_ratio"] == "3:2"  # medium framing mapping
    assert spec["composition"] == "rule_of_thirds"
    assert spec["style"] == "photorealistic"
    assert spec["identity_tokens"] == []
    assert spec["asset_refs"] == []


def test_compose_declared_characters_become_identity_tokens():
    spec = compose_image_spec(
        _shot(framing="close_up", characters=["Amina", "amina", "Omar"])
    )
    assert spec["identity_tokens"] == ["char:amina", "char:omar"]
    assert spec["subject"] == "Amina, Omar"
    assert spec["aspect_ratio"] == "4:3"
    assert spec["composition"] == "centered"


def test_compose_declared_props_become_asset_refs():
    spec = compose_image_spec(_shot(props=["brass lantern", "map"]))
    assert spec["asset_refs"] == ["brass lantern", "map"]


def test_compose_absent_stays_absent_no_invented_attributes():
    spec = compose_image_spec(_shot())
    # no characters declared -> no tokens, no fabricated attributes anywhere
    assert spec["identity_tokens"] == []
    assert "amina" not in str(spec).lower()
    assert spec["setting"] == "unspecified"  # reported, not invented


def test_compose_establishing_mapping():
    spec = compose_image_spec(_shot(framing="establishing", setting="courtyard"))
    assert spec["aspect_ratio"] == "16:9"
    assert spec["setting"] == "courtyard"


def test_compose_extreme_close_up_mapping():
    spec = compose_image_spec(_shot(framing="extreme_close_up"))
    assert spec["aspect_ratio"] == "1:1"
    assert spec["composition"] == "centered"


def test_compose_brief_overrides_win():
    spec = compose_image_spec(
        _shot(framing="establishing"),
        brief={
            "subject": "the council chamber",
            "style": "watercolor",
            "lighting": "low_key",
            "aspect_ratio": "4:3",
            "palette": ["indigo", "ochre"],
            "negative_extra": ["no border"],
        },
    )
    assert spec["subject"] == "the council chamber"
    assert spec["style"] == "watercolor"
    assert spec["lighting"] == "low_key"
    assert spec["aspect_ratio"] == "4:3"
    assert spec["palette"] == ["indigo", "ochre"]
    assert "no border" in spec["negative_constraints"]


def test_compose_style_param_beats_brief():
    spec = compose_image_spec(_shot(), brief={"style": "anime"}, style="cinematic")
    assert spec["style"] == "cinematic"


def test_compose_lighting_keyword_rules():
    assert compose_image_spec(_shot(purpose="the danger threatens"))["lighting"] == "low_key"
    assert compose_image_spec(_shot(purpose="a night patrol"))["lighting"] == "neon_night"
    assert compose_image_spec(_shot(purpose="at sunrise"))["lighting"] == "golden_hour"
    assert compose_image_spec(_shot())["lighting"] == "natural"


def test_compose_negative_constraints_include_style_specific():
    spec = compose_image_spec(_shot(), style="anime")
    assert "no watermark" in spec["negative_constraints"]
    assert "no photographic grain" in spec["negative_constraints"]


def test_compose_rejects_bad_enum_and_words():
    with pytest.raises(ImagePlanError):
        compose_image_spec(_shot(framing="sideways"))
    with pytest.raises(ImagePlanError):
        compose_image_spec(_shot(), brief={"style": "cubist"})
    with pytest.raises(ImagePlanError):
        compose_image_spec(_shot(), brief={"aspect_ratio": "2:1"})
    with pytest.raises(ImagePlanError):
        compose_image_spec("not a shot")


# ---------------------------------------------------------------------------
# parse_image_spec


def test_parse_round_trip():
    spec = _spec()
    assert parse_image_spec(copy.deepcopy(spec)) == spec


def test_parse_requires_fields():
    with pytest.raises(ImagePlanError):
        parse_image_spec({"spec_id": "x"})
    with pytest.raises(ImagePlanError):
        parse_image_spec("nope")
    bad = _spec()
    bad["status"] = "RENDERED"  # only PLANNED exists in this engine
    with pytest.raises(ImagePlanError):
        parse_image_spec(bad)


# ---------------------------------------------------------------------------
# consistency manifest


def _two_specs_same_character():
    return [
        compose_image_spec(_shot(shot_id="S1", characters=["Amina"])),
        compose_image_spec(_shot(shot_id="S2", framing="close_up",
                                 characters=["Amina"])),
    ]


def test_manifest_recurring_character_gets_shared_token():
    manifest = build_consistency_manifest(_two_specs_same_character())
    assert manifest["characters"] == [{
        "identity_token": "char:amina",
        "appears_in": ["spec-S1", "spec-S2"],
        "shared_palette": [],
    }]
    rules1 = manifest["specs"][0]["consistency_rules"]
    assert any("char:amina" in r for r in rules1)


def test_manifest_single_appearance_character_no_rule():
    specs = [
        compose_image_spec(_shot(shot_id="S1", characters=["Amina"])),
        compose_image_spec(_shot(shot_id="S2")),
    ]
    manifest = build_consistency_manifest(specs)
    assert manifest["characters"] == []
    assert manifest["specs"][0]["consistency_rules"] == []


def test_manifest_missing_token_warning_when_subject_names_character():
    specs = _two_specs_same_character()
    specs[1]["identity_tokens"] = []  # caller stripped the token
    manifest = build_consistency_manifest(specs)
    assert any("spec-S2" in w for w in manifest["warnings"])


def test_manifest_empty_input_raises():
    with pytest.raises(ImagePlanError):
        build_consistency_manifest([])


def test_attach_consistency_manifest_returns_valid_specs():
    specs = attach_consistency_manifest(_two_specs_same_character())
    for spec in specs:
        parse_image_spec(spec)  # re-validates
    assert any(spec["consistency_rules"] for spec in specs)


# ---------------------------------------------------------------------------
# plan_edit


def test_plan_edit_inpainting_requires_region_and_guidance():
    spec = _spec()
    with pytest.raises(ImagePlanError):
        plan_edit(spec, "inpainting", guidance="add a window")
    with pytest.raises(ImagePlanError):
        plan_edit(spec, "inpainting", region={"x": 0.1, "y": 0.1,
                                              "width": 0.2, "height": 0.2})
    edit = plan_edit(spec, "inpainting",
                     region={"x": 0.1, "y": 0.1, "width": 0.2, "height": 0.2},
                     guidance="a brass lantern on the table")
    assert edit["kind"] == "inpainting"
    assert edit["status"] == "PLANNED"
    assert edit["source_spec_id"] == spec["spec_id"]
    assert edit["bounds"]["area_fraction_max"] == 0.5


def test_plan_edit_outpainting_direction_and_extent():
    spec = _spec()
    with pytest.raises(ImagePlanError):
        plan_edit(spec, "outpainting")
    with pytest.raises(ImagePlanError):
        plan_edit(spec, "outpainting", direction="sideways")
    with pytest.raises(ImagePlanError):
        plan_edit(spec, "outpainting", direction="left", extent=4.0)
    edit = plan_edit(spec, "outpainting", direction="right")
    assert edit["direction"] == "right"
    assert edit["extent"] == 0.25


def test_plan_edit_background_removal_needs_no_region():
    edit = plan_edit(_spec(), "background_removal")
    assert edit["target"] == "background"


def test_plan_edit_object_removal_requires_region():
    with pytest.raises(ImagePlanError):
        plan_edit(_spec(), "object_removal")
    edit = plan_edit(_spec(), "object_removal",
                     region={"x": 0.0, "y": 0.0, "width": 0.5, "height": 1.0})
    assert edit["mask_region"]["width"] == 0.5


def test_plan_edit_relighting_requires_lighting_and_bounds_strength():
    with pytest.raises(ImagePlanError):
        plan_edit(_spec(), "relighting")
    with pytest.raises(ImagePlanError):
        plan_edit(_spec(), "relighting", lighting="low_key", strength=2.0)
    edit = plan_edit(_spec(), "relighting", lighting="golden_hour")
    assert edit["strength"] == 0.5


def test_plan_edit_region_must_fit_canvas():
    with pytest.raises(ImagePlanError):
        plan_edit(_spec(), "object_removal",
                  region={"x": 0.8, "y": 0.0, "width": 0.5, "height": 0.5})


def test_plan_edit_unknown_kind_rejected():
    with pytest.raises(ImagePlanError):
        plan_edit(_spec(), "upscaling")


# ---------------------------------------------------------------------------
# asset library


def test_asset_library_registers_planned_assets_only():
    specs = _two_specs_same_character()
    library = build_asset_library(specs)
    assert [a["asset_id"] for a in library["assets"]] == ["asset-0001", "asset-0002"]
    assert all(a["status"] == "PLANNED" for a in library["assets"])
    assert library["assets"][0]["ref"] == "spec-S1"
    assert library["assets"][0]["source_shot"] == "S1"
    assert library["assets"][0]["kind"] == "image_spec"


def test_asset_library_includes_edit_plans():
    spec = _spec()
    edit = plan_edit(spec, "background_removal")
    library = build_asset_library([spec], edits=[edit])
    assert library["assets"][1]["kind"] == "edit_plan"
    assert library["assets"][1]["ref"] == edit["edit_id"]


def test_parse_asset_library_rejects_duplicates_and_bad_status():
    library = build_asset_library([_spec()])
    library["assets"].append(dict(library["assets"][0]))
    with pytest.raises(ImagePlanError):
        parse_asset_library(library)
    bad = build_asset_library([_spec()])
    bad["assets"][0]["status"] = "DONE"
    with pytest.raises(ImagePlanError):
        parse_asset_library(bad)


# ---------------------------------------------------------------------------
# critique + gates + readiness


def test_critique_clean_specs_no_findings():
    assert critique_specs(_two_specs_same_character()) == []


def test_critique_flags_empty_subject():
    spec = compose_image_spec(_shot(purpose=""))
    findings = critique_specs([spec])
    assert any(f["check"] == "empty_subject" for f in findings)
    assert all(f["detail"] for f in findings)  # explicit reasons


def test_critique_flags_contradictory_combo():
    spec = compose_image_spec(_shot(framing="establishing"))
    spec["aspect_ratio"] = "9:16"  # portrait vs establishing: contradiction
    findings = critique_specs([spec])
    combo = [f for f in findings if f["check"] == "contradictory_combo"]
    assert combo and combo[0]["severity"] == "error"
    assert "contradictory" in combo[0]["detail"] or "contradicts" in combo[0]["detail"]


def test_critique_flags_missing_consistency_token():
    specs = _two_specs_same_character()
    specs[1]["identity_tokens"] = []
    findings = critique_specs(specs)
    assert any(f["check"] == "missing_consistency_token" for f in findings)


def test_gates_pass_on_clean_plan_with_manifest():
    specs = _two_specs_same_character()
    manifest = build_asset_library(specs)
    assert run_image_gates(specs, manifest) == []


def test_gates_fail_on_duplicates_and_bad_manifest_ref():
    spec = _spec()
    failures = run_image_gates([spec, copy.deepcopy(spec)])
    assert any("duplicates" in f for f in failures)
    manifest = build_asset_library([spec])
    manifest["assets"][0]["ref"] = "spec-UNKNOWN"
    failures = run_image_gates([spec], manifest)
    assert any("unknown spec" in f for f in failures)


def test_gates_fail_on_contradiction_and_missing_token():
    specs = _two_specs_same_character()
    specs[0] = compose_image_spec(
        _shot(shot_id="S1", framing="establishing", characters=["Amina"])
    )
    specs[0]["aspect_ratio"] = "9:16"
    specs[1]["identity_tokens"] = []
    failures = run_image_gates(specs)
    assert any("contradicts" in f for f in failures)
    assert any("identity token" in f for f in failures)


def test_gates_empty_specs_fail():
    assert run_image_gates([]) == ["image_plan has no specs"]


def test_readiness_ready_seal():
    specs = _two_specs_same_character()
    manifest = build_asset_library(specs)
    seal = image_plan_readiness(specs, [], manifest)
    assert seal["ready"] is True
    assert seal["blocking_items"] == []
    assert seal["seal"]["authority_preserved"] is True
    assert seal["seal"]["assets_registered"] == 2


def test_readiness_blocks_on_failures_and_empty():
    seal = image_plan_readiness([], ["some failure"])
    assert seal["ready"] is False
    assert "some failure" in seal["blocking_items"]
    assert "no specs — image plan is empty" in seal["blocking_items"]
    assert seal["seal"]["authority_preserved"] is True
