"""Image generation planning engine — deterministic, offline, advisory.

SPEC/PLANNING side of §16 Image Generation. This module composes structured
generation SPECS (subject / setting / composition / lighting / style fields,
aspect ratio, negative constraints), consistency manifests across a shot list,
validated edit DESCRIPTORS (inpainting / outpainting / background-removal /
object-removal / relighting), and an asset library manifest of planned assets.
It produces plans and critiques only — it NEVER generates pixels, NEVER calls
an image model or external binary, and owns no state. Pure stdlib.

Pipeline (each step is independently callable and validated):
  compose_image_spec -> parse_image_spec
  build_consistency_manifest -> attach_consistency_manifest
  plan_edit -> build_asset_library -> parse_asset_library
  critique_specs -> run_image_gates -> image_plan_readiness seal.

Dedup (engine registry):
  - ENG-GRA-021 (graphics_fabric) is the VECTOR side of the graphics family:
    it builds SVG documents and lays out geometry. This module is the
    RASTER-generation SPEC side: it composes text/structure descriptors for a
    (hypothetical, external) raster generator and performs no drawing, no
    serialization, no layout math. No function, field, or gate overlaps.
  - ENG-WR-020 (storyboard_previs) is SHOT-side: it designs shot composition
    from scene plans. This module CONSUMES an ENG-WR-020 shot dict (or any
    caller-supplied dict with the same declared fields) and derives a
    generation spec from it — it never re-designs shots, never checks shot
    continuity, and never builds animatics.
  - ENG-UND-017 / ENG-RES-018 / ENG-WR-019 are TEXT-side (understanding,
    evidence, writing); ENG-DEC-002 is CHANGE-side. This engine touches none.
  - No canonical component is imported: the engine is composable but
    standalone, so it can never pull authority into an advisory path.

ABSENT stays ABSENT: a shot that declares no characters yields a spec with no
identity tokens; a shot with no setting yields setting "unspecified" and the
critique reports it — undeclared character/prop attributes (age, clothing,
color, model) are NEVER invented. All derived choices come from bounded,
inspectable rules over the shot's declared fields; nothing is "creative".
"""

from __future__ import annotations

from typing import Any, Iterable, Mapping

# ---------------------------------------------------------------------------
# Bounded vocabulary and budgets (mirrors storyboard_previs discipline).

_ASPECT_RATIOS = ("1:1", "4:3", "3:2", "16:9", "9:16", "21:9")
_PORTRAIT_ASPECTS = ("9:16",)
_ULTRAWIDE_ASPECTS = ("21:9",)

_STYLE_PRESETS = (
    "photorealistic",
    "cinematic",
    "illustration",
    "anime",
    "watercolor",
    "oil_painting",
)

_LIGHTING_MOODS = (
    "natural",
    "golden_hour",
    "overcast",
    "studio",
    "neon_night",
    "low_key",
    "high_key",
)

_COMPOSITION_RULES = (
    "rule_of_thirds",
    "centered",
    "leading_lines",
    "symmetrical",
    "negative_space",
)

_FRAMINGS = ("extreme_close_up", "close_up", "medium", "wide", "establishing")

_EDIT_KINDS = (
    "inpainting",
    "outpainting",
    "background_removal",
    "object_removal",
    "relighting",
)

_OUTPAINT_DIRECTIONS = ("left", "right", "up", "down")
_SEVERITIES = ("error", "warning")

_MAX_FIELD_WORDS = 40
_MAX_TEXT_WORDS = 80
_MAX_SPECS = 40
_MAX_ASSETS = 80
_MAX_TOKENS = 8
_MAX_FINDINGS = 20
_MAX_PALETTE = 6
_MIN_EXTENT = 0.05
_MAX_EXTENT = 1.0
_MIN_STRENGTH = 0.1
_MAX_STRENGTH = 1.0

_DEFAULT_NEGATIVES = (
    "no watermark",
    "no text artifacts",
    "no extra fingers",
    "no duplicated subjects",
)

_STYLE_NEGATIVES = {
    "photorealistic": ("no illustration outlines", "no cartoon artifacts"),
    "cinematic": ("no illustration outlines", "no flat shading"),
    "illustration": ("no photographic grain", "no lens distortion"),
    "anime": ("no photographic grain", "no lens distortion"),
    "watercolor": ("no photographic grain", "no hard vector edges"),
    "oil_painting": ("no photographic grain", "no lens flare artifacts"),
}

# Framing -> deterministic derived fields (all inspectable, first match wins).
_COMPOSITION_BY_FRAMING = {
    "establishing": "rule_of_thirds",
    "wide": "negative_space",
    "medium": "rule_of_thirds",
    "close_up": "centered",
    "extreme_close_up": "centered",
}

_ASPECT_BY_FRAMING = {
    "establishing": "16:9",
    "wide": "16:9",
    "medium": "3:2",
    "close_up": "4:3",
    "extreme_close_up": "1:1",
}

# Wording that tilts the lighting mood by bounded deterministic rule.
_MENACE_WORDS = ("obstacle", "threat", "conflict", "confront", "menace",
                 "danger", "chase", "argument", "对抗", "خطر")
_NIGHT_WORDS = ("night", "neon", "midnight", "dark", "ليل", "夜")
_WARM_WORDS = ("morning", "sunrise", "sunset", "golden", "dawn", "dusk",
               "فجر", "朝")

# Framings that tolerate portrait / ultrawide aspects without contradiction.
_PORTRAIT_OK_FRAMINGS = ("close_up", "extreme_close_up", "medium")
_ULTRAWIDE_OK_FRAMINGS = ("establishing", "wide")


class ImagePlanError(ValueError):
    """Bounded, user-facing image-plan parse/quality failure."""


def _words(text: str) -> int:
    return len(text.split())


def _short(text: str, where: str) -> str:
    value = text.strip()
    if not value:
        raise ImagePlanError(f"image_plan.{where} must be a non-empty string")
    if _words(value) > _MAX_FIELD_WORDS:
        raise ImagePlanError(
            f"image_plan.{where} exceeds {_MAX_FIELD_WORDS} words"
        )
    return value


def _bounded(text: str, cap: int = _MAX_FIELD_WORDS) -> str:
    """Bound free text to a word cap (used for composed, not validated, text)."""
    return " ".join((text or "").split()[:cap])


def _enum(value: Any, where: str, choices: tuple[str, ...]) -> str:
    name = str(value).strip()
    if name not in choices:
        raise ImagePlanError(
            f"image_plan.{where} must be one of {choices}"
        )
    return name


def _token_list(value: Any, where: str) -> list[str]:
    if not isinstance(value, list):
        raise ImagePlanError(f"image_plan.{where} must be a list")
    if len(value) > _MAX_TOKENS:
        raise ImagePlanError(f"image_plan.{where} exceeds {_MAX_TOKENS} entries")
    out: list[str] = []
    seen: set[str] = set()
    for item in value:
        token = _short(str(item), where)
        key = token.lower()
        if key not in seen:
            seen.add(key)
            out.append(token)
    return out


def _palette(value: Any, where: str) -> list[str]:
    if not isinstance(value, list):
        raise ImagePlanError(f"image_plan.{where} must be a list")
    if not value:
        raise ImagePlanError(f"image_plan.{where} must not be empty")
    if len(value) > _MAX_PALETTE:
        raise ImagePlanError(f"image_plan.{where} exceeds {_MAX_PALETTE} entries")
    out: list[str] = []
    for item in value:
        color = str(item).strip()
        if not color:
            raise ImagePlanError(f"image_plan.{where} entries must be non-empty")
        if _words(color) > 3:
            raise ImagePlanError(
                f"image_plan.{where} entries exceed 3 words"
            )
        if color.lower() not in {c.lower() for c in out}:
            out.append(color)
    return out


def _num_in(value: Any, where: str, low: float, high: float) -> float:
    if isinstance(value, bool):
        raise ImagePlanError(f"image_plan.{where} must be a number")
    try:
        number = float(value)
    except (TypeError, ValueError):
        raise ImagePlanError(f"image_plan.{where} must be a number") from None
    if not low <= number <= high:
        raise ImagePlanError(
            f"image_plan.{where} must be within {low}..{high}"
        )
    return number


def _identity_token(name: str) -> str:
    """Deterministic shared identity token for a declared character name."""
    slug = "-".join(name.lower().split())
    return f"char:{slug}"


def _recurring_token_gaps(
    parsed: list[dict[str, Any]],
) -> list[tuple[str, str, set[str]]]:
    """Characters whose identity token is missing where their name appears.

    A character is recurring when the union of specs holding its identity
    token and specs merely naming it in the subject spans 2+ specs. Every
    spec that names the character in its subject but does not carry the
    token is a gap: (token, spec_id, token_holders)."""
    holders: dict[str, set[str]] = {}
    for spec in parsed:
        for token in spec["identity_tokens"]:
            holders.setdefault(token, set()).add(spec["spec_id"])
    gaps: list[tuple[str, str, set[str]]] = []
    for token, token_holders in sorted(holders.items()):
        name = token.removeprefix("char:")
        for spec in parsed:
            if spec["spec_id"] in token_holders:
                continue
            if token not in spec["identity_tokens"] \
                    and name in spec["subject"].lower():
                gaps.append((token, spec["spec_id"], token_holders))
    return gaps


# ---------------------------------------------------------------------------
# 1. Spec composition: shot -> structured generation spec. Every derived field
#    comes from a bounded rule over the shot's DECLARED fields; brief/style
#    caller overrides are validated through the same enums. ABSENT stays
#    ABSENT: undeclared characters/props/attributes are never invented.


def compose_image_spec(
    shot: Mapping[str, Any],
    brief: Mapping[str, Any] | None = None,
    style: str | None = None,
) -> dict[str, Any]:
    """Compose a structured generation spec from one shot (ENG-WR-020 output
    shape, or any caller-supplied dict with the same declared fields).

    Derived fields (first decisive rule wins, all inspectable):
      subject    — brief.subject if supplied, else the shot's declared
                   characters joined, else a bounded form of the shot purpose
      setting    — brief override, else the shot's declared setting, else
                   "unspecified" (reported by the critique, never fabricated)
      composition— bounded mapping from the shot framing
      lighting   — menace wording -> low_key; night wording -> neon_night;
                   warm wording -> golden_hour; brief override wins; else
                   natural
      style      — validated caller style (param beats brief), else brief
                   style, else "photorealistic"
      aspect     — bounded mapping from the shot framing (brief override wins)
      negatives  — defaults + style-specific additions + brief extras
      identity_tokens / asset_refs — only for caller-declared characters/props

    This composes a SPEC, not pixels: no model is called and no image state
    exists anywhere in this module.
    """
    if not isinstance(shot, Mapping):
        raise ImagePlanError("image_plan.compose_image_spec expects a shot object")
    if brief is not None and not isinstance(brief, Mapping):
        raise ImagePlanError("image_plan.brief must be an object")
    brief = brief or {}

    shot_id = _short(str(shot.get("shot_id", "shot")), "shot_id")
    framing = shot.get("framing", "medium")
    if framing is not None:
        framing = _enum(framing, "framing", _FRAMINGS)
    else:
        framing = "medium"

    characters = _token_list(shot["characters"], "characters") \
        if shot.get("characters") is not None else []
    props = _token_list(shot["props"], "props") \
        if shot.get("props") is not None else []

    # subject: caller brief wins; then declared characters; then purpose.
    if brief.get("subject") is not None:
        subject = _short(str(brief["subject"]), "brief.subject")
    elif characters:
        subject = _bounded(", ".join(characters))
    else:
        purpose = str(shot.get("purpose", "") or "")
        subject = _bounded(purpose) if purpose.strip() else "unspecified subject"

    if brief.get("setting") is not None:
        setting = _short(str(brief["setting"]), "brief.setting")
    elif shot.get("setting"):
        setting = _short(str(shot["setting"]), "setting")
    else:
        setting = "unspecified"

    if style is not None:
        style_name = _enum(style, "style", _STYLE_PRESETS)
    elif brief.get("style") is not None:
        style_name = _enum(brief["style"], "brief.style", _STYLE_PRESETS)
    else:
        style_name = "photorealistic"

    if brief.get("lighting") is not None:
        lighting = _enum(brief["lighting"], "brief.lighting", _LIGHTING_MOODS)
    else:
        text = " ".join([str(shot.get("purpose", "") or ""),
                         str(shot.get("setting", "") or "")]).lower()
        if any(w in text for w in _MENACE_WORDS):
            lighting = "low_key"
        elif any(w in text for w in _NIGHT_WORDS):
            lighting = "neon_night"
        elif any(w in text for w in _WARM_WORDS):
            lighting = "golden_hour"
        else:
            lighting = "natural"

    if brief.get("aspect_ratio") is not None:
        aspect = _enum(brief["aspect_ratio"], "brief.aspect_ratio", _ASPECT_RATIOS)
    else:
        aspect = _ASPECT_BY_FRAMING[framing]

    negatives = list(_DEFAULT_NEGATIVES) + list(_STYLE_NEGATIVES[style_name])
    if brief.get("negative_extra") is not None:
        negatives += _token_list(brief["negative_extra"], "brief.negative_extra")
    deduped: list[str] = []
    for neg in negatives:
        if neg not in deduped:
            deduped.append(neg)

    spec: dict[str, Any] = {
        "spec_id": f"spec-{shot_id}",
        "source_shot": shot_id,
        "framing_hint": framing,
        "subject": subject,
        "setting": setting,
        "composition": _COMPOSITION_BY_FRAMING[framing],
        "lighting": lighting,
        "style": style_name,
        "aspect_ratio": aspect,
        "palette": _palette(brief["palette"], "brief.palette")
        if brief.get("palette") is not None else [],
        "negative_constraints": deduped,
        "identity_tokens": [_identity_token(c) for c in characters],
        "asset_refs": list(props),
        "consistency_rules": [],
        "status": "PLANNED",
        "note": "generation spec only — no pixels are produced",
    }
    return parse_image_spec(spec)


# ---------------------------------------------------------------------------
# Strict parse / validate (mirrors storyboard_previs parse discipline).
# Unknown keys are ignored (forward-tolerant); required keys and enums are
# enforced; free-text fields are word-capped.


def parse_image_spec(payload: Any) -> dict[str, Any]:
    """Validate and normalize one generation spec.

    Raises ImagePlanError with a specific reason. Cross-spec consistency
    (recurring characters, contradictory combos) is the CRITIQUE's and
    GATE's job, not the parser's.
    """
    if not isinstance(payload, Mapping):
        raise ImagePlanError("image_plan spec must be a JSON object")
    required = (
        "spec_id", "source_shot", "subject", "setting", "composition",
        "lighting", "style", "aspect_ratio", "negative_constraints",
        "identity_tokens", "asset_refs", "status",
    )
    missing = [k for k in required if k not in payload]
    if missing:
        raise ImagePlanError(
            f"image_plan spec missing required field(s): {missing}"
        )

    spec: dict[str, Any] = {
        "spec_id": _short(str(payload["spec_id"]), "spec_id"),
        "source_shot": _short(str(payload["source_shot"]), "source_shot"),
        "framing_hint": _enum(
            payload.get("framing_hint", "medium"), "framing_hint", _FRAMINGS
        ),
        "subject": _short(str(payload["subject"]), "subject"),
        "setting": _short(str(payload["setting"]), "setting"),
        "composition": _enum(payload["composition"], "composition", _COMPOSITION_RULES),
        "lighting": _enum(payload["lighting"], "lighting", _LIGHTING_MOODS),
        "style": _enum(payload["style"], "style", _STYLE_PRESETS),
        "aspect_ratio": _enum(payload["aspect_ratio"], "aspect_ratio", _ASPECT_RATIOS),
        "palette": _palette(payload["palette"], "palette")
        if payload.get("palette") else [],
        "negative_constraints": _token_list(
            payload["negative_constraints"], "negative_constraints"
        ),
        "identity_tokens": _token_list(
            payload["identity_tokens"], "identity_tokens"
        ),
        "asset_refs": _token_list(payload["asset_refs"], "asset_refs"),
        "consistency_rules": [
            _short(str(r), "consistency_rules")
            for r in payload.get("consistency_rules", [])
        ][: _MAX_TOKENS],
        "status": _enum(payload["status"], "status", ("PLANNED",)),
    }
    if payload.get("note") is not None:
        spec["note"] = _bounded(str(payload["note"]), _MAX_TEXT_WORDS)
    return spec


# ---------------------------------------------------------------------------
# 2. Consistency manifest: shared identity tokens, palette tokens, and
#    explicit per-asset consistency rules across a shot list's specs.


def build_consistency_manifest(
    specs: Iterable[Mapping[str, Any]],
) -> dict[str, Any]:
    """Build a cross-spec consistency manifest.

    Deterministic rules (all inspectable):
      recurring characters — a declared character (by shared identity token)
                           appearing in 2+ specs gets one canonical token and
                           an explicit rule on every spec that declares it
      palette tokens       — the union of caller-supplied palette entries,
                             reported as shared tokens
      missing tokens       — a recurring character whose token is absent from
                           some declaring spec is reported as a warning entry
                           (explicit reason), never silently patched

    Characters are matched ONLY by their declared identity tokens; nothing
    about appearance is inferred or invented.
    """
    parsed = [parse_image_spec(s) for s in (specs or [])]
    if not parsed:
        raise ImagePlanError(
            "image_plan.build_consistency_manifest expects at least one spec"
        )

    token_to_specs: dict[str, list[str]] = {}
    for spec in parsed:
        for token in spec["identity_tokens"]:
            token_to_specs.setdefault(token, []).append(spec["spec_id"])

    characters: list[dict[str, Any]] = []
    palette: list[str] = []
    for spec in parsed:
        for color in spec["palette"]:
            if color.lower() not in {c.lower() for c in palette}:
                palette.append(color)

    gaps = _recurring_token_gaps(parsed)
    gap_tokens = {token for token, _, _ in gaps}

    manifest_specs: list[dict[str, Any]] = []
    warnings: list[str] = [
        f"recurring character {token} named in subject of spec {spec_id} "
        f"but identity token absent"
        for token, spec_id, _ in gaps
    ]
    for spec in parsed:
        rules = list(spec["consistency_rules"])
        for token in sorted(token_to_specs):
            holders = token_to_specs[token]
            if len(holders) < 2:
                continue  # single-appearance character: no consistency rule
            if token in spec["identity_tokens"]:
                rule = _bounded(
                    f"keep identity token {token} consistent across "
                    f"{len(holders)} specs: {', '.join(sorted(holders))}"
                )
                if rule not in rules:
                    rules.append(rule)
            elif token in gap_tokens:
                rule = _bounded(
                    f"restore identity token {token} — the character recurs "
                    f"across this shot list"
                )
                if rule not in rules:
                    rules.append(rule)
        entry = dict(spec)
        entry["consistency_rules"] = rules[:_MAX_TOKENS]
        manifest_specs.append(entry)

    for token, holders in sorted(token_to_specs.items()):
        if len(holders) >= 2:
            characters.append({
                "identity_token": token,
                "appears_in": sorted(holders),
                "shared_palette": palette,
            })

    return {
        "characters": characters,
        "palette_tokens": palette,
        "specs": manifest_specs,
        "warnings": sorted(set(warnings))[:_MAX_FINDINGS],
    }


def attach_consistency_manifest(
    specs: Iterable[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    """Return the specs with the consistency manifest's per-asset rules
    attached (validated through parse_image_spec)."""
    manifest = build_consistency_manifest(specs)
    return [parse_image_spec(s) for s in manifest["specs"]]


# ---------------------------------------------------------------------------
# 3. Edit planning: validated edit DESCRIPTORS only. mask region, direction,
#    and bounds are structural data for an external editor — no pixel op ever
#    runs here.


def _parse_region(value: Any, where: str) -> dict[str, float]:
    if not isinstance(value, Mapping):
        raise ImagePlanError(f"image_plan.{where} must be an object")
    region = {
        "x": _num_in(value.get("x"), f"{where}.x", 0.0, 1.0),
        "y": _num_in(value.get("y"), f"{where}.y", 0.0, 1.0),
        "width": _num_in(value.get("width"), f"{where}.width", 0.0, 1.0),
        "height": _num_in(value.get("height"), f"{where}.height", 0.0, 1.0),
    }
    if region["x"] + region["width"] > 1.0 + 1e-9:
        raise ImagePlanError(f"image_plan.{where} exceeds right image bound")
    if region["y"] + region["height"] > 1.0 + 1e-9:
        raise ImagePlanError(f"image_plan.{where} exceeds bottom image bound")
    return region


def plan_edit(
    spec: Mapping[str, Any],
    edit_kind: str,
    *,
    region: Mapping[str, Any] | None = None,
    direction: str | None = None,
    guidance: str = "",
    extent: Any = None,
    strength: Any = None,
    lighting: str | None = None,
) -> dict[str, Any]:
    """Plan one validated edit DESCRIPTOR against a composed spec.

    Per-kind requirements (each raises ImagePlanError with a reason):
      inpainting        — mask region (normalized box) + non-empty guidance
      outpainting       — direction (left/right/up/down) + extent fraction
      background_removal— no region; the whole background is the target
      object_removal    — mask region (contents marked for removal)
      relighting        — lighting mood + strength 0.1..1.0

    The returned descriptor carries status PLANNED and performs no pixel
    operations — it is data for an external editor, nothing more.
    """
    if not isinstance(spec, Mapping):
        raise ImagePlanError("image_plan.plan_edit expects a spec object")
    parsed_spec = parse_image_spec(spec)
    kind = _enum(edit_kind, "edit_kind", _EDIT_KINDS)
    text = _bounded(guidance) if guidance else ""

    descriptor: dict[str, Any] = {
        "edit_id": f"edit-{parsed_spec['spec_id']}-{kind}",
        "kind": kind,
        "source_spec_id": parsed_spec["spec_id"],
        "status": "PLANNED",
        "note": "edit descriptor only — no pixel operations performed",
    }

    if kind == "inpainting":
        if region is None:
            raise ImagePlanError(
                "image_plan.inpainting requires a mask region"
            )
        if not text:
            raise ImagePlanError(
                "image_plan.inpainting requires non-empty guidance"
            )
        descriptor["mask_region"] = _parse_region(region, "region")
        descriptor["guidance"] = text
        descriptor["bounds"] = {"area_fraction_max": 0.5}
    elif kind == "outpainting":
        if direction is None:
            raise ImagePlanError(
                "image_plan.outpainting requires a direction"
            )
        descriptor["direction"] = _enum(
            direction, "direction", _OUTPAINT_DIRECTIONS
        )
        descriptor["extent"] = _num_in(
            extent if extent is not None else 0.25,
            "extent", _MIN_EXTENT, _MAX_EXTENT,
        )
        descriptor["bounds"] = {"canvas_growth_max": _MAX_EXTENT}
    elif kind == "background_removal":
        descriptor["target"] = "background"
    elif kind == "object_removal":
        if region is None:
            raise ImagePlanError(
                "image_plan.object_removal requires a mask region"
            )
        descriptor["mask_region"] = _parse_region(region, "region")
        descriptor["target"] = "masked region contents"
    elif kind == "relighting":
        if lighting is None:
            raise ImagePlanError(
                "image_plan.relighting requires a lighting mood"
            )
        descriptor["lighting"] = _enum(lighting, "lighting", _LIGHTING_MOODS)
        descriptor["strength"] = _num_in(
            strength if strength is not None else 0.5,
            "strength", _MIN_STRENGTH, _MAX_STRENGTH,
        )
    return descriptor


# ---------------------------------------------------------------------------
# 4. Asset library manifest: registry of PLANNED assets only — every entry
#    links an id, a kind, a source shot, and a spec/edit reference. Status
#    PLANNED is the only value this engine can ever emit.


def parse_asset_library(payload: Any) -> dict[str, Any]:
    """Validate and normalize an asset library manifest."""
    if not isinstance(payload, Mapping):
        raise ImagePlanError("image_plan asset library must be a JSON object")
    assets = payload.get("assets")
    if not isinstance(assets, list):
        raise ImagePlanError("image_plan.assets must be a list")
    if len(assets) > _MAX_ASSETS:
        raise ImagePlanError(f"image_plan.assets exceeds {_MAX_ASSETS} entries")
    parsed_assets: list[dict[str, Any]] = []
    seen: set[str] = set()
    for index, asset in enumerate(assets):
        where = f"assets[{index}]"
        if not isinstance(asset, Mapping):
            raise ImagePlanError(f"image_plan.{where} must be an object")
        entry = {
            "asset_id": _short(str(asset.get("asset_id", "")), f"{where}.asset_id"),
            "kind": _enum(
                asset.get("kind"), f"{where}.kind",
                ("image_spec", "edit_plan"),
            ),
            "source_shot": _short(
                str(asset.get("source_shot", "")), f"{where}.source_shot"
            ),
            "ref": _short(str(asset.get("ref", "")), f"{where}.ref"),
            "status": _enum(asset.get("status"), f"{where}.status", ("PLANNED",)),
        }
        if entry["asset_id"] in seen:
            raise ImagePlanError(
                f"image_plan.{where}.asset_id duplicates {entry['asset_id']}"
            )
        seen.add(entry["asset_id"])
        parsed_assets.append(entry)
    return {"assets": parsed_assets}


def build_asset_library(
    specs: Iterable[Mapping[str, Any]],
    edits: Iterable[Mapping[str, Any]] = (),
) -> dict[str, Any]:
    """Register every spec (and optional edit descriptor) as a PLANNED asset.

    Asset ids are deterministic (asset-0001, asset-0002, ...) in input order.
    """
    parsed_specs = [parse_image_spec(s) for s in (specs or [])]
    assets: list[dict[str, Any]] = [
        {
            "asset_id": f"asset-{i + 1:04d}",
            "kind": "image_spec",
            "source_shot": spec["source_shot"],
            "ref": spec["spec_id"],
            "status": "PLANNED",
        }
        for i, spec in enumerate(parsed_specs)
    ]
    base = len(assets)
    for offset, edit in enumerate(edits or []):
        if not isinstance(edit, Mapping):
            raise ImagePlanError("image_plan build_asset_library edit must be an object")
        assets.append({
            "asset_id": f"asset-{base + offset + 1:04d}",
            "kind": "edit_plan",
            "source_shot": str(edit.get("source_spec_id", "")),
            "ref": _short(str(edit.get("edit_id", "")), "edit.edit_id"),
            "status": "PLANNED",
        })
    return parse_asset_library({"assets": assets})


# ---------------------------------------------------------------------------
# 5. Critique: explicit, reasoned findings. Never edits the specs.


def _contradiction_reasons(spec: Mapping[str, Any]) -> list[str]:
    reasons: list[str] = []
    framing = spec["framing_hint"]
    aspect = spec["aspect_ratio"]
    if aspect in _PORTRAIT_ASPECTS and framing not in _PORTRAIT_OK_FRAMINGS:
        reasons.append(
            f"portrait aspect {aspect} contradicts {framing} framing "
            f"(establishing/wide scenes need horizontal coverage)"
        )
    if aspect in _ULTRAWIDE_ASPECTS and framing not in _ULTRAWIDE_OK_FRAMINGS:
        reasons.append(
            f"ultrawide aspect {aspect} contradicts {framing} framing "
            f"(subject-focused framings waste ultrawide canvas)"
        )
    return reasons


def critique_specs(specs: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
    """Check a spec list and return explicit, reasoned findings.

    Checks (each inspectable; findings cap at _MAX_FINDINGS):
      empty_subject            — subject is empty/placeholder ('unspecified')
      contradictory_combo      — aspect ratio fights the framing hint
      missing_consistency_token— a recurring character (2+ specs by shared
                                 identity token) lacks its token somewhere
    """
    parsed = [parse_image_spec(s) for s in (specs or [])]
    findings: list[dict[str, Any]] = []

    for spec in parsed:
        if spec["subject"].lower().startswith("unspecified"):
            findings.append({
                "check": "empty_subject",
                "severity": "warning",
                "spec_id": spec["spec_id"],
                "detail": _bounded(
                    f"spec {spec['spec_id']} has no declared subject — the "
                    f"shot declared neither characters nor a usable purpose"
                ),
            })
        for reason in _contradiction_reasons(spec):
            findings.append({
                "check": "contradictory_combo",
                "severity": "error",
                "spec_id": spec["spec_id"],
                "detail": _bounded(reason),
            })

    for token, spec_id, holders in _recurring_token_gaps(parsed):
        findings.append({
            "check": "missing_consistency_token",
            "severity": "warning",
            "spec_id": spec_id,
            "detail": _bounded(
                f"recurring character {token} holds an identity token in "
                f"{len(holders)} spec(s) and is named in the subject of "
                f"{spec_id}, but that spec carries no identity token"
            ),
        })
    return findings[:_MAX_FINDINGS]


# ---------------------------------------------------------------------------
# Deterministic gates over the spec list + asset library, then the readiness
# seal. Failures are reasons (empty = pass); nothing here weakens or replaces
# canonical validation.


def run_image_gates(
    specs: Iterable[Mapping[str, Any]],
    manifest: Mapping[str, Any] | None = None,
) -> list[str]:
    """Consistency gates: specs parse strictly; spec ids are unique; no
    contradictory aspect/framing combos; recurring characters carry their
    identity tokens; the asset library references only known specs/edits and
    holds PLANNED assets only."""
    failures: list[str] = []
    raw = list(specs or [])
    if not raw:
        return ["image_plan has no specs"]
    if len(raw) > _MAX_SPECS:
        return [f"image_plan exceeds {_MAX_SPECS} specs"]
    try:
        parsed = [parse_image_spec(s) for s in raw]
    except ImagePlanError as exc:
        return [f"spec failed validation: {exc}"]

    ids = [s["spec_id"] for s in parsed]
    if len(set(ids)) != len(ids):
        failures.append("spec ids contain duplicates")

    for spec in parsed:
        for reason in _contradiction_reasons(spec):
            failures.append(f"{spec['spec_id']}: {reason}")

    for token, spec_id, _ in _recurring_token_gaps(parsed):
        failures.append(
            f"{spec_id}: recurring character {token} named in subject "
            f"but missing identity token"
        )

    if manifest is not None:
        try:
            library = parse_asset_library(manifest)
        except ImagePlanError as exc:
            return failures + [f"asset library invalid: {exc}"]
        for asset in library["assets"]:
            if asset["kind"] == "image_spec" and asset["ref"] not in ids:
                failures.append(
                    f"asset {asset['asset_id']} references unknown spec "
                    f"{asset['ref']}"
                )
    return failures


def image_plan_readiness(
    specs: Iterable[Mapping[str, Any]],
    gate_failures: list[str],
    manifest: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Image-plan readiness seal. READY requires clean gates and at least one
    spec — a plan without specs is a generation of nothing. This engine is
    advisory: the seal always reports authority_preserved."""
    blocking = list(gate_failures)
    raw = list(specs or [])
    if not raw:
        blocking.append("no specs — image plan is empty")
    if manifest is not None:
        try:
            library = parse_asset_library(manifest)
        except ImagePlanError as exc:
            blocking.append(f"asset library invalid: {exc}")
            library = {"assets": []}
    else:
        library = {"assets": []}
    ready = not blocking
    return {
        "ready": ready,
        "blocking_items": blocking,
        "seal": {
            "specs_composed": bool(raw),
            "assets_registered": len(library["assets"]),
            "gates_clean": not gate_failures,
            "authority_preserved": True,  # advisory engine only
        },
    }
