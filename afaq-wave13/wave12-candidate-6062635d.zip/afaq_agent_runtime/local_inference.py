"""Process-isolated, provider-free local inference for AFAQ AI."""
from __future__ import annotations

import multiprocessing as mp
import os
import threading
import time
from pathlib import Path
from typing import Any, Mapping


def _install_network_guard():
    """Block non-loopback socket and DNS access; return a restore callback."""
    import ipaddress
    import socket

    original_connect = socket.socket.connect
    original_create_connection = socket.create_connection
    original_getaddrinfo = socket.getaddrinfo

    def _is_loopback(host: Any) -> bool:
        if host in {"localhost", "127.0.0.1", "::1"}:
            return True
        try:
            return ipaddress.ip_address(str(host)).is_loopback
        except ValueError:
            return False

    def guarded_connect(sock: socket.socket, address: Any) -> Any:
        if isinstance(address, tuple) and address:
            host = address[0]
            if not _is_loopback(host):
                raise PermissionError(
                    f"AFAQ local inference blocks outbound network access to {host}"
                )
        return original_connect(sock, address)

    def guarded_create_connection(address: Any, *args: Any, **kwargs: Any) -> socket.socket:
        if isinstance(address, tuple) and address:
            host = address[0]
            if not _is_loopback(host):
                raise PermissionError(
                    f"AFAQ local inference blocks outbound network access to {host}"
                )
        return original_create_connection(address, *args, **kwargs)

    def guarded_getaddrinfo(host: Any, *args: Any, **kwargs: Any):
        if host is not None and not _is_loopback(host):
            raise PermissionError(
                f"AFAQ local inference blocks external DNS/network resolution for {host}"
            )
        return original_getaddrinfo(host, *args, **kwargs)

    socket.socket.connect = guarded_connect
    socket.create_connection = guarded_create_connection
    socket.getaddrinfo = guarded_getaddrinfo

    def restore() -> None:
        socket.socket.connect = original_connect
        socket.create_connection = original_create_connection
        socket.getaddrinfo = original_getaddrinfo

    return restore


def _collect_text(value: Any, out: list[str]) -> None:
    if len(out) >= 32:
        return
    if isinstance(value, str):
        value = value.strip()
        if value and value not in out:
            out.append(value)
        return
    if isinstance(value, Mapping):
        for key in ("answer", "text", "output", "summary", "message", "content", "normalized"):
            if key in value:
                _collect_text(value[key], out)
        for key, item in value.items():
            if key not in {"answer", "text", "output", "summary", "message", "content", "normalized"}:
                _collect_text(item, out)
        return
    if isinstance(value, (list, tuple)):
        for item in value:
            _collect_text(item, out)


def _compose_text(prompt: str, executions: list[dict[str, Any]]) -> str:
    snippets: list[str] = []
    for execution in executions:
        _collect_text(execution.get("result"), snippets)
    if snippets:
        return "\n".join(snippets)
    return (
        "AFAQ local inference completed with structured engine output."
        if executions
        else f"AFAQ local inference produced no executable engine output for: {prompt}"
    )


def _worker(
    conn: Any,
    project_root: str,
    prompt: str,
    context: dict[str, Any],
    engine_ids: tuple[str, ...],
    payload: dict[str, Any],
    approved_by_job: bool,
) -> None:
    # Mandatory invariant for this execution path: provider adapters must
    # fail closed before network I/O.
    os.environ["AFAQ_LOCAL_ONLY"] = "1"
    restore_network = _install_network_guard()
    try:
        if engine_ids:
            from engines_live.fabric import invoke
            executions = []
            evidence_refs: list[str] = []
            merged = {"prompt": prompt, "text": prompt, "input": prompt, "context": context, **payload}
            for engine_id in engine_ids:
                row = invoke(engine_id, merged).as_dict()
                executions.append(row)
                evidence = row.get("evidence")
                if isinstance(evidence, Mapping) and evidence.get("run_path"):
                    evidence_refs.append(str(evidence["run_path"]))
            completed = bool(executions) and all(bool(row.get("ok")) for row in executions)
            blocked = not completed
            plan = {"mode": "explicit_engines", "engine_ids": list(engine_ids), "registry_driven": True}
            mode = "EXPLICIT_REGISTERED_ENGINES"
        else:
            from .native_generator import (
                NativeGeneratorUnavailable,
                NativeModelIntegrityError,
                generate_native,
                native_generator_status,
            )

            generator_status = native_generator_status(project_root)
            try:
                generation = generate_native(
                    project_root,
                    prompt,
                    context=context,
                    payload=payload,
                )
            except NativeGeneratorUnavailable as exc:
                conn.send({
                    "schema": "AFAQ_LOCAL_INFERENCE_V1",
                    "success": False,
                    "completed": False,
                    "blocked": False,
                    "text": "",
                    "mode": "AFAQ_NATIVE_GGUF",
                    "engine_ids": [],
                    "plan": {},
                    "executions": [],
                    "evidence_refs": [],
                    "runtime": {
                        "local_only": True,
                        "external_provider_dependency": False,
                        "external_daemon_required": False,
                        "network_required": False,
                        "process_isolated": True,
                        "worker_recycled": True,
                        "generator_available": False,
                        "generator_backend": "llama_cpp",
                        "model_available": bool(generator_status.get("model_available")),
                    },
                    "error": {
                        "code": "LOCAL_GENERATOR_UNAVAILABLE",
                        "message": str(exc),
                    },
                })
                return
            except NativeModelIntegrityError as exc:
                conn.send({
                    "schema": "AFAQ_LOCAL_INFERENCE_V1",
                    "success": False,
                    "completed": False,
                    "blocked": True,
                    "text": "",
                    "mode": "AFAQ_NATIVE_GGUF",
                    "engine_ids": [],
                    "plan": {},
                    "executions": [],
                    "evidence_refs": [],
                    "runtime": {
                        "local_only": True,
                        "external_provider_dependency": False,
                        "external_daemon_required": False,
                        "network_required": False,
                        "process_isolated": True,
                        "worker_recycled": True,
                        "generator_available": False,
                        "generator_backend": "llama_cpp",
                        "model_available": True,
                    },
                    "error": {
                        "code": "LOCAL_GENERATOR_MODEL_INTEGRITY_FAILED",
                        "message": str(exc),
                    },
                })
                return

            conn.send({
                "schema": "AFAQ_LOCAL_INFERENCE_V1",
                "success": True,
                "completed": True,
                "blocked": False,
                "text": generation["text"],
                "mode": "AFAQ_NATIVE_GGUF",
                "engine_ids": [],
                "plan": {},
                "executions": [],
                "evidence_refs": [],
                "runtime": {
                    "local_only": True,
                    "external_provider_dependency": False,
                    "external_daemon_required": False,
                    "network_required": False,
                    "process_isolated": True,
                    "worker_recycled": True,
                    "generator_available": True,
                    "generator_backend": generation["backend"],
                    "generator_identity": generation.get("generator_identity", "AFAQ"),
                    "model_profile": generation.get("model_profile"),
                    "model_quantization": generation.get("model_quantization"),
                    "base_model_provenance": generation.get("base_model_provenance"),
                    "model_path": generation["model_path"],
                    "model_sha256": generation["model_sha256"],
                    "model_size_bytes": generation["model_size_bytes"],
                    "finish_reason": generation.get("finish_reason"),
                    "output_truncated": generation.get("output_truncated", False),
                    "generation_seconds": generation.get("generation_seconds"),
                    "tokens_per_second": generation.get("tokens_per_second"),
                    "usage": generation.get("usage", {}),
                },
                "error": None,
            })
            return

        conn.send({
            "schema": "AFAQ_LOCAL_INFERENCE_V1",
            "success": completed,
            "completed": completed,
            "blocked": blocked,
            "text": _compose_text(prompt, executions),
            "mode": mode,
            "engine_ids": list(engine_ids),
            "plan": plan,
            "executions": executions,
            "evidence_refs": sorted(set(evidence_refs)),
            "runtime": {
                "local_only": True,
                "external_provider_dependency": False,
                "external_daemon_required": False,
                "network_required": False,
                "process_isolated": True,
                "worker_recycled": True,
                "generator_available": True,
            },
            "error": None,
        })
    except MemoryError:
        conn.send({
            "schema": "AFAQ_LOCAL_INFERENCE_V1",
            "success": False,
            "completed": False,
            "blocked": False,
            "text": "",
            "mode": "EXPLICIT_REGISTERED_ENGINES" if engine_ids else "AFAQ_NATIVE_GGUF",
            "engine_ids": list(engine_ids),
            "plan": {},
            "executions": [],
            "evidence_refs": [],
            "runtime": {
                "local_only": True,
                "external_provider_dependency": False,
                "external_daemon_required": False,
                "network_required": False,
                "process_isolated": True,
                "worker_recycled": True,
            },
            "error": {
                "code": "LOCAL_INFERENCE_MEMORY_PRESSURE",
                "message": "isolated inference worker exhausted available memory",
            },
        })
    except BaseException as exc:
        conn.send({
            "schema": "AFAQ_LOCAL_INFERENCE_V1",
            "success": False,
            "completed": False,
            "blocked": False,
            "text": "",
            "mode": "EXPLICIT_REGISTERED_ENGINES" if engine_ids else "AFAQ_NATIVE_GGUF",
            "engine_ids": list(engine_ids),
            "plan": {},
            "executions": [],
            "evidence_refs": [],
            "runtime": {
                "local_only": True,
                "external_provider_dependency": False,
                "external_daemon_required": False,
                "network_required": False,
                "process_isolated": True,
                "worker_recycled": True,
            },
            "error": {
                "code": "LOCAL_INFERENCE_WORKER_ERROR",
                "class": type(exc).__name__,
                "message": str(exc),
            },
        })
    finally:
        restore_network()
        conn.close()


def run_local_inference(
    project_root: str | Path,
    prompt: str,
    *,
    context: Mapping[str, Any] | None = None,
    engine_ids: list[str] | tuple[str, ...] | None = None,
    payload: Mapping[str, Any] | None = None,
    approved_by_job: bool = False,
    timeout_seconds: float = 300.0,
) -> dict[str, Any]:
    prompt = str(prompt or "").strip()
    if not prompt:
        raise ValueError("prompt is required")
    root = Path(project_root).resolve()
    if not root.is_dir():
        raise ValueError(f"project root not found: {root}")

    ids = tuple(str(item).strip() for item in (engine_ids or ()) if str(item).strip())
    ctx = mp.get_context("spawn")
    recv_conn, send_conn = ctx.Pipe(duplex=False)
    process = ctx.Process(
        target=_worker,
        args=(
            send_conn,
            str(root),
            prompt,
            dict(context or {}),
            ids,
            dict(payload or {}),
            bool(approved_by_job),
        ),
        name="afaq-local-inference",
        daemon=False,
    )
    process.start()
    send_conn.close()
    timeout = max(1.0, float(timeout_seconds))
    try:
        if not recv_conn.poll(timeout):
            if process.is_alive():
                process.terminate()
            process.join(timeout=5)
            return {
                "schema": "AFAQ_LOCAL_INFERENCE_V1",
                "success": False,
                "completed": False,
                "blocked": False,
                "text": "",
                "mode": "EXPLICIT_REGISTERED_ENGINES" if ids else "AFAQ_NATIVE_GGUF",
                "engine_ids": list(ids),
                "plan": {},
                "executions": [],
                "evidence_refs": [],
                "runtime": {
                    "local_only": True,
                    "external_provider_dependency": False,
                    "external_daemon_required": False,
                    "network_required": False,
                    "process_isolated": True,
                    "worker_recycled": True,
                },
                "error": {
                    "code": "LOCAL_INFERENCE_TIMEOUT",
                    "message": f"isolated inference exceeded {timeout:g} seconds",
                },
            }
        result = dict(recv_conn.recv())
        process.join(timeout=5)
        return result
    except EOFError:
        return {
            "schema": "AFAQ_LOCAL_INFERENCE_V1",
            "success": False,
            "completed": False,
            "blocked": False,
            "text": "",
            "mode": "EXPLICIT_REGISTERED_ENGINES" if ids else "AFAQ_NATIVE_GGUF",
            "engine_ids": list(ids),
            "plan": {},
            "executions": [],
            "evidence_refs": [],
            "runtime": {
                "local_only": True,
                "external_provider_dependency": False,
                "external_daemon_required": False,
                "network_required": False,
                "process_isolated": True,
                "worker_recycled": True,
            },
            "error": {
                "code": "LOCAL_INFERENCE_WORKER_EXITED",
                "message": f"inference worker exited without a result (exit={process.exitcode})",
            },
        }
    finally:
        recv_conn.close()
        if process.is_alive():
            process.terminate()
            process.join(timeout=5)


def _resident_native_success(generation: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "schema": "AFAQ_LOCAL_INFERENCE_V1",
        "success": True,
        "completed": True,
        "blocked": False,
        "text": str(generation.get("text") or ""),
        "mode": "AFAQ_NATIVE_GGUF",
        "engine_ids": [],
        "plan": {},
        "executions": [],
        "evidence_refs": [],
        "runtime": {
            "local_only": True,
            "external_provider_dependency": False,
            "external_daemon_required": False,
            "network_required": False,
            "process_isolated": True,
            "worker_recycled": False,
            "model_resident": True,
            "generator_available": True,
            "generator_backend": generation.get("backend", "llama_cpp"),
            "generator_identity": generation.get("generator_identity", "AFAQ"),
            "model_profile": generation.get("model_profile"),
            "model_quantization": generation.get("model_quantization"),
            "base_model_provenance": generation.get("base_model_provenance"),
            "model_path": generation.get("model_path"),
            "model_sha256": generation.get("model_sha256"),
            "model_size_bytes": generation.get("model_size_bytes"),
            "n_ctx": generation.get("n_ctx"),
            "max_tokens": generation.get("max_tokens"),
            "n_threads": generation.get("n_threads"),
            "n_gpu_layers": generation.get("n_gpu_layers"),
            "gpu_offload_supported": generation.get("gpu_offload_supported"),
            "model_cache_hit": generation.get("model_cache_hit"),
            "model_load_seconds": generation.get("model_load_seconds"),
            "ttft_seconds": generation.get("ttft_seconds"),
            "finish_reason": generation.get("finish_reason"),
            "output_truncated": generation.get("output_truncated", False),
            "generation_seconds": generation.get("generation_seconds"),
            "tokens_per_second": generation.get("tokens_per_second"),
            "usage": generation.get("usage", {}),
        },
        "error": None,
    }


def _resident_native_failure(code: str, message: str) -> dict[str, Any]:
    return {
        "schema": "AFAQ_LOCAL_INFERENCE_V1",
        "success": False,
        "completed": False,
        "blocked": False,
        "text": "",
        "mode": "AFAQ_NATIVE_GGUF",
        "engine_ids": [],
        "plan": {},
        "executions": [],
        "evidence_refs": [],
        "runtime": {
            "local_only": True,
            "external_provider_dependency": False,
            "external_daemon_required": False,
            "network_required": False,
            "process_isolated": True,
            "worker_recycled": True,
            "model_resident": False,
        },
        "error": {"code": code, "message": message},
    }


def _resident_native_worker(conn: Any, project_root: str) -> None:
    os.environ["AFAQ_LOCAL_ONLY"] = "1"
    restore_network = _install_network_guard()
    try:
        from .native_generator import generate_native, stream_native, warm_native

        while True:
            try:
                request = conn.recv()
            except EOFError:
                break
            if not isinstance(request, Mapping):
                continue
            op = str(request.get("op") or "")
            if op == "close":
                break
            try:
                if op == "warm":
                    warm = warm_native(
                        project_root,
                        payload=request.get("payload") or {},
                    )
                    conn.send({"type": "warm", "result": warm})
                    continue

                prompt = str(request.get("prompt") or "").strip()
                context = request.get("context") or {}
                payload = request.get("payload") or {}
                if not prompt:
                    conn.send({
                        "type": "final",
                        "result": _resident_native_failure(
                            "LOCAL_INFERENCE_INVALID_REQUEST",
                            "prompt is required",
                        ),
                    })
                    continue

                if op == "stream":
                    request_started = time.perf_counter()
                    first_delta_seen = False
                    for event in stream_native(
                        project_root,
                        prompt,
                        context=context,
                        payload=payload,
                    ):
                        if event.get("type") == "delta":
                            event = dict(event)
                            if not first_delta_seen:
                                event["ttft_seconds"] = max(
                                    0.0,
                                    time.perf_counter() - request_started,
                                )
                                first_delta_seen = True
                            conn.send(event)
                            continue
                        if event.get("type") == "final":
                            generation = dict(event.get("result") or {})
                            conn.send({
                                "type": "final",
                                "result": _resident_native_success(generation),
                            })
                    continue

                generation = generate_native(
                    project_root,
                    prompt,
                    context=context,
                    payload=payload,
                )
                conn.send({
                    "type": "final",
                    "result": _resident_native_success(generation),
                })
            except MemoryError:
                conn.send({
                    "type": "final",
                    "result": _resident_native_failure(
                        "LOCAL_INFERENCE_MEMORY_PRESSURE",
                        "resident inference worker exhausted available memory",
                    ),
                })
                break
            except BaseException as exc:
                conn.send({
                    "type": "final",
                    "result": _resident_native_failure(
                        "LOCAL_INFERENCE_WORKER_ERROR",
                        f"{type(exc).__name__}: {exc}",
                    ),
                })
                break
    finally:
        restore_network()
        conn.close()


class ResidentLocalInference:
    """Single isolated native worker with a model kept resident between requests."""

    def __init__(self, project_root: str | Path) -> None:
        root = Path(project_root).resolve()
        if not root.is_dir():
            raise ValueError(f"project root not found: {root}")
        self.project_root = root
        self._ctx = mp.get_context("spawn")
        self._lock = threading.Lock()
        self._conn: Any | None = None
        self._process: Any | None = None

    def _start_locked(self) -> None:
        if self._process is not None and self._process.is_alive() and self._conn is not None:
            return
        self._terminate_locked()
        parent, child = self._ctx.Pipe(duplex=True)
        process = self._ctx.Process(
            target=_resident_native_worker,
            args=(child, str(self.project_root)),
            name="afaq-native-resident-inference",
            daemon=False,
        )
        process.start()
        child.close()
        self._conn = parent
        self._process = process

    def _terminate_locked(self) -> None:
        conn = self._conn
        process = self._process
        self._conn = None
        self._process = None
        if conn is not None:
            try:
                conn.close()
            except OSError:
                pass
        if process is not None:
            if process.is_alive():
                process.terminate()
            process.join(timeout=5)

    def warm(
        self,
        *,
        payload: Mapping[str, Any] | None = None,
        timeout_seconds: float = 180.0,
    ) -> dict[str, Any]:
        with self._lock:
            self._start_locked()
            assert self._conn is not None
            self._conn.send({"op": "warm", "payload": dict(payload or {})})
            timeout = max(1.0, float(timeout_seconds))
            if not self._conn.poll(timeout):
                self._terminate_locked()
                raise TimeoutError(f"resident model warmup exceeded {timeout:g} seconds")
            try:
                event = self._conn.recv()
            except EOFError as exc:
                self._terminate_locked()
                raise RuntimeError("resident inference worker exited during warmup") from exc
            if not isinstance(event, Mapping) or event.get("type") != "warm":
                self._terminate_locked()
                raise RuntimeError("resident inference worker returned invalid warmup response")
            return dict(event.get("result") or {})

    def stream(
        self,
        prompt: str,
        *,
        context: Mapping[str, Any] | None = None,
        payload: Mapping[str, Any] | None = None,
        timeout_seconds: float = 300.0,
    ):
        prompt = str(prompt or "").strip()
        if not prompt:
            raise ValueError("prompt is required")

        completed = False
        with self._lock:
            self._start_locked()
            assert self._conn is not None
            self._conn.send({
                "op": "stream",
                "prompt": prompt,
                "context": dict(context or {}),
                "payload": dict(payload or {}),
            })
            deadline = time.monotonic() + max(1.0, float(timeout_seconds))
            try:
                while True:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0 or not self._conn.poll(remaining):
                        result = _resident_native_failure(
                            "LOCAL_INFERENCE_TIMEOUT",
                            f"resident inference exceeded {max(1.0, float(timeout_seconds)):g} seconds",
                        )
                        self._terminate_locked()
                        completed = True
                        yield {"type": "final", "result": result}
                        return
                    try:
                        event = self._conn.recv()
                    except EOFError:
                        result = _resident_native_failure(
                            "LOCAL_INFERENCE_WORKER_EXITED",
                            "resident inference worker exited without a result",
                        )
                        self._terminate_locked()
                        completed = True
                        yield {"type": "final", "result": result}
                        return
                    if not isinstance(event, Mapping):
                        continue
                    event = dict(event)
                    yield event
                    if event.get("type") == "final":
                        completed = True
                        result = event.get("result")
                        if isinstance(result, Mapping) and not result.get("success"):
                            self._terminate_locked()
                        return
            finally:
                if not completed:
                    self._terminate_locked()

    def infer(
        self,
        prompt: str,
        *,
        context: Mapping[str, Any] | None = None,
        payload: Mapping[str, Any] | None = None,
        timeout_seconds: float = 300.0,
    ) -> dict[str, Any]:
        for event in self.stream(
            prompt,
            context=context,
            payload=payload,
            timeout_seconds=timeout_seconds,
        ):
            if event.get("type") == "final":
                return dict(event.get("result") or {})
        raise RuntimeError("resident inference ended without a final result")

    def close(self) -> None:
        with self._lock:
            if self._conn is not None and self._process is not None and self._process.is_alive():
                try:
                    self._conn.send({"op": "close"})
                    self._process.join(timeout=5)
                except (BrokenPipeError, EOFError, OSError):
                    pass
            self._terminate_locked()
