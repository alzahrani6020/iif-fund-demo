"""Embedded, process-local GGUF text generation for AFAQ AI.

This module deliberately has no HTTP client and no model-download behavior.
Runtime generation is possible only from model weights already provisioned on
local storage owned by AFAQ.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping


class NativeGeneratorUnavailable(RuntimeError):
    """Raised when the embedded backend or local model weights are unavailable."""


class NativeModelIntegrityError(RuntimeError):
    """Raised when configured model integrity evidence does not match the file."""


@dataclass(frozen=True)
class NativeModel:
    path: Path
    sha256: str
    size_bytes: int


def _model_root(project_root: str | Path) -> Path:
    return Path(project_root).resolve() / "var" / "afaq_ai" / "models"


def _active_manifest_path(project_root: str | Path) -> Path:
    return _model_root(project_root) / "active-model.json"


def _read_active_manifest(project_root: str | Path) -> dict[str, Any] | None:
    path = _active_manifest_path(project_root)
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        raise NativeGeneratorUnavailable("AFAQ native active-model manifest is unreadable") from exc
    if not isinstance(data, Mapping):
        raise NativeGeneratorUnavailable("AFAQ native active-model manifest is invalid")
    return dict(data)


def resolve_model_path(project_root: str | Path) -> Path | None:
    configured = os.environ.get("AFAQ_NATIVE_MODEL_PATH", "").strip()
    if configured:
        path = Path(configured).expanduser().resolve()
        return path if path.is_file() else None

    root = _model_root(project_root)
    manifest = _read_active_manifest(project_root)
    if manifest is not None:
        filename = str(manifest.get("filename") or "").strip()
        if not filename or Path(filename).name != filename or not filename.lower().endswith(".gguf"):
            raise NativeGeneratorUnavailable("AFAQ native active-model manifest has an invalid filename")
        active = (root / filename).resolve()
        try:
            active.relative_to(root.resolve())
        except ValueError as exc:
            raise NativeGeneratorUnavailable("AFAQ native active-model path escapes model root") from exc
        if not active.is_file():
            raise NativeGeneratorUnavailable(
                f"AFAQ native active model is missing: {filename}"
            )
        return active

    if not root.is_dir():
        return None

    candidates = sorted(
        (path for path in root.glob("*.gguf") if path.is_file()),
        key=lambda path: path.name.lower(),
    )
    if not candidates:
        return None
    if len(candidates) > 1:
        raise NativeGeneratorUnavailable(
            "multiple GGUF models are present; set AFAQ_NATIVE_MODEL_PATH explicitly"
        )
    return candidates[0]


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _expected_sha256(path: Path) -> str:
    configured = os.environ.get("AFAQ_NATIVE_MODEL_SHA256", "").strip().lower()
    if configured:
        return configured
    sidecar = path.with_suffix(path.suffix + ".sha256")
    if sidecar.is_file():
        return sidecar.read_text(encoding="utf-8").strip().split()[0].lower()
    return ""


def inspect_model(project_root: str | Path, *, verify: bool = False) -> NativeModel | None:
    path = resolve_model_path(project_root)
    if path is None:
        return None

    actual = _sha256(path) if verify else ""
    expected = _expected_sha256(path)
    if verify and expected and actual.lower() != expected:
        raise NativeModelIntegrityError(
            f"GGUF SHA256 mismatch for {path.name}: expected {expected}, got {actual}"
        )
    return NativeModel(path=path, sha256=actual, size_bytes=path.stat().st_size)


def native_generator_status(project_root: str | Path) -> dict[str, Any]:
    backend_available = importlib.util.find_spec("llama_cpp") is not None
    try:
        model_path = resolve_model_path(project_root)
        discovery_error = None
    except NativeGeneratorUnavailable as exc:
        model_path = None
        discovery_error = str(exc)

    integrity_reference = _expected_sha256(model_path) if model_path is not None else ""
    try:
        active_manifest = _read_active_manifest(project_root)
    except NativeGeneratorUnavailable:
        active_manifest = None
    return {
        "backend": "llama_cpp",
        "backend_available": backend_available,
        "model_available": model_path is not None,
        "model_path": str(model_path) if model_path is not None else None,
        "model_integrity_reference_available": bool(integrity_reference),
        "model_profile": (
            str(active_manifest.get("profile") or "")
            if active_manifest is not None and model_path is not None
            else None
        ),
        "model_quantization": (
            str(active_manifest.get("quantization") or "")
            if active_manifest is not None and model_path is not None
            else None
        ),
        "generator_identity": (
            str(active_manifest.get("generator_identity") or "AFAQ")
            if active_manifest is not None and model_path is not None
            else "AFAQ"
        ),
        "base_model_provenance": (
            str(active_manifest.get("base_model_provenance") or "")
            if active_manifest is not None and model_path is not None
            else None
        ),
        "available": bool(backend_available and model_path is not None and discovery_error is None),
        "discovery_error": discovery_error,
        "external_provider_dependency": False,
        "external_daemon_required": False,
        "network_required": False,
    }


def _positive_int(value: Any, default: int) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return default
    return parsed if parsed > 0 else default


def _temperature(value: Any, default: float = 0.2) -> float:
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return default
    return max(0.0, parsed)


_VERIFIED_MODEL_CACHE: dict[tuple[str, int, int, str], NativeModel] = {}
_RESIDENT_LLM: Any | None = None
_RESIDENT_LLM_KEY: tuple[Any, ...] | None = None


def _verified_model(project_root: str | Path) -> NativeModel:
    path = resolve_model_path(project_root)
    stat = path.stat()
    expected = _expected_sha256(path)
    key = (str(path), int(stat.st_size), int(stat.st_mtime_ns), expected)
    cached = _VERIFIED_MODEL_CACHE.get(key)
    if cached is not None:
        return cached

    model = inspect_model(project_root, verify=True)
    if model is None:
        raise NativeGeneratorUnavailable("local GGUF model disappeared before load")
    _VERIFIED_MODEL_CACHE.clear()
    _VERIFIED_MODEL_CACHE[key] = model
    return model


def _gpu_offload_supported() -> bool:
    try:
        from llama_cpp import llama_cpp
        return bool(llama_cpp.llama_supports_gpu_offload())
    except (ImportError, AttributeError, OSError):
        return False


def _resident_llm(
    model: NativeModel,
    *,
    n_ctx: int,
    n_threads: int,
    n_gpu_layers: int,
    chat_format: str,
) -> tuple[Any, bool, float]:
    global _RESIDENT_LLM, _RESIDENT_LLM_KEY

    key = (
        str(model.path),
        model.sha256,
        n_ctx,
        n_threads,
        n_gpu_layers,
        chat_format,
    )
    if _RESIDENT_LLM is not None and _RESIDENT_LLM_KEY == key:
        return _RESIDENT_LLM, True, 0.0

    from llama_cpp import Llama

    previous = _RESIDENT_LLM
    _RESIDENT_LLM = None
    _RESIDENT_LLM_KEY = None
    if previous is not None:
        del previous
        __import__("gc").collect()

    kwargs: dict[str, Any] = {
        "model_path": str(model.path),
        "n_ctx": n_ctx,
        "n_threads": n_threads,
        "n_gpu_layers": n_gpu_layers,
        "verbose": False,
    }
    if chat_format:
        kwargs["chat_format"] = chat_format

    started = time.perf_counter()
    llm = Llama(**kwargs)
    load_seconds = max(0.0, time.perf_counter() - started)
    _RESIDENT_LLM = llm
    _RESIDENT_LLM_KEY = key
    return llm, False, load_seconds


def _prepare_native_request(
    project_root: str | Path,
    prompt: str,
    *,
    context: Mapping[str, Any] | None = None,
    payload: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    status = native_generator_status(project_root)
    if not status["backend_available"]:
        raise NativeGeneratorUnavailable(
            "embedded backend unavailable; install requirements-native-inference.txt"
        )
    if not status["model_available"]:
        detail = status.get("discovery_error")
        raise NativeGeneratorUnavailable(
            detail
            or "no GGUF model is provisioned; place one model under var/afaq_ai/models "
            "or set AFAQ_NATIVE_MODEL_PATH"
        )

    model = _verified_model(project_root)
    options = dict(payload or {})
    n_ctx = _positive_int(options.get("n_ctx") or os.environ.get("AFAQ_NATIVE_N_CTX"), 4096)
    max_tokens = _positive_int(
        options.get("max_tokens") or os.environ.get("AFAQ_NATIVE_MAX_TOKENS"), 512
    )
    n_threads = _positive_int(
        options.get("n_threads") or os.environ.get("AFAQ_NATIVE_N_THREADS"),
        max(1, os.cpu_count() or 1),
    )

    gpu_supported = _gpu_offload_supported()
    configured_gpu_layers = (
        options.get("n_gpu_layers")
        if options.get("n_gpu_layers") is not None
        else os.environ.get("AFAQ_NATIVE_N_GPU_LAYERS")
    )
    try:
        n_gpu_layers = (
            int(configured_gpu_layers)
            if configured_gpu_layers not in (None, "")
            else (-1 if gpu_supported else 0)
        )
    except (TypeError, ValueError):
        n_gpu_layers = -1 if gpu_supported else 0
    if not gpu_supported:
        n_gpu_layers = 0

    temperature = _temperature(options.get("temperature"), 0.2)
    system = str(options.get("system") or "").strip()
    if not system:
        system = (
            "You are AFAQ AI, a precise local assistant. "
            "Answer directly in the same language as the user's request. "
            "If the request is in Arabic, answer in clear Arabic and do not switch to English "
            "unless the user explicitly asks for English."
        )

    context_text = ""
    if context:
        context_text = json.dumps(dict(context), ensure_ascii=False, separators=(",", ":"))

    parts = []
    if system:
        parts.append(system)
    if context_text:
        parts.append(f"Context:\n{context_text}")
    parts.append(str(prompt).strip())
    effective_prompt = "\n\n".join(parts)

    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    user_content = str(prompt).strip()
    if context_text:
        user_content = f"Context:\n{context_text}\n\n{user_content}"
    messages.append({"role": "user", "content": user_content})

    chat_format = str(options.get("chat_format") or "").strip()
    llm, model_cache_hit, model_load_seconds = _resident_llm(
        model,
        n_ctx=n_ctx,
        n_threads=n_threads,
        n_gpu_layers=n_gpu_layers,
        chat_format=chat_format,
    )
    return {
        "model": model,
        "llm": llm,
        "options": options,
        "n_ctx": n_ctx,
        "max_tokens": max_tokens,
        "n_threads": n_threads,
        "n_gpu_layers": n_gpu_layers,
        "gpu_offload_supported": gpu_supported,
        "temperature": temperature,
        "system": system,
        "context_text": context_text,
        "effective_prompt": effective_prompt,
        "messages": messages,
        "model_cache_hit": model_cache_hit,
        "model_load_seconds": model_load_seconds,
    }


def _generation_result(
    project_root: str | Path,
    request: Mapping[str, Any],
    *,
    text: str,
    response_mode: str,
    finish_reason: Any,
    usage: Mapping[str, Any] | None,
    generation_seconds: float,
    ttft_seconds: float | None = None,
) -> dict[str, Any]:
    usage_dict = dict(usage or {})
    completion_tokens = usage_dict.get("completion_tokens")
    try:
        completion_tokens = int(completion_tokens) if completion_tokens is not None else None
    except (TypeError, ValueError):
        completion_tokens = None
    tokens_per_second = (
        completion_tokens / generation_seconds
        if completion_tokens is not None and generation_seconds > 0
        else None
    )

    model = request["model"]
    active_manifest = _read_active_manifest(project_root)
    return {
        "text": text,
        "backend": "llama_cpp",
        "generator_identity": (
            str(active_manifest.get("generator_identity") or "AFAQ")
            if active_manifest is not None
            else "AFAQ"
        ),
        "model_profile": (
            str(active_manifest.get("profile") or "")
            if active_manifest is not None
            else None
        ),
        "model_quantization": (
            str(active_manifest.get("quantization") or "")
            if active_manifest is not None
            else None
        ),
        "base_model_provenance": (
            str(active_manifest.get("base_model_provenance") or "")
            if active_manifest is not None
            else None
        ),
        "model_path": str(model.path),
        "model_sha256": model.sha256,
        "model_size_bytes": model.size_bytes,
        "n_ctx": request["n_ctx"],
        "max_tokens": request["max_tokens"],
        "n_threads": request["n_threads"],
        "n_gpu_layers": request["n_gpu_layers"],
        "gpu_offload_supported": request["gpu_offload_supported"],
        "temperature": request["temperature"],
        "response_mode": response_mode,
        "finish_reason": str(finish_reason) if finish_reason is not None else None,
        "usage": usage_dict,
        "generation_seconds": generation_seconds,
        "tokens_per_second": tokens_per_second,
        "output_truncated": (
            str(finish_reason).lower() == "length"
            if finish_reason is not None
            else False
        ),
        "model_resident": True,
        "model_cache_hit": bool(request["model_cache_hit"]),
        "model_load_seconds": float(request["model_load_seconds"]),
        "ttft_seconds": ttft_seconds,
    }


def warm_native(
    project_root: str | Path,
    *,
    payload: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    request = _prepare_native_request(
        project_root,
        "AFAQ warmup",
        context={},
        payload=payload,
    )
    model = request["model"]
    return {
        "backend": "llama_cpp",
        "model_path": str(model.path),
        "model_sha256": model.sha256,
        "model_size_bytes": model.size_bytes,
        "n_ctx": request["n_ctx"],
        "n_threads": request["n_threads"],
        "n_gpu_layers": request["n_gpu_layers"],
        "gpu_offload_supported": request["gpu_offload_supported"],
        "model_resident": True,
        "model_cache_hit": bool(request["model_cache_hit"]),
        "model_load_seconds": float(request["model_load_seconds"]),
    }


def generate_native(
    project_root: str | Path,
    prompt: str,
    *,
    context: Mapping[str, Any] | None = None,
    payload: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Generate text with a process-resident embedded GGUF model."""
    request = _prepare_native_request(
        project_root,
        prompt,
        context=context,
        payload=payload,
    )
    llm = request["llm"]
    options = request["options"]
    max_tokens = request["max_tokens"]
    temperature = request["temperature"]

    text = ""
    response_mode = "chat"
    finish_reason = None
    usage: dict[str, Any] = {}
    started = time.perf_counter()
    use_chat = options.get("use_chat_template", True) is not False
    if use_chat:
        try:
            response = llm.create_chat_completion(
                messages=request["messages"],
                max_tokens=max_tokens,
                temperature=temperature,
            )
            choices = response.get("choices") if isinstance(response, Mapping) else None
            if isinstance(choices, list) and choices:
                first = choices[0]
                if isinstance(first, Mapping):
                    message = first.get("message")
                    if isinstance(message, Mapping):
                        text = str(message.get("content") or "").strip()
                    finish_reason = first.get("finish_reason")
            if isinstance(response, Mapping) and isinstance(response.get("usage"), Mapping):
                usage = dict(response["usage"])
        except (RuntimeError, ValueError, TypeError, AttributeError):
            text = ""

    if not text:
        response_mode = "completion"
        response = llm.create_completion(
            prompt=request["effective_prompt"],
            max_tokens=max_tokens,
            temperature=temperature,
            echo=False,
        )
        choices = response.get("choices") if isinstance(response, Mapping) else None
        if isinstance(choices, list) and choices:
            first = choices[0]
            if isinstance(first, Mapping):
                text = str(first.get("text") or "").strip()
                finish_reason = first.get("finish_reason")
        if isinstance(response, Mapping) and isinstance(response.get("usage"), Mapping):
            usage = dict(response["usage"])

    if not text:
        raise RuntimeError("embedded GGUF generator returned empty text")

    generation_seconds = max(0.0, time.perf_counter() - started)
    return _generation_result(
        project_root,
        request,
        text=text,
        response_mode=response_mode,
        finish_reason=finish_reason,
        usage=usage,
        generation_seconds=generation_seconds,
    )


def stream_native(
    project_root: str | Path,
    prompt: str,
    *,
    context: Mapping[str, Any] | None = None,
    payload: Mapping[str, Any] | None = None,
):
    """Yield native text deltas immediately, followed by one final metrics event."""
    request = _prepare_native_request(
        project_root,
        prompt,
        context=context,
        payload=payload,
    )
    llm = request["llm"]
    options = request["options"]
    max_tokens = request["max_tokens"]
    temperature = request["temperature"]

    started = time.perf_counter()
    first_text_at: float | None = None
    chunks: list[str] = []
    finish_reason = None
    response_mode = "chat"
    emitted = False

    def emit_piece(piece: str):
        nonlocal first_text_at, emitted
        if not piece:
            return None
        now = time.perf_counter()
        if first_text_at is None:
            first_text_at = now
        emitted = True
        chunks.append(piece)
        return {
            "type": "delta",
            "text": piece,
            "ttft_seconds": max(0.0, first_text_at - started),
        }

    use_chat = options.get("use_chat_template", True) is not False
    if use_chat:
        try:
            stream = llm.create_chat_completion(
                messages=request["messages"],
                max_tokens=max_tokens,
                temperature=temperature,
                stream=True,
            )
            for chunk in stream:
                if not isinstance(chunk, Mapping):
                    continue
                choices = chunk.get("choices")
                if not isinstance(choices, list) or not choices:
                    continue
                first = choices[0]
                if not isinstance(first, Mapping):
                    continue
                if first.get("finish_reason") is not None:
                    finish_reason = first.get("finish_reason")
                delta = first.get("delta")
                piece = (
                    str(delta.get("content") or "")
                    if isinstance(delta, Mapping)
                    else ""
                )
                event = emit_piece(piece)
                if event is not None:
                    yield event
        except (RuntimeError, ValueError, TypeError, AttributeError):
            if emitted:
                raise

    if not emitted:
        response_mode = "completion"
        stream = llm.create_completion(
            prompt=request["effective_prompt"],
            max_tokens=max_tokens,
            temperature=temperature,
            echo=False,
            stream=True,
        )
        for chunk in stream:
            if not isinstance(chunk, Mapping):
                continue
            choices = chunk.get("choices")
            if not isinstance(choices, list) or not choices:
                continue
            first = choices[0]
            if not isinstance(first, Mapping):
                continue
            if first.get("finish_reason") is not None:
                finish_reason = first.get("finish_reason")
            event = emit_piece(str(first.get("text") or ""))
            if event is not None:
                yield event

    text = "".join(chunks).strip()
    if not text:
        raise RuntimeError("embedded GGUF generator returned empty streamed text")

    generation_seconds = max(0.0, time.perf_counter() - started)
    usage: dict[str, Any] = {}
    try:
        completion_tokens = len(llm.tokenize(text.encode("utf-8"), add_bos=False))
        usage["completion_tokens"] = completion_tokens
    except (AttributeError, TypeError, ValueError):
        pass

    ttft_seconds = (
        max(0.0, first_text_at - started)
        if first_text_at is not None
        else None
    )
    result = _generation_result(
        project_root,
        request,
        text=text,
        response_mode=response_mode,
        finish_reason=finish_reason,
        usage=usage,
        generation_seconds=generation_seconds,
        ttft_seconds=ttft_seconds,
    )
    yield {"type": "final", "result": result}
