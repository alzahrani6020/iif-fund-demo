"""Persistent approval queue (governance hardening).

Approvals are first-class, durable records — not a transient task status.
Every approval carries the full request context, a deterministic risk level,
the permission decision, a hash of the proposal it authorizes, an optional
expiry, and the human decision (actor + reason + timestamp).

An approval authorizes exactly one proposal: at execution time the agent
re-hashes the current proposal and refuses to reuse a token whose proposal
changed (the stale approval is cancelled and a fresh one is required).
"""

from __future__ import annotations

import hashlib
import json
import posixpath
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from threading import RLock
from uuid import uuid4

DEFAULT_TTL_SECONDS = 24 * 3600
TERMINAL_STATUSES = ("approved", "rejected", "expired", "cancelled")


class ApprovalScopeExceeded(PermissionError):
    """Raised when a write operation is outside the durable approved scope."""


class MalformedScopeSnapshot(ValueError):
    """Raised when the stored durable scope snapshot is unusable."""


@dataclass(frozen=True, slots=True)
class ApprovalContext:
    """Durable authority presented at the point of mutation.

    The in-memory token is not part of this context; it is deliberately
    omitted so that token recreation/loss cannot widen authority.
    """

    approval_id: str
    task_id: str
    proposal_version_hash: str


def _canonical_rel_path(rel_path: str | Path) -> str:
    """Deterministic canonical form for a relative path used in scope matching.

    Preserves case and preserves ProjectBoundary containment semantics:
    the caller is still required to resolve the path against the project
    root and reject absolute paths or traversal before calling this helper.
    """
    if isinstance(rel_path, Path):
        rel_path = rel_path.as_posix()
    if not isinstance(rel_path, str):
        raise TypeError("relative path must be a string")
    normalized = rel_path.replace("\\", "/")
    normalized = posixpath.normpath(normalized)
    if posixpath.isabs(normalized):
        raise ValueError("path must be relative")
    parts = normalized.split("/")
    if any(part == ".." for part in parts):
        raise ValueError("path traversal not allowed")
    if normalized == ".":
        return ""
    return normalized


# Dormant schema version marker for the approval_store component.
# This is metadata only; it does not activate any runtime authority in S01.
_SCHEMA_VERSION = 1

_SCHEMA = """
CREATE TABLE IF NOT EXISTS approvals (
    approval_id TEXT PRIMARY KEY,
    task_id TEXT NOT NULL,
    agent_id TEXT NOT NULL,
    project TEXT NOT NULL,
    environment TEXT NOT NULL,
    action_type TEXT NOT NULL,
    risk_level TEXT NOT NULL,
    requested_changes TEXT NOT NULL,
    affected_files TEXT NOT NULL,
    proposed_tests TEXT NOT NULL,
    reason TEXT,
    permission_decision TEXT,
    proposal_hash TEXT NOT NULL,
    created_at TEXT NOT NULL,
    expires_at TEXT,
    status TEXT NOT NULL DEFAULT 'pending',
    approved_by TEXT,
    rejected_by TEXT,
    decision_at TEXT,
    decision_reason TEXT,
    scope_snapshot TEXT,
    expansion_policy TEXT NOT NULL DEFAULT 'none',
    proposal_version_hash TEXT,
    legacy INTEGER NOT NULL DEFAULT 0,
    scope_snapshot_source TEXT
);
CREATE INDEX IF NOT EXISTS approvals_task_idx ON approvals (task_id, created_at);
CREATE INDEX IF NOT EXISTS approvals_status_idx ON approvals (status, created_at);

CREATE TABLE IF NOT EXISTS schema_version (
    component TEXT PRIMARY KEY,
    version INTEGER NOT NULL,
    updated_at TEXT NOT NULL
);
"""

# Columns added after the initial release; applied idempotently to existing DBs.
_MIGRATIONS = (
    "ALTER TABLE approvals ADD COLUMN scope_snapshot TEXT",
    "ALTER TABLE approvals ADD COLUMN expansion_policy TEXT NOT NULL DEFAULT 'none'",
    "ALTER TABLE approvals ADD COLUMN proposal_version_hash TEXT",
    "ALTER TABLE approvals ADD COLUMN legacy INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE approvals ADD COLUMN scope_snapshot_source TEXT",
)


def _ensure_schema_version(conn: sqlite3.Connection, component: str, version: int) -> None:
    """Record the schema version for a named component.

    This is dormant metadata only. It does not gate runtime behavior in S01.
    """
    conn.execute(
        "INSERT INTO schema_version (component, version, updated_at) VALUES (?, ?, ?)"
        " ON CONFLICT(component) DO UPDATE SET version=excluded.version, updated_at=excluded.updated_at",
        (component, version, _utcnow()),
    )


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def proposal_hash(proposal) -> str:
    canonical = json.dumps(proposal, ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


class ApprovalStore:
    def __init__(self, path: str | Path) -> None:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(
            str(path), check_same_thread=False, isolation_level=None
        )
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA busy_timeout=5000")
        self._conn.executescript(_SCHEMA)
        existing = {row[1] for row in self._conn.execute("PRAGMA table_info(approvals)")}
        for statement in _MIGRATIONS:
            column = statement.split("ADD COLUMN ")[1].split(" ")[0]
            if column not in existing:
                self._conn.execute(statement)
        _ensure_schema_version(self._conn, "approval_store", _SCHEMA_VERSION)
        self._lock = RLock()

    def close(self) -> None:
        self._conn.close()

    # ------------------------------------------------------------------
    def create(
        self,
        *,
        task_id: str,
        agent_id: str,
        project: str,
        environment: str,
        action_type: str,
        risk_level: str,
        requested_changes,
        affected_files,
        proposed_tests,
        reason: str = "",
        permission_decision=None,
        proposal=None,
        ttl_seconds: int = DEFAULT_TTL_SECONDS,
    ) -> dict:
        approval_id = f"APR-{uuid4()}"
        created = datetime.now(timezone.utc)
        expires = created + timedelta(seconds=ttl_seconds)
        record = {
            "approval_id": approval_id,
            "task_id": task_id,
            "agent_id": agent_id,
            "project": project,
            "environment": environment,
            "action_type": action_type,
            "risk_level": risk_level,
            "requested_changes": requested_changes,
            "affected_files": affected_files,
            "proposed_tests": proposed_tests,
            "reason": reason,
            "permission_decision": permission_decision,
            "proposal_hash": proposal_hash(proposal),
            "created_at": created.isoformat(),
            "expires_at": expires.isoformat(),
            "status": "pending",
            "approved_by": None,
            "rejected_by": None,
            "decision_at": None,
            "decision_reason": None,
            "scope_snapshot": None,
            "expansion_policy": "none",
            "proposal_version_hash": None,
            "legacy": 0,
            "scope_snapshot_source": None,
        }
        if proposal is not None:
            primary_scope: list[dict[str, str]] = []
            for spec in proposal.get("files", []):
                path = _canonical_rel_path(spec["path"])
                action = spec.get("action", "edit")
                entry = {"path": path, "action": action}
                if action == "rename":
                    new_path = _canonical_rel_path(spec.get("new_path") or spec.get("to") or "")
                    primary_scope.append({"path": new_path, "action": "rename"})
                primary_scope.append(entry)
            seen: set[tuple[str, str]] = set()
            for entry in primary_scope:
                key = (entry["path"], entry["action"])
                if key in seen:
                    raise ValueError(
                        f"duplicate/conflicting durable scope entry: {key}"
                    )
                seen.add(key)
            record["scope_snapshot"] = {
                "primary_scope": primary_scope,
                "expansion_policy": "none",
            }
            record["proposal_version_hash"] = proposal_hash(proposal)
            record["scope_snapshot_source"] = "approved"
            record["legacy"] = 0
        with self._lock:
            self._conn.execute(
                "INSERT INTO approvals (approval_id, task_id, agent_id, project, environment,"
                " action_type, risk_level, requested_changes, affected_files, proposed_tests,"
                " reason, permission_decision, proposal_hash, created_at, expires_at, status,"
                " scope_snapshot, expansion_policy, proposal_version_hash, legacy, scope_snapshot_source)"
                " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    record["approval_id"], record["task_id"], record["agent_id"],
                    record["project"], record["environment"], record["action_type"],
                    record["risk_level"],
                    json.dumps(requested_changes, ensure_ascii=False),
                    json.dumps(affected_files, ensure_ascii=False),
                    json.dumps(proposed_tests, ensure_ascii=False),
                    record["reason"],
                    json.dumps(permission_decision, ensure_ascii=False) if permission_decision else None,
                    record["proposal_hash"], record["created_at"], record["expires_at"],
                    record["status"],
                    json.dumps(record["scope_snapshot"], ensure_ascii=False) if record["scope_snapshot"] else None,
                    record["expansion_policy"],
                    record["proposal_version_hash"],
                    record["legacy"],
                    record["scope_snapshot_source"],
                ),
            )
        return record

    def get(self, approval_id: str) -> dict | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM approvals WHERE approval_id = ?", (approval_id,)
            ).fetchone()
        return self._row_to_dict(row) if row else None

    def list(self, status: str | None = None, limit: int = 100) -> list[dict]:
        with self._lock:
            if status:
                rows = self._conn.execute(
                    "SELECT * FROM approvals WHERE status = ? ORDER BY created_at DESC LIMIT ?",
                    (status, limit),
                ).fetchall()
            else:
                rows = self._conn.execute(
                    "SELECT * FROM approvals ORDER BY created_at DESC LIMIT ?", (limit,)
                ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def pending_for_task(self, task_id: str) -> list[dict]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM approvals WHERE task_id = ? AND status = 'pending'"
                " ORDER BY created_at DESC", (task_id,)
            ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def for_task(self, task_id: str) -> list[dict]:
        """All approvals for a task, newest first (any status)."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM approvals WHERE task_id = ? ORDER BY created_at DESC", (task_id,)
            ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    # ------------------------------------------------------------------
    def _is_expired(self, record: dict) -> bool:
        if not record.get("expires_at"):
            return False
        try:
            expiry = datetime.fromisoformat(record["expires_at"])
        except ValueError:
            return False
        return datetime.now(timezone.utc) >= expiry

    def _mark(self, approval_id: str, expected: tuple[str, ...], **fields) -> dict:
        allowed = {
            "status", "approved_by", "rejected_by", "decision_at", "decision_reason",
        }
        unknown = set(fields) - allowed
        if unknown:
            raise ValueError(f"unknown approval fields: {sorted(unknown)}")
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                row = self._conn.execute(
                    "SELECT status FROM approvals WHERE approval_id = ?", (approval_id,)
                ).fetchone()
                if row is None:
                    raise KeyError(f"approval not found: {approval_id}")
                if expected and row[0] not in expected:
                    raise RuntimeError(
                        f"approval {approval_id} in status {row[0]}, expected one of {expected}"
                    )
                if fields:
                    assignments = ", ".join(f"{k} = ?" for k in fields)
                    self._conn.execute(
                        f"UPDATE approvals SET {assignments} WHERE approval_id = ?",
                        (*fields.values(), approval_id),
                    )
                self._conn.execute("COMMIT")
            except Exception:
                self._conn.execute("ROLLBACK")
                raise
        return self.get(approval_id)

    def decide(self, approval_id: str, *, decision: str, actor: str,
               reason: str = "") -> dict:
        """Human decision. Enforces pending status and expiry."""
        record = self.get(approval_id)
        if record is None:
            raise KeyError(f"approval not found: {approval_id}")
        if record["status"] != "pending":
            raise RuntimeError(f"approval {approval_id} already {record['status']}")
        if self._is_expired(record):
            return self._mark(
                approval_id, ("pending",), status="expired",
                decision_at=_utcnow(),
                decision_reason=f"expired before decision; original request: {reason}",
            )
        if decision == "approve":
            return self._mark(
                approval_id, ("pending",), status="approved",
                approved_by=actor, decision_at=_utcnow(), decision_reason=reason or None,
            )
        if decision == "reject":
            return self._mark(
                approval_id, ("pending",), status="rejected",
                rejected_by=actor, decision_at=_utcnow(), decision_reason=reason or None,
            )
        raise ValueError(f"unknown decision: {decision}")

    def cancel_for_task(self, task_id: str, reason: str) -> int:
        with self._lock:
            cursor = self._conn.execute(
                "UPDATE approvals SET status = 'cancelled', decision_reason = ?, decision_at = ?"
                " WHERE task_id = ? AND status = 'pending'",
                (reason, _utcnow(), task_id),
            )
        return cursor.rowcount

    def authorize_execution(self, approval_id: str, current_proposal) -> dict:
        """Validate an approved request right before execution.

        Refuses expired approvals and proposal drift: if the proposal hash
        differs from what was approved, the approval is cancelled and a fresh
        approval is required. Returns the approval record on success.
        """
        record = self.get(approval_id)
        if record is None:
            raise KeyError(f"approval not found: {approval_id}")
        if record["status"] == "pending":
            raise RuntimeError(f"approval {approval_id} is still pending")
        if record["status"] == "expired":
            raise RuntimeError(f"approval {approval_id} has expired; request a new approval")
        if record["status"] == "approved" and self._is_expired(record):
            self._mark(approval_id, ("approved",), status="expired",
                       decision_reason="expired before execution")
            raise RuntimeError(f"approval {approval_id} has expired; request a new approval")
        if record["status"] != "approved":
            raise RuntimeError(f"approval {approval_id} is {record['status']}")
        current_hash = proposal_hash(current_proposal)
        if current_hash != record["proposal_hash"]:
            self._mark(
                approval_id, ("approved",),
                status="cancelled",
                decision_reason="proposal changed after approval; approval invalidated",
            )
            raise RuntimeError(
                "proposal changed after approval; the previous approval was cancelled "
                "and a fresh approval is required"
            )
        return record

    def validate_scope(
        self,
        context: ApprovalContext,
        relative_path: str,
        action: str,
    ) -> dict:
        """Fail-closed durable exact-scope check.

        A write is authorized only when the durable approval record contains
        the exact canonical (relative_path, action) pair. This method performs
        NO lifecycle mutation: proposal-version mismatches are rejected without
        cancelling, revoking, or otherwise altering the approval record.
        """
        if not isinstance(context, ApprovalContext):
            raise ApprovalScopeExceeded("invalid approval context")
        try:
            canonical_path = _canonical_rel_path(relative_path)
        except (TypeError, ValueError) as exc:
            raise ApprovalScopeExceeded(f"invalid relative path: {exc}") from exc

        record = self.get(context.approval_id)
        if record is None:
            raise ApprovalScopeExceeded("approval not found")
        if record["task_id"] != context.task_id:
            raise ApprovalScopeExceeded("approval/task mismatch")
        if record.get("proposal_version_hash") != context.proposal_version_hash:
            raise ApprovalScopeExceeded("proposal version mismatch")
        if record["status"] != "approved":
            raise ApprovalScopeExceeded(
                f"approval is {record['status']}, not approved"
            )
        if self._is_expired(record):
            raise ApprovalScopeExceeded("approval expired")
        if record.get("legacy"):
            raise ApprovalScopeExceeded("legacy approval cannot authorize writes")
        if record.get("expansion_policy", "none") != "none":
            raise ApprovalScopeExceeded("unsupported expansion policy")
        source = record.get("scope_snapshot_source")
        if source not in ("approved", "amendment"):
            raise ApprovalScopeExceeded("approval scope source is not authoritative")

        scope_snapshot = record.get("scope_snapshot")
        if not scope_snapshot:
            raise ApprovalScopeExceeded("missing durable scope")
        if not isinstance(scope_snapshot, dict):
            raise MalformedScopeSnapshot("scope snapshot is not a mapping")
        primary_scope = scope_snapshot.get("primary_scope")
        if not isinstance(primary_scope, list):
            raise MalformedScopeSnapshot("primary scope missing")

        allowed: set[tuple[str, str]] = set()
        for entry in primary_scope:
            if not isinstance(entry, dict):
                raise MalformedScopeSnapshot("scope entry is not a mapping")
            path = entry.get("path")
            entry_action = entry.get("action")
            if not isinstance(path, str) or not isinstance(entry_action, str):
                raise MalformedScopeSnapshot("scope entry missing path or action")
            key = (path, entry_action)
            if key in allowed:
                raise MalformedScopeSnapshot("duplicate/conflicting scope entry")
            allowed.add(key)

        if (canonical_path, action) not in allowed:
            raise ApprovalScopeExceeded(
                f"{action} on {relative_path!r} is outside the approved durable scope"
            )
        return record

    # ------------------------------------------------------------------
    @staticmethod
    def _row_to_dict(row: tuple) -> dict:
        keys = (
            "approval_id", "task_id", "agent_id", "project", "environment",
            "action_type", "risk_level", "requested_changes", "affected_files",
            "proposed_tests", "reason", "permission_decision", "proposal_hash",
            "created_at", "expires_at", "status", "approved_by", "rejected_by",
            "decision_at", "decision_reason", "scope_snapshot", "expansion_policy",
            "proposal_version_hash", "legacy", "scope_snapshot_source",
        )
        record = dict(zip(keys, row))
        for field in ("requested_changes", "affected_files", "proposed_tests", "permission_decision", "scope_snapshot"):
            if record.get(field):
                record[field] = json.loads(record[field])
        return record
