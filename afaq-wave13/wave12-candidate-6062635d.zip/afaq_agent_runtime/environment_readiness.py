"""R1 environment and hardware readiness foundation.

This module turns best-effort hardware detection into a normalized runtime
compatibility decision and a conservative resource envelope.

It does not manage devices, allocate GPUs, execute workloads, mutate policy,
or claim production performance. It is a readiness/measurement foundation.
"""

from __future__ import annotations

import os
import platform
import shutil
import sys

from dataclasses import asdict, dataclass
from enum import Enum
from pathlib import Path
from typing import Any

from .hardware import load_or_detect


R1_SCHEMA_V1 = "AFAQ_ENVIRONMENT_READINESS_R1_V1"


class ReadinessStatus(str, Enum):
    READY = "READY"
    DEGRADED = "DEGRADED"
    BLOCKED = "BLOCKED"


@dataclass(frozen=True)
class ResourceEnvelope:
    cpu_cores: int
    ram_total_gb: float
    hardware_profile: str
    gpu_count: int
    known_vram_total_gb: float
    unknown_vram_gpu_count: int
    accelerators: tuple[str, ...]
    worker_slots: int
    storage_free_gb: float

    def as_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["accelerators"] = list(self.accelerators)
        return data


@dataclass(frozen=True)
class EnvironmentReadinessReport:
    status: ReadinessStatus
    os_family: str
    os_release: str
    machine_arch: str
    python_version: str
    python_implementation: str
    hardware_profile: str
    hardware_fingerprint: str
    profile_key: str
    hardware_changed: bool
    resource_envelope: ResourceEnvelope
    reasons: tuple[str, ...]
    warnings: tuple[str, ...]
    schema_version: str = R1_SCHEMA_V1

    def as_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["status"] = self.status.value
        data["resource_envelope"] = self.resource_envelope.as_dict()
        data["reasons"] = list(self.reasons)
        data["warnings"] = list(self.warnings)
        return data


def _os_family() -> str:
    if sys.platform == "win32":
        return "windows"
    if sys.platform.startswith("linux"):
        return "linux"
    if sys.platform == "darwin":
        return "macos"
    return sys.platform or "unknown"


def derive_worker_slots(hw: dict[str, Any]) -> int:
    """Return a conservative local worker ceiling from detected hardware.

    This centralizes the same policy previously embedded in afaq-runtime.py:
    low CPU boxes stay small, GPU boxes may use up to 8 workers, and
    CPU-only high-capacity boxes may use up to 6.
    """
    cores = max(1, int(hw.get("cpu_cores") or 1))
    profile = str(hw.get("profile") or "")
    gpus = list(hw.get("gpus") or [])

    if profile == "cpu_low":
        return max(1, min(2, cores // 2 or 1))
    if gpus:
        return max(2, min(8, cores // 2 or 2))
    return max(2, min(6, cores // 2 or 2))


def _storage_free_gb(path: Path) -> float:
    try:
        target = path if path.exists() else path.parent
        usage = shutil.disk_usage(target)
        return round(usage.free / (1024 ** 3), 2)
    except OSError:
        return 0.0


def _writable_probe(var_dir: Path) -> tuple[bool, str | None]:
    try:
        var_dir.mkdir(parents=True, exist_ok=True)
        probe = var_dir / f".r1-write-probe-{os.getpid()}"
        probe.write_text("ok\n", encoding="utf-8")
        probe.unlink()
        return True, None
    except OSError as exc:
        return False, f"var_dir_not_writable:{type(exc).__name__}:{exc}"


def assess_environment(var_dir: str | Path) -> EnvironmentReadinessReport:
    """Detect the current machine and produce a fail-closed compatibility report."""
    var_dir = Path(var_dir)
    hw, changed = load_or_detect(var_dir)

    reasons: list[str] = []
    warnings: list[str] = []

    py = sys.version_info
    if py < (3, 10):
        reasons.append(
            f"python_too_old:{py.major}.{py.minor};minimum=3.10"
        )

    writable, write_error = _writable_probe(var_dir)
    if not writable and write_error:
        reasons.append(write_error)

    os_family = _os_family()
    if os_family not in {"windows", "linux", "macos"}:
        warnings.append(f"os_not_verified:{os_family}")

    machine_arch = platform.machine() or "unknown"
    if machine_arch == "unknown":
        warnings.append("machine_arch_unknown")

    cores = max(1, int(hw.get("cpu_cores") or 1))
    ram = float(hw.get("ram_total_gb") or 0.0)
    if ram <= 0:
        warnings.append("ram_total_unknown")

    gpus = list(hw.get("gpus") or [])
    known_vram = [
        float(g.get("vram_gb"))
        for g in gpus
        if g.get("vram_gb") is not None
    ]
    unknown_vram = sum(
        1 for g in gpus
        if g.get("vram_gb") is None
    )
    if unknown_vram:
        warnings.append(
            f"gpu_vram_unknown:{unknown_vram};"
            "vram-required models must fail closed"
        )

    accelerators = tuple(
        sorted(str(x) for x in (hw.get("accelerators") or []))
    )

    envelope = ResourceEnvelope(
        cpu_cores=cores,
        ram_total_gb=ram,
        hardware_profile=str(hw.get("profile") or "unknown"),
        gpu_count=len(gpus),
        known_vram_total_gb=round(sum(known_vram), 2),
        unknown_vram_gpu_count=unknown_vram,
        accelerators=accelerators,
        worker_slots=derive_worker_slots(hw),
        storage_free_gb=_storage_free_gb(var_dir),
    )

    if reasons:
        status = ReadinessStatus.BLOCKED
    elif warnings:
        status = ReadinessStatus.DEGRADED
    else:
        status = ReadinessStatus.READY

    return EnvironmentReadinessReport(
        status=status,
        os_family=os_family,
        os_release=platform.release() or "unknown",
        machine_arch=machine_arch,
        python_version=platform.python_version(),
        python_implementation=platform.python_implementation(),
        hardware_profile=str(hw.get("profile") or "unknown"),
        hardware_fingerprint=str(hw.get("fingerprint") or ""),
        profile_key=str(hw.get("profile_key") or ""),
        hardware_changed=bool(changed),
        resource_envelope=envelope,
        reasons=tuple(reasons),
        warnings=tuple(warnings),
    )
