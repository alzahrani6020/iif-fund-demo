from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Mapping

from .permissions import normalize_environment
from .side_effects import SideEffectClassification


class ExecutionDecision(str, Enum):
    AUTONOMOUS_ALLOWED = "AUTONOMOUS_ALLOWED"
    APPROVAL_REQUIRED = "APPROVAL_REQUIRED"
    DENIED = "DENIED"
    VERIFICATION_REQUIRED = "VERIFICATION_REQUIRED"


@dataclass(frozen=True)
class ExecutionPolicyDecision:
    action: str
    decision: ExecutionDecision
    reason: str
    side_effect: str
    environment: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "action": self.action,
            "decision": self.decision.value,
            "reason": self.reason,
            "side_effect": self.side_effect,
            "environment": self.environment,
        }


_AUTONOMOUS_BOUNDED_WRITES = {
    "performance_selection_feedback",
    "model_profile",
}


def resolve_execution_policy(
    action: str,
    side_effect: SideEffectClassification,
    *,
    environment: str,
    args: Mapping[str, Any] | None = None,
) -> ExecutionPolicyDecision:
    env = normalize_environment(environment)
    normalized = str(action or "").strip().lower()

    if side_effect is SideEffectClassification.UNKNOWN:
        return ExecutionPolicyDecision(
            normalized,
            ExecutionDecision.DENIED,
            "unknown side effect is fail-closed",
            side_effect.value,
            env,
        )

    if side_effect is SideEffectClassification.READ_ONLY:
        return ExecutionPolicyDecision(
            normalized,
            ExecutionDecision.AUTONOMOUS_ALLOWED,
            "read-only capability may execute directly",
            side_effect.value,
            env,
        )

    if env == "production":
        return ExecutionPolicyDecision(
            normalized,
            ExecutionDecision.DENIED,
            "production mutation/external execution is not authorized by the current runtime policy",
            side_effect.value,
            env,
        )

    if side_effect is SideEffectClassification.WRITE:
        if normalized in _AUTONOMOUS_BOUNDED_WRITES:
            return ExecutionPolicyDecision(
                normalized,
                ExecutionDecision.AUTONOMOUS_ALLOWED,
                "bounded internal write is autonomous outside production; verification still applies",
                side_effect.value,
                env,
            )
        return ExecutionPolicyDecision(
            normalized,
            ExecutionDecision.APPROVAL_REQUIRED,
            "workspace or general mutation requires explicit approval",
            side_effect.value,
            env,
        )

    if side_effect is SideEffectClassification.EXTERNAL_SIDE_EFFECT:
        return ExecutionPolicyDecision(
            normalized,
            ExecutionDecision.VERIFICATION_REQUIRED,
            "external execution may run autonomously outside production but must pass independent mission verification",
            side_effect.value,
            env,
        )

    return ExecutionPolicyDecision(
        normalized,
        ExecutionDecision.DENIED,
        "no execution policy matched",
        side_effect.value,
        env,
    )
