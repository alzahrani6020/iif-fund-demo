from __future__ import annotations

import copy
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from .capability_planner import CapabilityPlan, CapabilityPlanStep, CapabilityPlanner
from .execution_policy import ExecutionDecision, resolve_execution_policy
from .orchestrator import AfaqOrchestrator
from .orchestrator_jobs import OrchestratorJobStore
from .side_effects import SideEffectClassification


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def _resolve_result_path(value: Any, path: str) -> Any:
    current = value
    for part in [item for item in path.split(".") if item]:
        if isinstance(current, Mapping):
            if part not in current:
                raise KeyError(f"step result path not found: {path}")
            current = current[part]
            continue
        if isinstance(current, (list, tuple)) and part.isdigit():
            index = int(part)
            if index < 0 or index >= len(current):
                raise KeyError(f"step result index out of range: {path}")
            current = current[index]
            continue
        raise KeyError(f"step result path not found: {path}")
    return current


def _resolve_step_references(value: Any, *, results: list[dict[str, Any]]) -> Any:
    if isinstance(value, Mapping):
        if "$from_step" in value:
            source = value.get("$from_step")
            path = value.get("path", "")
            if not isinstance(source, int) or source < 1 or source > len(results):
                raise ValueError(f"invalid prior-step reference: {source}")
            if not isinstance(path, str):
                raise ValueError("step reference path must be a string")
            source_result = results[source - 1]["result"]
            return copy.deepcopy(_resolve_result_path(source_result, path))
        return {
            str(key): _resolve_step_references(child, results=results)
            for key, child in value.items()
        }
    if isinstance(value, list):
        return [_resolve_step_references(item, results=results) for item in value]
    if isinstance(value, tuple):
        return tuple(_resolve_step_references(item, results=results) for item in value)
    return value


def _browser_verification_contract_sufficient(
    browser_args: Mapping[str, Any],
    verifier_args: Mapping[str, Any],
) -> bool:
    """Require an explicit post-condition strong enough for the browser action."""
    has_content_assertion = any(
        verifier_args.get(name) not in (None, "")
        for name in ("expected_contains", "expected_sha256")
    )
    actions = browser_args.get("actions") or ()
    if actions:
        return has_content_assertion
    return has_content_assertion or verifier_args.get("expected_status") is not None


def _feedback_id_from_write(result: Mapping[str, Any]) -> str | None:
    payload = result.get("result")
    if not isinstance(payload, Mapping):
        return None
    evidence = payload.get("evidence")
    if not isinstance(evidence, Mapping):
        return None
    feedback = evidence.get("feedback")
    if not isinstance(feedback, Mapping):
        return None
    feedback_id = str(feedback.get("feedback_id") or "").strip()
    return feedback_id or None


def _performance_history_has_feedback(
    result: Mapping[str, Any],
    feedback_id: str,
) -> bool:
    if result.get("status") != "COMPLETE":
        return False
    payload = result.get("result")
    if not isinstance(payload, Mapping):
        return False
    evidence = payload.get("evidence")
    if not isinstance(evidence, Mapping):
        return False
    history = evidence.get("selection_feedback")
    if not isinstance(history, (list, tuple)):
        return False
    return any(
        isinstance(item, Mapping)
        and str(item.get("feedback_id") or "").strip() == feedback_id
        for item in history
    )


def _remote_verifier_verified(result: Mapping[str, Any]) -> bool:
    if result.get("status") != "COMPLETE":
        return False
    payload = result.get("result")
    return bool(
        isinstance(payload, Mapping)
        and payload.get("mission_verified") is True
        and isinstance(result.get("verification"), Mapping)
        and result["verification"].get("verified") is True
    )


class OrchestratorExecutionUnavailable(RuntimeError):
    pass


class ShadowExecutionBlocked(RuntimeError):
    pass


class CapabilityInputsMissing(ValueError):
    def __init__(self, missing_inputs: tuple[dict[str, Any], ...]):
        super().__init__("capability plan has missing inputs")
        self.missing_inputs = tuple(dict(item) for item in missing_inputs)


class IdempotencyConflict(ValueError):
    pass


class GovernedOrchestratorJobs:
    """Persistent governed execution for planned engine capability sequences."""

    def __init__(
        self,
        *,
        store_path: str | Path,
        planner: CapabilityPlanner,
        orchestrator: AfaqOrchestrator,
        environment: str = "dev",
    ) -> None:
        self.store = OrchestratorJobStore(store_path)
        self.planner = planner
        self.orchestrator = orchestrator
        self.environment = environment
        self._threads: dict[str, threading.Thread] = {}
        self._lock = threading.Lock()

    def close(self) -> None:
        with self._lock:
            threads = list(self._threads.values())
        for thread in threads:
            if thread.is_alive():
                thread.join(timeout=5.0)
        self.store.close()

    def submit(
        self,
        request: str,
        *,
        context: Mapping[str, Any] | None = None,
        request_id: str | None = None,
        idempotency_key: str | None = None,
    ) -> tuple[dict[str, Any], bool]:
        normalized_context = dict(context or {})
        if idempotency_key:
            existing = self.store.get_by_idempotency_key(idempotency_key)
            if existing is not None:
                if (
                    existing.get("request") != request
                    or dict(existing.get("context") or {}) != normalized_context
                ):
                    raise IdempotencyConflict(
                        "idempotency key already used for a different request"
                    )
                return existing, False
        if not self.orchestrator.enabled():
            raise OrchestratorExecutionUnavailable(
                "orchestrator execution is disabled by feature flag"
            )

        plan = self.planner.plan(request, context=normalized_context)
        if not plan.executable:
            raise CapabilityInputsMissing(plan.missing_inputs)

        decisions = []
        needs_approval = False
        denied = []
        for step in plan.steps:
            effect = SideEffectClassification(step.side_effect)
            decision = resolve_execution_policy(
                step.action,
                effect,
                environment=self.environment,
                args=step.args,
            )
            decisions.append(decision.as_dict())
            if decision.decision is ExecutionDecision.DENIED:
                denied.append(decision.as_dict())
            elif decision.decision is ExecutionDecision.APPROVAL_REQUIRED:
                needs_approval = True

        if self.orchestrator.shadow() and any(
            step.side_effect != SideEffectClassification.READ_ONLY.value
            for step in plan.steps
        ):
            raise ShadowExecutionBlocked(
                "shadow mode blocks write and external-side-effect execution"
            )

        if denied:
            job, created = self.store.create(
                request=request,
                context=normalized_context,
                plan=plan.as_dict(),
                request_id=request_id,
                idempotency_key=idempotency_key,
                state="DENIED",
                approval_state="NOT_REQUIRED",
                verification_state="NOT_STARTED",
            )
            if created:
                self.store.update(
                    job["job_id"],
                    ("DENIED",),
                    result={"policy": decisions, "denied": denied},
                    finished_at=_utcnow(),
                )
                self.store.append_event(
                    job["job_id"],
                    "JOB_DENIED",
                    {"policy": decisions},
                )
            return self.store.get(job["job_id"]), created

        state = "AWAITING_APPROVAL" if needs_approval else "QUEUED"
        approval_state = "PENDING" if needs_approval else "NOT_REQUIRED"
        job, created = self.store.create(
            request=request,
            context=normalized_context,
            plan=plan.as_dict(),
            request_id=request_id,
            idempotency_key=idempotency_key,
            state=state,
            approval_state=approval_state,
            verification_state="PENDING",
        )
        if not created:
            return job, False

        self.store.update(
            job["job_id"],
            (state,),
            result={"policy": decisions},
        )
        self.store.append_event(
            job["job_id"],
            "JOB_CREATED",
            {
                "state": state,
                "approval_state": approval_state,
                "policy": decisions,
            },
        )
        if not needs_approval:
            self._start(job["job_id"])
        return self.store.get(job["job_id"]), True

    def approve(self, job_id: str) -> dict[str, Any]:
        job = self.store.get(job_id)
        if job is None:
            raise KeyError(job_id)
        if job["state"] != "AWAITING_APPROVAL":
            raise RuntimeError(f"job {job_id} is not awaiting approval")
        self.store.update(
            job_id,
            ("AWAITING_APPROVAL",),
            state="QUEUED",
            approval_state="APPROVED",
        )
        self.store.append_event(job_id, "JOB_APPROVED", {})
        self._start(job_id)
        return self.store.get(job_id)

    def reject(self, job_id: str) -> dict[str, Any]:
        job = self.store.get(job_id)
        if job is None:
            raise KeyError(job_id)
        updated = self.store.update(
            job_id,
            ("AWAITING_APPROVAL",),
            state="REJECTED",
            approval_state="REJECTED",
            verification_state="NOT_STARTED",
            finished_at=_utcnow(),
        )
        self.store.append_event(job_id, "JOB_REJECTED", {})
        return updated

    def get(self, job_id: str) -> dict[str, Any] | None:
        return self.store.get(job_id)

    def list(self, limit: int = 100) -> list[dict[str, Any]]:
        return self.store.list(limit)

    def events(self, job_id: str, limit: int = 500) -> list[dict[str, Any]]:
        return self.store.events(job_id, limit)

    def steps(self, job_id: str) -> list[dict[str, Any]]:
        return self.store.steps(job_id)

    def recover(self) -> dict[str, list[str]]:
        """Resume only work whose prior effects are durably known.

        Completed step checkpoints are replayed as data, not re-executed.
        A step left in STARTED has uncertain external state and is never retried
        automatically; that job requires reconciliation.
        """
        restarted: list[str] = []
        interrupted: list[str] = []

        for job in self.store.list_by_states(("RUNNING",)):
            checkpoints = self.store.steps(job["job_id"])
            started = [
                step for step in checkpoints
                if step["state"] == "STARTED"
            ]
            retryable_reads = [
                step for step in started
                if step["side_effect"] == SideEffectClassification.READ_ONLY.value
            ]
            uncertain = [
                step for step in started
                if step["side_effect"] != SideEffectClassification.READ_ONLY.value
            ]

            for step in retryable_reads:
                self.store.upsert_step(
                    job["job_id"],
                    step["step_number"],
                    action=step["action"],
                    engine_id=step["engine_id"],
                    side_effect=step["side_effect"],
                    state="RETRYABLE_AFTER_INTERRUPT",
                    resolved_args=step.get("resolved_args"),
                    result=None,
                    started_at=step.get("started_at"),
                    finished_at=None,
                )
                self.store.append_event(
                    job["job_id"],
                    "STEP_MARKED_RETRYABLE_AFTER_INTERRUPT",
                    {"step": step["step_number"], "action": step["action"]},
                )

            if uncertain:
                for step in uncertain:
                    self.store.upsert_step(
                        job["job_id"],
                        step["step_number"],
                        action=step["action"],
                        engine_id=step["engine_id"],
                        side_effect=step["side_effect"],
                        state="INTERRUPTED_UNCERTAIN",
                        resolved_args=step.get("resolved_args"),
                        result=step.get("result"),
                        started_at=step.get("started_at"),
                        finished_at=_utcnow(),
                    )
                updated = self.store.update(
                    job["job_id"],
                    ("RUNNING",),
                    state="INTERRUPTED_REQUIRES_RECONCILIATION",
                    verification_state="RECONCILIATION_REQUIRED",
                    error_code="RUNTIME_INTERRUPTED",
                    finished_at=_utcnow(),
                )
                interrupted.append(updated["job_id"])
                self.store.append_event(
                    updated["job_id"],
                    "JOB_INTERRUPTED_REQUIRES_RECONCILIATION",
                    {
                        "uncertain_steps": [
                            step["step_number"] for step in uncertain
                        ]
                    },
                )
                continue

            # The runtime stopped between durable step checkpoints. Re-queueing
            # is safe because _run() restores completed steps and starts at the
            # first step without a terminal checkpoint.
            self.store.update(
                job["job_id"],
                ("RUNNING",),
                state="QUEUED",
                verification_state="PENDING",
                error_code=None,
                finished_at=None,
            )
            self.store.append_event(
                job["job_id"],
                "JOB_RECOVERED_FROM_CHECKPOINT",
                {
                    "completed_steps": [
                        step["step_number"]
                        for step in checkpoints
                        if step["state"] in {"COMPLETE", "NOT_VERIFIED"}
                    ]
                },
            )
            self._start(job["job_id"])
            restarted.append(job["job_id"])

        for job in self.store.list_by_states(("QUEUED",)):
            if job["job_id"] in restarted:
                continue
            self.store.append_event(job["job_id"], "JOB_RECOVERED_QUEUED", {})
            self._start(job["job_id"])
            restarted.append(job["job_id"])

        return {
            "restarted": restarted,
            "interrupted": interrupted,
        }

    def _start(self, job_id: str) -> None:
        with self._lock:
            current = self._threads.get(job_id)
            if current is not None and current.is_alive():
                return
            thread = threading.Thread(
                target=self._run,
                args=(job_id,),
                daemon=True,
                name=f"afaq-orchestrator-{job_id}",
            )
            self._threads[job_id] = thread
            thread.start()

    def _run(self, job_id: str) -> None:
        job = self.store.get(job_id)
        if job is None or job["state"] != "QUEUED":
            return
        self.store.update(
            job_id,
            ("QUEUED",),
            state="RUNNING",
            started_at=_utcnow(),
        )
        self.store.append_event(job_id, "JOB_RUNNING", {})

        results = []
        unresolved_verifications: list[dict[str, Any]] = []
        checkpoints = {
            step["step_number"]: step
            for step in self.store.steps(job_id)
        }
        try:
            for index, raw in enumerate(job["plan"].get("steps", [])):
                step = CapabilityPlanStep(
                    action=str(raw["action"]),
                    objective=str(raw.get("objective") or ""),
                    args=dict(raw.get("args") or {}),
                    engine_id=str(raw["engine_id"]),
                    side_effect=str(raw["side_effect"]),
                    missing_args=tuple(raw.get("missing_args") or ()),
                )
                checkpoint = checkpoints.get(index + 1)
                restored = (
                    checkpoint is not None
                    and checkpoint["state"] in {
                        "COMPLETE",
                        "NOT_VERIFIED",
                        "FAILED",
                        "DENIED",
                        "SHADOW_BLOCKED",
                    }
                )
                if restored:
                    if not isinstance(checkpoint.get("result"), Mapping):
                        raise RuntimeError(
                            f"checkpoint {index + 1} missing persisted result"
                        )
                    resolved_args = dict(checkpoint.get("resolved_args") or {})
                    result = dict(checkpoint["result"])
                    results.append({
                        "step": index + 1,
                        "action": step.action,
                        "engine_id": step.engine_id,
                        "resolved_args": resolved_args,
                        "result": result,
                    })
                    self.store.append_event(
                        job_id,
                        "STEP_RESTORED_FROM_CHECKPOINT",
                        {
                            "step": index + 1,
                            "action": step.action,
                            "state": checkpoint["state"],
                        },
                    )
                else:
                    resolved_args = _resolve_step_references(
                        step.args,
                        results=results,
                    )
                    if not isinstance(resolved_args, Mapping):
                        raise ValueError("resolved step args must be a mapping")
                    resolved_args = dict(resolved_args)

                effect = SideEffectClassification(step.side_effect)
                if restored:
                    verification = result.get("verification")
                    write_verified = bool(
                        effect is SideEffectClassification.WRITE
                        and isinstance(verification, Mapping)
                        and verification.get("verified") is True
                    )
                    if (
                        effect is SideEffectClassification.EXTERNAL_SIDE_EFFECT
                        or (
                            effect is SideEffectClassification.WRITE
                            and not write_verified
                        )
                    ):
                        unresolved_verifications.append({
                            "source_step": index + 1,
                            "action": step.action,
                            "url": str(resolved_args.get("url") or "").strip() or None,
                            "args": dict(resolved_args),
                        })
                else:
                    decision = resolve_execution_policy(
                        step.action,
                        effect,
                        environment=self.environment,
                        args=resolved_args,
                    )
                    if decision.decision is ExecutionDecision.DENIED:
                        raise PermissionError(decision.reason)
                    if decision.decision is ExecutionDecision.APPROVAL_REQUIRED:
                        current = self.store.get(job_id)
                        if current["approval_state"] != "APPROVED":
                            raise PermissionError("approval is required before execution")
                    if decision.decision is ExecutionDecision.VERIFICATION_REQUIRED:
                        unresolved_verifications.append({
                            "source_step": index + 1,
                            "action": step.action,
                            "url": str(resolved_args.get("url") or "").strip() or None,
                            "args": dict(resolved_args),
                        })

                if not restored:
                    started_at = _utcnow()
                    self.store.upsert_step(
                        job_id,
                        index + 1,
                        action=step.action,
                        engine_id=step.engine_id,
                        side_effect=step.side_effect,
                        state="STARTED",
                        resolved_args=resolved_args,
                        started_at=started_at,
                    )
                    self.store.append_event(
                        job_id,
                        "STEP_STARTED",
                        {
                            "step": index + 1,
                            "action": step.action,
                            "engine_id": step.engine_id,
                        },
                    )

                    request_id = job.get("request_id")
                    current_job = self.store.get(job_id)
                    result = self.orchestrator.execute(
                        step.action,
                        resolved_args,
                        request_id=(
                            f"{request_id}:{index + 1}"
                            if request_id
                            else None
                        ),
                        approved_by_job=bool(
                            current_job
                            and current_job.get("approval_state") == "APPROVED"
                        ),
                    )
                    checkpoint_state = str(result.get("status") or "FAILED")
                    self.store.upsert_step(
                        job_id,
                        index + 1,
                        action=step.action,
                        engine_id=step.engine_id,
                        side_effect=step.side_effect,
                        state=checkpoint_state,
                        resolved_args=resolved_args,
                        result=result,
                        started_at=started_at,
                        finished_at=_utcnow(),
                    )
                    results.append({
                        "step": index + 1,
                        "action": step.action,
                        "engine_id": step.engine_id,
                        "resolved_args": resolved_args,
                        "result": result,
                    })
                    self.store.append_event(
                        job_id,
                        "STEP_FINISHED",
                        {
                            "step": index + 1,
                            "action": step.action,
                            "engine_id": step.engine_id,
                            "status": checkpoint_state,
                        },
                    )
                if result.get("status") == "FAILED":
                    raise RuntimeError("orchestrator step failed")
                if result.get("status") == "DENIED":
                    raise PermissionError("orchestrator denied step")
                if result.get("status") == "SHADOW_BLOCKED":
                    self.store.update(
                        job_id,
                        ("RUNNING",),
                        state="SHADOW_BLOCKED",
                        verification_state="NOT_STARTED",
                        error_code="SHADOW_BLOCKED",
                        result={"steps": results},
                        finished_at=_utcnow(),
                    )
                    self.store.append_event(job_id, "JOB_SHADOW_BLOCKED", {})
                    return

                if result.get("status") == "NOT_VERIFIED" and not any(
                    item["source_step"] == index + 1
                    for item in unresolved_verifications
                ):
                    obligation = {
                        "source_step": index + 1,
                        "action": step.action,
                        "url": str(resolved_args.get("url") or "").strip() or None,
                        "args": dict(resolved_args),
                    }
                    if step.action == "performance_selection_feedback":
                        obligation["feedback_id"] = _feedback_id_from_write(result)
                    unresolved_verifications.append(obligation)

                if step.action == "remote_verify" and _remote_verifier_verified(result):
                    verified_url = str(resolved_args.get("url") or "").strip()
                    match_index = None
                    for obligation_index in range(len(unresolved_verifications) - 1, -1, -1):
                        obligation = unresolved_verifications[obligation_index]
                        if obligation.get("action") != "browser_execute":
                            continue
                        if obligation.get("url") != verified_url:
                            continue
                        if not _browser_verification_contract_sufficient(
                            obligation.get("args") or {},
                            resolved_args,
                        ):
                            continue
                        match_index = obligation_index
                        break
                    if match_index is not None:
                        unresolved_verifications.pop(match_index)

                if step.action == "performance_history":
                    match_index = None
                    for obligation_index in range(len(unresolved_verifications) - 1, -1, -1):
                        obligation = unresolved_verifications[obligation_index]
                        if obligation.get("action") != "performance_selection_feedback":
                            continue
                        feedback_id = str(obligation.get("feedback_id") or "").strip()
                        if feedback_id and _performance_history_has_feedback(
                            result,
                            feedback_id,
                        ):
                            match_index = obligation_index
                            break
                    if match_index is not None:
                        unresolved_verifications.pop(match_index)

            verification_required = bool(unresolved_verifications)
            state = "VERIFICATION_REQUIRED" if verification_required else "COMPLETED"
            verification_state = "REQUIRED" if verification_required else "VERIFIED"
            self.store.update(
                job_id,
                ("RUNNING",),
                state=state,
                verification_state=verification_state,
                result={
                    "steps": results,
                    "unresolved_verifications": unresolved_verifications,
                },
                finished_at=_utcnow(),
            )
            self.store.append_event(
                job_id,
                "JOB_COMPLETED" if state == "COMPLETED" else "JOB_VERIFICATION_REQUIRED",
                {
                    "verification_state": verification_state,
                    "unresolved_count": len(unresolved_verifications),
                },
            )
        except PermissionError:
            self.store.update(
                job_id,
                ("RUNNING",),
                state="DENIED",
                verification_state="NOT_STARTED",
                error_code="POLICY_DENIED",
                result={"steps": results},
                finished_at=_utcnow(),
            )
            self.store.append_event(job_id, "JOB_DENIED", {"reason": "POLICY_DENIED"})
        except Exception:
            self.store.update(
                job_id,
                ("RUNNING",),
                state="FAILED",
                verification_state="FAILED",
                error_code="EXECUTION_FAILED",
                result={"steps": results},
                finished_at=_utcnow(),
            )
            self.store.append_event(job_id, "JOB_FAILED", {"code": "EXECUTION_FAILED"})
