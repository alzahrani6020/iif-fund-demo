"""Focused tests for the Storyboard & Previs engine (wave 4, §14 family).

Runs against afaq_agent_runtime.storyboard_previs only — no model, no network,
no runtime services, no canonical state. Intentionally OUTSIDE pytest.ini
testpaths so the canonical suite stays at exactly 44 tests.

Run explicitly:

    python -m pytest afaq_agent_runtime/tests_storyboard -q
"""

from __future__ import annotations

import copy

import pytest

from afaq_agent_runtime.storyboard_previs import (
    StoryboardError,
    build_animatic,
    check_continuity,
    compose_storyboard,
    design_shot,
    generate_shot_list,
    parse_animatic,
    parse_shot_list,
    run_storyboard_gates,
    storyboard_readiness,
)

# A scene plan shaped exactly like writing_engine.plan_scenes output
# (ENG-WR-019): three sequences covering seven beats in total.
_SCENE_PLAN = {
    "content_type": "video_script",
    "sequences": [
        {
            "order": 1,
            "purpose": "sequence covers hook + setup; begins: open with the stakes",
            "setting": "opening context",
            "beats_covered": [1, 2],
        },
        {
            "order": 2,
            "purpose": "sequence covers rising_action + midpoint; begins: develop the core",
            "setting": "main development",
            "beats_covered": [3, 4],
        },
        {
            "order": 3,
            "purpose": "sequence covers climax + resolution; begins: decisive moment",
            "setting": "closing",
            "beats_covered": [5, 6, 7],
        },
    ],
}


def _shot(**overrides):
    base = {
        "shot_id": "S1",
        "order": 1,
        "sequence_order": 1,
        "purpose": "cover the opening beat",
        "framing": "medium",
        "angle": "eye_level",
        "movement": "static",
        "duration_seconds": 4,
    }
    base.update(overrides)
    return base


def _annotated_shots():
    """Four shots across two sequences with characters/props declared."""
    return [
        _shot(shot_id="S1", order=1, sequence_order=1, framing="wide",
              characters=["amina"], props=["lantern"], setting="courtyard"),
        _shot(shot_id="S2", order=2, sequence_order=1, framing="medium",
              characters=["amina"], props=["lantern"], setting="courtyard"),
        _shot(shot_id="S3", order=3, sequence_order=2, framing="wide",
              characters=["amina", "bassam"], props=["lantern", "letter"],
              setting="workshop"),
        _shot(shot_id="S4", order=4, sequence_order=2, framing="medium",
              characters=["amina", "bassam"], props=["lantern", "letter"],
              setting="workshop"),
    ]


# -- strict parse / validate --------------------------------------------------------

def test_parse_shot_list_valid_roundtrip():
    shots = generate_shot_list(_SCENE_PLAN)
    animatic = build_animatic(shots)
    storyboard = {
        "shots": shots,
        "animatic": animatic,
        "continuity": [],
        "confidence": {"level": "high", "basis": "grounded in the scene plan"},
        "open_questions": [],
    }
    parsed = parse_shot_list(storyboard)
    assert len(parsed["shots"]) == 7
    assert parsed["animatic"]["total_duration_seconds"] > 0


def test_parse_shot_rejects_bad_framing():
    with pytest.raises(StoryboardError, match="framing"):
        parse_shot_list({
            "shots": [_shot(framing="aerial")],
            "animatic": {"shots": [], "total_duration_seconds": 4},
            "continuity": [],
            "confidence": {"level": "low", "basis": "x"},
            "open_questions": [],
        })


def test_parse_shot_rejects_duration_out_of_bounds():
    with pytest.raises(StoryboardError, match="within 2..15"):
        parse_shot_list({
            "shots": [_shot(duration_seconds=30)],
            "animatic": {"shots": [], "total_duration_seconds": 4},
            "continuity": [],
            "confidence": {"level": "low", "basis": "x"},
            "open_questions": [],
        })


def test_parse_shot_rejects_empty_purpose():
    with pytest.raises(StoryboardError, match="non-empty"):
        parse_shot_list({
            "shots": [_shot(purpose="   ")],
            "animatic": {"shots": [], "total_duration_seconds": 4},
            "continuity": [],
            "confidence": {"level": "low", "basis": "x"},
            "open_questions": [],
        })


def test_parse_shot_rejects_too_many_characters():
    with pytest.raises(StoryboardError, match="exceeds 6 entries"):
        parse_shot_list({
            "shots": [_shot(characters=[f"c{i}" for i in range(7)])],
            "animatic": {"shots": [], "total_duration_seconds": 4},
            "continuity": [],
            "confidence": {"level": "low", "basis": "x"},
            "open_questions": [],
        })


def test_parse_shot_list_rejects_non_object():
    with pytest.raises(StoryboardError, match="JSON object"):
        parse_shot_list(["not", "a", "mapping"])


def test_parse_shot_list_rejects_empty_shots():
    with pytest.raises(StoryboardError, match="must not be empty"):
        parse_shot_list({
            "shots": [],
            "animatic": {"shots": [{"shot_id": "S1", "order": 1,
                                    "transition_in": "cut", "start_seconds": 0,
                                    "duration_seconds": 4, "end_seconds": 4}],
                         "total_duration_seconds": 4},
            "continuity": [],
            "confidence": {"level": "low", "basis": "x"},
            "open_questions": [],
        })


def test_parse_animatic_rejects_bad_transition():
    with pytest.raises(StoryboardError, match="transition_in"):
        parse_animatic({
            "shots": [{"shot_id": "S1", "order": 1, "transition_in": "morph",
                       "start_seconds": 0, "duration_seconds": 4,
                       "end_seconds": 4}],
            "total_duration_seconds": 4,
        })


# -- design_shot composition rules ---------------------------------------------------

def test_design_shot_opening_shot_is_establishing():
    shot = design_shot(
        shot_index=0, shot_count_in_sequence=2,
        sequence_index=0, sequence_count=3,
        purpose="open the story", setting="opening context",
    )
    assert shot["framing"] == "establishing"
    assert shot["angle"] == "high"
    assert shot["movement"] == "static"
    assert shot["duration_seconds"] == 8
    assert shot["setting"] == "opening context"


def test_design_shot_later_sequence_opens_wide():
    shot = design_shot(
        shot_index=0, shot_count_in_sequence=2,
        sequence_index=1, sequence_count=3,
        purpose="continue the main development", setting="main development",
    )
    assert shot["framing"] == "wide"
    assert shot["movement"] == "pan"


def test_design_shot_decisive_wording_selects_close_up():
    shot = design_shot(
        shot_index=1, shot_count_in_sequence=3,
        sequence_index=2, sequence_count=3,
        purpose="cover the climax: the decisive moment arrives", setting="closing",
    )
    assert shot["framing"] == "close_up"
    assert shot["movement"] == "static"
    assert shot["duration_seconds"] == 3


def test_design_shot_menace_wording_selects_low_angle():
    shot = design_shot(
        shot_index=1, shot_count_in_sequence=2,
        sequence_index=1, sequence_count=3,
        purpose="the main obstacle and threat closes in", setting="main development",
    )
    assert shot["angle"] == "low"


def test_design_shot_final_shot_of_final_sequence_is_wide_dolly():
    shot = design_shot(
        shot_index=2, shot_count_in_sequence=3,
        sequence_index=2, sequence_count=3,
        purpose="resolve the story quietly", setting="closing",
    )
    assert shot["framing"] == "wide"
    assert shot["movement"] == "dolly"


def test_design_shot_single_beat_sequence_is_medium():
    shot = design_shot(
        shot_index=0, shot_count_in_sequence=1,
        sequence_index=1, sequence_count=3,
        purpose="one self-contained beat", setting="main development",
    )
    assert shot["framing"] == "medium"
    assert shot["duration_seconds"] == 4


# -- generate_shot_list ---------------------------------------------------------------

def test_generate_shot_list_covers_every_beat_once():
    shots = generate_shot_list(_SCENE_PLAN)
    assert len(shots) == 7  # 2 + 2 + 3 beats
    assert [s["order"] for s in shots] == list(range(1, 8))
    assert [s["shot_id"] for s in shots] == [f"S{i}" for i in range(1, 8)]
    linked = [s["sequence_order"] for s in shots]
    assert linked == [1, 1, 2, 2, 3, 3, 3]


def test_generate_shot_list_carries_setting_and_purpose():
    shots = generate_shot_list(_SCENE_PLAN)
    assert shots[0]["setting"] == "opening context"
    assert "beat 1" in shots[0]["purpose"]
    assert "hook" in shots[0]["purpose"]  # sequence purpose carried verbatim


def test_generate_shot_list_declares_no_characters_or_props():
    shots = generate_shot_list(_SCENE_PLAN)
    for shot in shots:
        assert "characters" not in shot
        assert "props" not in shot


def test_generate_shot_list_rejects_invalid_plan():
    with pytest.raises(StoryboardError):
        generate_shot_list({"content_type": "video_script", "sequences": []})


def test_generate_shot_list_rejects_over_budget():
    plan = {
        "content_type": "video_script",
        "sequences": [
            {
                "order": i + 1,
                "purpose": f"sequence {i + 1} covers development",
                "setting": "main development",
                "beats_covered": list(range(i * 10 + 1, i * 10 + 11)),
            }
            for i in range(5)
        ],
    }
    with pytest.raises(StoryboardError, match="exceeds 40 shots"):
        generate_shot_list(plan)


def test_generate_shot_list_does_not_mutate_input():
    plan = copy.deepcopy(_SCENE_PLAN)
    before = copy.deepcopy(plan)
    generate_shot_list(plan)
    assert plan == before


def test_generate_shot_list_is_deterministic():
    assert generate_shot_list(_SCENE_PLAN) == generate_shot_list(_SCENE_PLAN)


# -- check_continuity -----------------------------------------------------------------

def test_check_continuity_clean_annotated_shots():
    assert check_continuity(_annotated_shots()) == []


def test_check_continuity_flags_vanished_prop():
    shots = _annotated_shots()
    shots[1]["props"] = []  # lantern vanishes with same participants/setting
    issues = check_continuity(shots)
    assert any(i["kind"] == "prop_continuity" and i["severity"] == "error"
               for i in issues)
    assert all("lantern" in i["detail"] for i in issues
               if i["kind"] == "prop_continuity")


def test_check_continuity_ignores_prop_change_across_sequences():
    shots = _annotated_shots()
    shots[2]["props"] = ["letter"]  # different sequence: not consecutive-same-seq
    assert check_continuity(shots) == []


def test_check_continuity_ignores_prop_change_when_participants_change():
    shots = _annotated_shots()
    shots[1]["characters"] = ["amina", "bassam"]  # someone enters: props may reset
    prop_issues = [i for i in check_continuity(shots)
                   if i["kind"] == "prop_continuity"]
    assert prop_issues == []


def test_check_continuity_flags_mid_sequence_setting_change():
    shots = _annotated_shots()
    shots[1]["setting"] = "rooftop"  # mid-sequence teleport
    issues = check_continuity(shots)
    assert any(i["kind"] == "set_continuity" and i["severity"] == "error"
               for i in issues)


def test_check_continuity_warns_on_unestablished_character_intro():
    shots = _annotated_shots()
    shots[3]["characters"] = ["amina", "bassam", "noura"]
    issues = check_continuity(shots)
    assert any(i["kind"] == "character_intro" and i["severity"] == "warning"
               and "noura" in i["detail"] for i in issues)


def test_check_continuity_wide_introduction_is_clean():
    shots = _annotated_shots()
    shots[2]["characters"] = ["amina", "bassam", "noura"]
    shots[2]["framing"] = "wide"  # noura introduced wide: accepted
    assert check_continuity(shots) == []


def test_check_continuity_generated_shots_have_no_issues():
    shots = generate_shot_list(_SCENE_PLAN)
    assert check_continuity(shots) == []


def test_check_continuity_skips_undeclared_fields():
    shots = [_shot(shot_id="S1"), _shot(shot_id="S2", order=2)]
    assert check_continuity(shots) == []


# -- build_animatic -------------------------------------------------------------------

def test_build_animatic_transitions_and_timing():
    shots = generate_shot_list(_SCENE_PLAN)
    animatic = build_animatic(shots)
    entries = animatic["shots"]
    assert [e["shot_id"] for e in entries] == [s["shot_id"] for s in shots]
    # same-sequence neighbours cut; boundary into final sequence fades
    assert entries[0]["transition_in"] == "cut"
    assert entries[1]["transition_in"] == "cut"
    assert entries[2]["transition_in"] == "dissolve"  # seq 1 -> seq 2
    assert entries[4]["transition_in"] == "fade"      # seq 2 -> final seq 3
    # cumulative timing is consistent
    for previous, entry in zip(entries, entries[1:]):
        assert entry["start_seconds"] == previous["end_seconds"]
    total = sum(e["duration_seconds"] for e in entries)
    assert animatic["total_duration_seconds"] == total
    assert entries[-1]["end_seconds"] == total


def test_build_animatic_rejects_empty():
    with pytest.raises(StoryboardError, match="at least one shot"):
        build_animatic([])


# -- compose_storyboard (end-to-end) --------------------------------------------------

def test_compose_storyboard_end_to_end():
    storyboard = compose_storyboard(_SCENE_PLAN)
    assert len(storyboard["shots"]) == 7
    assert storyboard["animatic"]["total_duration_seconds"] > 0
    assert storyboard["continuity"] == []
    assert storyboard["confidence"]["level"] == "high"
    # everything the plan does not declare is honestly UNKNOWN
    joined = " ".join(storyboard["open_questions"])
    assert "characters UNKNOWN" in joined
    assert "props UNKNOWN" in joined


def test_compose_storyboard_roundtrips_through_parse():
    storyboard = compose_storyboard(_SCENE_PLAN)
    assert parse_shot_list(storyboard) == storyboard


def test_compose_storyboard_confidence_drops_on_continuity_errors():
    plan = copy.deepcopy(_SCENE_PLAN)
    plan["sequences"][0]["setting"] = "opening context"
    plan["sequences"][1]["setting"] = "opening context"  # same declared setting
    storyboard = compose_storyboard(plan)
    # annotate through re-check: generated shots declare settings, so mid-seq
    # consistency holds; instead force a check on annotated shots separately.
    assert storyboard["confidence"]["level"] in ("high", "medium")

    shots = generate_shot_list(plan)
    shots[2]["props"] = ["letter"]
    shots[3]["props"] = []  # same sequence+setting, but no declared participants
    # without declared participants the prop rule stays silent (honest skip)
    assert check_continuity(shots) == []


def test_compose_storyboard_rejects_bad_plan():
    with pytest.raises(StoryboardError):
        compose_storyboard({"sequences": "not-a-list"})


def test_compose_storyboard_rejects_long_title():
    with pytest.raises(StoryboardError, match="title exceeds"):
        compose_storyboard(_SCENE_PLAN, title="word " * 50)


def test_compose_storyboard_is_deterministic():
    assert compose_storyboard(_SCENE_PLAN) == compose_storyboard(_SCENE_PLAN)


# -- gates + readiness seal ------------------------------------------------------------

def test_gates_pass_on_composed_storyboard():
    storyboard = compose_storyboard(_SCENE_PLAN)
    assert run_storyboard_gates(storyboard, _SCENE_PLAN) == []


def test_gates_flag_unknown_sequence_link():
    storyboard = compose_storyboard(_SCENE_PLAN)
    storyboard["shots"][0]["sequence_order"] = 99
    failures = run_storyboard_gates(storyboard, _SCENE_PLAN)
    assert any("unknown sequence" in f for f in failures)


def test_gates_flag_animatic_mismatch():
    storyboard = compose_storyboard(_SCENE_PLAN)
    storyboard["animatic"]["total_duration_seconds"] += 10
    failures = run_storyboard_gates(storyboard, _SCENE_PLAN)
    assert any("disagrees with shot durations sum" in f for f in failures)


def test_gates_flag_continuity_error():
    storyboard = compose_storyboard(_SCENE_PLAN)
    storyboard["continuity"] = [{
        "kind": "prop_continuity", "severity": "error",
        "shot_id": "S2", "detail": "prop lantern vanished between S1 and S2",
    }]
    failures = run_storyboard_gates(storyboard, _SCENE_PLAN)
    assert any("continuity error" in f for f in failures)


def test_gates_flag_ungrounded_basis():
    storyboard = compose_storyboard(_SCENE_PLAN)
    storyboard["confidence"]["basis"] = "pulled from thin air entirely"
    failures = run_storyboard_gates(storyboard, _SCENE_PLAN)
    assert any("not grounded" in f for f in failures)


def test_gates_flag_non_contiguous_orders():
    storyboard = compose_storyboard(_SCENE_PLAN)
    storyboard["shots"][3]["order"] = 9
    failures = run_storyboard_gates(storyboard, _SCENE_PLAN)
    assert any("contiguous" in f for f in failures)


def test_gates_reject_invalid_plan():
    storyboard = compose_storyboard(_SCENE_PLAN)
    failures = run_storyboard_gates(storyboard, {"sequences": "broken"})
    assert failures and any("scene plan is invalid" in f for f in failures)


def test_readiness_seal_ready_when_clean():
    storyboard = compose_storyboard(_SCENE_PLAN)
    seal = storyboard_readiness(storyboard, [])
    assert seal["ready"] is True
    assert seal["blocking_items"] == []
    assert seal["seal"]["shots_planned"] is True
    assert seal["seal"]["animatic_built"] is True
    assert seal["seal"]["continuity_checked"] is True
    assert seal["seal"]["gates_clean"] is True
    assert seal["seal"]["authority_preserved"] is True


def test_readiness_seal_blocks_on_failures_and_empty():
    storyboard = compose_storyboard(_SCENE_PLAN)
    seal = storyboard_readiness(storyboard, ["animatic total mismatch"])
    assert seal["ready"] is False
    assert "animatic total mismatch" in seal["blocking_items"]

    empty_seal = storyboard_readiness({"shots": [], "animatic": {}}, [])
    assert empty_seal["ready"] is False
    assert any("no shots" in b for b in empty_seal["blocking_items"])


def test_readiness_seal_handles_non_object():
    seal = storyboard_readiness("not a mapping", [])
    assert seal["ready"] is False
    assert seal["seal"]["authority_preserved"] is True


# -- composition with ENG-WR-019 --------------------------------------------------------

def test_composes_with_writing_engine_plan_output():
    """Wave-4 engine consumes wave-3 plan_scenes output verbatim."""
    from afaq_agent_runtime.writing_engine import (
        build_structure,
        generate_brief,
        plan_scenes,
    )

    understanding = {
        "intent": {"kind": "development_task", "reason": "instruction requests a video"},
        "goals": ["write a short video script about solar adoption"],
        "audience": "general",
        "platform_hints": [],
        "constraints": ["keep it short"],
        "deliverables": ["video script"],
        "decomposition": ["confirm intent", "work goal", "verify"],
        "confidence": {
            "level": "medium",
            "basis": 'instruction states: "write a short video script about solar adoption"',
        },
        "open_questions": [],
    }
    brief = generate_brief(understanding)
    structure = build_structure(brief)
    scene_plan = plan_scenes(structure, brief)
    storyboard = compose_storyboard(scene_plan)
    assert len(storyboard["shots"]) == len(structure["beats"])
    assert run_storyboard_gates(storyboard, scene_plan) == []
    seal = storyboard_readiness(
        storyboard, run_storyboard_gates(storyboard, scene_plan)
    )
    assert seal["ready"] is True
