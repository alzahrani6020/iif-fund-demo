"""Mutation journal — durable, idempotent record of governed filesystem mutations.

This module implements the S02 API surface for the Stage 2C remediation plan.
It is intentionally NOT wired to DeveloperAgent, DeveloperTools, ApprovalStore,
or CheckpointEngine in S02. All operations are SQLite-only; no filesystem
operations are performed here.
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from threading import RLock
from typing import Any, Mapping

_SCHEMA_VERSION = 2

_SCHEMA = """
CREATE TABLE IF NOT EXISTS schema_version (
    component TEXT PRIMARY KEY,
    version INTEGER NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS mutation_records (
    record_id TEXT PRIMARY KEY,
    task_id TEXT NOT NULL,
    operation_id TEXT NOT NULL,
    proposal_version_hash TEXT NOT NULL,
    approval_id TEXT NOT NULL,
    relative_path TEXT NOT NULL,
    action TEXT NOT NULL,
    pre_image_hash TEXT,
    intended_post_image_hash TEXT,
    actual_post_image_hash TEXT,
    checkpoint_manifest_id TEXT NOT NULL,
    phase TEXT NOT NULL,
    attempt_timestamp TEXT NOT NULL,
    completion_timestamp TEXT,
    rollback_status TEXT NOT NULL DEFAULT 'not_needed',
    evidence_status TEXT NOT NULL DEFAULT 'pending',
    idempotency_key TEXT NOT NULL UNIQUE,
    sequence_number INTEGER NOT NULL,
    incomplete_reason TEXT,
    UNIQUE(task_id, operation_id)
);
CREATE INDEX IF NOT EXISTS mutation_records_task_seq_idx ON mutation_records (task_id, sequence_number);
CREATE INDEX IF NOT EXISTS mutation_records_manifest_idx ON mutation_records (checkpoint_manifest_id);
"""

# Applied idempotently to databases created by the S01 skeleton schema.
_MIGRATIONS = (
    "ALTER TABLE mutation_records ADD COLUMN incomplete_reason TEXT",
)


class MutationJournalError(RuntimeError):
    """Base class for mutation-journal errors."""


class InvalidPhaseTransition(MutationJournalError):
    """Raised when a phase transition violates the finite-state machine."""


class IdentityConflict(MutationJournalError):
    """Raised when the same operation_id is reused with differing identity."""


class DuplicateMutation(MutationJournalError):
    """Raised when an operation that is already durable is re-prepared."""


class MissingRecord(MutationJournalError):
    """Raised when a referenced mutation record does not exist."""


class MutationPhase:
    PREPARED = "prepared"
    MUTATING = "mutating"
    COMPLETED = "completed"
    COMMITTED = "committed"
    ROLLING_BACK = "rolling_back"
    ROLLED_BACK = "rolled_back"
    INCOMPLETE = "incomplete"

    _TERMINAL = frozenset({COMMITTED, ROLLED_BACK, INCOMPLETE})


# Legal predecessor phases for every target phase.
VALID_TRANSITIONS: dict[str, frozenset[str]] = {
    MutationPhase.PREPARED: frozenset(),
    MutationPhase.MUTATING: frozenset({MutationPhase.PREPARED}),
    MutationPhase.COMPLETED: frozenset({MutationPhase.MUTATING}),
    MutationPhase.COMMITTED: frozenset({MutationPhase.COMPLETED}),
    MutationPhase.ROLLING_BACK: frozenset({MutationPhase.PREPARED, MutationPhase.MUTATING, MutationPhase.COMPLETED}),
    MutationPhase.ROLLED_BACK: frozenset({MutationPhase.ROLLING_BACK}),
    MutationPhase.INCOMPLETE: frozenset({MutationPhase.PREPARED, MutationPhase.MUTATING, MutationPhase.COMPLETED, MutationPhase.ROLLING_BACK}),
}


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def _ensure_schema_version(conn: sqlite3.Connection, component: str, version: int) -> None:
    conn.execute(
        "INSERT INTO schema_version (component, version, updated_at) VALUES (?, ?, ?)"
        " ON CONFLICT(component) DO UPDATE SET version=excluded.version, updated_at=excluded.updated_at",
        (component, version, _utcnow()),
    )


def _idempotency_key(
    task_id: str,
    operation_id: str,
    proposal_version_hash: str,
    approval_id: str,
    relative_path: str,
    action: str,
    pre_image_hash: str | None,
    intended_post_image_hash: str | None,
    checkpoint_manifest_id: str,
) -> str:
    payload = {
        "task_id": task_id,
        "operation_id": operation_id,
        "proposal_version_hash": proposal_version_hash,
        "approval_id": approval_id,
        "relative_path": relative_path,
        "action": action,
        "pre_image_hash": pre_image_hash,
        "intended_post_image_hash": intended_post_image_hash,
        "checkpoint_manifest_id": checkpoint_manifest_id,
    }
    canonical = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


class MutationJournal:
    """Durable journal of governed mutation operations.

    S02 scope:
    - SQLite-only durable records.
    - Idempotent per-operation identity.
    - Explicit phase transitions with predecessor validation.
    - No filesystem operations.
    - No integration with runtime authority (DeveloperAgent, tools, approvals).
    """

    def __init__(self, path: str | Path) -> None:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(
            str(path), check_same_thread=False, isolation_level=None
        )
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA busy_timeout=5000")
        self._conn.executescript(_SCHEMA)
        self._apply_migrations()
        _ensure_schema_version(self._conn, "mutation_journal", _SCHEMA_VERSION)
        self._lock = RLock()

    def _apply_migrations(self) -> None:
        existing = {row[1] for row in self._conn.execute("PRAGMA table_info(mutation_records)")}
        for statement in _MIGRATIONS:
            column = statement.split("ADD COLUMN ")[1].split(" ")[0]
            if column not in existing:
                self._conn.execute(statement)

    def close(self) -> None:
        self._conn.close()

    # ------------------------------------------------------------------
    # Core API
    # ------------------------------------------------------------------
    def prepare(
        self,
        *,
        task_id: str,
        operation_id: str,
        proposal_version_hash: str,
        approval_id: str,
        relative_path: str,
        action: str,
        pre_image_hash: str | None,
        intended_post_image_hash: str | None,
        checkpoint_manifest_id: str,
    ) -> dict[str, Any]:
        """Create a PREPARED mutation record.

        Idempotency rules:
        - If an existing record has the same immutable identity and is in
          PREPARED or MUTATING, return it unchanged.
        - If an existing record has the same operation_id but a different
          immutable identity, raise IdentityConflict.
        - If an existing record is in any other phase (COMPLETED, COMMITTED,
          ROLLED_BACK, ROLLING_BACK, or INCOMPLETE), raise DuplicateMutation.
        """
        idempotency_key = _idempotency_key(
            task_id, operation_id, proposal_version_hash, approval_id,
            relative_path, action, pre_image_hash, intended_post_image_hash,
            checkpoint_manifest_id,
        )
        record_id = f"MUT-{hashlib.sha256((task_id + operation_id + _utcnow()).encode('utf-8')).hexdigest()[:16]}"

        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                existing = self._conn.execute(
                    "SELECT record_id, task_id, operation_id, proposal_version_hash, approval_id, "
                    "relative_path, action, pre_image_hash, intended_post_image_hash, "
                    "checkpoint_manifest_id, phase, idempotency_key, sequence_number, incomplete_reason "
                    "FROM mutation_records WHERE task_id = ? AND operation_id = ?",
                    (task_id, operation_id),
                ).fetchone()

                if existing is not None:
                    existing_key = _idempotency_key(
                        existing[1], existing[2], existing[3], existing[4],
                        existing[5], existing[6], existing[7], existing[8], existing[9],
                    )
                    if existing_key != idempotency_key:
                        raise IdentityConflict(
                            f"operation_id {operation_id!r} already exists with different identity"
                        )
                    if existing[10] in (MutationPhase.PREPARED, MutationPhase.MUTATING):
                        self._conn.execute("COMMIT")
                        return self._get_record(existing[0])
                    raise DuplicateMutation(
                        f"operation_id {operation_id!r} is already {existing[10]}"
                    )

                seq = self._next_sequence_locked(task_id)
                self._conn.execute(
                    "INSERT INTO mutation_records ("
                    "record_id, task_id, operation_id, proposal_version_hash, approval_id, "
                    "relative_path, action, pre_image_hash, intended_post_image_hash, "
                    "actual_post_image_hash, checkpoint_manifest_id, phase, attempt_timestamp, "
                    "completion_timestamp, rollback_status, evidence_status, idempotency_key, "
                    "sequence_number, incomplete_reason) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (
                        record_id, task_id, operation_id, proposal_version_hash, approval_id,
                        relative_path, action, pre_image_hash, intended_post_image_hash,
                        None, checkpoint_manifest_id, MutationPhase.PREPARED, _utcnow(),
                        None, "not_needed", "pending", idempotency_key, seq, None,
                    ),
                )
                self._conn.execute("COMMIT")
                return self._get_record(record_id)
            except Exception:
                self._conn.execute("ROLLBACK")
                raise

    def mark_mutating(self, record_id: str) -> dict[str, Any]:
        """Transition a PREPARED record to MUTATING."""
        return self._transition(record_id, MutationPhase.PREPARED, MutationPhase.MUTATING)

    def complete(self, record_id: str, actual_post_image_hash: str) -> dict[str, Any]:
        """Transition a MUTATING record to COMPLETED with the observed post-image hash."""
        return self._transition(
            record_id,
            MutationPhase.MUTATING,
            MutationPhase.COMPLETED,
            extra_fields={"actual_post_image_hash": actual_post_image_hash, "completion_timestamp": _utcnow()},
        )

    def mark_committed(self, task_id: str) -> list[dict[str, Any]]:
        """Atomically transition all COMPLETED records for a task to COMMITTED.

        S02-only: this does NOT update DevTaskStore or task state.
        """
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                rows = self._conn.execute(
                    "SELECT record_id, phase FROM mutation_records WHERE task_id = ?",
                    (task_id,),
                ).fetchall()
                if not rows:
                    self._conn.execute("COMMIT")
                    return []

                phases = {row[1] for row in rows}
                invalid = phases - {MutationPhase.COMPLETED, MutationPhase.COMMITTED, MutationPhase.ROLLED_BACK}
                if invalid:
                    raise InvalidPhaseTransition(
                        f"cannot mark_committed: task {task_id} has non-COMPLETED records in phases {sorted(invalid)}"
                    )

                self._conn.execute(
                    "UPDATE mutation_records SET phase = ? WHERE task_id = ? AND phase = ?",
                    (MutationPhase.COMMITTED, task_id, MutationPhase.COMPLETED),
                )
                self._conn.execute("COMMIT")
                return self.records_for_task(task_id)
            except Exception:
                self._conn.execute("ROLLBACK")
                raise

    def begin_rollback(self, task_id: str) -> list[dict[str, Any]]:
        """Atomically transition rollback-eligible records for a task to ROLLING_BACK.

        Only PREPARED, MUTATING, and COMPLETED records may enter ROLLING_BACK.
        INCOMPLETE, COMMITTED, and ROLLED_BACK records are left unchanged.
        """
        eligible = (MutationPhase.PREPARED, MutationPhase.MUTATING, MutationPhase.COMPLETED)
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                rows = self._conn.execute(
                    "SELECT record_id, phase FROM mutation_records WHERE task_id = ?",
                    (task_id,),
                ).fetchall()
                if not rows:
                    self._conn.execute("COMMIT")
                    return []

                # Validate explicitly; do not use an open-ended exclusion update.
                for record_id, phase in rows:
                    if phase not in eligible and phase != MutationPhase.ROLLING_BACK:
                        if phase in (MutationPhase.COMMITTED, MutationPhase.ROLLED_BACK, MutationPhase.INCOMPLETE):
                            continue
                        raise InvalidPhaseTransition(
                            f"cannot begin_rollback: record {record_id} is in phase {phase}"
                        )

                self._conn.execute(
                    "UPDATE mutation_records SET phase = ? WHERE task_id = ? AND phase IN (?, ?, ?)",
                    (MutationPhase.ROLLING_BACK, task_id, *eligible),
                )
                self._conn.execute("COMMIT")
                return self.records_for_task(task_id)
            except Exception:
                self._conn.execute("ROLLBACK")
                raise

    def mark_rolled_back(self, record_id: str) -> dict[str, Any]:
        """Transition a ROLLING_BACK record to ROLLED_BACK."""
        return self._transition(
            record_id,
            MutationPhase.ROLLING_BACK,
            MutationPhase.ROLLED_BACK,
            extra_fields={"completion_timestamp": _utcnow()},
        )

    def mark_incomplete(self, record_id: str, reason: str = "") -> dict[str, Any]:
        """Transition a non-terminal record to INCOMPLETE and persist the reason.

        Legal predecessors: PREPARED, MUTATING, COMPLETED, ROLLING_BACK.
        The reason is stored in ``incomplete_reason`` in the same transaction as
        the phase transition.
        """
        record = self._get_record(record_id)
        if record["phase"] in MutationPhase._TERMINAL:
            raise InvalidPhaseTransition(
                f"cannot mark_incomplete: record {record_id} is already {record['phase']}"
            )
        return self._transition(
            record_id,
            record["phase"],
            MutationPhase.INCOMPLETE,
            extra_fields={
                "completion_timestamp": _utcnow(),
                "incomplete_reason": reason,
            },
        )

    def records_for_task(self, task_id: str) -> list[dict[str, Any]]:
        """Return all mutation records for a task, ordered by sequence_number."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT record_id, task_id, operation_id, proposal_version_hash, approval_id, "
                "relative_path, action, pre_image_hash, intended_post_image_hash, "
                "actual_post_image_hash, checkpoint_manifest_id, phase, attempt_timestamp, "
                "completion_timestamp, rollback_status, evidence_status, idempotency_key, "
                "sequence_number, incomplete_reason FROM mutation_records WHERE task_id = ? ORDER BY sequence_number",
                (task_id,),
            ).fetchall()
        return [self._row_to_dict(row) for row in rows]

    def next_sequence(self, task_id: str) -> int:
        """Return the next sequence number for a task.

        This is advisory unless used inside the same transaction as prepare().
        The prepare() method allocates sequence numbers transactionally.
        """
        with self._lock:
            return self._next_sequence_locked(task_id)

    def reconcile_view(self, task_id: str) -> dict[str, Any]:
        """Read-only summary of the mutation journal state for a task.

        No filesystem inspection. No state mutation.
        """
        records = self.records_for_task(task_id)
        phases = {}
        for r in records:
            phases[r["phase"]] = phases.get(r["phase"], 0) + 1

        missing_hashes = [
            r["record_id"]
            for r in records
            if r["phase"] in (MutationPhase.COMPLETED, MutationPhase.COMMITTED)
            and r["actual_post_image_hash"] is None
        ]
        incomplete = [r["record_id"] for r in records if r["phase"] == MutationPhase.INCOMPLETE]

        operation_ids = [r["operation_id"] for r in records]
        duplicates = [op for op in set(operation_ids) if operation_ids.count(op) > 1]

        return {
            "task_id": task_id,
            "record_count": len(records),
            "phases": phases,
            "records": records,
            "missing_actual_hashes": missing_hashes,
            "incomplete_record_ids": incomplete,
            "duplicate_operation_ids": duplicates,
        }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    def _next_sequence_locked(self, task_id: str) -> int:
        row = self._conn.execute(
            "SELECT COALESCE(MAX(sequence_number), 0) FROM mutation_records WHERE task_id = ?",
            (task_id,),
        ).fetchone()
        return int(row[0]) + 1

    def _get_record(self, record_id: str) -> dict[str, Any]:
        row = self._conn.execute(
            "SELECT record_id, task_id, operation_id, proposal_version_hash, approval_id, "
            "relative_path, action, pre_image_hash, intended_post_image_hash, "
            "actual_post_image_hash, checkpoint_manifest_id, phase, attempt_timestamp, "
            "completion_timestamp, rollback_status, evidence_status, idempotency_key, "
            "sequence_number, incomplete_reason FROM mutation_records WHERE record_id = ?",
            (record_id,),
        ).fetchone()
        if row is None:
            raise MissingRecord(f"mutation record not found: {record_id}")
        return self._row_to_dict(row)

    def _transition(
        self,
        record_id: str,
        expected_phase: str,
        new_phase: str,
        extra_fields: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        if expected_phase not in VALID_TRANSITIONS.get(new_phase, frozenset()):
            raise InvalidPhaseTransition(
                f"invalid transition from {expected_phase} to {new_phase}"
            )
        extra = dict(extra_fields or {})

        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                row = self._conn.execute(
                    "SELECT phase FROM mutation_records WHERE record_id = ?",
                    (record_id,),
                ).fetchone()
                if row is None:
                    raise MissingRecord(f"mutation record not found: {record_id}")
                if row[0] != expected_phase:
                    raise InvalidPhaseTransition(
                        f"record {record_id} is {row[0]}, expected {expected_phase}"
                    )

                assignments = ["phase = ?"]
                values: list[Any] = [new_phase]
                for field, value in extra.items():
                    assignments.append(f"{field} = ?")
                    values.append(value)
                values.append(record_id)

                self._conn.execute(
                    f"UPDATE mutation_records SET {', '.join(assignments)} WHERE record_id = ?",
                    values,
                )
                self._conn.execute("COMMIT")
                return self._get_record(record_id)
            except Exception:
                self._conn.execute("ROLLBACK")
                raise

    @staticmethod
    def _row_to_dict(row: tuple) -> dict[str, Any]:
        return {
            "record_id": row[0],
            "task_id": row[1],
            "operation_id": row[2],
            "proposal_version_hash": row[3],
            "approval_id": row[4],
            "relative_path": row[5],
            "action": row[6],
            "pre_image_hash": row[7],
            "intended_post_image_hash": row[8],
            "actual_post_image_hash": row[9],
            "checkpoint_manifest_id": row[10],
            "phase": row[11],
            "attempt_timestamp": row[12],
            "completion_timestamp": row[13],
            "rollback_status": row[14],
            "evidence_status": row[15],
            "idempotency_key": row[16],
            "sequence_number": row[17],
            "incomplete_reason": row[18],
        }
