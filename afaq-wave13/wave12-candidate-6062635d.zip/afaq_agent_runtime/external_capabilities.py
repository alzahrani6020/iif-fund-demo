"""Native AFAQ Agent bridge to governed live capability engines.

This module owns the capability mapping and evidence semantics, but it does not
import a concrete engine fabric. Concrete execution is supplied through the
capability port by the outer composition layer.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from .capability_port import get_capability_invoker, get_capability_runtime_invoker


_ACTION_TO_ENGINE = {
    "files": ("ENG-CAP-158", "files"),
    "read": ("ENG-CAP-158", "read"),
    "search": ("ENG-CAP-158", "search"),
    "edit": ("ENG-CAP-158", "edit"),
    "run": ("ENG-CAP-158", "run"),
    "status": ("ENG-CAP-158", "status"),
    "diff": ("ENG-CAP-158", "diff"),
    "map": ("ENG-CAP-158", "map"),
    "web_fetch": ("ENG-CAP-091", "fetch"),
    "web_crawl": ("ENG-CAP-091", "crawl"),
    "web_explore": ("ENG-CAP-091", "explore"),
    "remote_verify": ("ENG-CAP-091", "verify_remote"),
    "browser_execute": ("ENG-CAP-001", "execute"),
    "mission_model": ("ENG-CAP-136", "execute"),
    "capability_compose": ("ENG-CAP-137", "execute"),
    "mission_graph": ("ENG-CAP-138", "execute"),
    "result_fuse": ("ENG-CAP-139", "execute"),
    "context_adapt": ("ENG-CAP-140", "execute"),
    "capability_discover": ("ENG-CAP-142", "discover"),
    "capability_session_status": ("ENG-CAP-142", "status"),
    "gap_resolve": ("ENG-CAP-143", "execute"),
    "evidence_verify": ("ENG-CAP-147", "execute"),
    "research_synthesize": ("ENG-CAP-148", "execute"),
    "causal_falsify": ("ENG-CAP-149", "execute"),
    "scenario_forecast": ("ENG-CAP-150", "execute"),
    "continuous_observe": ("ENG-CAP-153", "observe"),
    "continuous_compare": ("ENG-CAP-153", "compare_snapshots"),
    "frontier_discover": ("ENG-CAP-154", "execute"),
    "benchmark_observe": ("ENG-CAP-155", "execute"),
    "research_portfolio": ("ENG-CAP-156", "execute"),
    "goal_form": ("ENG-CAP-157", "execute"),
    "engine_invoke": ("DYNAMIC", "invoke"),
    "capability_invoke": ("CAPABILITY_FABRIC", "invoke"),
    "model_profile": ("ENG-CAP-093", "profile_declared"),
    "benchmark_engines": ("ENG-CAP-093", "benchmark_engines"),
    "benchmark_suite": ("ENG-CAP-093", "run_suite"),
    "performance_history": ("ENG-CAP-141", "history"),
    "performance_latest_metrics": ("ENG-CAP-141", "latest_metrics"),
    "performance_selection_feedback": ("ENG-CAP-141", "selection_feedback"),
    "performance_recommend": ("ENG-CAP-152", "recommend"),
    "performance_budget_check": ("ENG-CAP-152", "budget_check"),
    "performance_regression": ("ENG-CAP-152", "regression"),
    "performance_bottleneck": ("ENG-CAP-152", "bottleneck"),
    "performance_optimize": ("ENG-CAP-152", "optimize"),
}


@dataclass(frozen=True)
class AgentCapabilityResult:
    action: str
    engine_id: str
    ok: bool
    executed: bool
    runtime_implementation: bool
    operationally_proven: bool
    mission_verified: bool
    claim_level: str
    evidence: dict[str, Any]
    evidence_refs: tuple[str, ...]
    message: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "action": self.action,
            "engine_id": self.engine_id,
            "ok": self.ok,
            "executed": self.executed,
            "runtime_implementation": self.runtime_implementation,
            "operationally_proven": self.operationally_proven,
            "mission_verified": self.mission_verified,
            "claim_level": self.claim_level,
            "evidence": dict(self.evidence),
            "evidence_refs": list(self.evidence_refs),
            "message": self.message,
        }


def supported_actions() -> tuple[str, ...]:
    return tuple(sorted(_ACTION_TO_ENGINE))


def capability_binding(action: str) -> tuple[str, str]:
    """Return the canonical (engine_id, engine_action) binding for an action."""
    normalized = str(action or "").strip().lower()
    try:
        return _ACTION_TO_ENGINE[normalized]
    except KeyError as exc:
        raise ValueError(f"unsupported agent capability action: {normalized}") from exc


def _runtime_evidence(evidence: Mapping[str, Any]) -> dict[str, Any]:
    adapter = evidence.get("runtime_adapter")
    if isinstance(adapter, Mapping):
        nested = adapter.get("evidence")
        if isinstance(nested, Mapping):
            return dict(nested)
    return dict(evidence)


def _collect_evidence_refs(value: Any) -> tuple[str, ...]:
    refs: list[str] = []

    def walk(node: Any) -> None:
        if isinstance(node, Mapping):
            for key, child in node.items():
                if key in {"evidence_ref", "artifact_ref"} and isinstance(child, str) and child:
                    refs.append(child)
                elif key == "evidence_refs" and isinstance(child, (list, tuple)):
                    refs.extend(str(item) for item in child if item)
                else:
                    walk(child)
        elif isinstance(node, (list, tuple)):
            for item in node:
                walk(item)

    walk(value)
    return tuple(sorted(dict.fromkeys(refs)))


def _mission_verified(action: str, runtime: Mapping[str, Any]) -> bool:
    if action == "remote_verify":
        verification = runtime.get("verification")
        return bool(isinstance(verification, Mapping) and verification.get("verified"))
    if action == "mission_graph":
        verification = runtime.get("mission_verification")
        return bool(
            isinstance(verification, Mapping)
            and str(verification.get("status") or "").upper() == "VERIFIED"
        )
    return bool(runtime.get("mission_verified") is True)


def execute_agent_capability(
    action: str,
    payload: Mapping[str, Any] | None = None,
) -> AgentCapabilityResult:
    action = str(action or "").strip().lower()
    if action not in _ACTION_TO_ENGINE:
        raise ValueError(f"unsupported agent capability action: {action}")

    engine_id, engine_action = _ACTION_TO_ENGINE[action]
    request = dict(payload or {})

    if action == "capability_invoke":
        capability = str(request.pop("capability", "") or "").strip()
        capability_payload = request.pop("payload", None)
        if not capability:
            raise ValueError("capability_invoke requires capability")
        if capability_payload is None:
            capability_payload = {}
        if not isinstance(capability_payload, Mapping):
            raise ValueError("capability_invoke payload must be an object")
        run = get_capability_runtime_invoker()
        raw_run = dict(run(
            capability,
            payload=dict(capability_payload),
            engine_id=str(request.pop("engine_id", "AFAQ-AI") or "AFAQ-AI"),
            via_cycle=bool(request.pop("via_cycle", False)),
        ))
        executed = bool(raw_run.get("executed"))
        run_path = str(raw_run.get("run_path") or "")
        return AgentCapabilityResult(
            action=action,
            engine_id="CAPABILITY_FABRIC",
            ok=bool(raw_run.get("ok")),
            executed=executed,
            runtime_implementation=True,
            operationally_proven=False,
            mission_verified=False,
            claim_level=(
                "EXECUTED_STRUCTURAL_ONLY"
                if executed
                else "BLOCKED_OR_FAILED"
            ),
            evidence=raw_run,
            evidence_refs=(run_path,) if run_path else (),
            message=(
                f"capability fabric executed {capability}"
                if executed
                else f"capability fabric failed {capability}"
            ),
        )

    if action == "engine_invoke":
        requested_engine = str(request.pop("engine_id", "") or "").strip()
        engine_payload = request.pop("payload", None)
        if not requested_engine or not requested_engine.startswith("ENG-"):
            raise ValueError("engine_invoke requires a valid engine_id")
        if not isinstance(engine_payload, Mapping):
            raise ValueError("engine_invoke requires payload object")
        engine_id = requested_engine
        request = dict(engine_payload)
    if engine_id == "ENG-CAP-158":
        root = request.pop("_project_root", None)
        if root is not None:
            request["root"] = str(root)
    if action not in {"browser_execute", "engine_invoke"}:
        request["action"] = engine_action

    invoke = get_capability_invoker()
    result = invoke(engine_id, request)
    raw = result.as_dict()
    evidence = dict(raw.get("evidence") or {})
    runtime = _runtime_evidence(evidence)
    executed = bool(
        (evidence.get("runtime_adapter") or {}).get("executed")
        if isinstance(evidence.get("runtime_adapter"), Mapping)
        else evidence.get("executed")
    )
    verified = _mission_verified(action, runtime)
    refs = _collect_evidence_refs(runtime)

    if verified:
        claim_level = "MISSION_VERIFIED"
    elif executed and refs:
        claim_level = "EXECUTED_WITH_EVIDENCE"
    elif executed:
        claim_level = "EXECUTED_UNVERIFIED"
    elif result.ok:
        claim_level = "READY_OR_CALLABLE"
    else:
        claim_level = "BLOCKED_OR_FAILED"

    return AgentCapabilityResult(
        action=action,
        engine_id=engine_id,
        ok=bool(result.ok),
        executed=executed,
        runtime_implementation=bool(result.runtime_implementation),
        operationally_proven=bool(result.operationally_proven),
        mission_verified=verified,
        claim_level=claim_level,
        evidence=runtime,
        evidence_refs=refs,
        message=result.message,
    )
