"""Dependency-inversion port for governed capability execution.

The Agent Runtime owns the contract only. Concrete engine fabrics register an
invoker from an outer composition layer; this module never imports engines_live.
"""

from __future__ import annotations

from typing import Any, Mapping, Protocol


class CapabilityInvoker(Protocol):
    def __call__(
        self,
        engine_id: str,
        payload: Mapping[str, Any],
    ) -> Any: ...


class CapabilityRuntimeInvoker(Protocol):
    def __call__(
        self,
        capability: str,
        *,
        payload: Mapping[str, Any] | None = None,
        engine_id: str = "AFAQ-AI",
        via_cycle: bool = False,
    ) -> Mapping[str, Any]: ...


_invoker: CapabilityInvoker | None = None
_capability_runtime_invoker: CapabilityRuntimeInvoker | None = None


def register_capability_invoker(invoker: CapabilityInvoker) -> None:
    """Bind the concrete capability fabric.

    Registration is explicit and fail-closed: the runtime never discovers or
    imports a concrete engine package on its own.
    """
    if not callable(invoker):
        raise TypeError("capability invoker must be callable")
    global _invoker
    _invoker = invoker


def get_capability_invoker() -> CapabilityInvoker:
    """Return the registered engine invoker or fail closed when composition is absent."""
    if _invoker is None:
        raise RuntimeError("CAPABILITY_INVOKER_NOT_BOUND")
    return _invoker


def register_capability_runtime_invoker(invoker: CapabilityRuntimeInvoker) -> None:
    """Bind the registry-backed capability runtime without importing engines_live."""
    if not callable(invoker):
        raise TypeError("capability runtime invoker must be callable")
    global _capability_runtime_invoker
    _capability_runtime_invoker = invoker


def get_capability_runtime_invoker() -> CapabilityRuntimeInvoker:
    if _capability_runtime_invoker is None:
        raise RuntimeError("CAPABILITY_RUNTIME_INVOKER_NOT_BOUND")
    return _capability_runtime_invoker
