"""Durable non-blocking mission supervision for AFAQ DeveloperAgent."""
from __future__ import annotations
import json, posixpath, sqlite3, threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping
from uuid import uuid4

ACTIVE_DEV={"received","mapping","proposing","approved","executing","analyzing"}
MAX_MISSION_NODES=500
MAX_MISSION_TITLE=300
MAX_MISSION_INSTRUCTION=4000

def _now(): return datetime.now(timezone.utc).isoformat()
def _dump(v): return json.dumps(v,ensure_ascii=False,sort_keys=True)

class MissionError(RuntimeError): pass

class MissionSupervisor:
    def __init__(self,path:str|Path,developer_agent,poll_seconds:float=1.0):
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
        self.dev=developer_agent; self.poll_seconds=max(.2,float(poll_seconds))
        self._conn=sqlite3.connect(str(self.path),check_same_thread=False,isolation_level=None)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA busy_timeout=5000")
        self._conn.executescript("""
        CREATE TABLE IF NOT EXISTS missions(
          mission_id TEXT PRIMARY KEY,title TEXT NOT NULL,actor TEXT NOT NULL,
          state TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS mission_nodes(
          mission_id TEXT NOT NULL,node_id TEXT NOT NULL,instruction TEXT NOT NULL,
          depends_on TEXT NOT NULL,resources TEXT NOT NULL,task_id TEXT,state TEXT NOT NULL,
          last_error TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,
          PRIMARY KEY(mission_id,node_id));
        CREATE INDEX IF NOT EXISTS mission_nodes_state_idx ON mission_nodes(mission_id,state,updated_at);
        CREATE TABLE IF NOT EXISTS mission_events(
          seq INTEGER PRIMARY KEY AUTOINCREMENT,mission_id TEXT NOT NULL,node_id TEXT,
          event_type TEXT NOT NULL,payload TEXT NOT NULL,created_at TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS mission_events_idx ON mission_events(mission_id,seq);
        """)
        self._lock=threading.RLock(); self._stop=threading.Event(); self._thread=None

    def start(self):
        with self._lock:
            if self._thread and self._thread.is_alive(): return
            self._stop.clear()
            self._thread=threading.Thread(target=self._loop,daemon=True,name="afaq-mission-supervisor")
            self._thread.start()

    def stop(self):
        self._stop.set()
        if self._thread and self._thread.is_alive() and self._thread is not threading.current_thread():
            self._thread.join(timeout=max(2.0,self.poll_seconds*3))

    def close(self): self.stop(); self._conn.close()

    def _loop(self):
        while not self._stop.wait(self.poll_seconds):
            for mission in self.list_missions(200):
                if mission["state"] in {"active","waiting_owner","blocked"}:
                    try: self.tick(mission["mission_id"])
                    except Exception: continue

    def _event(self,mid,event,payload=None,node_id=None):
        self._conn.execute("INSERT INTO mission_events(mission_id,node_id,event_type,payload,created_at) VALUES(?,?,?,?,?)",
                           (mid,node_id,event,_dump(dict(payload or {})),_now()))

    @staticmethod
    def _normalize(nodes:list[Mapping[str,Any]]):
        if not nodes: raise MissionError("MISSION_NODES_REQUIRED")
        if len(nodes)>MAX_MISSION_NODES: raise MissionError("MISSION_TOO_LARGE")
        out=[]; ids=set()
        for raw in nodes:
            if not isinstance(raw, Mapping): raise MissionError("INVALID_NODE")
            deps_raw=raw.get("depends_on") or []
            resources_raw=raw.get("resources") or []
            if not isinstance(deps_raw,(list,tuple)) or not all(isinstance(x,str) for x in deps_raw):
                raise MissionError("INVALID_DEPENDENCIES")
            if not isinstance(resources_raw,(list,tuple)) or not all(isinstance(x,str) for x in resources_raw):
                raise MissionError("INVALID_RESOURCES")
            nid_raw=raw.get("id") or raw.get("node_id") or ""
            ins_raw=raw.get("instruction") or ""
            if not isinstance(nid_raw,str): raise MissionError("INVALID_NODE_ID")
            if not isinstance(ins_raw,str): raise MissionError("INSTRUCTION_REQUIRED")
            nid=nid_raw.strip(); ins=ins_raw.strip()
            if not nid or len(nid)>64: raise MissionError("INVALID_NODE_ID")
            if nid in ids: raise MissionError("DUPLICATE_NODE")
            if not ins: raise MissionError("INSTRUCTION_REQUIRED")
            if len(ins)>MAX_MISSION_INSTRUCTION: raise MissionError("INSTRUCTION_TOO_LONG")
            resources=[]
            for value in resources_raw:
                raw_resource=value.strip().replace("\\","/")
                if not raw_resource: continue
                normalized=posixpath.normpath(raw_resource)
                if normalized==".": continue
                resources.append(normalized)
            ids.add(nid)
            out.append({"id":nid,"instruction":ins,
                        "depends_on":tuple(dict.fromkeys(x.strip() for x in deps_raw if x.strip())),
                        "resources":tuple(sorted(set(resources)))})
        by={x["id"]:x for x in out}
        for x in out:
            if x["id"] in x["depends_on"]: raise MissionError("SELF_DEPENDENCY")
            if any(d not in by for d in x["depends_on"]): raise MissionError("UNKNOWN_DEPENDENCY")
        visiting=set(); visited=set()
        def visit(n):
            if n in visiting: raise MissionError("DEPENDENCY_CYCLE")
            if n in visited: return
            visiting.add(n)
            for d in by[n]["depends_on"]: visit(d)
            visiting.remove(n); visited.add(n)
        for n in by: visit(n)
        return out

    def create_mission(self,title,nodes,actor="unknown"):
        if not isinstance(title,str): raise MissionError("INVALID_MISSION_TITLE")
        title=title.strip()
        if not title: raise MissionError("MISSION_TITLE_REQUIRED")
        if len(title)>MAX_MISSION_TITLE: raise MissionError("MISSION_TITLE_TOO_LONG")
        nodes=self._normalize(nodes); mid="MSN-"+str(uuid4()); now=_now()
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                self._conn.execute("INSERT INTO missions VALUES(?,?,?,?,?,?)",(mid,title,actor[:128],"active",now,now))
                for x in nodes:
                    self._conn.execute("INSERT INTO mission_nodes VALUES(?,?,?,?,?,?,?,?,?,?)",
                                       (mid,x["id"],x["instruction"],_dump(x["depends_on"]),_dump(x["resources"]),None,"queued",None,now,now))
                self._event(mid,"mission_created",{"actor":actor,"node_count":len(nodes)})
                self._conn.execute("COMMIT")
            except Exception:
                self._conn.execute("ROLLBACK"); raise
        return self.tick(mid)

    def list_missions(self,limit=100):
        with self._lock:
            rows=self._conn.execute("SELECT mission_id,title,actor,state,created_at,updated_at FROM missions ORDER BY created_at DESC LIMIT ?",
                                    (max(1,min(int(limit),500)),)).fetchall()
            keys=("mission_id","title","actor","state","created_at","updated_at")
            return [dict(zip(keys,r)) for r in rows]

    def _nodes(self,mid):
        rows=self._conn.execute("SELECT node_id,instruction,depends_on,resources,task_id,state,last_error,created_at,updated_at FROM mission_nodes WHERE mission_id=? ORDER BY created_at,node_id",(mid,)).fetchall()
        keys=("node_id","instruction","depends_on","resources","task_id","state","last_error","created_at","updated_at")
        out=[]
        for r in rows:
            x=dict(zip(keys,r)); x["depends_on"]=json.loads(x["depends_on"]); x["resources"]=json.loads(x["resources"]); out.append(x)
        return out

    def get_mission(self,mid):
        with self._lock:
            row=self._conn.execute("SELECT mission_id,title,actor,state,created_at,updated_at FROM missions WHERE mission_id=?",(mid,)).fetchone()
            if row is None: raise KeyError(mid)
            m=dict(zip(("mission_id","title","actor","state","created_at","updated_at"),row)); m["nodes"]=self._nodes(mid)
            counts={}
            for n in m["nodes"]: counts[n["state"]]=counts.get(n["state"],0)+1
            m["counts"]=counts; return m

    def events(self,mid,limit=500):
        with self._lock:
            exists=self._conn.execute("SELECT 1 FROM missions WHERE mission_id=?",(mid,)).fetchone()
            if exists is None: raise KeyError(mid)
            rows=self._conn.execute("SELECT seq,node_id,event_type,payload,created_at FROM mission_events WHERE mission_id=? ORDER BY seq DESC LIMIT ?",
                                    (mid,max(1,min(int(limit),2000)))).fetchall()
            return [{"seq":r[0],"node_id":r[1],"event_type":r[2],"payload":json.loads(r[3]),"created_at":r[4]} for r in reversed(rows)]

    def _set(self,mid,nid,state,task_id=None,error=None):
        if task_id is None:
            self._conn.execute("UPDATE mission_nodes SET state=?,last_error=?,updated_at=? WHERE mission_id=? AND node_id=?",
                               (state,error,_now(),mid,nid))
        else:
            self._conn.execute("UPDATE mission_nodes SET state=?,last_error=?,task_id=?,updated_at=? WHERE mission_id=? AND node_id=?",
                               (state,error,task_id,_now(),mid,nid))

    def _sync(self,mid,node):
        if not node["task_id"]: return node["state"]
        task=self.dev.get_task(node["task_id"]); err=None
        if task is None: mapped="failed"; err="TASK_RECORD_MISSING"
        else:
            state=str(task.get("state") or "")
            if state=="awaiting_approval": mapped="waiting_owner"
            elif state in ACTIVE_DEV: mapped="running"
            elif state in {"completed","answered","no_action"}: mapped="completed"
            elif state in {"failed","clarification_required"}: mapped="failed"
            elif state=="rejected": mapped="rejected"
            elif state=="interrupted":
                try:
                    resumed=self.dev.resume(node["task_id"],actor="mission-supervisor-recovery",wait=False) or {}
                    resumed_state=str(resumed.get("state") or "")
                    if resumed_state=="awaiting_approval": mapped="waiting_owner"
                    elif resumed_state in ACTIVE_DEV or resumed_state=="interrupted": mapped="running"
                    elif resumed_state in {"completed","answered","no_action"}: mapped="completed"
                    elif resumed_state in {"failed","clarification_required"}: mapped="failed"
                    elif resumed_state=="rejected": mapped="rejected"
                    else: mapped="failed"; err="UNKNOWN_RESUME_STATE"
                except Exception as exc: mapped="failed"; err="RECOVERY_FAILED:"+type(exc).__name__
            else:
                mapped="failed"; err="UNKNOWN_TASK_STATE"
        if mapped!=node["state"]:
            self._set(mid,node["node_id"],mapped,error=err)
            self._event(mid,"node_state_changed",{"from":node["state"],"to":mapped,"task_id":node["task_id"]},node["node_id"])
        return mapped

    def tick(self,mid):
        with self._lock:
            m=self.get_mission(mid)
            for n in m["nodes"]: self._sync(mid,n)
            nodes=self._nodes(mid); states={n["node_id"]:n["state"] for n in nodes}; held=set()
            for n in nodes:
                if n["state"] in {"running","waiting_owner"}: held.update(n["resources"])
            for n in nodes:
                if n["state"] not in {"queued","blocked_dependency","blocked_resource"}: continue
                deps=[states.get(d,"queued") for d in n["depends_on"]]
                if any(s in {"failed","rejected","cancelled"} for s in deps):
                    self._set(mid,n["node_id"],"blocked_dependency",error="DEPENDENCY_NOT_SUCCESSFUL"); states[n["node_id"]]="blocked_dependency"; continue
                if not all(s=="completed" for s in deps):
                    self._set(mid,n["node_id"],"blocked_dependency"); states[n["node_id"]]="blocked_dependency"; continue
                resources=set(n["resources"])
                if resources & held:
                    self._set(mid,n["node_id"],"blocked_resource"); states[n["node_id"]]="blocked_resource"; continue
                try: tid=self.dev.submit(n["instruction"],actor="mission:"+mid,wait=False)
                except Exception as exc:
                    error_type=type(exc).__name__
                    self._set(mid,n["node_id"],"failed",error="DISPATCH_FAILED:"+error_type)
                    self._event(mid,"node_dispatch_failed",{"error_type":error_type},n["node_id"]); states[n["node_id"]]="failed"; continue
                self._set(mid,n["node_id"],"running",task_id=tid); self._event(mid,"node_dispatched",{"task_id":tid,"resources":sorted(resources)},n["node_id"])
                mapped=self._sync(mid,{**n,"task_id":tid,"state":"running"})
                if mapped in {"running","waiting_owner"}: held.update(resources)
                states[n["node_id"]]=mapped
            vals=[n["state"] for n in self._nodes(mid)]
            if vals and all(s=="completed" for s in vals): ms="completed"
            elif any(s=="waiting_owner" for s in vals): ms="waiting_owner"
            elif any(s in {"running","queued"} for s in vals): ms="active"
            elif any(s in {"failed","rejected"} for s in vals): ms="failed"
            elif any(s.startswith("blocked") for s in vals): ms="blocked"
            else: ms="active"
            self._conn.execute("UPDATE missions SET state=?,updated_at=? WHERE mission_id=?",(ms,_now(),mid))
            return self.get_mission(mid)

    def decision_package(self,mid):
        # Read-only presentation: GET callers must never advance or dispatch work.
        with self._lock:
            m=self.get_mission(mid); items=[]
            for n in m["nodes"]:
                if not n["task_id"]: continue
                for a in self.dev.approvals.pending_for_task(n["task_id"]):
                    items.append({"node_id":n["node_id"],"task_id":n["task_id"],"approval_id":a["approval_id"],
                                  "risk_level":a.get("risk_level"),"affected_files":a.get("affected_files") or [],
                                  "proposed_tests":a.get("proposed_tests") or [],"proposal_hash":a.get("proposal_hash"),
                                  "expires_at":a.get("expires_at"),"depends_on":n["depends_on"],"resources":n["resources"]})
            return {"mission_id":mid,"mission_state":m["state"],"pending_count":len(items),"items":items,
                    "partial_approval_supported":True,"semantics":"independent approvals preserve original proposal hashes; batch decisions are prevalidated but not transactional"}

    def decide(self,mid,actor,decisions=None,approve_all=False,reject_all=False,reason=""):
        with self._lock:
            pack=self.decision_package(mid); pending={x["approval_id"]:x for x in pack["items"]}; req=dict(decisions or {})
            if approve_all and reject_all: raise MissionError("CONFLICTING_BULK_DECISION")
            if req and (approve_all or reject_all): raise MissionError("MIXED_BULK_AND_ITEM_DECISIONS")
            if approve_all: req.update({x:"approve" for x in pending})
            if reject_all: req.update({x:"reject" for x in pending})
            if not req: raise MissionError("DECISION_REQUIRED")
            # Validate the entire requested batch before applying any decision so
            # malformed/stale input cannot partially mutate an otherwise valid set.
            for aid,decision in req.items():
                if aid not in pending: raise MissionError("APPROVAL_NOT_PENDING")
                if decision not in {"approve","reject"}: raise MissionError("INVALID_DECISION")
            results=[]
            for aid,decision in req.items():
                task=self.dev.decide_approval(aid,decision=decision,actor=actor,reason=reason or ("mission "+mid+" owner decision"),wait=False)
                results.append({"approval_id":aid,"decision":decision,"task_state":(task or {}).get("state")})
                self._event(mid,"owner_decision",{"approval_id":aid,"decision":decision,"actor":actor})
            return {"mission":self.tick(mid),"decisions":results}

    def recover(self):
        recovered=[]
        for m in self.list_missions(500):
            if m["state"] in {"active","waiting_owner","blocked"}:
                try: self.tick(m["mission_id"]); recovered.append(m["mission_id"])
                except Exception: continue
        return {"recovered":recovered}
