"""Checkpoint engine — S04 checkpoint / rollback / restore authority.

This module implements the S04 checkpoint contract on top of the S01 schema:

- deterministic checkpoint identity
- baseline pinning (git HEAD + per-target pre-image hashes)
- capture of edit targets, create targets, and rename source/destination
- restore to pre-mutation filesystem state
- post-restore verification by readback/hash comparison
- explicit partial/incomplete rollback reporting

It does NOT implement staged/atomic multi-file writes, commit orchestration,
task state machines, generic reconciliation, or mutation-journal wiring; those
belong to later slices.
"""

from __future__ import annotations

import hashlib
import json
import shutil
import sqlite3
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from threading import RLock
from typing import Any, Mapping

_SCHEMA_VERSION = 1

_SCHEMA = """
CREATE TABLE IF NOT EXISTS schema_version (
    component TEXT PRIMARY KEY,
    version INTEGER NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS checkpoint_manifests (
    manifest_id TEXT PRIMARY KEY,
    task_id TEXT NOT NULL,
    approval_id TEXT NOT NULL,
    created_at TEXT NOT NULL,
    entries_json TEXT NOT NULL,
    manifest_hash TEXT NOT NULL,
    phase TEXT NOT NULL DEFAULT 'prepared'
);
CREATE INDEX IF NOT EXISTS checkpoint_manifests_task_idx ON checkpoint_manifests (task_id);
"""


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _sha256_file(path: Path) -> str:
    return _sha256_bytes(path.read_bytes())


def _sha256_text(text: str) -> str:
    return _sha256_bytes(text.encode("utf-8"))


def _hash_dict(value: Mapping[str, Any]) -> str:
    canonical = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return _sha256_bytes(canonical.encode("utf-8"))


def _ensure_schema_version(conn: sqlite3.Connection, component: str, version: int) -> None:
    conn.execute(
        "INSERT INTO schema_version (component, version, updated_at) VALUES (?, ?, ?)"
        " ON CONFLICT(component) DO UPDATE SET version=excluded.version, updated_at=excluded.updated_at",
        (component, version, _utcnow()),
    )


class CheckpointEngineError(RuntimeError):
    """Base class for checkpoint-engine errors."""


class CheckpointBoundaryError(CheckpointEngineError):
    """Target path escapes the authorized project root."""


class CheckpointManifestError(CheckpointEngineError):
    """Manifest missing or corrupted."""


class CheckpointEngine:
    """Durable checkpoint capture and verified restore."""

    def __init__(
        self,
        path: str | Path,
        *,
        project_root: str | Path | None = None,
    ) -> None:
        self.db_path = Path(path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.snapshots_dir = self.db_path.parent / "checkpoints"
        self.snapshots_dir.mkdir(parents=True, exist_ok=True)
        self.project_root = Path(project_root).resolve() if project_root else None

        self._conn = sqlite3.connect(
            str(self.db_path), check_same_thread=False, isolation_level=None
        )
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.executescript(_SCHEMA)
        _ensure_schema_version(self._conn, "checkpoint_engine", _SCHEMA_VERSION)
        self._lock = RLock()

    def close(self) -> None:
        self._conn.close()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def capture(
        self,
        *,
        task_id: str,
        approval_id: str,
        proposal: Mapping[str, Any],
    ) -> dict[str, Any]:
        """Capture a durable checkpoint of the mutation target set.

        Returns a manifest dict including ``manifest_id``, ``snapshot_dir``,
        ``baseline_head``, and the captured ``entries``.
        """
        if self.project_root is None:
            raise CheckpointEngineError("project_root is required for capture")

        entries = []
        for spec in proposal.get("files", []):
            entries.append(self._capture_entry(spec))
        entries.sort(key=lambda e: e["path"])

        baseline_head = self._git_head()
        content: dict[str, Any] = {
            "task_id": task_id,
            "approval_id": approval_id,
            "baseline_head": baseline_head,
            "entries": entries,
        }
        manifest_hash = _hash_dict(content)
        manifest_id = f"CP-{manifest_hash[:16]}"
        created_at = _utcnow()
        entries_json = json.dumps(content, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
        snapshot_dir = self._snapshot_dir(manifest_id)
        snapshot_dir.mkdir(parents=True, exist_ok=True)

        # Snapshot every captured pre-image that existed on disk.
        for entry in entries:
            if entry.get("pre_image_exists") and entry.get("pre_image_hash"):
                self._snapshot_file(entry["path"], snapshot_dir)
            if entry["action"] == "rename" and entry.get("new_path_exists") and entry.get("new_path_hash"):
                self._snapshot_file(entry["new_path"], snapshot_dir)

        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                existing = self._conn.execute(
                    "SELECT entries_json FROM checkpoint_manifests WHERE manifest_id = ?",
                    (manifest_id,),
                ).fetchone()
                if existing is not None:
                    if existing[0] == entries_json:
                        # Idempotent re-capture of identical state.
                        self._conn.execute("COMMIT")
                        return self._manifest_from_content(content, manifest_id, str(snapshot_dir))
                    raise CheckpointEngineError(
                        f"checkpoint identity collision for {manifest_id}"
                    )

                self._conn.execute(
                    "INSERT INTO checkpoint_manifests "
                    "(manifest_id, task_id, approval_id, created_at, entries_json, manifest_hash, phase) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (manifest_id, task_id, approval_id, created_at, entries_json, manifest_hash, "captured"),
                )
                self._conn.execute("COMMIT")
            except Exception:
                self._conn.execute("ROLLBACK")
                raise

        return self._manifest_from_content(content, manifest_id, str(snapshot_dir))

    def restore(
        self,
        *,
        task_id: str,
        manifest_id: str | None = None,
    ) -> dict[str, Any]:
        """Restore the filesystem state captured in a checkpoint manifest.

        Returns a structured result with ``status`` (``full`` / ``partial``)
        and per-entry verification details. The manifest phase is updated to
        ``restored`` or ``incomplete``.
        """
        manifest = self._load_manifest(task_id, manifest_id)
        snapshot_dir = self._snapshot_dir(manifest["manifest_id"])
        entries = manifest["entries"]

        results: list[dict[str, Any]] = []
        all_ok = True
        for entry in entries:
            ok = True
            reason: str | None = None
            try:
                self._restore_entry(entry, snapshot_dir)
            except Exception as exc:  # noqa: BLE001 - restore must continue
                ok = False
                reason = f"restore error: {type(exc).__name__}: {exc}"
                all_ok = False

            verification = self._verify_entry(entry)
            if not verification["ok"]:
                ok = False
                sep = "; " if reason else ""
                reason = f"{reason or ''}{sep}verification: {verification['reason']}"
                all_ok = False

            results.append(
                {
                    "path": entry["path"],
                    "action": entry["action"],
                    "expected_exists": entry.get("pre_image_exists"),
                    "expected_hash": entry.get("pre_image_hash"),
                    "actual_exists": verification.get("actual_exists"),
                    "actual_hash": verification.get("actual_hash"),
                    "ok": ok,
                    "reason": reason,
                }
            )

        phase = "restored" if all_ok else "incomplete"
        with self._lock:
            self._conn.execute(
                "UPDATE checkpoint_manifests SET phase = ? WHERE manifest_id = ?",
                (phase, manifest["manifest_id"]),
            )

        return {
            "status": "full" if all_ok else "partial",
            "manifest_id": manifest["manifest_id"],
            "baseline_head": manifest.get("baseline_head"),
            "entries": results,
        }

    def latest_manifest(self, task_id: str) -> dict[str, Any]:
        """Return the most recent manifest for a task (read-only)."""
        return self._load_manifest(task_id, manifest_id=None)

    def get_latest_manifest(self, task_id: str) -> dict[str, Any]:
        """Alias for ``latest_manifest`` used by integration tests."""
        return self.latest_manifest(task_id)

    def read_snapshot(self, manifest_id: str, relative_path: str) -> bytes:
        """Read a captured snapshot file as raw bytes."""
        snapshot = self._snapshot_dir(manifest_id) / Path(*relative_path.split("/"))
        return snapshot.read_bytes()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    def _capture_entry(self, spec: Mapping[str, Any]) -> dict[str, Any]:
        action = spec.get("action", "edit")
        if action not in ("edit", "create", "rename"):
            raise CheckpointEngineError(f"unsupported checkpoint action: {action}")

        path = self._normalize_path(spec["path"])
        self._assert_inside_project(path)
        entry: dict[str, Any] = {"path": path, "action": action}

        target = self._project_path(path)
        if target.exists():
            if target.is_dir():
                raise CheckpointEngineError(f"cannot checkpoint directory as file target: {path}")
            entry["pre_image_exists"] = True
            entry["pre_image_hash"] = _sha256_file(target)
        else:
            entry["pre_image_exists"] = False
            entry["pre_image_hash"] = None

        if action == "create":
            content = spec.get("content")
            entry["intended_post_image_hash"] = _sha256_text(content) if content is not None else None

        elif action == "rename":
            new_path = self._normalize_path(spec["new_path"])
            self._assert_inside_project(new_path)
            entry["new_path"] = new_path
            dest = self._project_path(new_path)
            if dest.exists():
                if dest.is_dir():
                    raise CheckpointEngineError(
                        f"cannot checkpoint directory as rename destination: {new_path}"
                    )
                entry["new_path_exists"] = True
                entry["new_path_hash"] = _sha256_file(dest)
            else:
                entry["new_path_exists"] = False
                entry["new_path_hash"] = None

        return entry

    def _restore_entry(self, entry: dict[str, Any], snapshot_dir: Path) -> None:
        action = entry["action"]

        if action in ("edit", "rename"):
            self._restore_file(
                entry["path"],
                entry.get("pre_image_exists"),
                entry.get("pre_image_hash"),
                snapshot_dir,
            )

        if action == "create":
            target = self._project_path(entry["path"])
            if target.exists():
                if target.is_file():
                    target.unlink()
                elif target.is_dir():
                    raise CheckpointEngineError(
                        f"cannot remove directory created as file target: {entry['path']}"
                    )

        if action == "rename":
            self._restore_file(
                entry["new_path"],
                entry.get("new_path_exists"),
                entry.get("new_path_hash"),
                snapshot_dir,
            )

    def _restore_file(
        self,
        path: str,
        existed: bool | None,
        expected_hash: str | None,
        snapshot_dir: Path,
    ) -> None:
        target = self._project_path(path)
        if existed:
            snapshot = snapshot_dir / Path(*path.split("/"))
            if not snapshot.is_file():
                raise CheckpointEngineError(f"snapshot missing for {path}")
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(snapshot, target)
        else:
            if target.exists():
                if target.is_file():
                    target.unlink()
                elif target.is_dir():
                    raise CheckpointEngineError(
                        f"expected file absent but found directory: {path}"
                    )

    def _verify_entry(self, entry: dict[str, Any]) -> dict[str, Any]:
        checks = [(entry["path"], entry.get("pre_image_exists"), entry.get("pre_image_hash"))]
        if entry["action"] == "rename":
            checks.append(
                (entry["new_path"], entry.get("new_path_exists"), entry.get("new_path_hash"))
            )

        for path, expected_exists, expected_hash in checks:
            target = self._project_path(path)
            if expected_exists:
                if not target.is_file():
                    return {
                        "ok": False,
                        "reason": f"{path}: expected file, found {self._path_kind(target)}",
                        "actual_exists": target.exists(),
                        "actual_hash": None,
                    }
                actual_hash = _sha256_file(target)
                if actual_hash != expected_hash:
                    return {
                        "ok": False,
                        "reason": f"{path}: hash mismatch",
                        "actual_exists": True,
                        "actual_hash": actual_hash,
                    }
            else:
                if target.exists():
                    return {
                        "ok": False,
                        "reason": f"{path}: expected absent, exists",
                        "actual_exists": True,
                        "actual_hash": _sha256_file(target) if target.is_file() else None,
                    }

        return {"ok": True, "actual_exists": True, "actual_hash": expected_hash}

    def _load_manifest(self, task_id: str, manifest_id: str | None) -> dict[str, Any]:
        with self._lock:
            if manifest_id is not None:
                row = self._conn.execute(
                    "SELECT manifest_id, entries_json, phase FROM checkpoint_manifests "
                    "WHERE manifest_id = ?",
                    (manifest_id,),
                ).fetchone()
            else:
                row = self._conn.execute(
                    "SELECT manifest_id, entries_json, phase FROM checkpoint_manifests "
                    "WHERE task_id = ? ORDER BY created_at DESC LIMIT 1",
                    (task_id,),
                ).fetchone()
        if row is None:
            raise CheckpointManifestError(f"no checkpoint manifest found for task {task_id}")
        loaded_manifest_id = row[0]
        content = json.loads(row[1])
        content["manifest_id"] = loaded_manifest_id
        content["phase"] = row[2]
        content["snapshot_dir"] = str(self._snapshot_dir(loaded_manifest_id))
        return content

    def _snapshot_file(self, path: str, snapshot_dir: Path) -> None:
        source = self._project_path(path)
        if not source.is_file():
            return
        dest = snapshot_dir / Path(*path.split("/"))
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, dest)

    def _snapshot_dir(self, manifest_id: str) -> Path:
        return self.snapshots_dir / manifest_id

    def _manifest_from_content(
        self,
        content: dict[str, Any],
        manifest_id: str,
        snapshot_dir: str,
    ) -> dict[str, Any]:
        return {
            "manifest_id": manifest_id,
            "snapshot_dir": snapshot_dir,
            "baseline_head": content["baseline_head"],
            "task_id": content["task_id"],
            "approval_id": content["approval_id"],
            "entries": content["entries"],
            "files": sum(1 for e in content["entries"] if e.get("pre_image_exists")),
        }

    def _project_path(self, relative_path: str) -> Path:
        if self.project_root is None:
            raise CheckpointEngineError("project_root is required")
        return self.project_root / Path(*relative_path.split("/"))

    def _normalize_path(self, raw: str) -> str:
        # Preserve absolute/relative form and separators; containment is validated separately.
        return Path(raw.replace("\\", "/")).as_posix()

    def _assert_inside_project(self, relative_path: str) -> None:
        if self.project_root is None:
            raise CheckpointEngineError("project_root is required")
        raw = Path(relative_path.replace("\\", "/"))
        if raw.is_absolute():
            target = raw.expanduser().resolve()
        else:
            target = (self.project_root / raw).resolve()
        try:
            target.relative_to(self.project_root)
        except ValueError as exc:
            raise CheckpointBoundaryError(
                f"checkpoint target outside project root: {relative_path}"
            ) from exc

    def _git_head(self) -> str | None:
        if self.project_root is None or not (self.project_root / ".git").exists():
            return None
        try:
            result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                cwd=str(self.project_root),
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except Exception:  # noqa: BLE001 - git baseline is best-effort
            pass
        return None

    def _path_kind(self, path: Path) -> str:
        if not path.exists():
            return "absent"
        if path.is_dir():
            return "directory"
        if path.is_file():
            return "file"
        return "other"
