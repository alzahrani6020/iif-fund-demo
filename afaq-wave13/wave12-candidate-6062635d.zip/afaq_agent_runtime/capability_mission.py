"""DeveloperAgent adapter onto the verified existing-capability runtime.

Reuses plan/resolve/compose/graph/execute/observe/replan/verify/persist.
Does not reimplement those layers. Genesis, learning, training, promotion,
dynamic attach, and automatic rollback stay disabled.
"""

from __future__ import annotations

import ast
from pathlib import Path
from typing import Any, Mapping

from capability_cycle.drift import evaluate_drift
from capability_cycle.handlers import handler_version, implemented_ids
from capability_cycle.performance_store import (
    PerformanceStore,
    live_performance_store_path,
)
from capability_cycle.planner import Requirement
from capability_cycle.runtime import RuntimeResult, execute_plan

# Single source of truth: the live handler registry. Keeping a hand-maintained
# duplicate here caused capability drift as the registry expanded.
KNOWN_IMPLEMENTED_CAPABILITIES: tuple[str, ...] = tuple(implemented_ids())

REGISTRY_INTEGRITY_CAPABILITIES: tuple[str, ...] = (
    "CAP-AUDIT-001",
    "CAP-EVAL-001",
    "CAP-TRUTH-001",
)
IMPORT_GRAPH_TRUTH_CAPABILITIES: tuple[str, ...] = ("CAP-TRUTH-001",)


def capability_cycle_import_edges() -> tuple[tuple[str, str], ...]:
    """Live intra-package import graph of capability_cycle (tests excluded)."""
    root = Path(__file__).resolve().parents[1] / "capability_cycle"
    edges: list[tuple[str, str]] = []
    for path in sorted(root.glob("*.py")):
        source = path.stem
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if not isinstance(node, ast.ImportFrom) or node.level < 1:
                continue
            if node.module:
                edges.append((source, node.module.split(".")[0]))
            else:
                edges.extend((source, alias.name) for alias in node.names)
    return tuple(dict.fromkeys(edges))


def live_capability_integrity_payloads() -> dict[str, dict[str, Any]]:
    """Payloads built from current repository capability facts, not fixtures."""
    ids = implemented_ids()
    return {
        "CAP-AUDIT-001": {
            "data": {
                "implemented_ids": list(ids),
                "versions": {cap_id: handler_version(cap_id) for cap_id in ids},
            }
        },
        "CAP-EVAL-001": {
            "expected": list(KNOWN_IMPLEMENTED_CAPABILITIES),
            "actual": list(ids),
        },
        "CAP-TRUTH-001": {
            "edges": [list(edge) for edge in capability_cycle_import_edges()],
        },
    }


def runtime_result_view(result: RuntimeResult) -> dict[str, Any]:
    mission = result.mission_verification
    correlation = None
    if result.performance:
        correlation = result.performance[0].correlation_id
    elif mission is not None:
        correlation = mission.correlation_id
    return {
        "status": result.status,
        "reason": result.reason,
        "correlation_id": correlation,
        "mission_verification": mission.as_dict() if mission is not None else None,
        "plan_ids": list(result.plan.required_ids) if result.plan else [],
        "original_plan_ids": (
            list(result.original_plan.required_ids) if result.original_plan else []
        ),
        "observations": list(result.observations),
        "performance": [
            {
                "correlation_id": record.correlation_id,
                "capability_id": record.capability_id,
                "duration_ms": record.duration_ms,
                "outcome": record.outcome,
                "learning_activated": record.learning_activated,
                "training_activated": record.training_activated,
                "auto_promoted": record.auto_promoted,
            }
            for record in result.performance
        ],
        "performance_record_ids": list(result.performance_record_ids),
        "historical_records_consulted": result.historical_records_consulted,
        "retries": result.retries,
        "replan_records": list(result.replan_records),
        "genesis_called": False,
        "learning_activated": False,
        "training_activated": False,
        "promotion_activated": False,
        "auto_rollback_activated": False,
    }


def execute_agent_capability_mission(
    *,
    instruction: str,
    capability_ids: tuple[str, ...] | None = None,
    payloads: Mapping[str, dict[str, Any]] | None = None,
    performance_store: PerformanceStore | None = None,
    var_dir: str | Path | None = None,
) -> dict[str, Any]:
    """Express a DeveloperAgent mission through execute_plan only."""
    owned = performance_store is None
    if performance_store is not None:
        store = performance_store
    elif var_dir is not None:
        store = PerformanceStore(live_performance_store_path(var_dir))
    else:
        store = PerformanceStore(":memory:")
    try:
        requirement = Requirement(
            text=instruction,
            explicit_capability_ids=tuple(capability_ids or ()),
            request_genesis=False,
        )
        result = execute_plan(
            requirement,
            payloads=payloads,
            performance_store=store,
        )
        view = runtime_result_view(result)
        drift: dict[str, Any] | None = None
        drift_status = "NOT_REQUIRED"
        primary = (capability_ids or view["plan_ids"] or (None,))[0]
        if primary and result.performance_record_ids:
            evaluation = evaluate_drift(
                store, capability_id=str(primary), metric="mission_success_rate"
            )
            drift = evaluation.as_dict()
            drift_status = evaluation.status
        view["drift"] = drift
        view["drift_status"] = drift_status
        view["rollback_used"] = False
        view["performance_store_path"] = store.path
        return view
    finally:
        if owned:
            store.close()
