from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from threading import RLock
from typing import Any, Mapping
from uuid import uuid4


_SCHEMA = """
CREATE TABLE IF NOT EXISTS orchestrator_jobs (
    job_id TEXT PRIMARY KEY,
    request_id TEXT,
    idempotency_key TEXT UNIQUE,
    request TEXT NOT NULL,
    context TEXT NOT NULL,
    plan TEXT NOT NULL,
    state TEXT NOT NULL,
    approval_state TEXT NOT NULL,
    verification_state TEXT NOT NULL,
    result TEXT,
    error_code TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    started_at TEXT,
    finished_at TEXT
);
CREATE INDEX IF NOT EXISTS orchestrator_jobs_state_idx
ON orchestrator_jobs (state, created_at);

CREATE TABLE IF NOT EXISTS orchestrator_job_events (
    seq INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id TEXT NOT NULL,
    event_type TEXT NOT NULL,
    payload TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS orchestrator_job_events_job_idx
ON orchestrator_job_events (job_id, seq);

CREATE TABLE IF NOT EXISTS orchestrator_job_steps (
    job_id TEXT NOT NULL,
    step_number INTEGER NOT NULL,
    action TEXT NOT NULL,
    engine_id TEXT NOT NULL,
    side_effect TEXT NOT NULL,
    state TEXT NOT NULL,
    resolved_args TEXT,
    result TEXT,
    started_at TEXT,
    finished_at TEXT,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (job_id, step_number)
);
CREATE INDEX IF NOT EXISTS orchestrator_job_steps_job_idx
ON orchestrator_job_steps (job_id, step_number);
"""


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


class OrchestratorJobStore:
    def __init__(self, path: str | Path) -> None:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(
            str(path), check_same_thread=False, isolation_level=None
        )
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.executescript(_SCHEMA)
        self._lock = RLock()

    def close(self) -> None:
        self._conn.close()

    def create(
        self,
        *,
        request: str,
        context: Mapping[str, Any],
        plan: Mapping[str, Any],
        request_id: str | None,
        idempotency_key: str | None,
        state: str,
        approval_state: str,
        verification_state: str = "PENDING",
    ) -> tuple[dict[str, Any], bool]:
        now = _utcnow()
        job_id = f"ORCHJOB-{uuid4()}"
        with self._lock:
            if idempotency_key:
                row = self._conn.execute(
                    "SELECT * FROM orchestrator_jobs WHERE idempotency_key = ?",
                    (idempotency_key,),
                ).fetchone()
                if row is not None:
                    return self._row(row), False
            self._conn.execute(
                """
                INSERT INTO orchestrator_jobs (
                    job_id, request_id, idempotency_key, request, context,
                    plan, state, approval_state, verification_state,
                    created_at, updated_at
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    job_id,
                    request_id,
                    idempotency_key,
                    request,
                    json.dumps(dict(context), ensure_ascii=False),
                    json.dumps(dict(plan), ensure_ascii=False),
                    state,
                    approval_state,
                    verification_state,
                    now,
                    now,
                ),
            )
        return self.get(job_id), True

    def get(self, job_id: str) -> dict[str, Any] | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM orchestrator_jobs WHERE job_id = ?",
                (job_id,),
            ).fetchone()
        return self._row(row) if row else None

    def list(self, limit: int = 100) -> list[dict[str, Any]]:
        limit = max(1, min(int(limit), 1000))
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM orchestrator_jobs ORDER BY created_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [self._row(row) for row in rows]

    def append_event(
        self,
        job_id: str,
        event_type: str,
        payload: Mapping[str, Any] | None = None,
    ) -> int:
        with self._lock:
            cursor = self._conn.execute(
                """
                INSERT INTO orchestrator_job_events
                    (job_id, event_type, payload, created_at)
                VALUES (?,?,?,?)
                """,
                (
                    job_id,
                    str(event_type),
                    json.dumps(dict(payload or {}), ensure_ascii=False),
                    _utcnow(),
                ),
            )
        return int(cursor.lastrowid)

    def events(self, job_id: str, limit: int = 500) -> list[dict[str, Any]]:
        limit = max(1, min(int(limit), 2000))
        with self._lock:
            rows = self._conn.execute(
                """
                SELECT seq, job_id, event_type, payload, created_at
                FROM orchestrator_job_events
                WHERE job_id = ?
                ORDER BY seq
                LIMIT ?
                """,
                (job_id, limit),
            ).fetchall()
        return [
            {
                "seq": row[0],
                "job_id": row[1],
                "event_type": row[2],
                "payload": json.loads(row[3]),
                "created_at": row[4],
            }
            for row in rows
        ]

    def upsert_step(
        self,
        job_id: str,
        step_number: int,
        *,
        action: str,
        engine_id: str,
        side_effect: str,
        state: str,
        resolved_args: Mapping[str, Any] | None = None,
        result: Mapping[str, Any] | None = None,
        started_at: str | None = None,
        finished_at: str | None = None,
    ) -> dict[str, Any]:
        now = _utcnow()
        with self._lock:
            self._conn.execute(
                """
                INSERT INTO orchestrator_job_steps (
                    job_id, step_number, action, engine_id, side_effect,
                    state, resolved_args, result, started_at, finished_at, updated_at
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(job_id, step_number) DO UPDATE SET
                    action=excluded.action,
                    engine_id=excluded.engine_id,
                    side_effect=excluded.side_effect,
                    state=excluded.state,
                    resolved_args=excluded.resolved_args,
                    result=excluded.result,
                    started_at=COALESCE(excluded.started_at, orchestrator_job_steps.started_at),
                    finished_at=excluded.finished_at,
                    updated_at=excluded.updated_at
                """,
                (
                    job_id,
                    int(step_number),
                    str(action),
                    str(engine_id),
                    str(side_effect),
                    str(state),
                    (
                        json.dumps(dict(resolved_args), ensure_ascii=False)
                        if resolved_args is not None
                        else None
                    ),
                    (
                        json.dumps(dict(result), ensure_ascii=False)
                        if result is not None
                        else None
                    ),
                    started_at,
                    finished_at,
                    now,
                ),
            )
        return self.get_step(job_id, step_number)

    def get_step(self, job_id: str, step_number: int) -> dict[str, Any] | None:
        with self._lock:
            row = self._conn.execute(
                """
                SELECT job_id, step_number, action, engine_id, side_effect,
                       state, resolved_args, result, started_at, finished_at, updated_at
                FROM orchestrator_job_steps
                WHERE job_id = ? AND step_number = ?
                """,
                (job_id, int(step_number)),
            ).fetchone()
        return self._step_row(row) if row else None

    def steps(self, job_id: str) -> list[dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(
                """
                SELECT job_id, step_number, action, engine_id, side_effect,
                       state, resolved_args, result, started_at, finished_at, updated_at
                FROM orchestrator_job_steps
                WHERE job_id = ?
                ORDER BY step_number
                """,
                (job_id,),
            ).fetchall()
        return [self._step_row(row) for row in rows]

    def get_by_idempotency_key(self, key: str) -> dict[str, Any] | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM orchestrator_jobs WHERE idempotency_key = ?",
                (key,),
            ).fetchone()
        return self._row(row) if row else None

    def list_by_states(self, states: tuple[str, ...]) -> list[dict[str, Any]]:
        if not states:
            return []
        placeholders = ",".join("?" for _ in states)
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM orchestrator_jobs WHERE state IN ("
                + placeholders
                + ") ORDER BY created_at",
                states,
            ).fetchall()
        return [self._row(row) for row in rows]

    def update(self, job_id: str, expected_states: tuple[str, ...], **fields) -> dict[str, Any]:
        allowed = {
            "state", "approval_state", "verification_state", "result",
            "error_code", "started_at", "finished_at",
        }
        unknown = set(fields) - allowed
        if unknown:
            raise ValueError(f"unknown orchestrator job fields: {sorted(unknown)}")
        if "result" in fields and fields["result"] is not None and not isinstance(fields["result"], str):
            fields["result"] = json.dumps(fields["result"], ensure_ascii=False)
        fields["updated_at"] = _utcnow()

        with self._lock:
            row = self._conn.execute(
                "SELECT state FROM orchestrator_jobs WHERE job_id = ?",
                (job_id,),
            ).fetchone()
            if row is None:
                raise KeyError(f"orchestrator job not found: {job_id}")
            if expected_states and row[0] not in expected_states:
                raise RuntimeError(
                    f"job {job_id} in state {row[0]}, expected one of {expected_states}"
                )
            names = list(fields)
            assignments = ", ".join(name + " = ?" for name in names)
            values = [fields[name] for name in names]
            self._conn.execute(
                "UPDATE orchestrator_jobs SET " + assignments + " WHERE job_id = ?",
                (*values, job_id),
            )
        return self.get(job_id)

    @staticmethod
    def _step_row(row: tuple) -> dict[str, Any]:
        keys = (
            "job_id", "step_number", "action", "engine_id", "side_effect",
            "state", "resolved_args", "result", "started_at", "finished_at",
            "updated_at",
        )
        record = dict(zip(keys, row))
        for name in ("resolved_args", "result"):
            if record.get(name):
                record[name] = json.loads(record[name])
        return record

    @staticmethod
    def _row(row: tuple) -> dict[str, Any]:
        keys = (
            "job_id", "request_id", "idempotency_key", "request", "context",
            "plan", "state", "approval_state", "verification_state", "result",
            "error_code", "created_at", "updated_at", "started_at", "finished_at",
        )
        record = dict(zip(keys, row))
        for name in ("context", "plan", "result"):
            if record.get(name):
                record[name] = json.loads(record[name])
        return record
