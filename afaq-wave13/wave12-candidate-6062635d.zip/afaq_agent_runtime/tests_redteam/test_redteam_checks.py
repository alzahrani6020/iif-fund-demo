"""Red-team adversarial checks for the AFAQ runtime (master-task section 326).

These tests live OUTSIDE the canonical pytest suite: ``pytest.ini`` testpaths
cover only ``afaq_agent_runtime/tests`` and ``afaq_intelligence_core``, so the
canonical count is unaffected. They are deterministic, offline, and fast.

Evidence-based only: every check exercises a real public API of a current
component. No fake engines, no stubbed components.

Covered checks:

1.  Audit append-only / history tampering (sections 276, 326): the ledger
    exposes no mutation API; the store grows monotonically; a direct
    UPDATE/DELETE through a second SQLite connection is observable via an
    external snapshot, and — since the section 276 hardening — is also
    detected by the built-in ``verify()`` hash-chain check (rows carry
    ``prev_hash``/``entry_hash``; ``health()`` additionally reports
    ``chain_ok``/``chain_checked``).
2.  Path containment / workspace escape (section 327): ``ProjectBoundary``
    rejects ``../`` escapes and absolute paths outside the root.
3.  Knowledge poisoning / bad learning promotion (section 326): memory
    contracts reject malformed payloads (empty id/content/evidence,
    out-of-range confidence, blank scope fields, invalidated-without-reason).
4.  Risk score != authority (section 329): a low risk approval stays
    pending; there is no auto-grant path — ``authorize_execution`` refuses a
    pending approval and only the human ``decide`` transitions status.
5.  Security evidence preservation (sections 222, 326): a denied action
    recorded in the audit ledger preserves actor, action, and reason.
6.  False coverage claims (sections 316, 326): no absolute claim strings
    ("all countries", "all languages", "all industries") exist in
    ``afaq_intelligence_core`` source.
7.  No unsafe automated defense (section 326): the runtime module surface
    contains no automatic blocking/containment executor module.

Not applicable to current components (no real checkable surface — no tests
written, per task instruction):

- Translation numeric corruption: no translation engine exists in the
  runtime or AIC source.
- Currency/unit mismatch: no financial/unit conversion component exists.
- Reference-period mismatch: no time-series or period-tagged data component.
- False competitive superiority: no benchmark/comparison component exists.
- Fake top-100 ranking: no ranking component exists.
- Invalid customer inference: no customer/profile inference component.
- Privacy scope violation: no PII collection component; only permission
  classification, already covered by canonical tests.
- Bad commodity normalization: no commodity/reference-data component.
- Financial look-ahead bias: no financial modeling component.
- Forecast leakage: no forecasting component exists.
- Cascade overconfidence: no confidence-propagation component.
- False humanitarian claim: no humanitarian/aid claim component.
- Stale regulation/economic data: no regulation/economic data source
  component (runtime is offline by design).
- Cross-project leakage: no multi-project data-sharing component;
  ``MemoryScope.same_boundary`` enforces the boundary in contracts.
- Wrong project routing: routing only exists inside ``GovernedProjectAgent``
  bound to one project root; no cross-project router.
- Source outage: no external source integrations in the runtime.
- Incorrect official-source identification: no source-catalog component.
- False source independence: no source-catalog component.
"""

from __future__ import annotations

import pkgutil
import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

import pytest

import afaq_agent_runtime
from afaq_agent_runtime import permissions, risk
from afaq_agent_runtime.approval_store import ApprovalStore
from afaq_agent_runtime.audit_ledger import AuditLedger
from afaq_agent_runtime.developer_tools import ProjectBoundary
from afaq_intelligence_core import aic_memory_contracts as contracts
from afaq_intelligence_core.aic_memory_store import MemoryNotFoundError, MemoryStore

AIC_ROOT = Path(afaq_agent_runtime.__file__).resolve().parent.parent / "afaq_intelligence_core"

# -- check 1: audit append-only / history tampering -----------------------------


def _ledger(tmp_path: Path) -> AuditLedger:
    return AuditLedger(tmp_path / "audit.db")


def test_audit_ledger_has_no_mutation_api(tmp_path: Path) -> None:
    ledger = _ledger(tmp_path)
    for forbidden in ("update", "delete", "remove", "rewrite", "replace", "rollback"):
        assert not hasattr(ledger, forbidden), f"ledger exposes mutation API: {forbidden}"
    ledger.close()


def test_audit_ledger_grows_monotonically(tmp_path: Path) -> None:
    ledger = _ledger(tmp_path)
    seqs: list[int] = []
    for i in range(5):
        assert ledger.count() == i
        seqs.append(ledger.record(f"action-{i}", detail={"i": i}, actor="redteam"))
    assert seqs == sorted(seqs)
    assert len(set(seqs)) == len(seqs)
    assert ledger.count() == 5
    ledger.close()


def test_audit_ledger_direct_sql_tamper_is_detectable_externally(tmp_path: Path) -> None:
    """No UPDATE/DELETE API exists, but the DB file is plain SQLite (WAL). A
    tamper attempt through a second connection succeeds at the file level; the
    snapshot comparison proves the tamper is observable, not silent (built-in
    chain detection is covered by the section 276 verify() tests below)."""
    db_path = tmp_path / "audit.db"
    ledger = AuditLedger(db_path)
    ledger.record("sensitive-fact", detail={"value": "original"}, actor="alice")
    snapshot = ledger.list()
    ledger.close()

    conn = sqlite3.connect(str(db_path))
    conn.execute(
        "UPDATE audit_ledger SET detail = ? WHERE action = ?",
        ('{"value": "forged"}', "sensitive-fact"),
    )
    conn.execute("DELETE FROM audit_ledger WHERE action = ?", ("sensitive-fact",))
    conn.commit()
    conn.close()

    after = AuditLedger(db_path)
    try:
        tampered = after.list()
        assert tampered != snapshot, "tamper left no observable trace"
        assert after.count() == 0
    finally:
        after.close()


# -- check 1b: tamper-evident hash chain (section 276) ----------------------------

_REPO_ROOT = AIC_ROOT.parent


def _tamper(db_path: Path, sql: str, params: tuple = ()) -> None:
    conn = sqlite3.connect(str(db_path))
    conn.execute(sql, params)
    conn.commit()
    conn.close()


def test_verify_ok_on_fresh_ledger(tmp_path: Path) -> None:
    ledger = _ledger(tmp_path)
    for i in range(3):
        ledger.record(f"action-{i}", detail={"i": i}, actor="redteam")
    assert ledger.verify() == {"ok": True, "checked": 3, "first_bad_seq": None}
    ledger.close()


def test_verify_detects_detail_tamper(tmp_path: Path) -> None:
    db_path = tmp_path / "audit.db"
    ledger = AuditLedger(db_path)
    bad_seq = ledger.record("sensitive-fact", detail={"value": "original"}, actor="alice")
    ledger.record("follow-up", detail={"x": 1}, actor="bob")
    ledger.close()

    _tamper(db_path, "UPDATE audit_ledger SET detail = ? WHERE seq = ?",
            ('{"value": "forged"}', bad_seq))

    ledger = AuditLedger(db_path)
    try:
        result = ledger.verify()
        assert result["ok"] is False
        assert result["first_bad_seq"] == bad_seq
    finally:
        ledger.close()


def test_verify_detects_newest_row_deletion(tmp_path: Path) -> None:
    """Deleting the newest row leaves all remaining hashes valid, so the chain
    cannot flag a row; detection is via the AUTOINCREMENT watermark: the
    highest inserted seq exceeds the max seq still present. Reported as
    ok=False with first_bad_seq=None (no bad row exists)."""
    db_path = tmp_path / "audit.db"
    ledger = AuditLedger(db_path)
    for i in range(3):
        ledger.record(f"action-{i}", detail={"i": i}, actor="redteam")
    ledger.close()

    _tamper(db_path, "DELETE FROM audit_ledger WHERE seq = (SELECT MAX(seq) FROM audit_ledger)")

    ledger = AuditLedger(db_path)
    try:
        result = ledger.verify()
        assert result["ok"] is False
        assert result["checked"] == 2
        assert result["first_bad_seq"] is None
    finally:
        ledger.close()


def test_verify_detects_interior_row_deletion(tmp_path: Path) -> None:
    db_path = tmp_path / "audit.db"
    ledger = AuditLedger(db_path)
    for i in range(3):
        ledger.record(f"action-{i}", detail={"i": i}, actor="redteam")
    ledger.close()

    _tamper(db_path, "DELETE FROM audit_ledger WHERE seq = 2")

    ledger = AuditLedger(db_path)
    try:
        result = ledger.verify()
        assert result["ok"] is False
        assert result["first_bad_seq"] == 3  # seq gap + broken prev_hash link
    finally:
        ledger.close()


def test_verify_detects_actor_tamper(tmp_path: Path) -> None:
    """Every stored column is inside the hash, not just detail."""
    db_path = tmp_path / "audit.db"
    ledger = AuditLedger(db_path)
    bad_seq = ledger.record("signed-action", detail={"k": "v"}, actor="alice")
    ledger.close()

    _tamper(db_path, "UPDATE audit_ledger SET actor = ? WHERE seq = ?", ("mallory", bad_seq))

    ledger = AuditLedger(db_path)
    try:
        result = ledger.verify()
        assert result["ok"] is False
        assert result["first_bad_seq"] == bad_seq
    finally:
        ledger.close()


def test_health_reports_chain_integrity(tmp_path: Path) -> None:
    ledger = _ledger(tmp_path)
    ledger.record("action-0", detail={"i": 0}, actor="redteam")
    report = ledger.health()
    assert report["ok"] is True
    assert report["chain_ok"] is True
    assert report["chain_checked"] == 1
    ledger.close()


_LEGACY_SCHEMA = """
CREATE TABLE audit_ledger (
    seq INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id TEXT,
    approval_id TEXT,
    actor TEXT,
    agent_id TEXT,
    environment TEXT,
    action TEXT NOT NULL,
    detail TEXT NOT NULL,
    created_at TEXT NOT NULL
);
"""


def test_legacy_db_without_hash_columns_migrates_and_verifies(tmp_path: Path) -> None:
    """A pre-chain database (no prev_hash/entry_hash columns) is migrated at
    open: columns are added, the chain is backfilled sequentially, all
    existing records are preserved, and new records chain onto the backfill."""
    db_path = tmp_path / "legacy.db"
    conn = sqlite3.connect(str(db_path))
    conn.executescript(_LEGACY_SCHEMA)
    for i in range(3):
        conn.execute(
            "INSERT INTO audit_ledger (task_id, actor, action, detail, created_at)"
            " VALUES (?,?,?,?,?)",
            (f"task-{i}", "legacy-actor", f"legacy-action-{i}", f'{{"i": {i}}}',
             "2026-01-01T00:00:00+00:00"),
        )
    conn.commit()
    conn.close()

    ledger = AuditLedger(db_path)
    try:
        assert ledger.count() == 3
        entries = ledger.list()
        assert [e["action"] for e in entries] == [
            "legacy-action-0", "legacy-action-1", "legacy-action-2",
        ]
        assert all(e["actor"] == "legacy-actor" for e in entries)
        assert ledger.verify() == {"ok": True, "checked": 3, "first_bad_seq": None}
        ledger.record("post-migration", detail={"ok": True}, actor="redteam")
        assert ledger.verify() == {"ok": True, "checked": 4, "first_bad_seq": None}
    finally:
        ledger.close()


def test_live_db_copy_migrates_and_verifies(tmp_path: Path) -> None:
    """The real var/aic_audit.db has thousands of pre-chain rows. Open a
    backup copy in tmp_path and confirm the backfill preserves integrity."""
    live = _REPO_ROOT / "var" / "aic_audit.db"
    if not live.exists():
        pytest.skip("live audit database not present")
    copy_path = tmp_path / "audit-copy.db"
    source = sqlite3.connect(str(live))
    dest = sqlite3.connect(str(copy_path))
    try:
        source.backup(dest)
    finally:
        source.close()
        dest.close()

    ledger = AuditLedger(copy_path)
    try:
        result = ledger.verify()
        assert result["checked"] == ledger.count()
        assert result == {
            "ok": True, "checked": ledger.count(), "first_bad_seq": None,
        }
    finally:
        ledger.close()


# -- check 2: path containment / workspace escape -------------------------------


def _boundary(tmp_path: Path) -> ProjectBoundary:
    return ProjectBoundary(tmp_path)


def test_boundary_rejects_dotdot_escape(tmp_path: Path) -> None:
    boundary = _boundary(tmp_path)
    with pytest.raises(PermissionError):
        boundary.inside(tmp_path / "sub" / ".." / ".." / "outside.txt")
    with pytest.raises(PermissionError):
        boundary.inside("../outside.txt")


def test_boundary_rejects_absolute_path_outside_root(tmp_path: Path) -> None:
    boundary = _boundary(tmp_path)
    outside = tmp_path.parent / f"sibling-{tmp_path.name}.txt"
    with pytest.raises(PermissionError):
        boundary.inside(outside)


def test_boundary_accepts_inside_path(tmp_path: Path) -> None:
    boundary = _boundary(tmp_path)
    target = tmp_path / "src" / "app.py"
    # The tool-call idiom (see read_project_file/create_file): relative paths
    # are joined onto the root before the containment check.
    assert boundary.inside(boundary.root / "src/app.py") == target.resolve()
    assert boundary.inside(target) == target.resolve()


# -- check 3: knowledge poisoning / bad learning promotion ----------------------


def _valid_evidence() -> tuple[contracts.MemoryEvidence, ...]:
    return (
        contracts.MemoryEvidence(evidence_id="EV-1", source_ref="task://rt", confidence=0.8),
    )


def _valid_scope() -> contracts.MemoryScope:
    return contracts.MemoryScope(
        tenant_id="t1", project_id="p1", agent_id="a1", environment="development"
    )


def _base_record_kwargs() -> dict:
    return {
        "memory_type": contracts.MemoryType.LESSON,
        "content": {"finding": "x"},
        "evidence": _valid_evidence(),
        "scope": _valid_scope(),
    }


def test_contract_rejects_empty_memory_id() -> None:
    with pytest.raises(ValueError):
        contracts.MemoryRecord(
            memory_id="   ", state=contracts.MemoryState.ACTIVE,
            created_at=datetime.now(timezone.utc),
            **_base_record_kwargs(),
        )


def test_contract_rejects_empty_content() -> None:
    kwargs = _base_record_kwargs()
    kwargs["content"] = {}
    with pytest.raises(ValueError):
        contracts.MemoryRecord(
            memory_id="MEM-x", state=contracts.MemoryState.ACTIVE,
            created_at=datetime.now(timezone.utc), **kwargs,
        )


def test_contract_rejects_missing_evidence() -> None:
    kwargs = _base_record_kwargs()
    kwargs["evidence"] = ()
    with pytest.raises(ValueError):
        contracts.MemoryRecord(
            memory_id="MEM-x", state=contracts.MemoryState.ACTIVE,
            created_at=datetime.now(timezone.utc), **kwargs,
        )


def test_contract_rejects_out_of_range_confidence() -> None:
    with pytest.raises(ValueError):
        contracts.MemoryEvidence(evidence_id="EV-1", source_ref="task://rt", confidence=1.5)
    with pytest.raises(ValueError):
        contracts.MemoryEvidence(evidence_id="EV-1", source_ref="task://rt", confidence=-0.1)


def test_contract_rejects_blank_scope_fields() -> None:
    for field in ("tenant_id", "project_id", "agent_id", "environment"):
        values = {"tenant_id": "t", "project_id": "p", "agent_id": "a", "environment": "dev"}
        values[field] = ""
        with pytest.raises(ValueError):
            contracts.MemoryScope(**values)


def test_contract_rejects_invalidated_without_reason() -> None:
    with pytest.raises(ValueError):
        contracts.MemoryRecord(
            memory_id="MEM-x", state=contracts.MemoryState.INVALIDATED,
            created_at=datetime.now(timezone.utc),
            **_base_record_kwargs(),
        )


def test_store_rejects_supersede_of_nonexistent_memory() -> None:
    """A fabricated 'supersedes' link cannot promote poisoned content: the
    store requires the superseded record to exist and be ACTIVE."""
    store = MemoryStore()
    poisoned = contracts.new_memory_record(**_base_record_kwargs())
    poisoned = contracts.MemoryRecord(
        memory_id=poisoned.memory_id,
        memory_type=poisoned.memory_type,
        content=poisoned.content,
        evidence=poisoned.evidence,
        state=poisoned.state,
        created_at=poisoned.created_at,
        scope=poisoned.scope,
        supersedes="MEM-fabricated-target",
        metadata=poisoned.metadata,
    )
    with pytest.raises(MemoryNotFoundError):
        store.add(poisoned)
    assert store.count() == 0


# -- check 4: risk score != authority ------------------------------------------


def _low_risk_proposal() -> dict:
    return {"files": [], "tests": [{"name": "unit"}]}


def test_low_risk_classification_is_low() -> None:
    result = risk.classify_risk(_low_risk_proposal(), "dev")
    assert result["level"] == "low"


def test_low_risk_approval_stays_pending_without_human_decision(tmp_path: Path) -> None:
    store = ApprovalStore(tmp_path / "approvals.db")
    proposal = _low_risk_proposal()
    record = store.create(
        task_id="task-rt",
        agent_id="agent-rt",
        project="demo",
        environment="dev",
        action_type="run_tests",
        risk_level="low",
        requested_changes=[],
        affected_files=[],
        proposed_tests=proposal["tests"],
        reason="redteam low-risk request",
        proposal=proposal,
    )
    assert record["status"] == "pending"
    assert not hasattr(store, "auto_approve")
    assert store.list(status="approved") == []
    # Behavioral: execution authorization refuses a pending approval —
    # a low risk score grants nothing on its own.
    with pytest.raises(RuntimeError):
        store.authorize_execution(record["approval_id"], proposal)
    assert store.get(record["approval_id"])["status"] == "pending"
    store.close()


def test_approval_transition_requires_explicit_decision(tmp_path: Path) -> None:
    store = ApprovalStore(tmp_path / "approvals.db")
    record = store.create(
        task_id="task-rt2",
        agent_id="agent-rt",
        project="demo",
        environment="dev",
        action_type="run_tests",
        risk_level="low",
        requested_changes=[],
        affected_files=[],
        proposed_tests=[],
        proposal={"files": []},
    )
    decided = store.decide(record["approval_id"], decision="approve", actor="human-1")
    assert decided["status"] == "approved"
    assert decided["approved_by"] == "human-1"
    store.close()


# -- check 5: security evidence preservation -----------------------------------


def test_denied_action_preserves_actor_action_and_reason(tmp_path: Path) -> None:
    ledger = AuditLedger(tmp_path / "audit.db")
    decision = permissions.decide_file_action("git_push", "src/app.py", "dev")
    assert decision["action"] == "deny"
    ledger.record(
        "permission_denied",
        actor="agent-rt",
        task_id="task-rt",
        detail={
            "requested_action": "git_push",
            "path": "src/app.py",
            "environment": "dev",
            "reason": decision["reason"],
        },
    )
    entries = ledger.list(task_id="task-rt")
    assert len(entries) == 1
    entry = entries[0]
    assert entry["actor"] == "agent-rt"
    assert entry["action"] == "permission_denied"
    assert entry["detail"]["reason"] == decision["reason"]
    assert "denied" in entry["detail"]["reason"]
    ledger.close()


# -- check 6: false coverage claims --------------------------------------------


def test_no_absolute_coverage_claims_in_aic_source() -> None:
    pattern = re.compile(r"all (countries|languages|industries)", re.IGNORECASE)
    offenders: list[str] = []
    for path in AIC_ROOT.rglob("*.py"):
        if pattern.search(path.read_text(encoding="utf-8")):
            offenders.append(path.name)
    assert offenders == [], f"absolute coverage claims found in: {offenders}"


# -- check 7: no unsafe automated defense ---------------------------------------


def test_no_automatic_blocking_or_containment_executor_modules() -> None:
    denylist = {"auto_blocker", "auto_contain", "kill_executor", "auto_defense", "auto_quarantine"}
    package = afaq_agent_runtime
    module_names = {
        info.name for info in pkgutil.walk_packages(package.__path__, package.__name__ + ".")
    }
    module_names.update(dir(package))
    offenders = sorted(
        name for name in module_names if name.split(".")[-1].lower() in denylist
    )
    assert offenders == [], f"automatic defense executor modules found: {offenders}"
