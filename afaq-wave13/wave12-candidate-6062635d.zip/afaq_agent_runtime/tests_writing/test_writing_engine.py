"""Focused tests for the Writing & Script engine (wave 3, §13 family).

Runs against afaq_agent_runtime.writing_engine only — no model, no network,
no runtime services, no canonical state. Intentionally OUTSIDE pytest.ini
testpaths so the canonical suite stays at exactly 44 tests.

Run explicitly:

    python -m pytest afaq_agent_runtime/tests_writing -q
"""

from __future__ import annotations

import pytest

from afaq_agent_runtime.writing_engine import (
    WritingError,
    build_structure,
    evaluate_script,
    generate_brief,
    improve_script,
    parse_evaluation,
    parse_scene_plan,
    parse_structure,
    parse_writing_brief,
    plan_scenes,
    run_writing_gates,
    writing_readiness,
)

_UNDERSTANDING = {
    "intent": {"kind": "development_task", "reason": "instruction requests new content"},
    "goals": ["write a short video script about solar adoption"],
    "audience": "general",
    "platform_hints": ["python"],
    "constraints": ["keep it short"],
    "deliverables": ["video script"],
    "decomposition": ["confirm intent", "work goal", "verify"],
    "confidence": {
        "level": "medium",
        "basis": 'instruction states: "write a short video script about solar adoption"',
    },
    "open_questions": [],
}

_RESEARCH = {
    "topic": "solar adoption",
    "sources": [],
    "facts": [
        {
            "claim": "solar adoption reached 42% in rural areas",
            "source_id": "gov-1",
            "evidence": "solar adoption reached 42% according to the survey",
            "uncertainty": "low",
        }
    ],
    "analysis": {
        "facets": ["solar"],
        "key_terms": ["solar", "adoption", "rural"],
        "coverage": "single_source",
        "consensus": ["2 sources agree: solar adoption reached 42%"],
        "conflicts": [],
    },
    "confidence": {"level": "medium", "basis": 'topic states: "solar adoption"'},
    "open_questions": [],
}

_GOOD_DRAFT = (
    "Narrator: In rural villages, solar adoption is changing daily life.\n"
    "Amina: Our village switched to solar adoption last year.\n"
    "Narrator: According to officials, solar adoption reached 42% in rural areas. "
    "The panels are cheap to run and easy to maintain.\n"
    "Amina: We want every neighbor to join the solar adoption program.\n"
    "Narrator: Start small, measure savings, and expand your own solar setup."
)

_BAD_DRAFT = (
    "The committee met and discussed the quarterly procurement framework "
    "and its implications for the stakeholder engagement matrix "
    "in the forthcoming fiscal period and beyond "
    + "with considerable attention to administrative detail. " * 20
)


def _brief():
    return generate_brief(_UNDERSTANDING, _RESEARCH)


# -- brief generation ---------------------------------------------------------------

def test_generate_brief_from_understanding_and_research():
    brief = _brief()
    assert brief["content_type"] == "video_script"
    assert brief["audience"] == "general"
    assert brief["target_length"] == "short"
    assert brief["goals"] == ["write a short video script about solar adoption"]
    assert len(brief["key_messages"]) >= 1
    assert any("solar" in m for m in brief["key_messages"])
    assert brief["confidence"]["level"] in ("medium", "high")


def test_generate_brief_without_research_falls_back_to_goals():
    brief = generate_brief(_UNDERSTANDING)
    assert brief["key_messages"], "brief always carries key messages"
    assert all(m.startswith("deliver on goal:") for m in brief["key_messages"])


def test_generate_brief_does_not_mutate_inputs():
    understanding = {
        "goals": ["write a story about the sea"],
        "audience": "general",
        "constraints": [],
        "open_questions": [],
        "confidence": {"level": "low", "basis": "instruction states story about the sea"},
    }
    before = {k: (list(v) if isinstance(v, list) else v) for k, v in understanding.items()}
    generate_brief(understanding)
    assert understanding["goals"] == before["goals"]
    assert understanding["open_questions"] == before["open_questions"]


def test_generate_brief_discloses_unknown_content_type():
    brief = generate_brief({
        "goals": ["do the thing"],
        "audience": "unknown",
        "constraints": [],
        "open_questions": [],
        "confidence": {"level": "low", "basis": "instruction states thing"},
    })
    assert brief["content_type"] == "unknown"
    assert any("content_type UNKNOWN" in q for q in brief["open_questions"])


def test_generate_brief_rejects_non_object():
    with pytest.raises(WritingError, match="understanding object"):
        generate_brief("not a mapping")


# -- structure (arc / beat sheet) -----------------------------------------------------

def test_build_structure_story_arc():
    structure = build_structure(_brief())
    assert structure["arc"] == "three_act"
    roles = [b["role"] for b in structure["beats"]]
    assert roles[0] == "hook"
    assert "climax" in roles and "resolution" in roles
    assert [b["order"] for b in structure["beats"]] == list(
        range(1, len(roles) + 1)
    )


def test_build_structure_article_arc_listicle_vs_inverted():
    article_brief = dict(_brief())
    article_brief["content_type"] = "article"
    article_brief["goals"] = ["write an article listing five tips"]
    structure = build_structure(article_brief)
    assert structure["arc"] == "listicle"

    article_brief["goals"] = ["write an article about solar policy"]
    structure = build_structure(article_brief)
    assert structure["arc"] == "inverted_pyramid"


def test_build_structure_documentation_is_sequential():
    doc_brief = dict(_brief())
    doc_brief["content_type"] = "documentation"
    structure = build_structure(doc_brief)
    assert structure["arc"] == "sequential"


def test_build_structure_beat_purposes_are_bounded_and_grounded():
    structure = build_structure(_brief())
    for beat in structure["beats"]:
        assert len(beat["purpose"].split()) <= 40
        assert beat["purpose"].strip()
    assert any("video script" in b["purpose"] or "solar" in b["purpose"]
               for b in structure["beats"])


def test_build_structure_rejects_invalid_brief():
    with pytest.raises(WritingError):
        build_structure({"title": "incomplete"})


# -- scene / sequence planning --------------------------------------------------------

def test_plan_scenes_covers_every_beat_exactly_once():
    brief = _brief()
    structure = build_structure(brief)
    plan = plan_scenes(structure, brief)
    assert len(plan["sequences"]) >= 2
    covered = [b for s in plan["sequences"] for b in s["beats_covered"]]
    beat_orders = [b["order"] for b in structure["beats"]]
    assert sorted(covered) == beat_orders
    assert plan["sequences"][0]["setting"] == "opening context"
    assert plan["sequences"][-1]["setting"] == "closing"
    assert plan["audience"] == "general"


def test_plan_scenes_is_deterministic():
    structure = build_structure(_brief())
    a = plan_scenes(structure)
    b = plan_scenes(structure)
    assert a == b


def test_plan_scenes_without_brief_still_valid():
    structure = build_structure(_brief())
    plan = plan_scenes(structure)
    parse_scene_plan(plan)  # round-trips through the parser


# -- evaluation -----------------------------------------------------------------------

def test_evaluate_script_good_draft_scores_higher_than_bad():
    brief = _brief()
    structure = build_structure(brief)
    good = evaluate_script(_GOOD_DRAFT, brief, structure, _RESEARCH)
    bad = evaluate_script(_BAD_DRAFT, brief, structure, _RESEARCH)
    assert good["overall_score"] > bad["overall_score"]
    assert 0 <= good["overall_score"] <= 100
    assert {d["name"] for d in good["dimensions"]} == {
        "alignment", "structure", "readability", "dialogue", "grounding",
    }


def test_evaluate_script_every_dimension_has_reasons():
    evaluation = evaluate_script(_GOOD_DRAFT, _brief(), build_structure(_brief()))
    for dimension in evaluation["dimensions"]:
        assert dimension["reasons"], f"{dimension['name']} must explain its score"


def test_evaluate_script_dialogue_format_without_dialogue_punished():
    brief = _brief()  # video_script
    no_dialogue = "The sun rises over the village. Panels gleam on every roof. Birds sing."
    evaluation = evaluate_script(no_dialogue, brief)
    dialogue = next(d for d in evaluation["dimensions"] if d["name"] == "dialogue")
    assert dialogue["score"] < 50
    assert any("no dialogue" in r for r in dialogue["reasons"])


def test_evaluate_script_neutral_scores_without_optional_inputs():
    evaluation = evaluate_script(_GOOD_DRAFT, _brief())
    structure_dim = next(d for d in evaluation["dimensions"] if d["name"] == "structure")
    grounding_dim = next(d for d in evaluation["dimensions"] if d["name"] == "grounding")
    assert structure_dim["score"] == 50
    assert grounding_dim["score"] == 50
    assert any("UNKNOWN" in q for q in evaluation["open_questions"])


def test_evaluate_script_suggestions_carry_reasons():
    evaluation = evaluate_script(_BAD_DRAFT, _brief())
    assert evaluation["suggestions"], "bad draft must produce suggestions"
    for suggestion in evaluation["suggestions"]:
        assert suggestion["reason"].strip()
        assert suggestion["severity"] in ("high", "medium", "low")
        assert suggestion["issue"] and suggestion["suggestion"]


def test_evaluate_script_rejects_empty_draft():
    with pytest.raises(WritingError, match="non-empty draft"):
        evaluate_script("   ", _brief())


# -- improvement feedback -------------------------------------------------------------

def test_improve_script_prioritizes_high_severity():
    brief = _brief()
    feedback = improve_script(_BAD_DRAFT, brief)
    severities = [a["severity"] for a in feedback["actions"]]
    rank = {"high": 0, "medium": 1, "low": 2}
    assert severities == sorted(severities, key=lambda s: rank[s])
    assert feedback["evaluation"]["overall_score"] < 80
    assert feedback["ready_to_publish"] is False


# -- strict validation ----------------------------------------------------------------

def _valid_brief(**overrides):
    base = {
        "title": "solar video script",
        "content_type": "video_script",
        "audience": "general",
        "goals": ["write a short video script about solar adoption"],
        "key_messages": ["solar adoption is rising"],
        "constraints": ["keep it short"],
        "tone": "conversational",
        "target_length": "short",
        "confidence": {"level": "medium", "basis": "brief derived from the solar goal"},
        "open_questions": [],
    }
    base.update(overrides)
    return base


def test_parse_writing_brief_valid_shape():
    brief = parse_writing_brief(_valid_brief())
    assert brief["content_type"] == "video_script"
    assert brief["target_length"] == "short"


def test_enum_rejection_content_type():
    with pytest.raises(WritingError, match="content_type"):
        parse_writing_brief(_valid_brief(content_type="podcast"))


def test_enum_rejection_tone():
    with pytest.raises(WritingError, match="tone"):
        parse_writing_brief(_valid_brief(tone="angry"))


def test_enum_rejection_target_length():
    with pytest.raises(WritingError, match="target_length"):
        parse_writing_brief(_valid_brief(target_length="epic"))


def test_enum_rejection_audience():
    with pytest.raises(WritingError, match="audience"):
        parse_writing_brief(_valid_brief(audience="aliens"))


def test_missing_fields_rejected():
    payload = _valid_brief()
    del payload["goals"]
    with pytest.raises(WritingError, match="missing required field"):
        parse_writing_brief(payload)


def test_unknown_keys_ignored():
    payload = _valid_brief(future_field={"anything": True})
    brief = parse_writing_brief(payload)
    assert "future_field" not in brief


def test_word_cap_rejected_by_parser():
    with pytest.raises(WritingError, match="exceeds 40 words"):
        parse_writing_brief(_valid_brief(title="word " * 41))


def test_parse_structure_rejects_bad_beat_role():
    payload = {
        "content_type": "story",
        "arc": "three_act",
        "beats": [
            {"order": 1, "role": "hook", "purpose": "open"},
            {"order": 2, "role": "explosion", "purpose": "do something"},
            {"order": 3, "role": "resolution", "purpose": "close"},
        ],
    }
    with pytest.raises(WritingError, match="role"):
        parse_structure(payload)


def test_parse_structure_enforces_beat_budget():
    beats = [
        {"order": i + 1, "role": "hook", "purpose": f"purpose {i}"}
        for i in range(13)
    ]
    with pytest.raises(WritingError, match="entries"):
        parse_structure({"content_type": "story", "arc": "three_act", "beats": beats})


def test_parse_scene_plan_rejects_empty_beats_covered():
    payload = {
        "content_type": "story",
        "sequences": [
            {"order": 1, "purpose": "p", "setting": "s", "beats_covered": []},
            {"order": 2, "purpose": "p2", "setting": "s2", "beats_covered": [1]},
        ],
    }
    with pytest.raises(WritingError, match="beats_covered"):
        parse_scene_plan(payload)


def test_parse_evaluation_enforces_score_range():
    payload = {
        "overall_score": 150,
        "dimensions": [],
        "suggestions": [],
        "confidence": {"level": "low", "basis": "basis"},
        "open_questions": [],
    }
    with pytest.raises(WritingError, match="0..100"):
        parse_evaluation(payload)


# -- consistency gates ----------------------------------------------------------------

def _document():
    brief = _brief()
    structure = build_structure(brief)
    plan = plan_scenes(structure, brief)
    document = dict(structure)
    document["sequences"] = plan["sequences"]
    return brief, structure, document


def test_gates_pass_for_engine_produced_plan():
    brief, _, document = _document()
    assert run_writing_gates(document, brief) == []


def test_gate_duplicate_beat_orders_fail():
    brief, _, document = _document()
    document["beats"] = [dict(b) for b in document["beats"]]
    document["beats"][1]["order"] = document["beats"][0]["order"]
    failures = run_writing_gates(document, brief)
    assert any("duplicates" in f for f in failures)


def test_gate_orphan_beat_not_covered_fails():
    brief, _, document = _document()
    document["sequences"] = [dict(s) for s in document["sequences"]]
    document["sequences"][0]["beats_covered"] = document["sequences"][0]["beats_covered"][1:]
    failures = run_writing_gates(document, brief)
    assert any("not covered" in f for f in failures)


def test_gate_double_covered_beat_fails():
    brief, _, document = _document()
    document["sequences"] = [dict(s) for s in document["sequences"]]
    first = document["sequences"][0]["beats_covered"][0]
    document["sequences"][1]["beats_covered"] = [first] + document["sequences"][1]["beats_covered"]
    failures = run_writing_gates(document, brief)
    assert any("more than once" in f for f in failures)


def test_gate_ungrounded_confidence_fails():
    brief, _, document = _document()
    brief = dict(brief)
    brief["confidence"] = {"level": "medium", "basis": "it feels right"}
    failures = run_writing_gates(document, brief)
    assert any("not grounded" in f for f in failures)


def test_gate_content_type_mismatch_fails():
    brief, _, document = _document()
    document = dict(document)
    document["content_type"] = "article"
    failures = run_writing_gates(document, brief)
    assert any("disagrees" in f for f in failures)


# -- readiness seal -------------------------------------------------------------------

def test_readiness_ready_for_engine_produced_plan():
    brief, _, document = _document()
    result = writing_readiness(document, run_writing_gates(document, brief))
    assert result["ready"] is True
    assert result["blocking_items"] == []
    assert result["seal"]["authority_preserved"] is True


def test_readiness_blocked_without_structure():
    result = writing_readiness({"sequences": []}, [])
    assert result["ready"] is False
    assert any("no beats" in b for b in result["blocking_items"])


def test_readiness_blocked_when_gates_fail():
    brief, _, document = _document()
    document["sequences"] = [dict(s) for s in document["sequences"]]
    document["sequences"][0]["beats_covered"] = document["sequences"][0]["beats_covered"][1:]
    failures = run_writing_gates(document, brief)
    result = writing_readiness(document, failures)
    assert result["ready"] is False
    for failure in failures:
        assert failure in result["blocking_items"]
