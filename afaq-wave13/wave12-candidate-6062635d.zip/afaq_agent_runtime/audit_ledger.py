"""Append-only audit ledger (governance hardening).

A dedicated SQLite database, separate from task events, recording every
governance-relevant fact: who created a task, which agent ran it, what was
planned, which model and tools were used, approval requests and decisions,
files changed, tests run, rollbacks, final outcomes, and memory ids.

The ledger only grows. There is intentionally no update or delete API —
invalidation is expressed by appending a newer record, never by rewriting
history.

Integrity (master-task section 276): every row additionally carries
``prev_hash`` / ``entry_hash`` forming a sha256 hash chain in ``seq`` order.
The entry hash covers the full row content (seq, prev_hash, task_id,
approval_id, actor, agent_id, environment, action, detail as canonical JSON,
created_at), so any direct sqlite-level rewrite of a stored column breaks the
chain. ``verify()`` walks the chain and reports the first bad sequence number;
tail truncation after the last insert is caught via the AUTOINCREMENT
watermark (``sqlite_sequence``). Legacy databases without the hash columns are
migrated at open time: the columns are added and the chain is backfilled
sequentially without touching existing content.
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from threading import RLock

_SCHEMA = """
CREATE TABLE IF NOT EXISTS audit_ledger (
    seq INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id TEXT,
    approval_id TEXT,
    actor TEXT,
    agent_id TEXT,
    environment TEXT,
    action TEXT NOT NULL,
    detail TEXT NOT NULL,
    created_at TEXT NOT NULL,
    prev_hash TEXT,
    entry_hash TEXT
);
CREATE INDEX IF NOT EXISTS audit_task_idx ON audit_ledger (task_id, seq);
CREATE INDEX IF NOT EXISTS audit_action_idx ON audit_ledger (action, seq);
"""


def _canonical_detail(detail_text: str) -> str:
    """Re-serialize stored detail JSON with stable key order and separators."""
    try:
        return json.dumps(
            json.loads(detail_text), sort_keys=True, ensure_ascii=False,
            separators=(",", ":"),
        )
    except (json.JSONDecodeError, TypeError):
        return detail_text


def _entry_hash(
    seq: int,
    prev_hash: str | None,
    task_id: str | None,
    approval_id: str | None,
    actor: str | None,
    agent_id: str | None,
    environment: str | None,
    action: str,
    detail_text: str,
    created_at: str,
) -> str:
    payload = {
        "seq": seq,
        "prev_hash": prev_hash or "",
        "task_id": task_id,
        "approval_id": approval_id,
        "actor": actor,
        "agent_id": agent_id,
        "environment": environment,
        "action": action,
        "detail": _canonical_detail(detail_text),
        "created_at": created_at,
    }
    blob = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


class AuditLedger:
    def __init__(self, path: str | Path) -> None:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(
            str(path), check_same_thread=False, isolation_level=None
        )
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA busy_timeout=5000")
        self._lock = RLock()
        with self._lock:
            self._conn.executescript(_SCHEMA)
            self._migrate_chain_columns()
            self._backfill_chain()
            self._head = self._load_head()

    def _migrate_chain_columns(self) -> None:
        """Add prev_hash/entry_hash to a pre-chain database, if missing."""
        columns = {
            row[1] for row in self._conn.execute("PRAGMA table_info(audit_ledger)")
        }
        if "prev_hash" not in columns:
            self._conn.execute("ALTER TABLE audit_ledger ADD COLUMN prev_hash TEXT")
        if "entry_hash" not in columns:
            self._conn.execute("ALTER TABLE audit_ledger ADD COLUMN entry_hash TEXT")

    def _backfill_chain(self) -> None:
        """Hash any rows missing entry_hash, chaining in seq order."""
        rows = self._conn.execute(
            "SELECT seq, task_id, approval_id, actor, agent_id, environment, action,"
            " detail, created_at, entry_hash FROM audit_ledger ORDER BY seq"
        ).fetchall()
        prev = ""
        for row in rows:
            if row[9] is None:
                digest = _entry_hash(row[0], prev, *row[1:9])
                self._conn.execute(
                    "UPDATE audit_ledger SET prev_hash = ?, entry_hash = ? WHERE seq = ?",
                    (prev, digest, row[0]),
                )
                prev = digest
            else:
                prev = row[9]

    def _load_head(self) -> str:
        row = self._conn.execute(
            "SELECT entry_hash FROM audit_ledger ORDER BY seq DESC LIMIT 1"
        ).fetchone()
        return row[0] if row and row[0] is not None else ""

    def close(self) -> None:
        self._conn.close()

    def record(
        self,
        action: str,
        *,
        detail: dict | None = None,
        task_id: str | None = None,
        approval_id: str | None = None,
        actor: str = "system",
        agent_id: str | None = None,
        environment: str | None = None,
    ) -> int:
        """Append one immutable record. This is the only mutation."""
        if not action or not action.strip():
            raise ValueError("audit action is required")
        detail_text = json.dumps(detail or {}, ensure_ascii=False)
        created_at = datetime.now(timezone.utc).isoformat()
        with self._lock:
            cursor = self._conn.execute(
                "INSERT INTO audit_ledger (task_id, approval_id, actor, agent_id, environment,"
                " action, detail, created_at, prev_hash) VALUES (?,?,?,?,?,?,?,?,?)",
                (
                    task_id, approval_id, actor, agent_id, environment, action,
                    detail_text, created_at, self._head,
                ),
            )
            seq = cursor.lastrowid
            digest = _entry_hash(
                seq, self._head, task_id, approval_id, actor, agent_id,
                environment, action, detail_text, created_at,
            )
            self._conn.execute(
                "UPDATE audit_ledger SET entry_hash = ? WHERE seq = ?", (digest, seq)
            )
            self._head = digest
        return seq

    def list(self, task_id: str | None = None, limit: int = 200) -> list[dict]:
        with self._lock:
            if task_id:
                rows = self._conn.execute(
                    "SELECT seq, task_id, approval_id, actor, agent_id, environment, action,"
                    " detail, created_at FROM audit_ledger WHERE task_id = ?"
                    " ORDER BY seq DESC LIMIT ?",
                    (task_id, limit),
                ).fetchall()
            else:
                rows = self._conn.execute(
                    "SELECT seq, task_id, approval_id, actor, agent_id, environment, action,"
                    " detail, created_at FROM audit_ledger ORDER BY seq DESC LIMIT ?",
                    (limit,),
                ).fetchall()
        return [
            {
                "seq": r[0], "task_id": r[1], "approval_id": r[2], "actor": r[3],
                "agent_id": r[4], "environment": r[5], "action": r[6],
                "detail": json.loads(r[7]), "created_at": r[8],
            }
            for r in reversed(rows)
        ]

    def count(self) -> int:
        with self._lock:
            row = self._conn.execute("SELECT COUNT(*) FROM audit_ledger").fetchone()
        return int(row[0])

    def verify(self) -> dict:
        """Walk the hash chain over all rows, in seq order.

        Returns ``{"ok", "checked", "first_bad_seq"}``. A row is bad when its
        seq is not contiguous, its stored ``prev_hash`` does not match the
        previous row's entry hash, or its stored ``entry_hash`` does not
        recompute from the row content. Deleting the newest row leaves all
        remaining hashes valid, so tail truncation is instead detected via
        the AUTOINCREMENT watermark (``sqlite_sequence``); it reports
        ``ok=False`` with ``first_bad_seq=None``.
        """
        with self._lock:
            rows = self._conn.execute(
                "SELECT seq, task_id, approval_id, actor, agent_id, environment, action,"
                " detail, created_at, prev_hash, entry_hash FROM audit_ledger ORDER BY seq"
            ).fetchall()
            ok = True
            checked = 0
            first_bad_seq: int | None = None
            prev = ""
            expected_seq: int | None = None
            for row in rows:
                seq = row[0]
                bad = (
                    (expected_seq is not None and seq != expected_seq)
                    or row[9] != prev
                    or row[10] != _entry_hash(seq, prev, *row[1:9])
                )
                if bad:
                    ok = False
                    if first_bad_seq is None:
                        first_bad_seq = seq
                checked += 1
                expected_seq = seq + 1
                prev = _entry_hash(seq, prev, *row[1:9])
            # Tail truncation: a deleted newest row leaves no bad row behind,
            # but the AUTOINCREMENT watermark remembers the highest seq ever
            # inserted.
            watermark = self._conn.execute(
                "SELECT seq FROM sqlite_sequence WHERE name = 'audit_ledger'"
            ).fetchone()
            last_seq = rows[-1][0] if rows else 0
            if watermark is not None and last_seq < watermark[0]:
                ok = False
        return {"ok": ok, "checked": checked, "first_bad_seq": first_bad_seq}

    def health(self) -> dict:
        try:
            with self._lock:
                row = self._conn.execute("PRAGMA quick_check").fetchone()
                integrity = self.verify()
            result = {"ok": bool(row and row[0] == "ok"), "check": row[0] if row else None}
            result["chain_ok"] = integrity["ok"]
            result["chain_checked"] = integrity["checked"]
            return result
        except Exception as exc:  # noqa: BLE001 - health probe must report, not crash
            return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
