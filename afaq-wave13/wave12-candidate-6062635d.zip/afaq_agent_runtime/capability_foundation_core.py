"""Operational Capability Foundation Core.

Dedicated runtime implementation for:
- ENG-CAP-005 Capability Discovery & Resolver Engine
- ENG-CAP-006 Provider Registry & Adapter Runtime

Truth boundaries:
- candidate != verified
- verified != certified
- health != authority
- selected != authorized
- missing evidence never silently becomes PASS
- provider registry never stores credentials or secrets
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from current_authority.resolver import AuthorityRequest, resolve

REPO_ROOT = Path(__file__).resolve().parents[1]

CANDIDATE_REGISTRY = (
    REPO_ROOT / "capability-foundation" / "PROVIDER_CANDIDATE_REGISTRY.json"
)
ALLOWLIST = REPO_ROOT / "provider_adapters" / "ALLOWLIST.json"
RUNTIME_REGISTRY = REPO_ROOT / "provider_adapters" / "RUNTIME_REGISTRY.json"

SECRET_KEYS = {
    "api_key",
    "apikey",
    "token",
    "secret",
    "password",
    "credential",
    "credentials",
}

PRIVACY_LEVELS = {
    "public": 0,
    "standard": 1,
    "elevated": 2,
    "strict": 3,
}


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _provider_id(name: str) -> str:
    value = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")
    return value[:96]


def _set(value: Any) -> frozenset[str]:
    if value is None:
        return frozenset()
    if isinstance(value, str):
        return frozenset({value})
    if isinstance(value, (list, tuple, set, frozenset)):
        return frozenset(str(v) for v in value if v is not None)
    return frozenset()


def _dt(value: Any) -> datetime | None:
    if isinstance(value, datetime):
        result = value
    elif isinstance(value, str) and value.strip():
        try:
            result = datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return None
    else:
        return None

    if result.tzinfo is None:
        result = result.replace(tzinfo=timezone.utc)
    return result


def _age_seconds(value: datetime | None) -> float | None:
    if value is None:
        return None
    return max(0.0, (_now() - value).total_seconds())


def _load_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return default


def _contains_secret(value: Any) -> bool:
    if isinstance(value, Mapping):
        for key, item in value.items():
            if str(key).lower() in SECRET_KEYS:
                return True
            if _contains_secret(item):
                return True
    elif isinstance(value, (list, tuple)):
        return any(_contains_secret(v) for v in value)
    return False


def _atomic_write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    os.replace(tmp, path)


@dataclass(frozen=True)
class Check:
    state: str
    reason: str
    details: Mapping[str, Any] = field(default_factory=dict)

    @property
    def passed(self) -> bool:
        return self.state == "PASS"

    def as_dict(self) -> dict[str, Any]:
        return {
            "state": self.state,
            "reason": self.reason,
            "details": dict(self.details),
        }


@dataclass(frozen=True)
class Provider:
    provider_id: str
    name: str

    candidate: bool = False
    adapter_implemented: bool = False
    verified: bool = False
    certified: bool = False

    health_status: str = "UNKNOWN"

    supported_capabilities: frozenset[str] = frozenset()
    provided_contracts: frozenset[str] = frozenset()
    dependencies: frozenset[str] = frozenset()
    environments: frozenset[str] = frozenset()
    certifications: frozenset[str] = frozenset()
    side_effects: frozenset[str] = frozenset()
    required_authorities: frozenset[str] = frozenset()

    privacy_level: str = "standard"

    evidence_observed_at: datetime | None = None
    health_observed_at: datetime | None = None
    certification_observed_at: datetime | None = None
    certification_valid_until: datetime | None = None

    auth_scheme: str | None = None
    credential_present: bool = False

    version: str | None = None
    compatible_versions: frozenset[str] = frozenset()

    priority: int = 100

    limits: Mapping[str, Any] = field(default_factory=dict)
    data_policy: Mapping[str, Any] = field(default_factory=dict)
    metadata: Mapping[str, Any] = field(default_factory=dict)


def _normalise_provider(
    provider_id: str,
    name: str,
    raw: Mapping[str, Any],
) -> Provider:
    env_name = raw.get("env_api_key")

    return Provider(
        provider_id=provider_id,
        name=name,
        candidate=bool(raw.get("candidate", True)),
        adapter_implemented=bool(raw.get("adapter_implemented")),
        verified=bool(raw.get("verified")),
        certified=bool(raw.get("certified")),
        health_status=str(raw.get("health_status") or "UNKNOWN").upper(),
        supported_capabilities=_set(raw.get("supported_capabilities")),
        provided_contracts=_set(raw.get("provided_contracts")),
        dependencies=_set(raw.get("dependencies")),
        environments=_set(raw.get("environments")),
        certifications=_set(raw.get("certifications")),
        side_effects=_set(raw.get("side_effects")),
        required_authorities=_set(raw.get("required_authorities")),
        privacy_level=str(raw.get("privacy_level") or "standard").lower(),
        evidence_observed_at=_dt(raw.get("evidence_observed_at")),
        health_observed_at=_dt(raw.get("health_observed_at")),
        certification_observed_at=_dt(
            raw.get("certification_observed_at")
        ),
        certification_valid_until=_dt(
            raw.get("certification_valid_until")
        ),
        auth_scheme=(
            str(raw["auth_scheme"])
            if raw.get("auth_scheme")
            else ("env_api_key" if env_name else None)
        ),
        credential_present=bool(
            env_name and os.environ.get(str(env_name))
        ),
        version=str(raw["version"]) if raw.get("version") else None,
        compatible_versions=_set(raw.get("compatible_versions")),
        priority=int(raw.get("priority") or 100),
        limits=dict(raw.get("limits") or {}),
        data_policy=dict(raw.get("data_policy") or {}),
        metadata=dict(raw),
    )


class ProviderRegistry:
    def __init__(self, providers: list[Provider]) -> None:
        self._providers = {p.provider_id: p for p in providers}

    def all(self) -> list[Provider]:
        return sorted(self._providers.values(), key=lambda p: p.provider_id)

    def get(self, provider_id: str) -> Provider | None:
        return self._providers.get(provider_id)

    def discover(self, capability_id: str) -> list[Provider]:
        return [
            p for p in self.all()
            if capability_id in p.supported_capabilities
        ]


def _runtime_entries() -> dict[str, dict[str, Any]]:
    data = _load_json(
        RUNTIME_REGISTRY,
        {"schema": "afaq.provider-runtime-registry/v1", "providers": {}},
    )
    providers = data.get("providers") if isinstance(data, dict) else None
    return dict(providers) if isinstance(providers, dict) else {}


def upsert_runtime_provider(raw: Mapping[str, Any]) -> dict[str, Any]:
    """Persist non-secret provider runtime metadata."""

    if _contains_secret(raw):
        raise ValueError(
            "provider runtime registry rejects credentials/secrets"
        )

    name = str(raw.get("name") or raw.get("provider_id") or "").strip()
    if not name:
        raise ValueError("provider name/provider_id is required")

    provider_id = str(raw.get("provider_id") or _provider_id(name))

    current = _runtime_entries()
    old = current.get(provider_id)
    merged = dict(old) if isinstance(old, dict) else {}
    merged.update(dict(raw))
    merged["provider_id"] = provider_id
    merged["name"] = name

    current[provider_id] = merged

    _atomic_write_json(
        RUNTIME_REGISTRY,
        {
            "schema": "afaq.provider-runtime-registry/v1",
            "providers": current,
        },
    )

    return {
        "provider_id": provider_id,
        "stored": True,
        "secret_material_stored": False,
    }


def build_registry(
    shared: Mapping[str, Any] | None,
    payload: Mapping[str, Any],
) -> ProviderRegistry:

    merged: dict[str, dict[str, Any]] = {}

    # Candidate inventory: candidate truth only.
    candidate_data = _load_json(CANDIDATE_REGISTRY, {})
    for raw in candidate_data.get("providers") or []:
        if not isinstance(raw, dict):
            continue

        name = str(raw.get("name") or "").strip()
        if not name:
            continue

        pid = str(raw.get("provider_id") or _provider_id(name))

        merged[pid] = {
            **raw,
            "provider_id": pid,
            "name": name,
            "candidate": True,
        }

    # Shared-engine candidate declarations.
    for raw in (shared or {}).get("provider_candidates") or []:
        if isinstance(raw, str):
            raw = {"name": raw}

        if not isinstance(raw, dict):
            continue

        name = str(raw.get("name") or "").strip()
        if not name:
            continue

        pid = str(raw.get("provider_id") or _provider_id(name))
        base = dict(merged.get(pid) or {})
        base.update(raw)
        base["provider_id"] = pid
        base["name"] = name
        base.setdefault("candidate", True)
        merged[pid] = base

    # Allowlist adds verification/configuration truth only.
    allowlist = _load_json(ALLOWLIST, {})
    allowed = allowlist.get("providers")
    if isinstance(allowed, dict):
        for pid, raw in allowed.items():
            if not isinstance(raw, dict):
                continue

            base = dict(merged.get(str(pid)) or {})
            base.update(raw)
            base["provider_id"] = str(pid)
            base.setdefault("name", str(pid))
            merged[str(pid)] = base

    # Persisted runtime observations override static candidate metadata.
    for pid, raw in _runtime_entries().items():
        if not isinstance(raw, dict):
            continue

        base = dict(merged.get(pid) or {})
        base.update(raw)
        base["provider_id"] = pid
        base.setdefault("name", pid)
        merged[pid] = base

    # Request observations are ephemeral and highest precedence.
    for raw in payload.get("providers") or []:
        if not isinstance(raw, dict):
            continue

        name = str(raw.get("name") or raw.get("provider_id") or "").strip()
        if not name:
            continue

        pid = str(raw.get("provider_id") or _provider_id(name))
        base = dict(merged.get(pid) or {})
        base.update(raw)
        base["provider_id"] = pid
        base["name"] = name
        merged[pid] = base

    return ProviderRegistry([
        _normalise_provider(
            pid,
            str(raw.get("name") or pid),
            raw,
        )
        for pid, raw in sorted(merged.items())
    ])


# ============================================================
# SHARED CHECKS / PRIMITIVES
# ============================================================

def check_health(
    provider: Provider,
    *,
    max_age_seconds: int,
) -> Check:
    if provider.health_status not in {"READY", "HEALTHY"}:
        if provider.health_status in {"FAIL", "FAILED", "UNHEALTHY"}:
            return Check("FAIL", "provider_unhealthy")
        return Check("UNKNOWN", "health_evidence_missing")

    age = _age_seconds(provider.health_observed_at)
    if age is None:
        return Check("UNKNOWN", "health_timestamp_missing")

    if age > max_age_seconds:
        return Check(
            "FAIL",
            "health_evidence_stale",
            {"age_seconds": int(age)},
        )

    return Check(
        "PASS",
        "health_ready_not_authorized",
        {"age_seconds": int(age)},
    )


def check_certification(provider: Provider) -> Check:
    if not provider.verified:
        return Check("FAIL", "provider_not_verified")

    if not provider.certified:
        return Check("FAIL", "provider_not_certified")

    if provider.certification_observed_at is None:
        return Check("UNKNOWN", "certification_evidence_timestamp_missing")

    if (
        provider.certification_valid_until is not None
        and _now() > provider.certification_valid_until
    ):
        return Check("FAIL", "certification_expired")

    return Check("PASS", "certification_valid")


def check_evidence_freshness(
    provider: Provider,
    *,
    max_age_seconds: int,
) -> Check:
    age = _age_seconds(provider.evidence_observed_at)

    if age is None:
        return Check("UNKNOWN", "provider_evidence_missing")

    if age > max_age_seconds:
        return Check(
            "FAIL",
            "provider_evidence_stale",
            {"age_seconds": int(age)},
        )

    return Check(
        "PASS",
        "provider_evidence_fresh",
        {"age_seconds": int(age)},
    )


def check_contracts(
    provider: Provider,
    required: frozenset[str],
) -> Check:
    missing = required - provider.provided_contracts

    if missing:
        return Check(
            "FAIL",
            "required_contracts_missing",
            {"missing": sorted(missing)},
        )

    return Check("PASS", "contract_match")


def check_dependencies(
    provider: Provider,
    required: frozenset[str],
) -> Check:
    missing = required - provider.dependencies

    if missing:
        return Check(
            "FAIL",
            "required_dependencies_missing",
            {"missing": sorted(missing)},
        )

    return Check("PASS", "dependencies_satisfied")


def check_compatibility(
    provider: Provider,
    *,
    environments: frozenset[str],
    required_version: str | None,
) -> Check:
    missing_env = environments - provider.environments

    if missing_env:
        return Check(
            "FAIL",
            "environment_incompatible",
            {"missing": sorted(missing_env)},
        )

    if required_version:
        if provider.version == required_version:
            return Check("PASS", "version_exact_match")

        if required_version in provider.compatible_versions:
            return Check("PASS", "version_declared_compatible")

        return Check(
            "FAIL",
            "version_incompatible",
            {
                "required": required_version,
                "provider": provider.version,
            },
        )

    return Check("PASS", "compatibility_constraints_satisfied")


def check_privacy(
    provider: Provider,
    required_level: str,
) -> Check:
    actual = PRIVACY_LEVELS.get(provider.privacy_level)
    required = PRIVACY_LEVELS.get(required_level)

    if actual is None:
        return Check("UNKNOWN", "provider_privacy_level_unknown")

    if required is None:
        return Check("FAIL", "requested_privacy_level_invalid")

    if actual < required:
        return Check(
            "FAIL",
            "privacy_level_insufficient",
            {
                "provider": provider.privacy_level,
                "required": required_level,
            },
        )

    return Check("PASS", "privacy_compatible")


def check_side_effects(
    provider: Provider,
    allowed: frozenset[str],
) -> Check:
    forbidden = provider.side_effects - allowed

    if forbidden:
        return Check(
            "FAIL",
            "side_effect_not_allowed",
            {"forbidden": sorted(forbidden)},
        )

    return Check("PASS", "side_effect_compatible")


def check_authority(
    provider: Provider,
    granted: frozenset[str],
) -> Check:
    missing = provider.required_authorities - granted

    if missing:
        return Check(
            "FAIL",
            "provider_authority_requirement_missing",
            {"missing": sorted(missing)},
        )

    # Current operational authority is also consulted.
    decision = resolve(
        AuthorityRequest(
            action="execute_tool",
            path=f"provider:{provider.provider_id}",
        )
    )

    if decision.outcome != "ALLOW":
        return Check(
            "FAIL",
            "current_authority_denied",
            {
                "outcome": decision.outcome,
                "reason": decision.reason,
            },
        )

    # This means compatible with authority, not execution authorization
    # produced by the resolver engine itself.
    return Check(
        "PASS",
        "authority_compatible_selection_only",
        {
            "authority_source": decision.source,
            "authority_reason": decision.reason,
        },
    )


def check_adapter_contract(provider: Provider) -> Check:
    if not provider.adapter_implemented:
        return Check("FAIL", "provider_adapter_not_implemented")

    return Check("PASS", "provider_adapter_present")


# ============================================================
# ENG-CAP-006
# ============================================================

CAP_006 = (
    "provider_identity",
    "adapter_contract",
    "provider_metadata",
    "auth_scheme",
    "health",
    "certification",
    "fallback",
    "limits",
    "data_policy",
    "version_compatibility",
)


def _provider_summary(
    provider: Provider,
    *,
    max_health_age_seconds: int,
) -> dict[str, Any]:

    return {
        "provider_id": provider.provider_id,
        "name": provider.name,

        "identity": {
            "candidate": provider.candidate,
            "verified": provider.verified,
        },

        "adapter_contract": check_adapter_contract(
            provider
        ).as_dict(),

        "provider_metadata": {
            "supported_capabilities": sorted(
                provider.supported_capabilities
            ),
            "environments": sorted(provider.environments),
            "priority": provider.priority,
        },

        "auth_scheme": {
            "scheme": provider.auth_scheme,
            "credential_present": provider.credential_present,
            "credential_value_exposed": False,
        },

        "health": check_health(
            provider,
            max_age_seconds=max_health_age_seconds,
        ).as_dict(),

        "certification": check_certification(
            provider
        ).as_dict(),

        "limits": dict(provider.limits),
        "data_policy": dict(provider.data_policy),

        "version_compatibility": {
            "version": provider.version,
            "compatible_versions": sorted(
                provider.compatible_versions
            ),
        },
    }


def execute_006(
    payload: Mapping[str, Any],
    shared: Mapping[str, Any] | None,
) -> dict[str, Any]:

    action = str(payload.get("action") or "inspect")

    mutation = None

    if action == "upsert_provider":
        raw = payload.get("provider")
        if not isinstance(raw, Mapping):
            raise ValueError(
                "upsert_provider requires payload.provider object"
            )

        mutation = upsert_runtime_provider(raw)

    registry = build_registry(shared, payload)

    max_health_age = int(
        payload.get("max_health_age_seconds") or 300
    )

    providers = registry.all()

    ready = [
        p for p in providers
        if check_adapter_contract(p).passed
        and check_health(
            p,
            max_age_seconds=max_health_age,
        ).passed
        and check_certification(p).passed
    ]

    fallback = (
        sorted(
            ready,
            key=lambda p: (p.priority, p.provider_id),
        )[0]
        if ready
        else None
    )

    return {
        "ok": True,
        "engine_id": "ENG-CAP-006",
        "runtime_implementation": True,
        "operation": action,
        "mutation": mutation,

        "provider_count": len(providers),
        "providers": [
            _provider_summary(
                p,
                max_health_age_seconds=max_health_age,
            )
            for p in providers
        ],

        "fallback": {
            "provider_id": (
                fallback.provider_id if fallback else None
            ),
            "state": "PASS" if fallback else "UNKNOWN",
            "reason": (
                "eligible_fallback_selected"
                if fallback
                else "no_verified_certified_healthy_fallback"
            ),
        },

        "network_invoked": False,

        "bound_capabilities": list(CAP_006),
        "missing_capabilities": [],

        "truth_rules": [
            "CANDIDATE != VERIFIED",
            "VERIFIED != CERTIFIED",
            "HEALTH_READY != AUTHORIZED",
            "REGISTRY_ENTRY != EXECUTION_AUTHORITY",
        ],
    }


# ============================================================
# ENG-CAP-005
# ============================================================

CAP_005 = (
    "discover",
    "contract_match",
    "dependency_check",
    "compatibility_check",
    "certification_check",
    "health_check",
    "evidence_freshness",
    "privacy_check",
    "side_effect_check",
    "authority_compatibility",
    "select_provider",
    "autonomous_capability_resolution",
    "owner_authority_aware_resolution",
)


def execute_005(
    payload: Mapping[str, Any],
    shared: Mapping[str, Any] | None,
) -> dict[str, Any]:

    capability_id = str(
        payload.get("capability_id")
        or payload.get("capability")
        or ""
    ).strip()

    registry = build_registry(shared, payload)

    if not capability_id:
        return {
            "ok": True,
            "engine_id": "ENG-CAP-005",
            "runtime_implementation": True,
            "resolution_state": "NO_REQUEST",
            "selected_provider_id": None,
            "authorized": False,
            "network_invoked": False,
            "bound_capabilities": list(CAP_005),
            "missing_capabilities": [],
        }

    required_contracts = _set(payload.get("required_contracts"))
    required_dependencies = _set(
        payload.get("required_dependencies")
    )
    required_environments = _set(
        payload.get("required_environments")
        or payload.get("required_environment")
    )
    required_certifications = _set(
        payload.get("required_certifications")
    )
    allowed_side_effects = _set(
        payload.get("allowed_side_effects")
        or ["selection_only"]
    )
    granted_authorities = _set(
        payload.get("granted_authorities")
    )

    privacy_level = str(
        payload.get("privacy_level") or "standard"
    ).lower()

    required_version = (
        str(payload["required_version"])
        if payload.get("required_version")
        else None
    )

    max_health_age = int(
        payload.get("max_health_age_seconds") or 300
    )
    max_evidence_age = int(
        payload.get("max_evidence_age_seconds") or 86400
    )

    discovered = registry.discover(capability_id)

    evaluated: list[dict[str, Any]] = []
    eligible: list[Provider] = []

    for provider in discovered:

        certification = check_certification(provider)

        if required_certifications:
            missing_cert = (
                required_certifications
                - provider.certifications
            )
            if missing_cert:
                certification = Check(
                    "FAIL",
                    "required_certifications_missing",
                    {"missing": sorted(missing_cert)},
                )

        checks = {
            "contract_match": check_contracts(
                provider,
                required_contracts,
            ),
            "dependency_check": check_dependencies(
                provider,
                required_dependencies,
            ),
            "compatibility_check": check_compatibility(
                provider,
                environments=required_environments,
                required_version=required_version,
            ),
            "certification_check": certification,
            "health_check": check_health(
                provider,
                max_age_seconds=max_health_age,
            ),
            "evidence_freshness": check_evidence_freshness(
                provider,
                max_age_seconds=max_evidence_age,
            ),
            "privacy_check": check_privacy(
                provider,
                privacy_level,
            ),
            "side_effect_check": check_side_effects(
                provider,
                allowed_side_effects,
            ),
            "authority_compatibility": check_authority(
                provider,
                granted_authorities,
            ),
            "adapter_contract": check_adapter_contract(
                provider
            ),
        }

        passed = all(c.passed for c in checks.values())

        if passed:
            eligible.append(provider)

        evaluated.append({
            "provider_id": provider.provider_id,
            "eligible": passed,
            "checks": {
                name: result.as_dict()
                for name, result in checks.items()
            },
        })

    # Deterministic autonomous selection.
    eligible.sort(
        key=lambda p: (p.priority, p.provider_id)
    )

    selected = eligible[0] if eligible else None

    if selected is None:
        resolution_state = (
            "NO_PROVIDER_DISCOVERED"
            if not discovered
            else "NO_ELIGIBLE_PROVIDER"
        )
    elif len(eligible) == 1:
        resolution_state = "SELECTED"
    else:
        resolution_state = "SELECTED_BY_PRIORITY"

    return {
        "ok": True,
        "engine_id": "ENG-CAP-005",
        "runtime_implementation": True,

        "capability_id": capability_id,

        "discover": {
            "candidate_count": len(discovered),
            "candidate_provider_ids": [
                p.provider_id for p in discovered
            ],
        },

        "evaluations": evaluated,

        "autonomous_capability_resolution": {
            "state": resolution_state,
            "policy": "priority_then_provider_id",
        },

        "owner_authority_aware_resolution": {
            "checked": True,
            "selection_creates_authority": False,
        },

        "selected_provider_id": (
            selected.provider_id if selected else None
        ),

        # Resolver selection itself never authorizes provider execution.
        "authorized": False,
        "network_invoked": False,

        "bound_capabilities": list(CAP_005),
        "missing_capabilities": [],

        "truth_rules": [
            "SELECTED != AUTHORIZED",
            "PROVIDER_CAPABILITY != AUTHORITY",
            "REUSE_PROVIDER != TRUST_PROVIDER_AS_AUTHORITY",
        ],
    }


def execute_foundation_engine(
    engine_id: str,
    payload: Mapping[str, Any],
    shared: Mapping[str, Any] | None,
) -> dict[str, Any]:

    if engine_id == "ENG-CAP-005":
        return execute_005(payload, shared)

    if engine_id == "ENG-CAP-006":
        return execute_006(payload, shared)

    raise KeyError(
        f"unsupported capability foundation engine: {engine_id}"
    )
