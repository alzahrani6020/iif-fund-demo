from __future__ import annotations

import argparse
import json
import os
import signal
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parent
VAR_DIR = REPO / "var" / "runtime_supervisor"
STATE_FILE = VAR_DIR / "state.json"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def detect_parallel(value: str) -> int:
    if value != "auto":
        n = int(value)
        if n < 1:
            raise ValueError("--parallel must be >= 1")
        return n

    try:
        from afaq_agent_runtime.environment_readiness import (
            assess_environment,
        )
        report = assess_environment(REPO / "var")
        return int(report.resource_envelope.worker_slots)
    except Exception:
        return max(1, min(4, (os.cpu_count() or 2) // 2 or 1))


def write_state(data: dict[str, Any]) -> None:
    """Atomically replace the supervisor state file.

    The temp file is fully written, flushed, and closed before os.replace(),
    which avoids exposing a partially-written JSON document to readers.
    """
    VAR_DIR.mkdir(parents=True, exist_ok=True)
    tmp = STATE_FILE.with_name(
        f"{STATE_FILE.name}.{os.getpid()}.tmp"
    )
    try:
        with tmp.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(data, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, STATE_FILE)
    finally:
        try:
            if tmp.exists():
                tmp.unlink()
        except OSError:
            pass


def load_registry():
    from engines_live.registry import build_registry
    return build_registry()


def engine_ready(engine) -> tuple[bool, list[str]]:
    reasons: list[str] = []
    if getattr(engine, "live_status", None) != "ACTIVE":
        reasons.append(f"status={getattr(engine, 'live_status', None)}")
    if not callable(getattr(engine, "handler", None)):
        reasons.append("handler_not_callable")

    try:
        from engines_live.fabric import bind_capability_packages
        binding = bind_capability_packages(
            tuple(getattr(engine, "capability_packages", ()) or ()),
            tuple(getattr(engine, "package_paths", ()) or ()),
            tuple(getattr(engine, "required_capabilities", ()) or ()),
        )
        missing = list(binding.get("missing_capabilities") or [])
        if missing:
            reasons.append("missing_capabilities=" + ",".join(missing))
    except Exception as exc:
        reasons.append(f"binding_error={type(exc).__name__}:{exc}")

    return (not reasons), reasons


def readiness_snapshot(registry: dict[str, Any]) -> dict[str, Any]:
    engines: dict[str, Any] = {}
    ready_ids: list[str] = []
    blocked_ids: list[str] = []

    for engine_id, engine in sorted(registry.items()):
        ready, reasons = engine_ready(engine)
        engines[engine_id] = {
            "ready": ready,
            "name": getattr(engine, "name", engine_id),
            "kind": getattr(engine, "kind", "unknown"),
            "live_status": getattr(engine, "live_status", "unknown"),
            "adapter": getattr(engine, "adapter_name", ""),
            "reasons": reasons,
        }
        (ready_ids if ready else blocked_ids).append(engine_id)

    return {
        "timestamp": utc_now(),
        "total": len(registry),
        "ready_count": len(ready_ids),
        "blocked_count": len(blocked_ids),
        "ready_ids": ready_ids,
        "blocked_ids": blocked_ids,
        "engines": engines,
    }


def select_ready_engines(
    registry: dict[str, Any],
    snapshot: dict[str, Any],
    requested_ids: list[str],
) -> list[str]:
    """Resolve requested engines and fail closed for the default all-engine gate."""
    if requested_ids:
        unknown = [eid for eid in requested_ids if eid not in registry]
        if unknown:
            raise RuntimeError("unknown engine id(s): " + ", ".join(unknown))
        blocked = [
            eid
            for eid in requested_ids
            if not snapshot["engines"][eid]["ready"]
        ]
        if blocked:
            raise RuntimeError(
                "selected engine(s) not ready: " + ", ".join(blocked)
            )
        return requested_ids

    blocked = list(snapshot["blocked_ids"])
    if blocked:
        raise RuntimeError(
            "full runtime requires all engines ready; blocked: "
            + ", ".join(blocked)
        )

    return list(snapshot["ready_ids"])


def invoke_one(engine_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    from engines_live import invoke
    try:
        result = invoke(engine_id, payload)
        data = result.as_dict()
        return {
            "engine_id": engine_id,
            "ok": bool(data.get("ok")),
            "message": data.get("message"),
            "result": data,
        }
    except Exception as exc:
        return {
            "engine_id": engine_id,
            "ok": False,
            "message": f"{type(exc).__name__}: {exc}",
        }


def invoke_many(
    engine_ids: list[str],
    parallel: int,
    payload: dict[str, Any],
) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    with ThreadPoolExecutor(
        max_workers=parallel,
        thread_name_prefix="afaq-engine",
    ) as pool:
        futures = {
            pool.submit(invoke_one, eid, payload): eid
            for eid in engine_ids
        }
        for future in as_completed(futures):
            result = future.result()
            results.append(result)
            print(
                f"[{'OK' if result['ok'] else 'FAIL'}] "
                f"{result['engine_id']} - {result.get('message')}"
            )
    return sorted(results, key=lambda x: x["engine_id"])


def parse_ids(value: str | None) -> list[str]:
    if not value:
        return []
    return [x.strip() for x in value.split(",") if x.strip()]


def build_running_state(
    *,
    mode: str,
    parallel: int,
    started_at: str,
    snapshot: dict[str, Any],
    selected_engine_ids: list[str],
    invoke_enabled: bool,
) -> dict[str, Any]:
    return {
        "state": "RUNNING",
        "mode": mode,
        "parallel": parallel,
        "started_at": started_at,
        "last_heartbeat_at": utc_now(),
        "snapshot": snapshot,
        "selected_engine_ids": selected_engine_ids,
        "invoke_enabled": invoke_enabled,
        "policy": {
            "authority_bypass": False,
            "genesis": False,
            "training": False,
            "promotion": False,
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Unified AFAQ runtime gateway for engines and capabilities."
    )
    parser.add_argument(
        "--mode",
        choices=("full-runtime", "continuous"),
        default="full-runtime",
    )
    parser.add_argument(
        "--parallel",
        default="auto",
        help="Worker concurrency number or 'auto'.",
    )
    parser.add_argument(
        "--engines",
        help=(
            "Comma-separated engine IDs. "
            "Default: all engines, and the gate fails if any is blocked."
        ),
    )
    parser.add_argument(
        "--invoke",
        action="store_true",
        help=(
            "Actually invoke selected ready engines once. "
            "Continuous mode still supervises readiness after that one invocation."
        ),
    )
    parser.add_argument(
        "--interval",
        type=float,
        default=30.0,
        help="Continuous supervisor heartbeat interval in seconds.",
    )
    parser.add_argument(
        "--payload",
        help="Optional JSON object passed to invoked engines.",
    )
    args = parser.parse_args()

    if args.interval < 1:
        parser.error("--interval must be >= 1 second")

    try:
        parallel = detect_parallel(args.parallel)
    except Exception as exc:
        parser.error(str(exc))

    payload: dict[str, Any] = {
        "instruction": "AFAQ governed runtime execution",
        "text": "AFAQ governed runtime execution",
    }
    if args.payload:
        try:
            extra = json.loads(args.payload)
            if not isinstance(extra, dict):
                raise ValueError("payload must be a JSON object")
            payload.update(extra)
        except Exception as exc:
            parser.error(f"invalid --payload: {exc}")

    print("=" * 72)
    print("AFAQ UNIFIED RUNTIME GATEWAY")
    print("=" * 72)
    print(f"repo     : {REPO}")
    print(f"mode     : {args.mode}")
    print(f"parallel : {parallel}")
    print("policy   : governed runtime; no authority bypass")
    print("Genesis / Training / Promotion are not enabled by this gateway.")
    print()

    stopping = False
    started_at = utc_now()

    def stop_handler(signum, frame):
        nonlocal stopping
        stopping = True
        print("\nShutdown requested: entering DRAINING state...")

    signal.signal(signal.SIGINT, stop_handler)
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, stop_handler)

    def refresh() -> tuple[dict[str, Any], dict[str, Any], list[str]]:
        registry = load_registry()
        snapshot = readiness_snapshot(registry)
        ready_ids = select_ready_engines(
            registry,
            snapshot,
            parse_ids(args.engines),
        )

        state = build_running_state(
            mode=args.mode,
            parallel=parallel,
            started_at=started_at,
            snapshot=snapshot,
            selected_engine_ids=ready_ids,
            invoke_enabled=bool(args.invoke),
        )
        write_state(state)
        return registry, snapshot, ready_ids

    try:
        registry, snapshot, ready_ids = refresh()
    except Exception as exc:
        write_state({
            "state": "BLOCKED",
            "mode": args.mode,
            "started_at": started_at,
            "last_heartbeat_at": utc_now(),
            "error": f"{type(exc).__name__}: {exc}",
        })
        print(f"RUNTIME GATE: RED - {type(exc).__name__}: {exc}")
        return 1

    print(
        f"Registry online: total={snapshot['total']} "
        f"ready={snapshot['ready_count']} blocked={snapshot['blocked_count']}"
    )
    print(f"Selected engines: {len(ready_ids)}")

    if args.invoke:
        print()
        print(
            f"Invoking {len(ready_ids)} engine(s) "
            f"with max_parallel={parallel}..."
        )
        results = invoke_many(ready_ids, parallel, payload)
        failed = [r for r in results if not r["ok"]]
        state = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        state["last_invocation_at"] = utc_now()
        state["last_results"] = results
        state["last_failed_count"] = len(failed)
        write_state(state)
        if failed:
            print(f"Invocation completed with {len(failed)} failure(s).")
            if args.mode == "full-runtime":
                return 2
        else:
            print("Invocation completed successfully.")

    if args.mode == "full-runtime":
        state = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        state["state"] = "READY"
        state["finished_at"] = utc_now()
        write_state(state)
        print()
        print("RUNTIME GATE: GREEN - READY")
        print(f"State file: {STATE_FILE}")
        return 0

    print()
    print("Continuous readiness supervisor is RUNNING.")
    print("This mode does not continuously execute workloads.")
    print("Press Ctrl+C for graceful shutdown.")
    cycle = 0
    while not stopping:
        cycle += 1
        try:
            registry, snapshot, ready_ids = refresh()
            print(
                f"[heartbeat {cycle}] ready={snapshot['ready_count']}/"
                f"{snapshot['total']} selected={len(ready_ids)}"
            )
        except Exception as exc:
            print(
                f"[heartbeat {cycle}] DEGRADED - "
                f"{type(exc).__name__}: {exc}"
            )
            write_state({
                "state": "DEGRADED",
                "mode": args.mode,
                "started_at": started_at,
                "last_heartbeat_at": utc_now(),
                "error": f"{type(exc).__name__}: {exc}",
            })

        slept = 0.0
        while slept < args.interval and not stopping:
            step = min(0.5, args.interval - slept)
            time.sleep(step)
            slept += step

    write_state({
        "state": "STOPPED",
        "mode": args.mode,
        "started_at": started_at,
        "stopped_at": utc_now(),
        "parallel": parallel,
    })
    print("RUNTIME GATEWAY: STOPPED CLEANLY")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
