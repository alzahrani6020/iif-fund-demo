from __future__ import annotations

from dataclasses import dataclass

from .gap_store import (
    GapStore,
    ObservedGap,
)


@dataclass(frozen=True)
class GapQueueItem:
    fingerprint: str
    subject_ref: str
    gap_type: str
    occurrence_count: int
    priority: str
    latest_gap_id: str
    latest_reconciliation_id: str
    evidence_refs: tuple[str, ...]
    reason_codes: tuple[str, ...]


def _priority(
    gap: ObservedGap,
) -> str:
    if gap.severity == "CRITICAL":
        return "CRITICAL"

    if gap.severity == "HIGH":
        return "HIGH"

    if gap.severity == "MEDIUM":
        return "MEDIUM"

    return "LOW"


def consume_observed_gaps(
    store: GapStore,
) -> tuple[
    GapQueueItem,
    ...,
]:
    rank = {
        "CRITICAL": 0,
        "HIGH": 1,
        "MEDIUM": 2,
        "LOW": 3,
    }

    items = [
        GapQueueItem(
            fingerprint=(
                gap.fingerprint
            ),
            subject_ref=(
                gap.subject_ref
            ),
            gap_type=(
                gap.gap_type
            ),
            occurrence_count=(
                gap.occurrence_count
            ),
            priority=(
                _priority(
                    gap
                )
            ),
            latest_gap_id=(
                gap.latest_gap_id
            ),
            latest_reconciliation_id=(
                gap.latest_reconciliation_id
            ),
            evidence_refs=(
                gap.evidence_refs
            ),
            reason_codes=(
                gap.reason_codes
            ),
        )
        for gap in (
            store.observed_gaps()
        )
    ]

    return tuple(
        sorted(
            items,
            key=lambda item: (
                rank[
                    item.priority
                ],
                item.fingerprint,
            ),
        )
    )
