from __future__ import annotations
from dataclasses import asdict, dataclass
from enum import Enum
from typing import Any

REMEDIATION_CASE_SCHEMA_V1 = "AFAQ_REMEDIATION_CASE_V1"
REMEDIATION_PROPOSAL_SCHEMA_V1 = "AFAQ_REMEDIATION_PROPOSAL_V1"
RESOLUTION_CRITERION_SCHEMA_V1 = "AFAQ_RESOLUTION_CRITERION_V1"

class RemediationCaseStatus(str, Enum):
    OPEN = "OPEN"
    CLOSED = "CLOSED"

class RemediationDisposition(str, Enum):
    NONE = "NONE"
    REMEDIATED = "REMEDIATED"
    NOT_ACTIONABLE = "NOT_ACTIONABLE"
    SUPERSEDED = "SUPERSEDED"
    DUPLICATE = "DUPLICATE"
    WITHDRAWN = "WITHDRAWN"

def _require_text(value: str, field: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field} must be a non-empty string")

def _validate_refs(values: tuple[str, ...], field: str, required: bool = False) -> None:
    if not isinstance(values, tuple):
        raise TypeError(f"{field} must be tuple[str, ...]")
    for value in values:
        _require_text(value, field)
    if len(set(values)) != len(values):
        raise ValueError(f"{field} contains duplicate references")
    if required and not values:
        raise ValueError(f"{field} must not be empty")

@dataclass(frozen=True)
class RemediationCase:
    remediation_case_id: str
    subject_ref: str
    source_gap_refs: tuple[str, ...]
    status: RemediationCaseStatus
    disposition: RemediationDisposition
    proposal_refs: tuple[str, ...]
    resolution_criterion_refs: tuple[str, ...]
    evidence_refs: tuple[str, ...]
    opened_at: str
    closed_at: str | None
    schema_version: str = REMEDIATION_CASE_SCHEMA_V1

    def __post_init__(self) -> None:
        if self.schema_version != REMEDIATION_CASE_SCHEMA_V1:
            raise ValueError("unsupported RemediationCase schema")
        _require_text(self.remediation_case_id, "remediation_case_id")
        _require_text(self.subject_ref, "subject_ref")
        _require_text(self.opened_at, "opened_at")
        if self.closed_at is not None:
            _require_text(self.closed_at, "closed_at")
        _validate_refs(self.source_gap_refs, "source_gap_refs", True)
        _validate_refs(self.proposal_refs, "proposal_refs")
        _validate_refs(self.resolution_criterion_refs, "resolution_criterion_refs")
        _validate_refs(self.evidence_refs, "evidence_refs")
        if not isinstance(self.status, RemediationCaseStatus):
            raise TypeError("status must be RemediationCaseStatus")
        if not isinstance(self.disposition, RemediationDisposition):
            raise TypeError("disposition must be RemediationDisposition")
        if self.status is RemediationCaseStatus.OPEN:
            if self.disposition is not RemediationDisposition.NONE:
                raise ValueError("OPEN remediation case must have disposition NONE")
            if self.closed_at is not None:
                raise ValueError("OPEN remediation case must not have closed_at")
        else:
            if self.disposition is RemediationDisposition.NONE:
                raise ValueError("CLOSED remediation case requires disposition")
            if self.closed_at is None:
                raise ValueError("CLOSED remediation case requires closed_at")
        if self.disposition is RemediationDisposition.REMEDIATED:
            if self.status is not RemediationCaseStatus.CLOSED:
                raise ValueError("REMEDIATED requires CLOSED status")
            if not self.resolution_criterion_refs:
                raise ValueError("REMEDIATED requires resolution_criterion_refs")
            if not self.evidence_refs:
                raise ValueError("REMEDIATED requires explicit evidence_refs")

    def as_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["status"] = self.status.value
        data["disposition"] = self.disposition.value
        for f in ("source_gap_refs","proposal_refs","resolution_criterion_refs","evidence_refs"):
            data[f] = list(data[f])
        return data

@dataclass(frozen=True)
class RemediationProposal:
    remediation_proposal_id: str
    remediation_case_id: str
    subject_ref: str
    source_gap_refs: tuple[str, ...]
    proposed_change_refs: tuple[str, ...]
    verification_plan_refs: tuple[str, ...]
    risk_refs: tuple[str, ...]
    evidence_refs: tuple[str, ...]
    created_at: str
    schema_version: str = REMEDIATION_PROPOSAL_SCHEMA_V1

    def __post_init__(self) -> None:
        if self.schema_version != REMEDIATION_PROPOSAL_SCHEMA_V1:
            raise ValueError("unsupported RemediationProposal schema")
        for f, v in (
            ("remediation_proposal_id", self.remediation_proposal_id),
            ("remediation_case_id", self.remediation_case_id),
            ("subject_ref", self.subject_ref),
            ("created_at", self.created_at),
        ):
            _require_text(v, f)
        _validate_refs(self.source_gap_refs, "source_gap_refs", True)
        _validate_refs(self.proposed_change_refs, "proposed_change_refs", True)
        _validate_refs(self.verification_plan_refs, "verification_plan_refs", True)
        _validate_refs(self.risk_refs, "risk_refs")
        _validate_refs(self.evidence_refs, "evidence_refs")

    def as_dict(self) -> dict[str, Any]:
        data = asdict(self)
        for f in ("source_gap_refs","proposed_change_refs","verification_plan_refs","risk_refs","evidence_refs"):
            data[f] = list(data[f])
        return data

@dataclass(frozen=True)
class ResolutionCriterion:
    resolution_criterion_id: str
    remediation_case_id: str
    subject_ref: str
    expected_ref: str
    verification_method_ref: str
    required_evidence_refs: tuple[str, ...]
    created_at: str
    schema_version: str = RESOLUTION_CRITERION_SCHEMA_V1

    def __post_init__(self) -> None:
        if self.schema_version != RESOLUTION_CRITERION_SCHEMA_V1:
            raise ValueError("unsupported ResolutionCriterion schema")
        for f, v in (
            ("resolution_criterion_id", self.resolution_criterion_id),
            ("remediation_case_id", self.remediation_case_id),
            ("subject_ref", self.subject_ref),
            ("expected_ref", self.expected_ref),
            ("verification_method_ref", self.verification_method_ref),
            ("created_at", self.created_at),
        ):
            _require_text(v, f)
        _validate_refs(self.required_evidence_refs, "required_evidence_refs", True)

    def as_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["required_evidence_refs"] = list(self.required_evidence_refs)
        return data
