"""Independent certification/trust for capability usability.

The handler registry creates implementations. This module evaluates them.
Self-approval is forbidden.
SANDBOX_PASS != CERTIFIED.
CERTIFIED_CANDIDATE != ACTIVE_CAPABILITY.
"""

from __future__ import annotations

import hashlib
import json
import re
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Mapping

from .handlers import (
    ARTIFACT_IMPLEMENTATION_SOURCE,
    CANDIDATE_BEHAVIORALLY_CERTIFIED,
    CANDIDATE_CERTIFIED,
    CANDIDATE_INDEPENDENTLY_REVIEWED,
    CERTIFICATION_KIND_BEHAVIORAL,
    CERTIFICATION_KIND_PIPELINE,
    BehavioralCertificationRecord,
    BehavioralEvaluationResult,
    CandidateBehaviorEvidence,
    CandidateCertificationRecord,
    CandidateEvaluationRecord,
    CandidateRegistrationError,
    CandidateReviewRecord,
    CriterionVerdict,
    export_candidate_artifact,
    get_candidate_behavior,
    get_candidate_behavior_evaluation,
    get_candidate_evaluation,
    get_candidate_review,
    get_candidate_sandbox,
    handler_version,
    has_implementation,
    record_candidate_behavior,
    record_candidate_behavior_certification,
    record_candidate_behavior_evaluation,
    record_candidate_certification,
    record_candidate_evaluation,
    record_candidate_review,
    reject_caller_claims,
)
from .sandbox import SandboxResult

_ALLOWED_CRITERIA_FIELDS = frozenset(
    {
        "criteria_id",
        "capability_id",
        "expected_artifact_hash",
        "expected_marker",
    }
)
_FORBIDDEN_CRITERIA_KEYS = frozenset(
    {
        "result",
        "evaluation_passed",
        "passed",
        "certified",
        "active",
        "current",
        "promoted",
    }
)
_BEHAVIOR_CONTRACT_FIELDS = (
    "requirement_id",
    "capability_id",
    "input_contract",
    "output_contract",
    "acceptance_criteria",
    "constraints",
    "artifact_hash",
)
_VERDICT_PASS = "PASS"
_VERDICT_FAIL = "FAIL"
_VERDICT_INSUFFICIENT = "INSUFFICIENT_EVIDENCE"
_ISOLATION_CONSTRAINTS = {
    "no_network": "NETWORK_ISOLATION_PARTIAL",
    "no_filesystem_mutation": "FILESYSTEM_ISOLATION_PARTIAL",
    "no_filesystem": "FILESYSTEM_ISOLATION_PARTIAL",
    "no_subprocess": "SUBPROCESS_ISOLATION_PARTIAL",
    "no_credentials": "SECRET_ACCESS_BLOCK_PARTIAL",
}
_DETERMINISM_KEYS = frozenset(
    {"deterministic", "determinism", "deterministic_output"}
)
_SELF_AUTHORITY_KEYS = frozenset(
    {"passed", "certified", "valid", "evaluation_passed", "active", "promoted"}
)

STATES = (
    "UNVERIFIED",
    "VERIFIED",
    "CERTIFIED",
    "REJECTED",
    "QUARANTINED",
)


@dataclass(frozen=True)
class CertificationRecord:
    capability_id: str
    state: str
    version: str | None
    provenance: str
    contract_valid: bool
    implemented: bool
    sandbox_validated: bool
    tests_present: bool
    evidence_complete: bool
    reason: str
    certified_by: str


class CertificationError(RuntimeError):
    pass


def evaluate(
    capability_id: str,
    *,
    sandbox: SandboxResult | None,
    contract_valid: bool,
    tests_present: bool,
    evidence: dict[str, Any] | None = None,
    requester: str = "generator",
) -> CertificationRecord:
    implemented = has_implementation(capability_id)
    version = handler_version(capability_id)
    sandbox_validated = bool(sandbox and sandbox.validated)
    evidence = evidence or {}
    evidence_complete = bool(
        capability_id
        and version
        and evidence.get("provenance")
        and contract_valid
        and sandbox_validated
        and tests_present
    )

    if requester == "generator":
        # Evaluation may proceed; certification grant cannot be self-issued.
        pass

    if not implemented:
        return CertificationRecord(
            capability_id=capability_id,
            state="REJECTED",
            version=version,
            provenance=str(evidence.get("provenance", "descriptor_only")),
            contract_valid=contract_valid,
            implemented=False,
            sandbox_validated=False,
            tests_present=tests_present,
            evidence_complete=False,
            reason="DESCRIPTOR_EXISTS_NOT_IMPLEMENTED",
            certified_by="certifier",
        )

    if sandbox is None:
        return CertificationRecord(
            capability_id=capability_id,
            state="UNVERIFIED",
            version=version,
            provenance=str(evidence.get("provenance", "handler_registry")),
            contract_valid=contract_valid,
            implemented=True,
            sandbox_validated=False,
            tests_present=tests_present,
            evidence_complete=False,
            reason="SANDBOX_REQUIRED",
            certified_by="certifier",
        )

    if not sandbox.validated:
        return CertificationRecord(
            capability_id=capability_id,
            state="QUARANTINED",
            version=version,
            provenance=str(evidence.get("provenance", "handler_registry")),
            contract_valid=contract_valid,
            implemented=True,
            sandbox_validated=False,
            tests_present=tests_present,
            evidence_complete=False,
            reason="SANDBOX_VALIDATION_FAILED",
            certified_by="certifier",
        )

    if not evidence_complete:
        return CertificationRecord(
            capability_id=capability_id,
            state="VERIFIED",
            version=version,
            provenance=str(evidence.get("provenance", "handler_registry")),
            contract_valid=contract_valid,
            implemented=True,
            sandbox_validated=True,
            tests_present=tests_present,
            evidence_complete=False,
            reason="REQUIRED_CERTIFICATION_EVIDENCE_INCOMPLETE",
            certified_by="certifier",
        )

    if requester == "generator":
        return CertificationRecord(
            capability_id=capability_id,
            state="VERIFIED",
            version=version,
            provenance=str(evidence["provenance"]),
            contract_valid=True,
            implemented=True,
            sandbox_validated=True,
            tests_present=True,
            evidence_complete=True,
            reason="SELF_CERTIFICATION_FORBIDDEN",
            certified_by="certifier",
        )

    return CertificationRecord(
        capability_id=capability_id,
        state="CERTIFIED",
        version=version,
        provenance=str(evidence["provenance"]),
        contract_valid=True,
        implemented=True,
        sandbox_validated=True,
        tests_present=True,
        evidence_complete=True,
        reason="INDEPENDENT_CERTIFICATION",
        certified_by="certifier",
    )


def is_usable(record: CertificationRecord) -> bool:
    return (
        record.implemented
        and record.sandbox_validated
        and record.state == "CERTIFIED"
    )


def review_candidate(
    capability_id: str,
    *,
    requester: str = "generator",
    claims: dict[str, Any] | None = None,
) -> CandidateReviewRecord:
    """Independent candidate review. Never certifies or activates."""
    reject_caller_claims(claims)
    record, _blob = export_candidate_artifact(capability_id)
    sandbox = get_candidate_sandbox(capability_id)
    if sandbox is None:
        raise CandidateRegistrationError("MISSING_SANDBOX_EVIDENCE")
    if sandbox.artifact_hash != record.artifact_hash:
        raise CandidateRegistrationError("CROSS_ARTIFACT_EVIDENCE")
    if not sandbox.validated:
        return CandidateReviewRecord(
            capability_id=record.capability_id,
            artifact_hash=record.artifact_hash,
            state="REJECTED",
            reason="SANDBOX_VALIDATION_FAILED",
            reviewed_by="reviewer",
            sandbox_evidence_ref=sandbox.evidence_ref,
            registration_evidence=record.registration_evidence,
        )
    if requester in {"generator", "learner", "evaluator"}:
        return CandidateReviewRecord(
            capability_id=record.capability_id,
            artifact_hash=record.artifact_hash,
            state="REJECTED",
            reason="SELF_REVIEW_FORBIDDEN",
            reviewed_by="reviewer",
            sandbox_evidence_ref=sandbox.evidence_ref,
            registration_evidence=record.registration_evidence,
        )
    review = CandidateReviewRecord(
        capability_id=record.capability_id,
        artifact_hash=record.artifact_hash,
        state=CANDIDATE_INDEPENDENTLY_REVIEWED,
        reason="INDEPENDENT_REVIEW",
        reviewed_by="reviewer",
        sandbox_evidence_ref=sandbox.evidence_ref,
        registration_evidence=record.registration_evidence,
    )
    record_candidate_review(review)
    return review


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _require_reviewed_candidate(capability_id: str):
    record, blob = export_candidate_artifact(capability_id)
    current_hash = hashlib.sha256(blob).hexdigest()
    if current_hash != record.artifact_hash:
        raise CandidateRegistrationError("CANDIDATE_TAMPERED")
    sandbox = get_candidate_sandbox(capability_id)
    if sandbox is None or not sandbox.validated:
        raise CandidateRegistrationError("MISSING_SANDBOX_EVIDENCE")
    if sandbox.artifact_hash != record.artifact_hash:
        raise CandidateRegistrationError("CROSS_ARTIFACT_EVIDENCE")
    review = get_candidate_review(capability_id)
    if review is None or review.state != CANDIDATE_INDEPENDENTLY_REVIEWED:
        raise CandidateRegistrationError("MISSING_REVIEW_EVIDENCE")
    if review.artifact_hash != record.artifact_hash:
        raise CandidateRegistrationError("CROSS_ARTIFACT_EVIDENCE")
    return record, blob, sandbox, review


def _criteria_contract(
    criteria: Mapping[str, Any] | None,
    capability_id: str,
) -> tuple[str | None, str | None, bytes | None, str]:
    if criteria is None or not isinstance(criteria, Mapping) or not criteria:
        return None, None, None, "INSUFFICIENT_CRITERIA"
    keys = set(criteria)
    if keys & _FORBIDDEN_CRITERIA_KEYS:
        raise CandidateRegistrationError("FORBIDDEN_CANDIDATE_CLAIM")
    if keys - _ALLOWED_CRITERIA_FIELDS:
        return None, None, None, "INSUFFICIENT_CRITERIA"
    criteria_id = criteria.get("criteria_id")
    expected_hash = criteria.get("expected_artifact_hash")
    if not isinstance(criteria_id, str) or not criteria_id.strip():
        return None, None, None, "INSUFFICIENT_CRITERIA"
    if not isinstance(expected_hash, str) or len(expected_hash.strip()) != 64:
        return None, None, None, "INSUFFICIENT_CRITERIA"
    bound_id = criteria.get("capability_id")
    if bound_id is not None and bound_id != capability_id:
        return None, None, None, "INSUFFICIENT_CRITERIA"
    marker_raw = criteria.get("expected_marker")
    marker: bytes | None
    if marker_raw is None:
        marker = None
    elif isinstance(marker_raw, bytes):
        marker = marker_raw
    elif isinstance(marker_raw, str):
        marker = marker_raw.encode("utf-8")
    else:
        return None, None, None, "INSUFFICIENT_CRITERIA"
    return criteria_id.strip(), expected_hash.strip().lower(), marker, ""


def evaluate_candidate(
    capability_id: str,
    *,
    criteria: Mapping[str, Any] | None,
    requester: str = "generator",
    claims: Mapping[str, Any] | None = None,
) -> CandidateEvaluationRecord:
    """Evaluate a reviewed candidate against explicit artifact criteria."""
    reject_caller_claims(claims)
    record, blob, sandbox, review = _require_reviewed_candidate(capability_id)
    criteria_id, expected_hash, marker, criteria_gap = _criteria_contract(
        criteria, record.capability_id
    )
    refs = (
        record.registration_evidence,
        sandbox.evidence_ref,
        review.sandbox_evidence_ref,
    )
    if requester == "generator":
        evaluation = CandidateEvaluationRecord(
            evaluation_id=uuid.uuid4().hex,
            capability_id=record.capability_id,
            artifact_hash=record.artifact_hash,
            criteria_reference=criteria_id or "NONE",
            result="INSUFFICIENT_EVIDENCE",
            reason="SELF_EVALUATION_FORBIDDEN",
            evidence_refs=refs,
            timestamp=_now(),
        )
        record_candidate_evaluation(evaluation)
        return evaluation
    if criteria_gap:
        evaluation = CandidateEvaluationRecord(
            evaluation_id=uuid.uuid4().hex,
            capability_id=record.capability_id,
            artifact_hash=record.artifact_hash,
            criteria_reference="NONE",
            result="INSUFFICIENT_EVIDENCE",
            reason="INSUFFICIENT_CRITERIA",
            evidence_refs=refs,
            timestamp=_now(),
        )
        record_candidate_evaluation(evaluation)
        return evaluation
    current_hash = hashlib.sha256(blob).hexdigest()
    passed = current_hash == expected_hash and (
        marker is None or marker in blob
    )
    evaluation = CandidateEvaluationRecord(
        evaluation_id=uuid.uuid4().hex,
        capability_id=record.capability_id,
        artifact_hash=record.artifact_hash,
        criteria_reference=str(criteria_id),
        result="PASSED" if passed else "FAILED",
        reason="CRITERIA_MET" if passed else "CRITERIA_NOT_MET",
        evidence_refs=refs + (str(criteria_id),),
        timestamp=_now(),
    )
    record_candidate_evaluation(evaluation)
    return evaluation


def certify_candidate(
    capability_id: str,
    *,
    requester: str = "generator",
    claims: Mapping[str, Any] | None = None,
) -> CandidateCertificationRecord:
    """Certify a passed candidate evaluation. Never activates."""
    reject_caller_claims(claims)
    record, _blob, sandbox, review = _require_reviewed_candidate(capability_id)
    evaluation = get_candidate_evaluation(capability_id)
    if evaluation is None:
        raise CandidateRegistrationError("MISSING_EVALUATION_EVIDENCE")
    if evaluation.artifact_hash != record.artifact_hash:
        raise CandidateRegistrationError("CROSS_ARTIFACT_EVIDENCE")
    if requester == "generator":
        raise CandidateRegistrationError("SELF_CERTIFICATION_FORBIDDEN")
    if evaluation.result == "FAILED":
        raise CandidateRegistrationError("FAILED_EVALUATION")
    if evaluation.result != "PASSED":
        raise CandidateRegistrationError("INSUFFICIENT_EVIDENCE")
    certification = CandidateCertificationRecord(
        certification_id=uuid.uuid4().hex,
        capability_id=record.capability_id,
        artifact_hash=record.artifact_hash,
        sandbox_evidence_ref=sandbox.evidence_ref,
        review_evidence_ref=(
            f"candidate-review:{record.capability_id}:{review.artifact_hash[:16]}"
        ),
        evaluation_evidence_ref=f"candidate-eval:{evaluation.evaluation_id}",
        certified_at=_now(),
        certifier="certifier",
        status=CANDIDATE_CERTIFIED,
        certification_kind=CERTIFICATION_KIND_PIPELINE,
    )
    record_candidate_certification(certification)
    return certification


def _behavioral_certification_gap(evaluation: BehavioralEvaluationResult | None) -> str | None:
    if evaluation is None:
        return "MISSING_BEHAVIORAL_EVALUATION"
    if evaluation.status == "FAILED":
        return "FAILED_EVALUATION"
    if evaluation.status != "PASSED":
        return "INSUFFICIENT_EVIDENCE"
    if evaluation.input_contract_result == _VERDICT_FAIL:
        return "INPUT_CONTRACT_FAILED"
    if evaluation.input_contract_result != _VERDICT_PASS:
        return "INSUFFICIENT_EVIDENCE"
    if evaluation.output_contract_result == _VERDICT_FAIL:
        return "OUTPUT_CONTRACT_FAILED"
    if evaluation.output_contract_result != _VERDICT_PASS:
        return "INSUFFICIENT_EVIDENCE"
    for item in evaluation.acceptance_criteria_results:
        if item.result == _VERDICT_FAIL:
            return "ACCEPTANCE_CRITERIA_FAILED"
        if item.result != _VERDICT_PASS:
            return "ACCEPTANCE_CRITERIA_INSUFFICIENT"
    for item in evaluation.constraint_results:
        if item.result == _VERDICT_FAIL:
            return "CONSTRAINT_FAILED"
        if item.result != _VERDICT_PASS:
            return "CONSTRAINT_INSUFFICIENT"
    return None


def certify_candidate_behavior(
    capability_id: str,
    *,
    requester: str = "generator",
    claims: Mapping[str, Any] | None = None,
) -> BehavioralCertificationRecord:
    """Issue behavioral certification from persisted evidence. Never activates."""
    reject_caller_claims(claims)
    if requester == "generator":
        raise CandidateRegistrationError("SELF_CERTIFICATION_FORBIDDEN")
    record, blob = export_candidate_artifact(capability_id)
    current_hash = hashlib.sha256(blob).hexdigest()
    if current_hash != record.artifact_hash:
        raise CandidateRegistrationError("CANDIDATE_TAMPERED")
    if record.artifact_class != ARTIFACT_IMPLEMENTATION_SOURCE:
        raise CandidateRegistrationError("SPECIFICATION_ARTIFACT_NOT_CERTIFIABLE")
    sandbox = get_candidate_sandbox(capability_id)
    review = get_candidate_review(capability_id)
    behavior = get_candidate_behavior(capability_id)
    evaluation = get_candidate_behavior_evaluation(capability_id)
    if sandbox is None or not sandbox.validated:
        raise CandidateRegistrationError("MISSING_SANDBOX_EVIDENCE")
    if review is None or review.state != CANDIDATE_INDEPENDENTLY_REVIEWED:
        raise CandidateRegistrationError("MISSING_REVIEW_EVIDENCE")
    if behavior is None:
        raise CandidateRegistrationError("MISSING_BEHAVIOR_EVIDENCE")
    hashes = {
        current_hash,
        record.artifact_hash,
        sandbox.artifact_hash,
        review.artifact_hash,
        behavior.artifact_hash,
    }
    if evaluation is not None:
        hashes.add(evaluation.artifact_hash)
    if len(hashes) != 1:
        raise CandidateRegistrationError("CROSS_ARTIFACT_CERTIFICATION_DENIED")
    gap = _behavioral_certification_gap(evaluation)
    if gap:
        raise CandidateRegistrationError(gap)
    if evaluation.requirement_id != behavior.requirement_id:
        raise CandidateRegistrationError("CROSS_ARTIFACT_CERTIFICATION_DENIED")
    certification = BehavioralCertificationRecord(
        certification_id=uuid.uuid4().hex,
        certification_kind=CERTIFICATION_KIND_BEHAVIORAL,
        capability_id=record.capability_id,
        artifact_hash=current_hash,
        requirement_id=evaluation.requirement_id,
        registration_ref=record.registration_evidence,
        sandbox_ref=sandbox.evidence_ref,
        review_ref=f"candidate-review:{record.capability_id}:{review.artifact_hash[:16]}",
        behavior_evidence_ref=behavior.behavior_evidence_id,
        behavioral_evaluation_ref=evaluation.evaluation_id,
        criteria_result_refs=tuple(
            f"{item.criterion_id}:{item.result}" for item in evaluation.acceptance_criteria_results
        ),
        constraints_result_refs=tuple(
            f"{item.criterion_id}:{item.result}" for item in evaluation.constraint_results
        ),
        certified_at=_now(),
        certifier="certifier",
        status=CANDIDATE_BEHAVIORALLY_CERTIFIED,
    )
    record_candidate_behavior_certification(certification)
    return certification


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _embedded_contract(source: str) -> dict[str, Any]:
    refs: dict[str, Any] = {}
    mapping = {
        "input_contract_ref:": "input_contract",
        "output_contract_ref:": "output_contract",
        "acceptance_criteria_ref:": "acceptance_criteria",
        "requirement_id:": "requirement_id",
        "capability_id:": "capability_id",
    }
    for line in source.splitlines():
        text = line[1:].strip() if line.startswith("#") else line.strip()
        for prefix, key in mapping.items():
            if text.startswith(prefix):
                raw = text[len(prefix):].strip()
                if key in {"requirement_id", "capability_id"}:
                    refs[key] = raw
                else:
                    refs[key] = json.loads(raw)
    return refs


def _type_verdict(actual: Any, declared: Any) -> str:
    if isinstance(declared, dict):
        if not isinstance(actual, dict):
            return _VERDICT_FAIL
        results = []
        for key, spec in declared.items():
            if key not in actual:
                results.append(_VERDICT_FAIL)
                continue
            results.append(_type_verdict(actual[key], spec))
        if _VERDICT_FAIL in results:
            return _VERDICT_FAIL
        if _VERDICT_INSUFFICIENT in results:
            return _VERDICT_INSUFFICIENT
        return _VERDICT_PASS
    if not isinstance(declared, str):
        return _VERDICT_INSUFFICIENT
    name = declared.strip().lower()
    if name in {"object", "dict"}:
        return _VERDICT_PASS if isinstance(actual, dict) else _VERDICT_FAIL
    if name in {"string", "str"}:
        return _VERDICT_PASS if isinstance(actual, str) else _VERDICT_FAIL
    if name == "bool":
        return _VERDICT_PASS if isinstance(actual, bool) else _VERDICT_FAIL
    if name == "int":
        return _VERDICT_PASS if isinstance(actual, int) and not isinstance(actual, bool) else _VERDICT_FAIL
    if name in {"number", "float"}:
        return _VERDICT_PASS if isinstance(actual, (int, float)) and not isinstance(actual, bool) else _VERDICT_FAIL
    if name == "hex":
        if not isinstance(actual, str) or not actual:
            return _VERDICT_FAIL
        return _VERDICT_PASS if re.fullmatch(r"[0-9a-fA-F]+", actual) else _VERDICT_FAIL
    return _VERDICT_INSUFFICIENT


def _combine(*results: str) -> str:
    if _VERDICT_FAIL in results:
        return _VERDICT_FAIL
    if _VERDICT_INSUFFICIENT in results:
        return _VERDICT_INSUFFICIENT
    return _VERDICT_PASS


def _status_from_parts(*results: str) -> str:
    combined = _combine(*results)
    if combined == _VERDICT_FAIL:
        return "FAILED"
    if combined == _VERDICT_INSUFFICIENT:
        return "INSUFFICIENT_EVIDENCE"
    return "PASSED"


def _criterion(
    criterion_id: str,
    result: str,
    reason: str,
    refs: tuple[str, ...],
) -> CriterionVerdict:
    return CriterionVerdict(
        criterion_id=criterion_id,
        result=result,
        reason=reason,
        evidence_refs=refs,
    )


def _determinism_verdict(
    capability_id: str,
    test_input: Mapping[str, Any],
    first: CandidateBehaviorEvidence,
    refs: tuple[str, ...],
) -> CriterionVerdict:
    from .sandbox import BEHAVIOR_EXECUTED, execute_candidate_behavior

    second = execute_candidate_behavior(capability_id, test_input=test_input)
    record_candidate_behavior(first)
    if second.status != BEHAVIOR_EXECUTED or first.result_digest is None:
        return _criterion("deterministic_output", _VERDICT_FAIL, "DETERMINISM_RERUN_FAILED", refs)
    if second.result_digest == first.result_digest and _canonical(
        second.return_value
    ) == _canonical(first.return_value):
        return _criterion("deterministic_output", _VERDICT_PASS, "DETERMINISM_MATCHED", refs)
    return _criterion("deterministic_output", _VERDICT_FAIL, "DETERMINISM_MISMATCH", refs)


def _eval_named(
    key: str,
    value: Any,
    *,
    behavior: CandidateBehaviorEvidence,
    blob: bytes,
    return_value: Any,
    determinism: CriterionVerdict | None,
    refs: tuple[str, ...],
) -> CriterionVerdict:
    if key in _SELF_AUTHORITY_KEYS:
        return _criterion(key, _VERDICT_INSUFFICIENT, "CANDIDATE_SELF_CLAIM_IGNORED", refs)
    if key in _ISOLATION_CONSTRAINTS:
        return _criterion(key, _VERDICT_INSUFFICIENT, _ISOLATION_CONSTRAINTS[key], refs)
    if key == "pure":
        return _criterion(key, _VERDICT_INSUFFICIENT, "PURITY_NOT_PROVEN", refs)
    if key in _DETERMINISM_KEYS:
        if not value:
            return _criterion(key, _VERDICT_INSUFFICIENT, "DETERMINISM_NOT_REQUIRED", refs)
        if determinism is None:
            return _criterion(key, _VERDICT_INSUFFICIENT, "DETERMINISM_SINGLE_RUN", refs)
        return _criterion(key, determinism.result, determinism.reason, refs)
    if key == "bounded_duration_ms":
        if not isinstance(value, (int, float)) or behavior.duration_ms is None:
            return _criterion(key, _VERDICT_INSUFFICIENT, "DURATION_NOT_COMPARABLE", refs)
        if behavior.duration_ms <= float(value):
            return _criterion(key, _VERDICT_PASS, "DURATION_WITHIN_BOUND", refs)
        return _criterion(key, _VERDICT_FAIL, "DURATION_EXCEEDED", refs)
    if key == "expected_capability_id":
        got = return_value.get("capability_id") if isinstance(return_value, dict) else None
        if got == value:
            return _criterion(key, _VERDICT_PASS, "CAPABILITY_ID_MATCHED", refs)
        return _criterion(key, _VERDICT_FAIL, "CAPABILITY_ID_MISMATCH", refs)
    if key == "expected_ok":
        got = return_value.get("ok") if isinstance(return_value, dict) else None
        if got is value:
            return _criterion(key, _VERDICT_PASS, "OK_MATCHED", refs)
        return _criterion(key, _VERDICT_FAIL, "OK_MISMATCH", refs)
    if key == "required_output_keys":
        if not isinstance(value, (list, tuple)) or not isinstance(return_value, dict):
            return _criterion(key, _VERDICT_FAIL, "REQUIRED_KEYS_UNMET", refs)
        missing = [item for item in value if item not in return_value]
        if missing:
            return _criterion(key, _VERDICT_FAIL, "REQUIRED_KEYS_UNMET", refs)
        return _criterion(key, _VERDICT_PASS, "REQUIRED_KEYS_PRESENT", refs)
    if key == "digest_is_hex":
        digest = return_value.get("digest") if isinstance(return_value, dict) else None
        if _type_verdict(digest, "hex") == _VERDICT_PASS:
            return _criterion(key, _VERDICT_PASS, "DIGEST_HEX", refs)
        return _criterion(key, _VERDICT_FAIL, "DIGEST_NOT_HEX", refs)
    if key == "expected_marker":
        marker = str(value).encode("utf-8")
        if marker in blob:
            return _criterion(key, _VERDICT_PASS, "MARKER_PRESENT", refs)
        return _criterion(key, _VERDICT_FAIL, "MARKER_ABSENT", refs)
    if key == "expected_output":
        if _canonical(return_value) == _canonical(value):
            return _criterion(key, _VERDICT_PASS, "OUTPUT_MATCHED", refs)
        return _criterion(key, _VERDICT_FAIL, "OUTPUT_MISMATCH", refs)
    if key == "approved_proposal_criteria":
        if isinstance(value, (list, tuple)) and all(isinstance(item, str) and item.strip() for item in value):
            return _criterion(key, _VERDICT_PASS, "APPROVED_CRITERIA_BOUND", refs)
        return _criterion(key, _VERDICT_FAIL, "APPROVED_CRITERIA_MISSING", refs)
    return _criterion(key, _VERDICT_INSUFFICIENT, "CRITERION_NOT_MACHINE_VERIFIABLE", refs)


def evaluate_candidate_behavior(
    capability_id: str,
    *,
    requirement: Mapping[str, Any] | None,
    test_input: Mapping[str, Any] | None = None,
    requester: str = "generator",
    claims: Mapping[str, Any] | None = None,
) -> BehavioralEvaluationResult:
    """Compare recorded sandbox behavior to a predeclared contract.

    Does not certify, activate, or change evaluate_candidate semantics.
    """
    reject_caller_claims(claims)
    record, blob = export_candidate_artifact(capability_id)
    current_hash = hashlib.sha256(blob).hexdigest()
    if current_hash != record.artifact_hash:
        raise CandidateRegistrationError("CANDIDATE_TAMPERED")
    if record.artifact_class != ARTIFACT_IMPLEMENTATION_SOURCE:
        raise CandidateRegistrationError("SPECIFICATION_ARTIFACT_NOT_EVALUABLE")
    behavior = get_candidate_behavior(capability_id)
    if behavior is None:
        raise CandidateRegistrationError("MISSING_BEHAVIOR_EVIDENCE")
    if behavior.artifact_hash != current_hash:
        raise CandidateRegistrationError("CROSS_ARTIFACT_EVIDENCE")
    if (
        not isinstance(requirement, Mapping)
        or not requirement
        or any(field not in requirement for field in _BEHAVIOR_CONTRACT_FIELDS)
    ):
        raise CandidateRegistrationError("INSUFFICIENT_CONTRACT")
    if requirement.get("capability_id") != record.capability_id:
        raise CandidateRegistrationError("INSUFFICIENT_CONTRACT")
    if requirement.get("artifact_hash") != current_hash:
        raise CandidateRegistrationError("CANDIDATE_TAMPERED")
    if requirement.get("requirement_id") != behavior.requirement_id:
        raise CandidateRegistrationError("CROSS_ARTIFACT_EVIDENCE")
    if set(requirement) & _FORBIDDEN_CRITERIA_KEYS:
        raise CandidateRegistrationError("FORBIDDEN_CANDIDATE_CLAIM")

    from .sandbox import _canonical_digest

    if not isinstance(test_input, Mapping) or not test_input:
        raise CandidateRegistrationError("STALE_BEHAVIOR_EVIDENCE")
    if _canonical_digest(dict(test_input)) != behavior.input_digest:
        raise CandidateRegistrationError("STALE_BEHAVIOR_EVIDENCE")

    source = blob.decode("utf-8", errors="replace")
    embedded = _embedded_contract(source)
    if embedded:
        for key in ("input_contract", "output_contract", "acceptance_criteria"):
            if key in embedded and _canonical(embedded[key]) != _canonical(requirement[key]):
                raise CandidateRegistrationError("CONTRACT_MISMATCH")
        if (
            embedded.get("requirement_id")
            and embedded["requirement_id"] != requirement["requirement_id"]
        ):
            raise CandidateRegistrationError("CONTRACT_MISMATCH")
        if (
            embedded.get("capability_id")
            and embedded["capability_id"] != requirement["capability_id"]
        ):
            raise CandidateRegistrationError("CONTRACT_MISMATCH")

    refs = (
        record.registration_evidence,
        behavior.behavior_evidence_id,
        str(requirement["requirement_id"]),
    )
    criteria_reference = _canonical(requirement["acceptance_criteria"])
    needs_determinism = False
    declared_criteria = requirement["acceptance_criteria"]
    declared_constraints = requirement["constraints"]
    if isinstance(declared_criteria, Mapping):
        needs_determinism = any(
            key in _DETERMINISM_KEYS and declared_criteria[key]
            for key in declared_criteria
        )
    if isinstance(declared_constraints, Mapping):
        needs_determinism = needs_determinism or any(
            key in _DETERMINISM_KEYS and declared_constraints[key]
            for key in declared_constraints
        )

    determinism = None
    if needs_determinism:
        determinism = _determinism_verdict(
            record.capability_id, test_input, behavior, refs
        )
        behavior = get_candidate_behavior(capability_id) or behavior

    if requester == "generator":
        result = BehavioralEvaluationResult(
            evaluation_id=uuid.uuid4().hex,
            capability_id=record.capability_id,
            artifact_hash=current_hash,
            requirement_id=str(requirement["requirement_id"]),
            behavior_evidence_id=behavior.behavior_evidence_id,
            criteria_reference=criteria_reference,
            status="INSUFFICIENT_EVIDENCE",
            reason="SELF_EVALUATION_FORBIDDEN",
            input_contract_result=_VERDICT_INSUFFICIENT,
            output_contract_result=_VERDICT_INSUFFICIENT,
            acceptance_criteria_results=(
                _criterion(
                    "self_evaluation",
                    _VERDICT_INSUFFICIENT,
                    "SELF_EVALUATION_FORBIDDEN",
                    refs,
                ),
            ),
            constraint_results=(),
            evidence_refs=refs,
            evaluated_at=_now(),
        )
        record_candidate_behavior_evaluation(result)
        return result

    from .sandbox import BEHAVIOR_BLOCKED, BEHAVIOR_EXECUTED, BEHAVIOR_FAILED, BEHAVIOR_TIMEOUT

    if behavior.execution_status in {BEHAVIOR_FAILED, BEHAVIOR_TIMEOUT}:
        result = BehavioralEvaluationResult(
            evaluation_id=uuid.uuid4().hex,
            capability_id=record.capability_id,
            artifact_hash=current_hash,
            requirement_id=str(requirement["requirement_id"]),
            behavior_evidence_id=behavior.behavior_evidence_id,
            criteria_reference=criteria_reference,
            status="FAILED",
            reason=behavior.execution_status,
            input_contract_result=_VERDICT_INSUFFICIENT,
            output_contract_result=_VERDICT_FAIL,
            acceptance_criteria_results=(
                _criterion(
                    "execution_status",
                    _VERDICT_FAIL,
                    behavior.execution_status,
                    refs,
                ),
            ),
            constraint_results=(),
            evidence_refs=refs,
            evaluated_at=_now(),
        )
        record_candidate_behavior_evaluation(result)
        return result
    if behavior.execution_status != BEHAVIOR_EXECUTED:
        result = BehavioralEvaluationResult(
            evaluation_id=uuid.uuid4().hex,
            capability_id=record.capability_id,
            artifact_hash=current_hash,
            requirement_id=str(requirement["requirement_id"]),
            behavior_evidence_id=behavior.behavior_evidence_id,
            criteria_reference=criteria_reference,
            status="INSUFFICIENT_EVIDENCE",
            reason=behavior.execution_status or BEHAVIOR_BLOCKED,
            input_contract_result=_VERDICT_INSUFFICIENT,
            output_contract_result=_VERDICT_INSUFFICIENT,
            acceptance_criteria_results=(
                _criterion(
                    "execution_status",
                    _VERDICT_INSUFFICIENT,
                    behavior.execution_status or BEHAVIOR_BLOCKED,
                    refs,
                ),
            ),
            constraint_results=(),
            evidence_refs=refs,
            evaluated_at=_now(),
        )
        record_candidate_behavior_evaluation(result)
        return result

    payload = test_input.get("test_payload")
    input_result = _type_verdict(payload, requirement["input_contract"])
    return_value = behavior.return_value
    try:
        json.dumps(return_value, sort_keys=True, separators=(",", ":"))
        json_ok = True
    except TypeError:
        json_ok = False
    output_result = _VERDICT_FAIL if not json_ok else _type_verdict(
        return_value, requirement["output_contract"]
    )
    if (
        isinstance(return_value, dict)
        and isinstance(requirement["output_contract"], Mapping)
        and "capability_id" in requirement["output_contract"]
        and return_value.get("capability_id") != record.capability_id
    ):
        output_result = _VERDICT_FAIL

    criteria_results: list[CriterionVerdict] = []
    if isinstance(declared_criteria, Mapping) and declared_criteria:
        for key in declared_criteria:
            criteria_results.append(
                _eval_named(
                    str(key),
                    declared_criteria[key],
                    behavior=behavior,
                    blob=blob,
                    return_value=return_value,
                    determinism=determinism,
                    refs=refs,
                )
            )
    else:
        criteria_results.append(
            _criterion(
                "acceptance_criteria",
                _VERDICT_INSUFFICIENT,
                "CRITERION_NOT_MACHINE_VERIFIABLE",
                refs,
            )
        )

    constraint_results: list[CriterionVerdict] = []
    if isinstance(declared_constraints, Mapping):
        for key, value in declared_constraints.items():
            if value in {False, None, ""}:
                continue
            constraint_results.append(
                _eval_named(
                    str(key),
                    value,
                    behavior=behavior,
                    blob=blob,
                    return_value=return_value,
                    determinism=determinism,
                    refs=refs,
                )
            )
    if not embedded:
        constraint_results.append(
            _criterion(
                "contract_binding",
                _VERDICT_INSUFFICIENT,
                "CONTRACT_NOT_BOUND_IN_ARTIFACT",
                refs,
            )
        )

    status = _status_from_parts(
        input_result,
        output_result,
        *(item.result for item in criteria_results),
        *(item.result for item in constraint_results),
    )
    reason = {
        "PASSED": "CONTRACTS_SATISFIED",
        "FAILED": "CONTRACTS_NOT_SATISFIED",
        "INSUFFICIENT_EVIDENCE": "CONTRACTS_INSUFFICIENTLY_EVIDENCED",
    }[status]
    result = BehavioralEvaluationResult(
        evaluation_id=uuid.uuid4().hex,
        capability_id=record.capability_id,
        artifact_hash=current_hash,
        requirement_id=str(requirement["requirement_id"]),
        behavior_evidence_id=behavior.behavior_evidence_id,
        criteria_reference=criteria_reference,
        status=status,
        reason=reason,
        input_contract_result=input_result,
        output_contract_result=output_result,
        acceptance_criteria_results=tuple(criteria_results),
        constraint_results=tuple(constraint_results),
        evidence_refs=refs,
        evaluated_at=_now(),
    )
    record_candidate_behavior_evaluation(result)
    return result
