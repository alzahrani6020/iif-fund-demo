"""Deterministic, side-effect-free reconciliation.

Explicit facts in.
GapRecord values out.

This module does not resolve references from storage and does not
infer negative facts from missing references.
"""

from __future__ import annotations

import hashlib

from dataclasses import dataclass
from enum import Enum

from .reconciliation_contracts import (
    GapConfidence,
    GapRecord,
    GapSeverity,
    GapStatus,
    GapType,
    ReconciliationInput,
    VerificationDecision,
    VerificationStatus,
)


class PresenceState(str, Enum):
    UNKNOWN = "UNKNOWN"
    PRESENT = "PRESENT"
    MISSING = "MISSING"


class ContractState(str, Enum):
    UNKNOWN = "UNKNOWN"
    PASS = "PASS"
    FAILED = "FAILED"


class AuthorityState(str, Enum):
    UNKNOWN = "UNKNOWN"
    ALLOW = "ALLOW"
    BLOCK = "BLOCK"
    OWNER_REQUIRED = "OWNER_REQUIRED"


class DriftState(str, Enum):
    UNKNOWN = "UNKNOWN"
    INSUFFICIENT_EVIDENCE = "INSUFFICIENT_EVIDENCE"
    STABLE = "STABLE"
    WARNING = "WARNING"
    DEGRADED = "DEGRADED"


def _require_text(value: str, field: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(
            f"{field} must be a non-empty string"
        )


def _validate_refs(
    values: tuple[str, ...],
    field: str,
) -> None:
    if not isinstance(values, tuple):
        raise TypeError(
            f"{field} must be tuple[str, ...]"
        )

    for value in values:
        _require_text(value, field)

    if len(set(values)) != len(values):
        raise ValueError(
            f"{field} contains duplicate references"
        )


def _require_evidence_for_resolved_state(
    state: Enum,
    unknown: Enum,
    refs: tuple[str, ...],
    field: str,
) -> None:
    if state != unknown and not refs:
        raise ValueError(
            f"{field} requires explicit evidence refs"
        )


@dataclass(frozen=True)
class ReconciliationFacts:
    """Explicitly resolved facts supplied to reconciliation.

    UNKNOWN is not failure.
    Missing refs are not negative facts.
    """

    subject_ref: str

    capability_state: PresenceState = PresenceState.UNKNOWN
    capability_evidence_refs: tuple[str, ...] = ()

    implementation_state: PresenceState = PresenceState.UNKNOWN
    implementation_evidence_refs: tuple[str, ...] = ()

    runtime_state: PresenceState = PresenceState.UNKNOWN
    runtime_evidence_refs: tuple[str, ...] = ()

    contract_state: ContractState = ContractState.UNKNOWN
    contract_evidence_refs: tuple[str, ...] = ()

    authority_state: AuthorityState = AuthorityState.UNKNOWN
    authority_evidence_refs: tuple[str, ...] = ()

    drift_state: DriftState = DriftState.UNKNOWN
    drift_evidence_refs: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        _require_text(
            self.subject_ref,
            "subject_ref",
        )

        for field, refs in (
            (
                "capability_evidence_refs",
                self.capability_evidence_refs,
            ),
            (
                "implementation_evidence_refs",
                self.implementation_evidence_refs,
            ),
            (
                "runtime_evidence_refs",
                self.runtime_evidence_refs,
            ),
            (
                "contract_evidence_refs",
                self.contract_evidence_refs,
            ),
            (
                "authority_evidence_refs",
                self.authority_evidence_refs,
            ),
            (
                "drift_evidence_refs",
                self.drift_evidence_refs,
            ),
        ):
            _validate_refs(
                refs,
                field,
            )

        _require_evidence_for_resolved_state(
            self.capability_state,
            PresenceState.UNKNOWN,
            self.capability_evidence_refs,
            "capability_state",
        )

        _require_evidence_for_resolved_state(
            self.implementation_state,
            PresenceState.UNKNOWN,
            self.implementation_evidence_refs,
            "implementation_state",
        )

        _require_evidence_for_resolved_state(
            self.runtime_state,
            PresenceState.UNKNOWN,
            self.runtime_evidence_refs,
            "runtime_state",
        )

        _require_evidence_for_resolved_state(
            self.contract_state,
            ContractState.UNKNOWN,
            self.contract_evidence_refs,
            "contract_state",
        )

        _require_evidence_for_resolved_state(
            self.authority_state,
            AuthorityState.UNKNOWN,
            self.authority_evidence_refs,
            "authority_state",
        )

        _require_evidence_for_resolved_state(
            self.drift_state,
            DriftState.UNKNOWN,
            self.drift_evidence_refs,
            "drift_state",
        )


@dataclass(frozen=True)
class ReconciliationResult:
    reconciliation_id: str
    subject_ref: str
    gaps: tuple[GapRecord, ...]

    runtime_mutated: bool = False
    policy_mutated: bool = False
    authority_mutated: bool = False
    genesis_invoked: bool = False
    training_activated: bool = False
    promotion_activated: bool = False
    publish_activated: bool = False
    rollback_invoked: bool = False

    def as_dict(self) -> dict[str, object]:
        return {
            "reconciliation_id": self.reconciliation_id,
            "subject_ref": self.subject_ref,
            "gaps": [
                gap.as_dict()
                for gap in self.gaps
            ],
            "runtime_mutated": False,
            "policy_mutated": False,
            "authority_mutated": False,
            "genesis_invoked": False,
            "training_activated": False,
            "promotion_activated": False,
            "publish_activated": False,
            "rollback_invoked": False,
        }


_SEVERITY_RANK = {
    GapSeverity.LOW: 0,
    GapSeverity.MEDIUM: 1,
    GapSeverity.HIGH: 2,
    GapSeverity.CRITICAL: 3,
}


_CONFIDENCE_RANK = {
    GapConfidence.INSUFFICIENT: 0,
    GapConfidence.LOW: 1,
    GapConfidence.MEDIUM: 2,
    GapConfidence.HIGH: 3,
}


_GAP_ORDER = {
    gap_type: index
    for index, gap_type in enumerate(GapType)
}


@dataclass
class _Candidate:
    gap_type: GapType
    reason_codes: list[str]
    evidence_refs: list[str]
    severity: GapSeverity
    confidence: GapConfidence


def _merge_unique(
    target: list[str],
    incoming: tuple[str, ...],
) -> None:
    known = set(target)

    for item in incoming:
        if item not in known:
            target.append(item)
            known.add(item)


def _max_severity(
    left: GapSeverity,
    right: GapSeverity,
) -> GapSeverity:
    if _SEVERITY_RANK[right] > _SEVERITY_RANK[left]:
        return right
    return left


def _max_confidence(
    left: GapConfidence,
    right: GapConfidence,
) -> GapConfidence:
    if _CONFIDENCE_RANK[right] > _CONFIDENCE_RANK[left]:
        return right
    return left


def _add_candidate(
    candidates: dict[GapType, _Candidate],
    *,
    gap_type: GapType,
    reason_code: str,
    evidence_refs: tuple[str, ...],
    severity: GapSeverity,
    confidence: GapConfidence,
) -> None:
    current = candidates.get(gap_type)

    if current is None:
        candidates[gap_type] = _Candidate(
            gap_type=gap_type,
            reason_codes=[reason_code],
            evidence_refs=list(evidence_refs),
            severity=severity,
            confidence=confidence,
        )
        return

    if reason_code not in current.reason_codes:
        current.reason_codes.append(reason_code)

    _merge_unique(
        current.evidence_refs,
        evidence_refs,
    )

    current.severity = _max_severity(
        current.severity,
        severity,
    )

    current.confidence = _max_confidence(
        current.confidence,
        confidence,
    )


def _gap_id(
    *,
    reconciliation_id: str,
    gap_type: GapType,
    reason_codes: tuple[str, ...],
    evidence_refs: tuple[str, ...],
) -> str:
    material = "|".join(
        (
            reconciliation_id,
            gap_type.value,
            ",".join(reason_codes),
            ",".join(evidence_refs),
        )
    )

    digest = hashlib.sha256(
        material.encode("utf-8")
    ).hexdigest()[:20]

    return f"GAP-{digest}"


def reconcile(
    reconciliation_input: ReconciliationInput,
    facts: ReconciliationFacts,
    *,
    detected_at: str,
    verification: VerificationDecision | None = None,
) -> ReconciliationResult:
    """Produce zero or more GapRecord values.

    Caller is responsible for resolving opaque references into the
    explicit facts supplied here.

    The engine never interprets missing references as negative facts.
    """

    _require_text(
        detected_at,
        "detected_at",
    )

    if facts.subject_ref != reconciliation_input.subject_ref:
        raise ValueError(
            "SUBJECT_SCOPE_MISMATCH"
        )

    if verification is not None:
        if reconciliation_input.verification_ref is None:
            raise ValueError(
                "VERIFICATION_OBJECT_WITHOUT_REFERENCE"
            )

        if verification.cycle_id != reconciliation_input.cycle_id:
            raise ValueError(
                "VERIFICATION_CYCLE_MISMATCH"
            )

        if verification.subject_ref != reconciliation_input.subject_ref:
            raise ValueError(
                "VERIFICATION_SUBJECT_MISMATCH"
            )

    candidates: dict[GapType, _Candidate] = {}


    # --------------------------------------------------------
    # Verification
    # --------------------------------------------------------

    if reconciliation_input.verification_ref is not None:
        if verification is None:
            _add_candidate(
                candidates,
                gap_type=GapType.EVIDENCE_GAP,
                reason_code="VERIFICATION_REF_UNRESOLVED",
                evidence_refs=(),
                severity=GapSeverity.MEDIUM,
                confidence=GapConfidence.HIGH,
            )

        elif (
            verification.status
            is VerificationStatus.INSUFFICIENT_EVIDENCE
        ):
            _add_candidate(
                candidates,
                gap_type=GapType.EVIDENCE_GAP,
                reason_code="VERIFICATION_INSUFFICIENT_EVIDENCE",
                evidence_refs=verification.evidence_refs,
                severity=GapSeverity.MEDIUM,
                confidence=GapConfidence.HIGH,
            )

        elif (
            verification.status
            is VerificationStatus.FAILED
        ):
            _add_candidate(
                candidates,
                gap_type=GapType.VERIFICATION_GAP,
                reason_code="VERIFICATION_FAILED",
                evidence_refs=verification.evidence_refs,
                severity=GapSeverity.HIGH,
                confidence=GapConfidence.HIGH,
            )


    # --------------------------------------------------------
    # Capability
    # --------------------------------------------------------

    if (
        facts.capability_state
        is PresenceState.MISSING
    ):
        _add_candidate(
            candidates,
            gap_type=GapType.MISSING_CAPABILITY,
            reason_code="CAPABILITY_EXPLICITLY_MISSING",
            evidence_refs=facts.capability_evidence_refs,
            severity=GapSeverity.HIGH,
            confidence=GapConfidence.HIGH,
        )


    # --------------------------------------------------------
    # Implementation
    # --------------------------------------------------------

    if (
        facts.implementation_state
        is PresenceState.MISSING
    ):
        _add_candidate(
            candidates,
            gap_type=GapType.IMPLEMENTATION_GAP,
            reason_code="IMPLEMENTATION_EXPLICITLY_MISSING",
            evidence_refs=facts.implementation_evidence_refs,
            severity=GapSeverity.HIGH,
            confidence=GapConfidence.HIGH,
        )


    # --------------------------------------------------------
    # Runtime
    # --------------------------------------------------------

    if (
        facts.runtime_state
        is PresenceState.MISSING
    ):
        _add_candidate(
            candidates,
            gap_type=GapType.RUNTIME_GAP,
            reason_code="RUNTIME_EXPLICITLY_MISSING",
            evidence_refs=facts.runtime_evidence_refs,
            severity=GapSeverity.HIGH,
            confidence=GapConfidence.HIGH,
        )


    # --------------------------------------------------------
    # Contract
    # --------------------------------------------------------

    if (
        facts.contract_state
        is ContractState.FAILED
    ):
        _add_candidate(
            candidates,
            gap_type=GapType.CONTRACT_GAP,
            reason_code="CONTRACT_EXPLICITLY_FAILED",
            evidence_refs=facts.contract_evidence_refs,
            severity=GapSeverity.HIGH,
            confidence=GapConfidence.HIGH,
        )


    # --------------------------------------------------------
    # Authority
    # --------------------------------------------------------

    if (
        facts.authority_state
        is AuthorityState.BLOCK
    ):
        _add_candidate(
            candidates,
            gap_type=GapType.AUTHORITY_GAP,
            reason_code="AUTHORITY_BLOCK",
            evidence_refs=facts.authority_evidence_refs,
            severity=GapSeverity.HIGH,
            confidence=GapConfidence.HIGH,
        )

    elif (
        facts.authority_state
        is AuthorityState.OWNER_REQUIRED
    ):
        _add_candidate(
            candidates,
            gap_type=GapType.AUTHORITY_GAP,
            reason_code="OWNER_AUTHORITY_REQUIRED",
            evidence_refs=facts.authority_evidence_refs,
            severity=GapSeverity.MEDIUM,
            confidence=GapConfidence.HIGH,
        )


    # --------------------------------------------------------
    # Drift
    # --------------------------------------------------------

    if (
        facts.drift_state
        is DriftState.DEGRADED
    ):
        _add_candidate(
            candidates,
            gap_type=GapType.PERFORMANCE_GAP,
            reason_code="DRIFT_DEGRADED",
            evidence_refs=facts.drift_evidence_refs,
            severity=GapSeverity.MEDIUM,
            confidence=GapConfidence.MEDIUM,
        )

    elif (
        facts.drift_state
        is DriftState.INSUFFICIENT_EVIDENCE
    ):
        _add_candidate(
            candidates,
            gap_type=GapType.EVIDENCE_GAP,
            reason_code="DRIFT_INSUFFICIENT_EVIDENCE",
            evidence_refs=facts.drift_evidence_refs,
            severity=GapSeverity.MEDIUM,
            confidence=GapConfidence.HIGH,
        )

    # WARNING deliberately does not create a gap in V1.


    # --------------------------------------------------------
    # Materialize deterministic GapRecord values
    # --------------------------------------------------------

    records: list[GapRecord] = []

    for gap_type in sorted(
        candidates,
        key=lambda item: _GAP_ORDER[item],
    ):
        candidate = candidates[gap_type]

        reason_codes = tuple(
            candidate.reason_codes
        )

        evidence_refs = tuple(
            candidate.evidence_refs
        )

        records.append(
            GapRecord(
                gap_id=_gap_id(
                    reconciliation_id=(
                        reconciliation_input.reconciliation_id
                    ),
                    gap_type=gap_type,
                    reason_codes=reason_codes,
                    evidence_refs=evidence_refs,
                ),
                reconciliation_id=(
                    reconciliation_input.reconciliation_id
                ),
                gap_type=gap_type,
                subject_ref=(
                    reconciliation_input.subject_ref
                ),
                evidence_refs=evidence_refs,
                reason_codes=reason_codes,
                severity=candidate.severity,
                confidence=candidate.confidence,
                status=GapStatus.DETECTED,
                detected_at=detected_at,
            )
        )

    return ReconciliationResult(
        reconciliation_id=(
            reconciliation_input.reconciliation_id
        ),
        subject_ref=(
            reconciliation_input.subject_ref
        ),
        gaps=tuple(records),
    )
