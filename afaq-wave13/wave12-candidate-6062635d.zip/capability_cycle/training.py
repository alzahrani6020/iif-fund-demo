"""Self-training foundation: prepare and validate training material only.

Does not execute training, update weights, deploy models, promote,
change routing, activate capabilities, or widen authority.
TRAINING_JOB_SPECIFIED != TRAINING_STARTED.
"""

from __future__ import annotations

import hashlib
import json
import uuid
from dataclasses import dataclass, field, replace
from datetime import datetime, timezone
from typing import Any, Mapping

from .handlers import HANDLERS, _ACTIVE
from .performance_store import (
    PerformanceEvidence,
    PerformanceStore,
    StoreCorruptRecord,
    StoreReadFailed,
)
from .telemetry import redact

DATASET_SCHEMA_VERSION = 1
MIN_TRAINING_SAMPLES = 5
ALLOWED_LABEL_SOURCES = frozenset(
    {
        "MISSION_VERIFICATION",
        "OUTPUT_CONTRACT",
        "BEHAVIORAL_EVALUATION",
        "OWNER_APPROVED",
        "INDEPENDENT_CORRECTION",
    }
)
FORBIDDEN_LABEL_SOURCES = frozenset(
    {
        "SELF_REPORTED",
        "CANDIDATE_OK",
        "LEARNING_INFERENCE",
        "UNVERIFIED_MISSION",
        "HANDLER_OK",
    }
)
DATASET_STATUSES = frozenset(
    {"CANDIDATE", "VALIDATED", "REJECTED", "INSUFFICIENT_EVIDENCE"}
)
VALIDATION_STATUSES = frozenset({"VALIDATED", "REJECTED", "INSUFFICIENT_EVIDENCE"})
JOB_STATUSES = frozenset({"SPECIFIED", "NOT_READY", "REJECTED"})
TRAINING_METHODS = frozenset(
    {
        "SUPERVISED_FINE_TUNE",
        "PREFERENCE_TRAINING",
        "ADAPTER_TRAINING",
        "OTHER_EXACT_METHOD",
        "NOT_ESTABLISHED",
    }
)
_BUILDER_IDENTITIES = frozenset({"dataset_builder", "builder"})
_VALIDATOR_IDENTITIES = frozenset({"dataset_validator", "validator", "reviewer"})
_SPECIFIER_IDENTITIES = frozenset({"specifier", "planner"})
_BLOCKED_VALIDATORS = frozenset(
    {"dataset_builder", "builder", "learner", "generator", "trainer", "activator"}
)
_BLOCKED_SPECIFIERS = frozenset(
    {"dataset_builder", "builder", "learner", "trainer", "activator"}
)


class TrainingError(RuntimeError):
    """Fail-closed training-foundation rejection."""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _canonical(value: Any) -> str:
    return json.dumps(redact(value), sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def _hash(value: Any) -> str:
    return hashlib.sha256(_canonical(value).encode("utf-8")).hexdigest()


def _reject_claims(claims: Mapping[str, Any] | None) -> None:
    if claims:
        raise TrainingError("FORBIDDEN_TRAINING_CLAIM")


_DATASETS: dict[str, "TrainingDatasetCandidate"] = {}
_VALIDATIONS: dict[str, "TrainingDatasetValidation"] = {}
_JOBS: dict[str, "TrainingJobSpec"] = {}


def clear_training() -> None:
    _DATASETS.clear()
    _VALIDATIONS.clear()
    _JOBS.clear()


@dataclass(frozen=True)
class TrainingSample:
    sample_id: str
    source_evidence_ref: str
    source_type: str
    capability_id: str
    artifact_hash: str | None
    input: dict[str, Any]
    expected_output: str | None
    actual_output: str | None
    mission_verification: str | None
    quality_label: str
    created_at: str
    label_source: str
    label_confidence: str
    eligibility: str
    content_hash: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "sample_id": self.sample_id,
            "source_evidence_ref": self.source_evidence_ref,
            "source_type": self.source_type,
            "capability_id": self.capability_id,
            "artifact_hash": self.artifact_hash,
            "input": dict(self.input),
            "expected_output": self.expected_output,
            "actual_output": self.actual_output,
            "mission_verification": self.mission_verification,
            "quality_label": self.quality_label,
            "created_at": self.created_at,
            "label_source": self.label_source,
            "label_confidence": self.label_confidence,
            "eligibility": self.eligibility,
            "content_hash": self.content_hash,
        }


@dataclass(frozen=True)
class TrainingDatasetCandidate:
    dataset_id: str
    dataset_version: str
    target_model_scope: str
    source_capability_ids: tuple[str, ...]
    source_artifact_hashes: tuple[str, ...]
    evidence_refs: tuple[str, ...]
    sample_count: int
    schema_version: int
    dataset_purpose: str
    created_at: str
    created_by: str
    content_hash: str
    status: str
    samples: tuple[TrainingSample, ...]
    rejected_count: int
    duplicate_count: int
    conflict: bool
    reason: str
    details: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "dataset_id": self.dataset_id,
            "dataset_version": self.dataset_version,
            "target_model_scope": self.target_model_scope,
            "source_capability_ids": list(self.source_capability_ids),
            "source_artifact_hashes": list(self.source_artifact_hashes),
            "evidence_refs": list(self.evidence_refs),
            "sample_count": self.sample_count,
            "schema_version": self.schema_version,
            "dataset_purpose": self.dataset_purpose,
            "created_at": self.created_at,
            "created_by": self.created_by,
            "content_hash": self.content_hash,
            "status": self.status,
            "samples": [sample.as_dict() for sample in self.samples],
            "rejected_count": self.rejected_count,
            "duplicate_count": self.duplicate_count,
            "conflict": self.conflict,
            "reason": self.reason,
            "details": dict(self.details),
        }


@dataclass(frozen=True)
class TrainingDatasetValidation:
    validation_id: str
    dataset_id: str
    dataset_hash: str
    validator_identity: str
    provenance_result: str
    integrity_result: str
    label_quality_result: str
    redaction_result: str
    duplicate_result: str
    conflict_result: str
    scope_result: str
    sample_count_result: str
    status: str
    reason: str
    evidence_refs: tuple[str, ...]
    validated_at: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "validation_id": self.validation_id,
            "dataset_id": self.dataset_id,
            "dataset_hash": self.dataset_hash,
            "validator_identity": self.validator_identity,
            "provenance_result": self.provenance_result,
            "integrity_result": self.integrity_result,
            "label_quality_result": self.label_quality_result,
            "redaction_result": self.redaction_result,
            "duplicate_result": self.duplicate_result,
            "conflict_result": self.conflict_result,
            "scope_result": self.scope_result,
            "sample_count_result": self.sample_count_result,
            "status": self.status,
            "reason": self.reason,
            "evidence_refs": list(self.evidence_refs),
            "validated_at": self.validated_at,
        }


@dataclass(frozen=True)
class TrainingJobSpec:
    training_job_id: str
    dataset_id: str
    dataset_hash: str
    target_model_scope: str
    training_objective: str
    base_model_reference: str
    training_method: str
    hyperparameter_policy_reference: str
    resource_constraints: dict[str, Any]
    evaluation_plan: str
    rollback_plan: str
    deployment_allowed: bool
    created_at: str
    created_by: str
    status: str
    reason: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "training_job_id": self.training_job_id,
            "dataset_id": self.dataset_id,
            "dataset_hash": self.dataset_hash,
            "target_model_scope": self.target_model_scope,
            "training_objective": self.training_objective,
            "base_model_reference": self.base_model_reference,
            "training_method": self.training_method,
            "hyperparameter_policy_reference": self.hyperparameter_policy_reference,
            "resource_constraints": dict(self.resource_constraints),
            "evaluation_plan": self.evaluation_plan,
            "rollback_plan": self.rollback_plan,
            "deployment_allowed": False,
            "created_at": self.created_at,
            "created_by": self.created_by,
            "status": self.status,
            "reason": self.reason,
        }


def get_training_dataset(dataset_id: str) -> TrainingDatasetCandidate | None:
    return _DATASETS.get(dataset_id)


def get_training_validation(validation_id: str) -> TrainingDatasetValidation | None:
    return _VALIDATIONS.get(validation_id)


def get_training_job(training_job_id: str) -> TrainingJobSpec | None:
    return _JOBS.get(training_job_id)


def _mission_label(record: PerformanceEvidence) -> tuple[str, str, str] | None:
    if record.mission_verification_status == "VERIFIED" and record.final_outcome == "SUCCESS":
        return ("VERIFIED_SUCCESS", "MISSION_VERIFICATION", "HIGH")
    if record.mission_verification_status == "FAILED":
        return ("VERIFIED_FAILURE", "MISSION_VERIFICATION", "HIGH")
    return None


def _contains_unredacted_secret(value: Any) -> bool:
    if isinstance(value, Mapping):
        return any(_contains_unredacted_secret(item) for item in value.values())
    if isinstance(value, (list, tuple)):
        return any(_contains_unredacted_secret(item) for item in value)
    if not isinstance(value, str):
        return False
    lowered = value.lower()
    if "[redacted]" in lowered:
        return False
    return any(
        marker in lowered
        for marker in ("sk-", "bearer ", "ghp_", "password=", "api_key=")
    )


def _classify_record(
    record: PerformanceEvidence,
    *,
    capability_id: str,
    artifact_hash: str | None,
) -> tuple[str, str]:
    if not record.capability_id or not record.record_id or not record.evidence_refs:
        return ("INSUFFICIENT_EVIDENCE", "INCOMPLETE_PROVENANCE")
    if record.capability_id != capability_id:
        return ("REJECTED", "CROSS_CAPABILITY_EVIDENCE")
    if (
        artifact_hash
        and record.capability_version
        and record.capability_version != artifact_hash
    ):
        return ("REJECTED", "CROSS_VERSION_EVIDENCE")
    if record.record_kind not in {"FINAL", "FAILED"}:
        return ("REJECTED", "UNSUPPORTED_RECORD_KIND")
    if _mission_label(record) is None:
        return ("REJECTED", "UNVERIFIED_LABEL")
    return ("ELIGIBLE", "MISSION_VERIFIED_SEMANTICS")


def _sample_from_record(record: PerformanceEvidence) -> TrainingSample:
    label, source, confidence = _mission_label(record) or ("", "", "")
    payload = redact(
        {
            "capability_id": record.capability_id,
            "capability_version": record.capability_version,
            "mission_ids": list(record.mission_ids),
            "record_kind": record.record_kind,
            "evidence_refs": list(record.evidence_refs),
        }
    )
    content = {
        "capability_id": record.capability_id,
        "artifact_hash": record.capability_version,
        "mission_ids": list(record.mission_ids),
        "label": label,
        "evidence_refs": list(record.evidence_refs),
    }
    return TrainingSample(
        sample_id=uuid.uuid4().hex,
        source_evidence_ref=record.record_id,
        source_type="performance_evidence",
        capability_id=str(record.capability_id),
        artifact_hash=record.capability_version,
        input=dict(payload),
        expected_output=label,
        actual_output=record.final_outcome,
        mission_verification=record.mission_verification_status,
        quality_label=label,
        created_at=record.timestamp,
        label_source=source,
        label_confidence=confidence,
        eligibility="ELIGIBLE",
        content_hash=_hash(content),
    )


def _sample_from_mapping(data: Mapping[str, Any], *, capability_id: str) -> TrainingSample:
    source = str(data.get("label_source") or "")
    if source in FORBIDDEN_LABEL_SOURCES:
        raise TrainingError("FORBIDDEN_LABEL_SOURCE")
    if source not in ALLOWED_LABEL_SOURCES:
        raise TrainingError("FORBIDDEN_LABEL_SOURCE")
    if str(data.get("capability_id") or capability_id) != capability_id:
        raise TrainingError("CROSS_CAPABILITY_EVIDENCE")
    payload = redact(dict(data.get("input") or {}))
    label = data.get("expected_output")
    if not label:
        raise TrainingError("LABEL_UNSUPPORTED")
    content = {
        "capability_id": capability_id,
        "artifact_hash": data.get("artifact_hash"),
        "input": payload,
        "label": label,
    }
    return TrainingSample(
        sample_id=str(data.get("sample_id") or uuid.uuid4().hex),
        source_evidence_ref=str(data.get("source_evidence_ref") or ""),
        source_type=str(data.get("source_type") or "owner_approved"),
        capability_id=capability_id,
        artifact_hash=data.get("artifact_hash"),
        input=dict(payload),
        expected_output=str(label),
        actual_output=data.get("actual_output"),
        mission_verification=data.get("mission_verification"),
        quality_label=str(label),
        created_at=str(data.get("created_at") or _now()),
        label_source=source,
        label_confidence=str(data.get("label_confidence") or "HIGH"),
        eligibility="ELIGIBLE",
        content_hash=_hash(content),
    )


def build_training_dataset(
    store: PerformanceStore,
    *,
    capability_id: str,
    artifact_hash: str | None = None,
    requester: str = "learner",
    min_samples: int = MIN_TRAINING_SAMPLES,
    extra_samples: tuple[Mapping[str, Any], ...] = (),
    claims: Mapping[str, Any] | None = None,
    historical_records: tuple[Mapping[str, Any], ...] = (),
) -> TrainingDatasetCandidate:
    """Select verified evidence and emit a dataset candidate. Does not train."""
    _reject_claims(claims)
    del historical_records
    if requester not in _BUILDER_IDENTITIES:
        raise TrainingError("SELF_TRAINING_FORBIDDEN")
    handlers_before = dict(HANDLERS)
    active_before = dict(_ACTIVE)

    eligible: list[TrainingSample] = []
    rejected = 0
    duplicates = 0
    seen_hashes: set[str] = set()
    labels_by_input: dict[str, set[str]] = {}
    refs: list[str] = []
    versions: set[str] = set()

    for raw in store.by_capability_id(capability_id):
        try:
            record = store.get(raw.record_id)
        except StoreCorruptRecord:
            rejected += 1
            continue
        except StoreReadFailed:
            rejected += 1
            continue
        eligibility, _reason = _classify_record(
            record, capability_id=capability_id, artifact_hash=artifact_hash
        )
        if eligibility != "ELIGIBLE":
            rejected += 1
            continue
        sample = _sample_from_record(record)
        if _contains_unredacted_secret(sample.as_dict()):
            rejected += 1
            continue
        if sample.content_hash in seen_hashes:
            duplicates += 1
            continue
        seen_hashes.add(sample.content_hash)
        input_key = _hash(
            {
                "capability_id": sample.capability_id,
                "artifact_hash": sample.artifact_hash,
                "input": sample.input,
            }
        )
        labels_by_input.setdefault(input_key, set()).add(str(sample.expected_output))
        eligible.append(sample)
        refs.append(sample.source_evidence_ref)
        if sample.artifact_hash:
            versions.add(sample.artifact_hash)

    for extra in extra_samples:
        sample = _sample_from_mapping(extra, capability_id=capability_id)
        if _contains_unredacted_secret(sample.as_dict()):
            rejected += 1
            continue
        if sample.content_hash in seen_hashes:
            duplicates += 1
            continue
        seen_hashes.add(sample.content_hash)
        input_key = _hash(
            {
                "capability_id": sample.capability_id,
                "artifact_hash": sample.artifact_hash,
                "input": sample.input,
            }
        )
        labels_by_input.setdefault(input_key, set()).add(str(sample.expected_output))
        eligible.append(sample)
        if sample.source_evidence_ref:
            refs.append(sample.source_evidence_ref)
        if sample.artifact_hash:
            versions.add(sample.artifact_hash)

    conflict = any(len(labels) > 1 for labels in labels_by_input.values())
    eligible.sort(key=lambda item: (item.source_evidence_ref, item.content_hash))
    content_hash = _hash([sample.content_hash for sample in eligible])
    if conflict:
        status = "REJECTED"
        reason = "CONFLICTING_LABELS"
    elif len(eligible) < min_samples:
        status = "INSUFFICIENT_EVIDENCE"
        reason = "SAMPLE_BELOW_MINIMUM"
    else:
        status = "CANDIDATE"
        reason = "VERIFIED_EVIDENCE_SELECTED"
    dataset = TrainingDatasetCandidate(
        dataset_id=uuid.uuid4().hex,
        dataset_version=content_hash[:16],
        target_model_scope=f"capability:{capability_id}",
        source_capability_ids=(capability_id,),
        source_artifact_hashes=tuple(sorted(versions)),
        evidence_refs=tuple(refs),
        sample_count=len(eligible),
        schema_version=DATASET_SCHEMA_VERSION,
        dataset_purpose="verified mission-outcome training material only",
        created_at=_now(),
        created_by=requester,
        content_hash=content_hash,
        status=status,
        samples=tuple(eligible),
        rejected_count=rejected,
        duplicate_count=duplicates,
        conflict=conflict,
        reason=reason,
        details={
            "min_samples": min_samples,
            "duplicate_behavior": "exact content-hash drop; count not quality-inflating",
            "training_executed": False,
        },
    )
    if dict(HANDLERS) != handlers_before or dict(_ACTIVE) != active_before:
        raise TrainingError("ACTIVE_RUNTIME_MUTATED")
    _DATASETS[dataset.dataset_id] = dataset
    store.persist_training_dataset(dataset.as_dict())
    return dataset


def validate_training_dataset(
    store: PerformanceStore,
    *,
    dataset_id: str,
    requester: str = "learner",
    min_samples: int = MIN_TRAINING_SAMPLES,
    claims: Mapping[str, Any] | None = None,
) -> TrainingDatasetValidation:
    """Independently validate a dataset candidate. Grants no training authority."""
    _reject_claims(claims)
    if requester in _BLOCKED_VALIDATORS or requester not in _VALIDATOR_IDENTITIES:
        raise TrainingError("SELF_VALIDATION_FORBIDDEN")
    dataset = get_training_dataset(dataset_id)
    if dataset is None:
        raise TrainingError("UNKNOWN_TRAINING_DATASET")
    handlers_before = dict(HANDLERS)
    active_before = dict(_ACTIVE)

    provenance = "PASS" if dataset.evidence_refs and all(dataset.evidence_refs) else "FAIL"
    recomputed = _hash([sample.content_hash for sample in dataset.samples])
    integrity = "PASS" if recomputed == dataset.content_hash else "FAIL"
    label_quality = (
        "PASS"
        if dataset.samples
        and all(
            sample.label_source in ALLOWED_LABEL_SOURCES
            and sample.label_source not in FORBIDDEN_LABEL_SOURCES
            and sample.expected_output
            for sample in dataset.samples
        )
        else "FAIL"
    )
    redaction = (
        "PASS"
        if not any(_contains_unredacted_secret(sample.as_dict()) for sample in dataset.samples)
        else "FAIL"
    )
    hashes = [sample.content_hash for sample in dataset.samples]
    duplicate = "PASS" if len(hashes) == len(set(hashes)) else "FAIL"
    labels_by_input: dict[str, set[str]] = {}
    for sample in dataset.samples:
        key = _hash(
            {
                "capability_id": sample.capability_id,
                "artifact_hash": sample.artifact_hash,
                "input": sample.input,
            }
        )
        labels_by_input.setdefault(key, set()).add(str(sample.expected_output))
    conflict = "FAIL" if any(len(labels) > 1 for labels in labels_by_input.values()) else "PASS"
    scope = (
        "PASS"
        if dataset.source_capability_ids
        and all(
            sample.capability_id in dataset.source_capability_ids for sample in dataset.samples
        )
        else "FAIL"
    )
    sample_count = "PASS" if dataset.sample_count >= min_samples else "FAIL"
    checks = {
        "provenance": provenance,
        "integrity": integrity,
        "label_quality": label_quality,
        "redaction": redaction,
        "duplicate": duplicate,
        "conflict": conflict,
        "scope": scope,
        "sample_count": sample_count,
    }
    if any(value == "FAIL" for value in checks.values()):
        if sample_count == "FAIL" and all(
            value == "PASS" for key, value in checks.items() if key != "sample_count"
        ):
            status = "INSUFFICIENT_EVIDENCE"
            reason = "SAMPLE_BELOW_MINIMUM"
        elif conflict == "FAIL":
            status = "REJECTED"
            reason = "CONFLICTING_LABELS"
        else:
            status = "REJECTED"
            reason = "DATASET_VALIDATION_FAILED"
    else:
        status = "VALIDATED"
        reason = "INDEPENDENTLY_VALIDATED"

    result = TrainingDatasetValidation(
        validation_id=uuid.uuid4().hex,
        dataset_id=dataset.dataset_id,
        dataset_hash=dataset.content_hash,
        validator_identity=requester,
        provenance_result=provenance,
        integrity_result=integrity,
        label_quality_result=label_quality,
        redaction_result=redaction,
        duplicate_result=duplicate,
        conflict_result=conflict,
        scope_result=scope,
        sample_count_result=sample_count,
        status=status,
        reason=reason,
        evidence_refs=dataset.evidence_refs,
        validated_at=_now(),
    )
    if dict(HANDLERS) != handlers_before or dict(_ACTIVE) != active_before:
        raise TrainingError("ACTIVE_RUNTIME_MUTATED")
    _VALIDATIONS[result.validation_id] = result
    if status == "VALIDATED":
        _DATASETS[dataset.dataset_id] = replace(dataset, status="VALIDATED")
    store.persist_training_validation(result.as_dict())
    return result


def specify_training_job(
    store: PerformanceStore,
    *,
    dataset_id: str,
    requester: str = "learner",
    base_model_reference: str | None = None,
    training_method: str = "NOT_ESTABLISHED",
    claims: Mapping[str, Any] | None = None,
) -> TrainingJobSpec:
    """Create a non-executing training job specification. Then stop."""
    _reject_claims(claims)
    if requester in _BLOCKED_SPECIFIERS or requester not in _SPECIFIER_IDENTITIES:
        raise TrainingError("SELF_SPECIFICATION_FORBIDDEN")
    dataset = get_training_dataset(dataset_id)
    if dataset is None:
        raise TrainingError("UNKNOWN_TRAINING_DATASET")
    validated = next(
        (
            item
            for item in _VALIDATIONS.values()
            if item.dataset_id == dataset_id and item.status == "VALIDATED"
        ),
        None,
    )
    handlers_before = dict(HANDLERS)
    active_before = dict(_ACTIVE)
    method = training_method if training_method in TRAINING_METHODS else "NOT_ESTABLISHED"
    model = (base_model_reference or "").strip() or "NOT_ESTABLISHED"
    if validated is None or dataset.status != "VALIDATED":
        status = "REJECTED"
        reason = "DATASET_NOT_VALIDATED"
    elif model == "NOT_ESTABLISHED" or method == "NOT_ESTABLISHED":
        status = "NOT_READY"
        reason = "BASE_MODEL_OR_METHOD_NOT_ESTABLISHED"
    else:
        status = "SPECIFIED"
        reason = "JOB_SPECIFIED_NOT_STARTED"
    job = TrainingJobSpec(
        training_job_id=uuid.uuid4().hex,
        dataset_id=dataset.dataset_id,
        dataset_hash=dataset.content_hash,
        target_model_scope=dataset.target_model_scope,
        training_objective="prepare verified mission-outcome supervision only",
        base_model_reference=model,
        training_method=method,
        hyperparameter_policy_reference="NOT_ESTABLISHED",
        resource_constraints={"execution": "FORBIDDEN", "weight_update": "FORBIDDEN"},
        evaluation_plan="re-validate dataset hash before any future gated execution",
        rollback_plan="NOT_IMPLEMENTED",
        deployment_allowed=False,
        created_at=_now(),
        created_by=requester,
        status=status,
        reason=reason,
    )
    if dict(HANDLERS) != handlers_before or dict(_ACTIVE) != active_before:
        raise TrainingError("ACTIVE_RUNTIME_MUTATED")
    _JOBS[job.training_job_id] = job
    store.persist_training_job(job.as_dict())
    return job
