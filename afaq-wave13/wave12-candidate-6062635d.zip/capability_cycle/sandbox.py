"""Capability-scoped isolation for untrusted/new handler execution.

This is the capability-handler sandbox. Host command routes use
`afaq_agent_runtime.host_sandbox`. Setup failure fails closed.
SANDBOX_EXECUTED != SANDBOX_VALIDATED != CERTIFIED.
Candidate sandbox validation hashes a registered artifact in isolation
and never installs it into HANDLERS or _ACTIVE.
Behavioral sandbox execution observes handle(payload) in a child process.
BEHAVIOR_EXECUTED != acceptance pass != certified != active.
"""

from __future__ import annotations

import base64
import hashlib
import importlib
import json
import marshal
import subprocess
import sys
import tempfile
import time
import uuid
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from .handlers import (
    ARTIFACT_IMPLEMENTATION_SOURCE,
    HANDLERS,
    CandidateBehaviorEvidence,
    CandidateRegistrationError,
    CandidateSandboxEvidence,
    export_active_restore,
    export_candidate_artifact,
    record_candidate_behavior,
    record_candidate_sandbox,
    reject_caller_claims,
)

from .source_policy import (
    CandidateSourcePolicyError,
    candidate_safe_builtins,
    validate_candidate_code_object,
    validate_candidate_source,
)

ALLOWED_HANDLERS = frozenset(HANDLERS)
DEFAULT_TIMEOUT_S = 5
BEHAVIOR_EXECUTED = "BEHAVIOR_EXECUTED"
BEHAVIOR_FAILED = "BEHAVIOR_FAILED"
BEHAVIOR_TIMEOUT = "BEHAVIOR_TIMEOUT"
BEHAVIOR_BLOCKED = "BEHAVIOR_BLOCKED"
INSUFFICIENT_TEST_INPUT = "INSUFFICIENT_TEST_INPUT"
BEHAVIOR_PROTOCOL = "behavioral-sandbox-v1"
ISOLATION_PROFILE = (
    "process=subprocess;env=filtered;timeout=yes;"
    "fs=partial;net=partial;subproc=partial;secrets=partial"
)
_REQUIRED_BEHAVIOR_INPUT = (
    "capability_id",
    "requirement_id",
    "input_contract",
    "test_payload",
    "acceptance_criteria_reference",
)


@dataclass(frozen=True)
class SandboxResult:
    executed: bool
    validated: bool
    outcome: str
    failure_class: str | None
    stdout: str
    stderr: str
    returncode: int | None
    result: dict[str, Any] | None


@dataclass(frozen=True)
class BehavioralSandboxResult:
    status: str
    capability_id: str
    artifact_hash: str
    correlation_id: str
    requirement_id: str
    input_digest: str
    result_digest: str | None
    return_value: Any
    return_type: str | None
    duration_ms: float | None
    failure_reason: str | None
    evidence: CandidateBehaviorEvidence


class SandboxError(RuntimeError):
    pass


_RUNNER = r"""
import base64, hashlib, json, marshal, os, sys, types
from capability_cycle.handlers import HANDLERS
from capability_cycle.source_policy import candidate_safe_builtins, validate_candidate_code_object
try:
    from capability_cycle.merged_handlers import ensure_merged_handlers_registered
    ensure_merged_handlers_registered(write_map=False)
except Exception:
    pass
payload = json.loads(sys.stdin.read())
cap = payload["capability_id"]
fn = HANDLERS.get(cap)
restore = os.environ.get("AFAQ_CAP_RESTORE")
if restore:
    meta = json.loads(restore)
    if meta.get("capability_id") == cap:
        code = marshal.loads(base64.b64decode(meta["artifact"]))
        validate_candidate_code_object(code)
        digest = hashlib.sha256(code.co_code).hexdigest()
        if digest != meta.get("artifact_hash"):
            raise SystemExit("artifact_hash_mismatch")
        fn = types.FunctionType(
            code,
            {
                "__builtins__": candidate_safe_builtins(),
                "json": json,
                "hashlib": hashlib,
            },
            cap,
        )
if fn is None:
    raise SystemExit("unregistered_handler")
out = fn(payload.get("input") or {})
sys.stdout.write(json.dumps(out))
"""

_CANDIDATE_RUNNER = r"""
import hashlib, json, sys
payload = json.loads(sys.stdin.read())
artifact = bytes.fromhex(payload["artifact_hex"])
expected = payload["artifact_hash"]
digest = hashlib.sha256(artifact).hexdigest()
if digest != expected:
    raise SystemExit("artifact_hash_mismatch")
sys.stdout.write(json.dumps({"ok": True, "artifact_hash": digest}))
"""

_SHADOW_BUILD_RUNNER = r"""
import base64
import hashlib
import json
import marshal
import sys

payload = json.loads(sys.stdin.read())

repo = str(payload["repo"])
candidate_id = str(payload["candidate_id"])
source = bytes.fromhex(payload["source_hex"]).decode("utf-8")
expected = str(payload["artifact_hash"])

digest = hashlib.sha256(source.encode("utf-8")).hexdigest()
if digest != expected:
    raise SystemExit("candidate_tampered")

sys.path.insert(0, repo)

from capability_cycle.source_policy import (
    candidate_safe_builtins,
    validate_candidate_source,
)

try:
    validate_candidate_source(
        source,
        candidate_id,
    )
except Exception as exc:
    sys.stdout.write(
        json.dumps(
            {
                "ok": False,
                "failure": str(exc),
            },
            separators=(",", ":"),
        )
    )
    raise SystemExit(3)

namespace = {
    "__builtins__":
        candidate_safe_builtins(),
}

try:
    compiled = compile(
        source,
        "<isolated-shadow>",
        "exec",
    )
    exec(
        compiled,
        namespace,
        namespace,
    )
except Exception:
    sys.stdout.write(
        json.dumps(
            {
                "ok": False,
                "failure":
                    "SHADOW_COMPILE_FAILED",
            },
            separators=(",", ":"),
        )
    )
    raise SystemExit(4)

handle = namespace.get("handle")

if (
    not callable(handle)
    or
    not getattr(
        handle,
        "__code__",
        None,
    )
):
    sys.stdout.write(
        json.dumps(
            {
                "ok": False,
                "failure":
                    "SHADOW_MISSING_HANDLE",
            },
            separators=(",", ":"),
        )
    )
    raise SystemExit(5)

code = handle.__code__

sys.stdout.write(
    json.dumps(
        {
            "ok": True,
            "artifact":
                base64.b64encode(
                    marshal.dumps(code)
                ).decode("ascii"),
            "artifact_hash":
                hashlib.sha256(
                    code.co_code
                ).hexdigest(),
        },
        separators=(",", ":"),
    )
)
"""


_BEHAVIOR_RUNNER = r"""
import hashlib, json, sys, time, types
payload = json.loads(sys.stdin.read())
source = bytes.fromhex(payload["source_hex"]).decode("utf-8")
expected = payload["artifact_hash"]
digest = hashlib.sha256(source.encode("utf-8")).hexdigest()
if digest != expected:
    raise SystemExit("artifact_hash_mismatch")
from capability_cycle.source_policy import candidate_safe_builtins, validate_candidate_source
validate_candidate_source(source, str(payload.get("capability_id") or ""))
safe = candidate_safe_builtins()
ns = {"__builtins__": safe}
started = time.perf_counter()
try:
    compiled = compile(source, "<candidate>", "exec")
    exec(compiled, ns, ns)
except SyntaxError:
    raise SystemExit("malformed_source")
except Exception:
    duration_ms = (time.perf_counter() - started) * 1000.0
    sys.stdout.write(json.dumps({
        "protocol": "behavioral-sandbox-v1",
        "ok": False,
        "execution_status": "BEHAVIOR_FAILED",
        "artifact_hash": digest,
        "capability_id": payload.get("capability_id"),
        "correlation_id": payload.get("correlation_id"),
        "return_value": None,
        "return_type": None,
        "error_class": "LOAD_FAILED",
        "duration_ms": duration_ms,
    }, separators=(",", ":")))
    raise SystemExit(2)
handle = ns.get("handle")
if not isinstance(handle, types.FunctionType):
    raise SystemExit("missing_handle")
try:
    out = handle(payload.get("test_payload"))
    encoded = json.dumps(out, sort_keys=True, separators=(",", ":"))
    parsed = json.loads(encoded)
    duration_ms = (time.perf_counter() - started) * 1000.0
    sys.stdout.write(json.dumps({
        "protocol": "behavioral-sandbox-v1",
        "ok": True,
        "execution_status": "BEHAVIOR_EXECUTED",
        "artifact_hash": digest,
        "capability_id": payload.get("capability_id"),
        "correlation_id": payload.get("correlation_id"),
        "return_value": parsed,
        "return_type": type(out).__name__,
        "error_class": None,
        "duration_ms": duration_ms,
    }, separators=(",", ":")))
except Exception as exc:
    duration_ms = (time.perf_counter() - started) * 1000.0
    sys.stdout.write(json.dumps({
        "protocol": "behavioral-sandbox-v1",
        "ok": False,
        "execution_status": "BEHAVIOR_FAILED",
        "artifact_hash": digest,
        "capability_id": payload.get("capability_id"),
        "correlation_id": payload.get("correlation_id"),
        "return_value": None,
        "return_type": None,
        "error_class": type(exc).__name__,
        "duration_ms": duration_ms,
    }, separators=(",", ":")))
    raise SystemExit(2)
"""


def isolated_shadow_restore(
    candidate_id: str,
    target_capability_id: str,
) -> dict[str, str]:
    """Build one certified shadow artifact outside the host process.

    Does not write HANDLERS, _ACTIVE, or persisted restore blobs.
    """
    record, blob = export_candidate_artifact(candidate_id)
    current = hashlib.sha256(blob).hexdigest()
    if current != record.artifact_hash:
        raise CandidateRegistrationError("CANDIDATE_TAMPERED")
    if record.artifact_class != ARTIFACT_IMPLEMENTATION_SOURCE:
        raise CandidateRegistrationError("SHADOW_REQUIRES_IMPLEMENTATION_SOURCE")

    try:
        source = blob.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise CandidateRegistrationError("MALFORMED_ARTIFACT") from exc

    try:
        validate_candidate_source(
            source,
            candidate_id,
        )
    except CandidateSourcePolicyError as exc:
        raise CandidateRegistrationError(str(exc)) from exc

    repo = Path(__file__).resolve().parents[1]

    stdin = json.dumps(
        {
            "repo": str(repo),
            "candidate_id": candidate_id,
            "source_hex": blob.hex(),
            "artifact_hash": record.artifact_hash,
        },
        separators=(",", ":"),
    )

    try:
        completed = subprocess.run(
            [
                sys.executable,
                "-I",
                "-c",
                _SHADOW_BUILD_RUNNER,
            ],
            input=stdin,
            text=True,
            capture_output=True,
            timeout=DEFAULT_TIMEOUT_S,
            cwd=str(repo),
            env={
                "PYTHONIOENCODING": "utf-8",
            },
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise CandidateRegistrationError(
            "SHADOW_COMPILE_TIMEOUT"
        ) from exc
    except OSError as exc:
        raise CandidateRegistrationError(
            "SHADOW_COMPILE_FAILED"
        ) from exc

    try:
        result = json.loads(
            completed.stdout
        )
    except (
        json.JSONDecodeError,
        TypeError,
    ) as exc:
        raise CandidateRegistrationError(
            "SHADOW_COMPILE_FAILED"
        ) from exc

    if (
        completed.returncode != 0
        or
        not isinstance(result, dict)
        or
        result.get("ok") is not True
    ):
        failure = (
            result.get("failure")
            if isinstance(result, dict)
            else None
        )

        if failure in {
            "SHADOW_MISSING_HANDLE",
            "SHADOW_COMPILE_FAILED",
            "MALFORMED_ARTIFACT",
            "MISSING_ENTRYPOINT",
            "FORBIDDEN_SOURCE_CONSTRUCT",
            "FORBIDDEN_CANDIDATE_CLAIM",
        }:
            raise CandidateRegistrationError(
                str(failure)
            )

        raise CandidateRegistrationError(
            "SHADOW_COMPILE_FAILED"
        )

    encoded = result.get("artifact")
    code_hash = result.get("artifact_hash")

    if (
        not isinstance(encoded, str)
        or
        not encoded
        or
        not isinstance(code_hash, str)
        or
        len(code_hash) != 64
    ):
        raise CandidateRegistrationError(
            "SHADOW_COMPILE_FAILED"
        )

    return {
        "capability_id":
            target_capability_id,
        "artifact":
            encoded,
        "artifact_hash":
            code_hash,
        "source_artifact_hash":
            record.artifact_hash,
        "candidate_id":
            candidate_id,
        "shadow":
            "ISOLATED",
    }


def run_sandboxed(
    capability_id: str,
    payload: dict[str, Any],
    *,
    timeout_s: int = DEFAULT_TIMEOUT_S,
    bypass: bool = False,
    shadow_restore: Mapping[str, str] | None = None,
) -> SandboxResult:
    if bypass:
        return SandboxResult(
            executed=False,
            validated=False,
            outcome="BLOCKED",
            failure_class="SANDBOX_BYPASS_DENIED",
            stdout="",
            stderr="",
            returncode=None,
            result=None,
        )
    if capability_id not in HANDLERS:
        return SandboxResult(
            executed=False,
            validated=False,
            outcome="BLOCKED",
            failure_class="UNREGISTERED_HANDLER",
            stdout="",
            stderr="",
            returncode=None,
            result=None,
        )
    repo = Path(__file__).resolve().parents[1]
    try:
        tmp = tempfile.TemporaryDirectory(prefix="afaq-cap-sbx-")
    except OSError as exc:
        raise SandboxError("sandbox setup failed") from exc

    env = {
        "PYTHONPATH": str(repo),
        "PYTHONIOENCODING": "utf-8",
    }
    restore = dict(shadow_restore) if shadow_restore else export_active_restore(capability_id)
    if shadow_restore and (
        not restore.get("artifact") or not restore.get("artifact_hash")
    ):
        raise SandboxError("sandbox setup failed")
    if restore:
        env["AFAQ_CAP_RESTORE"] = json.dumps(
            {
                "capability_id": restore.get("capability_id") or capability_id,
                "artifact": restore["artifact"],
                "artifact_hash": restore["artifact_hash"],
            }
        )
    stdin = json.dumps({"capability_id": capability_id, "input": payload})
    try:
        completed = subprocess.run(
            [sys.executable, "-c", _RUNNER],
            input=stdin,
            text=True,
            capture_output=True,
            timeout=max(1, min(timeout_s, 30)),
            cwd=tmp.name,
            env=env,
            check=False,
        )
    except subprocess.TimeoutExpired:
        tmp.cleanup()
        return SandboxResult(
            executed=True,
            validated=False,
            outcome="FAILED",
            failure_class="TIMEOUT",
            stdout="",
            stderr="timeout",
            returncode=None,
            result=None,
        )
    except OSError as exc:
        tmp.cleanup()
        raise SandboxError("sandbox execution failed") from exc

    tmp.cleanup()
    parsed: dict[str, Any] | None = None
    validated = False
    failure = None
    if completed.returncode == 0:
        try:
            parsed = json.loads(completed.stdout or "{}")
            validated = isinstance(parsed, dict) and parsed.get("ok") is True
        except json.JSONDecodeError:
            failure = "INVALID_OUTPUT"
    else:
        failure = "NONZERO_EXIT"
    return SandboxResult(
        executed=True,
        validated=validated,
        outcome="PASSED" if validated else "FAILED",
        failure_class=failure,
        stdout=completed.stdout[-2000:],
        stderr=completed.stderr[-2000:],
        returncode=completed.returncode,
        result=parsed,
    )


def validate_candidate(
    capability_id: str,
    *,
    claims: dict[str, Any] | None = None,
    timeout_s: int = DEFAULT_TIMEOUT_S,
    bypass: bool = False,
) -> SandboxResult:
    """Sandbox-validate a registered candidate artifact without activation."""
    reject_caller_claims(claims)
    record, blob = export_candidate_artifact(capability_id)
    current_hash = hashlib.sha256(blob).hexdigest()
    if current_hash != record.artifact_hash:
        raise CandidateRegistrationError("CANDIDATE_TAMPERED")
    if bypass:
        return SandboxResult(
            executed=False,
            validated=False,
            outcome="BLOCKED",
            failure_class="SANDBOX_BYPASS_DENIED",
            stdout="",
            stderr="",
            returncode=None,
            result=None,
        )

    repo = Path(__file__).resolve().parents[1]
    try:
        tmp = tempfile.TemporaryDirectory(prefix="afaq-cap-cand-sbx-")
    except OSError as exc:
        raise SandboxError("sandbox setup failed") from exc

    stdin = json.dumps(
        {
            "capability_id": capability_id,
            "artifact_hex": blob.hex(),
            "artifact_hash": record.artifact_hash,
        }
    )
    env = {
        "PYTHONPATH": str(repo),
        "PYTHONIOENCODING": "utf-8",
    }
    try:
        completed = subprocess.run(
            [sys.executable, "-c", _CANDIDATE_RUNNER],
            input=stdin,
            text=True,
            capture_output=True,
            timeout=max(1, min(timeout_s, 30)),
            cwd=tmp.name,
            env=env,
            check=False,
        )
    except subprocess.TimeoutExpired:
        tmp.cleanup()
        result = SandboxResult(
            executed=True,
            validated=False,
            outcome="FAILED",
            failure_class="TIMEOUT",
            stdout="",
            stderr="timeout",
            returncode=None,
            result=None,
        )
        _store_candidate_sandbox(record.capability_id, record.artifact_hash, result)
        return result
    except OSError as exc:
        tmp.cleanup()
        raise SandboxError("sandbox execution failed") from exc

    tmp.cleanup()
    parsed: dict[str, Any] | None = None
    validated = False
    failure = None
    if completed.returncode == 0:
        try:
            parsed = json.loads(completed.stdout or "{}")
            isolated_hash = parsed.get("artifact_hash") if isinstance(parsed, dict) else None
            validated = (
                isinstance(parsed, dict)
                and parsed.get("ok") is True
                and isolated_hash == record.artifact_hash
            )
            if isolated_hash and isolated_hash != record.artifact_hash:
                raise CandidateRegistrationError("CANDIDATE_TAMPERED")
        except json.JSONDecodeError:
            failure = "INVALID_OUTPUT"
    elif (completed.stderr or "").find("artifact_hash_mismatch") >= 0:
        raise CandidateRegistrationError("CANDIDATE_TAMPERED")
    else:
        failure = "NONZERO_EXIT"
    result = SandboxResult(
        executed=True,
        validated=validated,
        outcome="PASSED" if validated else "FAILED",
        failure_class=failure,
        stdout=completed.stdout[-2000:],
        stderr=completed.stderr[-2000:],
        returncode=completed.returncode,
        result=parsed,
    )
    _store_candidate_sandbox(record.capability_id, record.artifact_hash, result)
    return result


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _canonical_digest(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def _behavior_evidence(
    *,
    capability_id: str,
    artifact_hash: str,
    requirement_id: str,
    correlation_id: str,
    input_digest: str,
    result_digest: str | None,
    execution_status: str,
    duration_ms: float | None,
    failure_reason: str | None,
) -> CandidateBehaviorEvidence:
    return CandidateBehaviorEvidence(
        behavior_evidence_id=uuid.uuid4().hex,
        capability_id=capability_id,
        artifact_hash=artifact_hash,
        requirement_id=requirement_id,
        correlation_id=correlation_id,
        input_digest=input_digest,
        result_digest=result_digest,
        execution_status=execution_status,
        duration_ms=duration_ms,
        isolation_profile=ISOLATION_PROFILE,
        timestamp=_now(),
        failure_reason=failure_reason,
    )


def _finish_behavior(
    evidence: CandidateBehaviorEvidence,
    *,
    return_value: Any = None,
    return_type: str | None = None,
) -> BehavioralSandboxResult:
    stored = replace(evidence, return_value=return_value, return_type=return_type)
    record_candidate_behavior(stored)
    return BehavioralSandboxResult(
        status=stored.execution_status,
        capability_id=stored.capability_id,
        artifact_hash=stored.artifact_hash,
        correlation_id=stored.correlation_id,
        requirement_id=stored.requirement_id,
        input_digest=stored.input_digest,
        result_digest=stored.result_digest,
        return_value=return_value,
        return_type=return_type,
        duration_ms=stored.duration_ms,
        failure_reason=stored.failure_reason,
        evidence=stored,
    )


def execute_candidate_behavior(
    capability_id: str,
    *,
    test_input: Mapping[str, Any] | None = None,
    claims: Mapping[str, Any] | None = None,
    timeout_s: int = DEFAULT_TIMEOUT_S,
    bypass: bool = False,
) -> BehavioralSandboxResult:
    """Observe implementation-source handle() in isolation. Not evaluation."""
    reject_caller_claims(claims)
    record, blob = export_candidate_artifact(capability_id)
    current_hash = hashlib.sha256(blob).hexdigest()
    if current_hash != record.artifact_hash:
        raise CandidateRegistrationError("CANDIDATE_TAMPERED")
    correlation_id = uuid.uuid4().hex
    requirement_id = ""
    input_digest = "NONE"

    if bypass:
        evidence = _behavior_evidence(
            capability_id=record.capability_id,
            artifact_hash=current_hash,
            requirement_id=requirement_id,
            correlation_id=correlation_id,
            input_digest=input_digest,
            result_digest=None,
            execution_status=BEHAVIOR_BLOCKED,
            duration_ms=None,
            failure_reason="SANDBOX_BYPASS_DENIED",
        )
        return _finish_behavior(evidence)

    if not isinstance(test_input, Mapping) or not test_input:
        evidence = _behavior_evidence(
            capability_id=record.capability_id,
            artifact_hash=current_hash,
            requirement_id=requirement_id,
            correlation_id=correlation_id,
            input_digest=input_digest,
            result_digest=None,
            execution_status=INSUFFICIENT_TEST_INPUT,
            duration_ms=None,
            failure_reason="INSUFFICIENT_TEST_INPUT",
        )
        return _finish_behavior(evidence)
    missing = [field for field in _REQUIRED_BEHAVIOR_INPUT if field not in test_input]
    if missing:
        evidence = _behavior_evidence(
            capability_id=record.capability_id,
            artifact_hash=current_hash,
            requirement_id=str(test_input.get("requirement_id") or ""),
            correlation_id=correlation_id,
            input_digest=_canonical_digest(dict(test_input)),
            result_digest=None,
            execution_status=INSUFFICIENT_TEST_INPUT,
            duration_ms=None,
            failure_reason="INSUFFICIENT_TEST_INPUT",
        )
        return _finish_behavior(evidence)
    if test_input.get("capability_id") != record.capability_id:
        evidence = _behavior_evidence(
            capability_id=record.capability_id,
            artifact_hash=current_hash,
            requirement_id=str(test_input.get("requirement_id") or ""),
            correlation_id=correlation_id,
            input_digest=_canonical_digest(dict(test_input)),
            result_digest=None,
            execution_status=INSUFFICIENT_TEST_INPUT,
            duration_ms=None,
            failure_reason="INSUFFICIENT_TEST_INPUT",
        )
        return _finish_behavior(evidence)
    claimed_hash = test_input.get("artifact_hash")
    if claimed_hash is not None and claimed_hash != current_hash:
        raise CandidateRegistrationError("CANDIDATE_TAMPERED")

    requirement_id = str(test_input["requirement_id"])
    input_digest = _canonical_digest(dict(test_input))
    if record.artifact_class != ARTIFACT_IMPLEMENTATION_SOURCE:
        evidence = _behavior_evidence(
            capability_id=record.capability_id,
            artifact_hash=current_hash,
            requirement_id=requirement_id,
            correlation_id=correlation_id,
            input_digest=input_digest,
            result_digest=None,
            execution_status=BEHAVIOR_BLOCKED,
            duration_ms=None,
            failure_reason="SPECIFICATION_ARTIFACT_NOT_EXECUTABLE",
        )
        return _finish_behavior(evidence)

    try:
        source = blob.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise CandidateRegistrationError("MALFORMED_ARTIFACT") from exc
    genesis_mod = importlib.import_module("capability_cycle.genesis")
    try:
        genesis_mod.validate_implementation_source(source, record.capability_id)
    except genesis_mod.GenesisError as exc:
        reason = str(exc)
        evidence = _behavior_evidence(
            capability_id=record.capability_id,
            artifact_hash=current_hash,
            requirement_id=requirement_id,
            correlation_id=correlation_id,
            input_digest=input_digest,
            result_digest=None,
            execution_status=BEHAVIOR_BLOCKED,
            duration_ms=None,
            failure_reason=reason,
        )
        return _finish_behavior(evidence)

    try:
        tmp = tempfile.TemporaryDirectory(prefix="afaq-cap-beh-sbx-")
    except OSError as exc:
        raise SandboxError("sandbox setup failed") from exc

    stdin = json.dumps(
        {
            "capability_id": record.capability_id,
            "source_hex": blob.hex(),
            "artifact_hash": current_hash,
            "correlation_id": correlation_id,
            "test_payload": test_input["test_payload"],
        }
    )
    repo = Path(__file__).resolve().parents[1]
    env = {
        "PYTHONPATH": str(repo),
        "PYTHONIOENCODING": "utf-8",
        "PYTHONNOUSERSITE": "1",
        "PYTHONDONTWRITEBYTECODE": "1",
    }
    started = time.perf_counter()
    bound = max(1, min(timeout_s, 30))
    try:
        completed = subprocess.run(
            [sys.executable, "-c", _BEHAVIOR_RUNNER],
            input=stdin,
            text=True,
            capture_output=True,
            timeout=bound,
            cwd=tmp.name,
            env=env,
            check=False,
        )
    except subprocess.TimeoutExpired:
        tmp.cleanup()
        evidence = _behavior_evidence(
            capability_id=record.capability_id,
            artifact_hash=current_hash,
            requirement_id=requirement_id,
            correlation_id=correlation_id,
            input_digest=input_digest,
            result_digest=None,
            execution_status=BEHAVIOR_TIMEOUT,
            duration_ms=bound * 1000.0,
            failure_reason="TIMEOUT",
        )
        return _finish_behavior(evidence)
    except OSError as exc:
        tmp.cleanup()
        raise SandboxError("sandbox execution failed") from exc

    tmp.cleanup()
    duration_ms = (time.perf_counter() - started) * 1000.0
    stderr = (completed.stderr or "")[-2000:]
    if completed.returncode not in {0, 2}:
        reason = "NONZERO_EXIT"
        if "artifact_hash_mismatch" in (completed.stderr or "") or completed.returncode == 3:
            raise CandidateRegistrationError("CANDIDATE_TAMPERED")
        if "malformed_source" in (completed.stderr or ""):
            reason = "MALFORMED_ARTIFACT"
        if "missing_handle" in (completed.stderr or ""):
            reason = "MISSING_ENTRYPOINT"
        evidence = _behavior_evidence(
            capability_id=record.capability_id,
            artifact_hash=current_hash,
            requirement_id=requirement_id,
            correlation_id=correlation_id,
            input_digest=input_digest,
            result_digest=None,
            execution_status=BEHAVIOR_BLOCKED if reason != "NONZERO_EXIT" else BEHAVIOR_FAILED,
            duration_ms=duration_ms,
            failure_reason=reason,
        )
        return _finish_behavior(evidence)

    try:
        parsed = json.loads(completed.stdout or "")
    except json.JSONDecodeError:
        evidence = _behavior_evidence(
            capability_id=record.capability_id,
            artifact_hash=current_hash,
            requirement_id=requirement_id,
            correlation_id=correlation_id,
            input_digest=input_digest,
            result_digest=None,
            execution_status=BEHAVIOR_FAILED,
            duration_ms=duration_ms,
            failure_reason="INVALID_OUTPUT",
        )
        return _finish_behavior(evidence)

    if (
        not isinstance(parsed, dict)
        or parsed.get("protocol") != BEHAVIOR_PROTOCOL
        or parsed.get("artifact_hash") != current_hash
        or parsed.get("capability_id") != record.capability_id
        or parsed.get("correlation_id") != correlation_id
    ):
        if isinstance(parsed, dict) and parsed.get("artifact_hash") not in {None, current_hash}:
            raise CandidateRegistrationError("CANDIDATE_TAMPERED")
        evidence = _behavior_evidence(
            capability_id=record.capability_id,
            artifact_hash=current_hash,
            requirement_id=requirement_id,
            correlation_id=correlation_id,
            input_digest=input_digest,
            result_digest=None,
            execution_status=BEHAVIOR_FAILED,
            duration_ms=duration_ms,
            failure_reason="INVALID_OUTPUT",
        )
        return _finish_behavior(evidence)

    status = str(parsed.get("execution_status") or BEHAVIOR_FAILED)
    if status not in {BEHAVIOR_EXECUTED, BEHAVIOR_FAILED}:
        status = BEHAVIOR_FAILED
    return_value = parsed.get("return_value")
    result_digest = None
    if status == BEHAVIOR_EXECUTED:
        result_digest = _canonical_digest(return_value)
    evidence = _behavior_evidence(
        capability_id=record.capability_id,
        artifact_hash=current_hash,
        requirement_id=requirement_id,
        correlation_id=correlation_id,
        input_digest=input_digest,
        result_digest=result_digest,
        execution_status=status,
        duration_ms=float(parsed.get("duration_ms") or duration_ms),
        failure_reason=None if status == BEHAVIOR_EXECUTED else str(
            parsed.get("error_class") or stderr or "BEHAVIOR_FAILED"
        ),
    )
    return _finish_behavior(
        evidence,
        return_value=return_value,
        return_type=parsed.get("return_type"),
    )


def _store_candidate_sandbox(
    capability_id: str,
    artifact_hash: str,
    result: SandboxResult,
) -> None:
    correlation_id = uuid.uuid4().hex
    record_candidate_sandbox(
        CandidateSandboxEvidence(
            capability_id=capability_id,
            artifact_hash=artifact_hash,
            validated=result.validated,
            outcome=result.outcome,
            failure_class=result.failure_class,
            evidence_ref=f"candidate-sandbox:{capability_id}:{artifact_hash[:16]}:{correlation_id[:8]}",
            correlation_id=correlation_id,
        )
    )
