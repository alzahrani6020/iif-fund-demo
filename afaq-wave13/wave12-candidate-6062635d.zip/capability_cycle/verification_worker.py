from __future__ import annotations

from dataclasses import dataclass

from .reconciliation_contracts import (
    VerificationDecision,
    VerificationStatus,
)


@dataclass(frozen=True)
class VerificationAssessment:
    assessment_id: str
    cycle_id: str
    subject_ref: str
    expected_ref: str | None
    actual_ref: str | None
    contract_refs: tuple[str, ...]
    evidence_refs: tuple[str, ...]
    status: VerificationStatus
    reason_codes: tuple[str, ...]
    verifier_identity_ref: str
    observed_at: str
    recorded_at: str


def _require_text(value: str, field: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field} must be non-empty")


def _validate_refs(values: tuple[str, ...], field: str) -> None:
    if not isinstance(values, tuple):
        raise TypeError(f"{field} must be tuple[str, ...]")

    seen: set[str] = set()

    for value in values:
        _require_text(value, field)

        if value in seen:
            raise ValueError(
                f"{field} contains duplicate references"
            )

        seen.add(value)


def produce_verification_decision(
    assessment: VerificationAssessment,
) -> VerificationDecision:
    for field, value in (
        ("assessment_id", assessment.assessment_id),
        ("cycle_id", assessment.cycle_id),
        ("subject_ref", assessment.subject_ref),
        ("verifier_identity_ref", assessment.verifier_identity_ref),
        ("observed_at", assessment.observed_at),
        ("recorded_at", assessment.recorded_at),
    ):
        _require_text(value, field)

    _validate_refs(
        assessment.contract_refs,
        "contract_refs",
    )

    _validate_refs(
        assessment.evidence_refs,
        "evidence_refs",
    )

    _validate_refs(
        assessment.reason_codes,
        "reason_codes",
    )

    if not assessment.reason_codes:
        raise ValueError(
            "VERIFICATION_REQUIRES_REASON_CODE"
        )

    if assessment.status in {
        VerificationStatus.VERIFIED,
        VerificationStatus.FAILED,
    }:
        if not assessment.expected_ref:
            raise ValueError(
                "VERIFIED_OR_FAILED_REQUIRES_EXPECTED_REF"
            )

        if not assessment.actual_ref:
            raise ValueError(
                "VERIFIED_OR_FAILED_REQUIRES_ACTUAL_REF"
            )

        if not assessment.evidence_refs:
            raise ValueError(
                "VERIFIED_OR_FAILED_REQUIRES_EVIDENCE"
            )

    return VerificationDecision(
        verification_id=assessment.assessment_id,
        cycle_id=assessment.cycle_id,
        subject_ref=assessment.subject_ref,
        expected_ref=assessment.expected_ref,
        actual_ref=assessment.actual_ref,
        contract_refs=assessment.contract_refs,
        evidence_refs=assessment.evidence_refs,
        status=assessment.status,
        reason_codes=assessment.reason_codes,
        verifier_identity_ref=assessment.verifier_identity_ref,
        observed_at=assessment.observed_at,
        recorded_at=assessment.recorded_at,
    )
