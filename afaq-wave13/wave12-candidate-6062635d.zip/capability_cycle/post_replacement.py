"""Post-replacement observe / KEEP / ROLLBACK_RECOMMENDED decision.

Decision-only. Does not restore, replace, promote, train, or mutate runtime.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Mapping

from ._post_replacement_state import _DECISIONS
from .drift import DriftEvidenceFailed, DriftThresholds, evaluate_drift
from .handlers import active_version_id, artifact_hash
from .improvement import (
    CapabilityReplacement,
    ImprovementComparison,
    ImprovementError,
    _bind_expected_outcome,
    _load_comparison,
    get_capability_replacement,
)
from .learning import LearningThresholds, _reject_claims
from .performance_store import (
    PerformanceEvidence,
    PerformanceStore,
    StoreCorruptRecord,
    StoreReadFailed,
)

DECISION_STATUSES = frozenset(
    {"KEEP", "ROLLBACK_RECOMMENDED", "INSUFFICIENT_EVIDENCE"}
)
_MIN_POST_SAMPLES = LearningThresholds().min_comparative_samples
_SAMPLE_RULE = (
    f"minimum {_MIN_POST_SAMPLES} post-replacement FINAL records "
    "for the same logical capability and new active artifact "
    "(LearningThresholds.min_comparative_samples)"
)


class PostReplacementError(ImprovementError):
    """Fail-closed post-replacement evaluation rejection."""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def clear_post_replacement_decisions() -> None:
    _DECISIONS.clear()


@dataclass(frozen=True)
class PostReplacementDecision:
    decision_id: str
    replacement_id: str
    target_capability_id: str
    old_artifact_hash: str
    new_artifact_hash: str
    baseline_evidence_refs: tuple[str, ...]
    post_replacement_evidence_refs: tuple[str, ...]
    baseline_metrics: dict[str, Any]
    post_metrics: dict[str, Any]
    sample_count: int
    mission_success_delta: float | None
    failure_rate_delta: float | None
    duration_delta: float | None
    replan_delta: float | None
    drift_status: str
    status: str
    reason: str
    created_at: str
    comparison_id: str = ""
    sample_rule: str = _SAMPLE_RULE
    auto_rollback: bool = False
    promotion_activated: bool = False
    training_activated: bool = False
    details: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "decision_id": self.decision_id,
            "replacement_id": self.replacement_id,
            "comparison_id": self.comparison_id,
            "target_capability_id": self.target_capability_id,
            "old_artifact_hash": self.old_artifact_hash,
            "new_artifact_hash": self.new_artifact_hash,
            "baseline_evidence_refs": list(self.baseline_evidence_refs),
            "post_replacement_evidence_refs": list(self.post_replacement_evidence_refs),
            "baseline_metrics": dict(self.baseline_metrics),
            "post_metrics": dict(self.post_metrics),
            "sample_count": self.sample_count,
            "mission_success_delta": self.mission_success_delta,
            "failure_rate_delta": self.failure_rate_delta,
            "duration_delta": self.duration_delta,
            "replan_delta": self.replan_delta,
            "drift_status": self.drift_status,
            "status": self.status,
            "reason": self.reason,
            "created_at": self.created_at,
            "sample_rule": self.sample_rule,
            "auto_rollback": False,
            "promotion_activated": False,
            "training_activated": False,
            "details": dict(self.details),
        }


def get_post_replacement_decision(decision_id: str) -> PostReplacementDecision | None:
    return _DECISIONS.get(decision_id)


def _replacement_from_mapping(data: Mapping[str, Any]) -> CapabilityReplacement:
    return CapabilityReplacement(
        replacement_id=str(data["replacement_id"]),
        comparison_id=str(data["comparison_id"]),
        proposal_id=str(data.get("proposal_id") or ""),
        proposal_evaluation_id=str(data.get("proposal_evaluation_id") or ""),
        target_capability_id=str(data["target_capability_id"]),
        candidate_capability_id=str(data.get("candidate_capability_id") or ""),
        old_artifact_hash=str(data.get("old_artifact_hash") or ""),
        candidate_artifact_hash=str(data["candidate_artifact_hash"]),
        behavioral_certification_ref=str(data.get("behavioral_certification_ref") or ""),
        authority_result=str(data.get("authority_result") or ""),
        pre_replacement_snapshot_ref=str(data.get("pre_replacement_snapshot_ref") or ""),
        switch_result=str(data.get("switch_result") or ""),
        post_switch_verification=dict(data.get("post_switch_verification") or {}),
        runtime_verification_ref=data.get("runtime_verification_ref"),
        replacement_eligibility=str(data.get("replacement_eligibility") or "NO"),
        status=str(data["status"]),
        reason=str(data.get("reason") or ""),
        created_at=str(data["created_at"]),
        created_by=str(data.get("created_by") or ""),
    )


def _load_replacement(store: PerformanceStore, replacement_id: str) -> CapabilityReplacement:
    loaded = get_capability_replacement(replacement_id)
    if loaded is not None:
        return loaded
    try:
        return _replacement_from_mapping(store.get_capability_replacement(replacement_id))
    except StoreReadFailed as exc:
        raise PostReplacementError("UNKNOWN_REPLACEMENT") from exc
    except StoreCorruptRecord as exc:
        raise PostReplacementError("REPLACEMENT_EVIDENCE_CORRUPT") from exc


def _required_replacement_fields(replacement: CapabilityReplacement) -> None:
    if replacement.status != "APPLIED":
        raise PostReplacementError("REPLACEMENT_NOT_APPLIED")
    missing = [
        name
        for name, value in (
            ("comparison_id", replacement.comparison_id),
            ("target_capability_id", replacement.target_capability_id),
            ("old_artifact_hash", replacement.old_artifact_hash),
            ("candidate_artifact_hash", replacement.candidate_artifact_hash),
            ("pre_replacement_snapshot_ref", replacement.pre_replacement_snapshot_ref),
            ("runtime_verification_ref", replacement.runtime_verification_ref),
        )
        if not value
    ]
    if missing:
        raise PostReplacementError("REPLACEMENT_INCOMPLETE")


def _is_final(record: PerformanceEvidence) -> bool:
    return record.record_kind == "FINAL"


def _verified_success(record: PerformanceEvidence) -> bool:
    return (
        record.mission_verification_status == "VERIFIED"
        and record.final_outcome == "SUCCESS"
    )


def _metrics(records: tuple[PerformanceEvidence, ...]) -> dict[str, Any]:
    if not records:
        return {
            "verified_success_rate": None,
            "execution_success_rate": None,
            "failure_rate": None,
            "mean_duration_ms": None,
            "replan_rate": None,
        }
    n = len(records)
    verified = sum(1 for record in records if _verified_success(record))
    executed = sum(1 for record in records if record.execution_outcome == "SUCCESS")
    failed = sum(
        1
        for record in records
        if record.mission_verification_status in {"FAILED", "INSUFFICIENT_EVIDENCE"}
    )
    durations = [record.duration_ms for record in records]
    replans = sum(1 for record in records if (record.replan_attempt or 0) > 0)
    return {
        "verified_success_rate": round(verified / n, 3),
        "execution_success_rate": round(executed / n, 3),
        "failure_rate": round(failed / n, 3),
        "mean_duration_ms": round(sum(durations) / n, 3),
        "replan_rate": round(replans / n, 3),
    }


def _delta(left: Any, right: Any) -> float | None:
    if not isinstance(left, (int, float)) or not isinstance(right, (int, float)):
        return None
    return round(right - left, 3)


def _finish(
    store: PerformanceStore,
    *,
    replacement: CapabilityReplacement,
    comparison: ImprovementComparison | None,
    status: str,
    reason: str,
    baseline_metrics: dict[str, Any],
    post_metrics: dict[str, Any],
    baseline_refs: tuple[str, ...],
    post_refs: tuple[str, ...],
    sample_count: int,
    drift_status: str,
    details: dict[str, Any],
) -> PostReplacementDecision:
    if status not in DECISION_STATUSES:
        raise PostReplacementError("INVALID_DECISION_STATUS")
    decision = PostReplacementDecision(
        decision_id=uuid.uuid4().hex,
        replacement_id=replacement.replacement_id,
        comparison_id=replacement.comparison_id,
        target_capability_id=replacement.target_capability_id,
        old_artifact_hash=replacement.old_artifact_hash,
        new_artifact_hash=replacement.candidate_artifact_hash,
        baseline_evidence_refs=baseline_refs,
        post_replacement_evidence_refs=post_refs,
        baseline_metrics=dict(baseline_metrics),
        post_metrics=dict(post_metrics),
        sample_count=sample_count,
        mission_success_delta=_delta(
            baseline_metrics.get("verified_success_rate"),
            post_metrics.get("verified_success_rate"),
        ),
        failure_rate_delta=_delta(
            baseline_metrics.get("failure_rate"),
            post_metrics.get("failure_rate"),
        ),
        duration_delta=_delta(
            baseline_metrics.get("mean_duration_ms"),
            post_metrics.get("mean_duration_ms"),
        ),
        replan_delta=_delta(
            baseline_metrics.get("replan_rate"),
            post_metrics.get("replan_rate"),
        ),
        drift_status=drift_status,
        status=status,
        reason=reason,
        created_at=_now(),
        details=details,
    )
    _DECISIONS[decision.decision_id] = decision
    store.persist_post_replacement_decision(decision.as_dict())
    return decision


def evaluate_post_replacement(
    store: PerformanceStore,
    *,
    replacement_id: str,
    requester: str = "observer",
    claims: Mapping[str, Any] | None = None,
    historical_records: tuple[Mapping[str, Any], ...] = (),
    target_capability_id: str | None = None,
) -> PostReplacementDecision:
    """Classify an APPLIED replacement. Never mutates active runtime."""
    _reject_claims(claims)
    del historical_records
    del requester

    replacement = _load_replacement(store, replacement_id)
    _required_replacement_fields(replacement)
    target = replacement.target_capability_id
    if target_capability_id and target_capability_id != target:
        raise PostReplacementError("CROSS_CAPABILITY_EVIDENCE")

    try:
        comparison = _load_comparison(store, replacement.comparison_id)
    except ImprovementError:
        comparison = None

    empty = _metrics(())
    if comparison is None:
        return _finish(
            store,
            replacement=replacement,
            comparison=None,
            status="INSUFFICIENT_EVIDENCE",
            reason="BASELINE_MISSING",
            baseline_metrics=empty,
            post_metrics=empty,
            baseline_refs=(),
            post_refs=(),
            sample_count=0,
            drift_status="INSUFFICIENT_EVIDENCE",
            details={"authority": False},
        )
    if comparison.target_capability_id != target:
        raise PostReplacementError("CROSS_CAPABILITY_EVIDENCE")
    if comparison.candidate_artifact_hash != replacement.candidate_artifact_hash:
        raise PostReplacementError("CROSS_VERSION_EVIDENCE")
    if (
        comparison.baseline_artifact_hash
        and comparison.baseline_artifact_hash != replacement.old_artifact_hash
    ):
        raise PostReplacementError("CROSS_VERSION_EVIDENCE")

    current = active_version_id(target) or artifact_hash(target)
    if current != replacement.candidate_artifact_hash:
        return _finish(
            store,
            replacement=replacement,
            comparison=comparison,
            status="INSUFFICIENT_EVIDENCE",
            reason="STALE_REPLACEMENT_CONTEXT",
            baseline_metrics=dict(comparison.baseline_metrics),
            post_metrics=empty,
            baseline_refs=tuple(comparison.evidence_refs),
            post_refs=(),
            sample_count=0,
            drift_status="INSUFFICIENT_EVIDENCE",
            details={"authority": False, "current_active_artifact": current},
        )

    workload = dict(comparison.workload_definition or {})
    mission_class = str(workload.get("mission_class") or target)
    if mission_class != target:
        return _finish(
            store,
            replacement=replacement,
            comparison=comparison,
            status="INSUFFICIENT_EVIDENCE",
            reason="MISSION_CLASS_CHANGED",
            baseline_metrics=dict(comparison.baseline_metrics),
            post_metrics=empty,
            baseline_refs=tuple(comparison.evidence_refs),
            post_refs=(),
            sample_count=0,
            drift_status="INSUFFICIENT_EVIDENCE",
            details={"authority": False},
        )

    expected_metric = comparison.expected_outcome_metric or _bind_expected_outcome(
        comparison.expected_outcome
    )
    if not expected_metric:
        return _finish(
            store,
            replacement=replacement,
            comparison=comparison,
            status="INSUFFICIENT_EVIDENCE",
            reason="EXPECTED_OUTCOME_NOT_MEASURABLE",
            baseline_metrics=dict(comparison.baseline_metrics),
            post_metrics=empty,
            baseline_refs=tuple(comparison.evidence_refs),
            post_refs=(),
            sample_count=0,
            drift_status="INSUFFICIENT_EVIDENCE",
            details={"authority": False},
        )

    try:
        records = store.checked_by_capability_id(target)
    except StoreCorruptRecord as exc:
        return _finish(
            store,
            replacement=replacement,
            comparison=comparison,
            status="INSUFFICIENT_EVIDENCE",
            reason="EVIDENCE_CORRUPT",
            baseline_metrics=dict(comparison.baseline_metrics),
            post_metrics=empty,
            baseline_refs=tuple(comparison.evidence_refs),
            post_refs=(),
            sample_count=0,
            drift_status="INSUFFICIENT_EVIDENCE",
            details={"authority": False, "error": str(exc)},
        )

    cutoff = replacement.created_at
    finals = tuple(record for record in records if _is_final(record))
    after = tuple(record for record in finals if record.timestamp > cutoff)
    post = tuple(
        record
        for record in after
        if record.capability_version == replacement.candidate_artifact_hash
    )
    ambiguous = tuple(
        record
        for record in after
        if not record.capability_version
    )
    old_after = tuple(
        record
        for record in after
        if record.capability_version == replacement.old_artifact_hash
    )
    if not post and (ambiguous or old_after):
        return _finish(
            store,
            replacement=replacement,
            comparison=comparison,
            status="INSUFFICIENT_EVIDENCE",
            reason="VERSION_IDENTITY_AMBIGUOUS" if ambiguous and not old_after else "OLD_VERSION_SAMPLES_EXCLUDED",
            baseline_metrics=dict(comparison.baseline_metrics),
            post_metrics=empty,
            baseline_refs=tuple(comparison.evidence_refs),
            post_refs=(),
            sample_count=0,
            drift_status="INSUFFICIENT_EVIDENCE",
            details={"authority": False, "excluded_old_version": len(old_after)},
        )

    post_metrics = _metrics(post)
    baseline_metrics = dict(comparison.baseline_metrics)
    if baseline_metrics.get("verified_success_rate") is None:
        pre = tuple(
            record
            for record in finals
            if record.timestamp <= cutoff
            and record.capability_version == replacement.old_artifact_hash
        )
        if pre:
            baseline_metrics = _metrics(pre)
    if baseline_metrics.get("verified_success_rate") is None:
        return _finish(
            store,
            replacement=replacement,
            comparison=comparison,
            status="INSUFFICIENT_EVIDENCE",
            reason="BASELINE_MISSING",
            baseline_metrics=baseline_metrics or empty,
            post_metrics=post_metrics,
            baseline_refs=tuple(comparison.evidence_refs),
            post_refs=tuple(record.record_id for record in post),
            sample_count=len(post),
            drift_status="INSUFFICIENT_EVIDENCE",
            details={"authority": False},
        )

    thresholds = DriftThresholds()
    try:
        drift = evaluate_drift(
            store,
            capability_id=target,
            metric="mission_success_rate",
            persist=False,
            historical_records=(),
        )
        drift_status = drift.status
        drift_ref = drift.evaluation_id
    except (DriftEvidenceFailed, ValueError):
        drift_status = "INSUFFICIENT_EVIDENCE"
        drift_ref = None

    details = {
        "authority": False,
        "expected_outcome_metric": expected_metric,
        "mission_class": mission_class,
        "sample_rule": _SAMPLE_RULE,
        "drift_ref": drift_ref,
        "acceptance_criteria": list(workload.get("acceptance_criteria") or ()),
        "runtime_verification_ref": replacement.runtime_verification_ref,
        "pre_replacement_snapshot_ref": replacement.pre_replacement_snapshot_ref,
    }
    baseline_refs = tuple(comparison.evidence_refs)
    post_refs = tuple(record.record_id for record in post)

    if len(post) < _MIN_POST_SAMPLES:
        return _finish(
            store,
            replacement=replacement,
            comparison=comparison,
            status="INSUFFICIENT_EVIDENCE",
            reason="INSUFFICIENT_SAMPLES",
            baseline_metrics=baseline_metrics,
            post_metrics=post_metrics,
            baseline_refs=baseline_refs,
            post_refs=post_refs,
            sample_count=len(post),
            drift_status=drift_status,
            details=details,
        )

    success_drop = (
        round(
            float(baseline_metrics["verified_success_rate"])
            - float(post_metrics["verified_success_rate"]),
            3,
        )
        if isinstance(baseline_metrics.get("verified_success_rate"), (int, float))
        and isinstance(post_metrics.get("verified_success_rate"), (int, float))
        else None
    )
    failure_increase = _delta(
        baseline_metrics.get("failure_rate"),
        post_metrics.get("failure_rate"),
    )
    duration_ratio = None
    baseline_duration = baseline_metrics.get("mean_duration_ms")
    post_duration = post_metrics.get("mean_duration_ms")
    if (
        isinstance(baseline_duration, (int, float))
        and baseline_duration > 0
        and isinstance(post_duration, (int, float))
    ):
        duration_ratio = round(post_duration / baseline_duration, 3)
    replan_increase = _delta(
        baseline_metrics.get("replan_rate"),
        post_metrics.get("replan_rate"),
    )
    expected_delta = _delta(
        baseline_metrics.get(expected_metric),
        post_metrics.get(expected_metric),
    )
    if expected_metric in {"failure_rate", "mean_duration_ms", "replan_rate"}:
        expected_contradicted = expected_delta is not None and expected_delta > 0
    else:
        expected_contradicted = expected_delta is not None and expected_delta < 0

    material = bool(
        (success_drop is not None and success_drop >= thresholds.success_rate_degraded_drop)
        or (
            failure_increase is not None
            and failure_increase >= thresholds.verification_failure_degraded
        )
        or (duration_ratio is not None and duration_ratio >= thresholds.duration_degraded_ratio)
        or (
            replan_increase is not None
            and replan_increase >= thresholds.replan_degraded_delta
        )
        or drift_status == "DEGRADED"
    )
    required_regression = bool(
        success_drop is not None and success_drop > 0
    )
    mission_outcomes_ok = (
        isinstance(post_metrics.get("verified_success_rate"), (int, float))
        and post_metrics["verified_success_rate"]
        >= float(baseline_metrics.get("verified_success_rate") or 0)
    )

    if drift_status == "INSUFFICIENT_EVIDENCE":
        return _finish(
            store,
            replacement=replacement,
            comparison=comparison,
            status="INSUFFICIENT_EVIDENCE",
            reason="DRIFT_INSUFFICIENT_EVIDENCE",
            baseline_metrics=baseline_metrics,
            post_metrics=post_metrics,
            baseline_refs=baseline_refs,
            post_refs=post_refs,
            sample_count=len(post),
            drift_status=drift_status,
            details=details,
        )
    if material:
        return _finish(
            store,
            replacement=replacement,
            comparison=comparison,
            status="ROLLBACK_RECOMMENDED",
            reason="POST_REPLACEMENT_REGRESSION",
            baseline_metrics=baseline_metrics,
            post_metrics=post_metrics,
            baseline_refs=baseline_refs,
            post_refs=post_refs,
            sample_count=len(post),
            drift_status=drift_status,
            details=details,
        )
    if required_regression or expected_contradicted or not mission_outcomes_ok:
        return _finish(
            store,
            replacement=replacement,
            comparison=comparison,
            status="INSUFFICIENT_EVIDENCE",
            reason="REQUIRED_METRIC_NOT_DECISIVE",
            baseline_metrics=baseline_metrics,
            post_metrics=post_metrics,
            baseline_refs=baseline_refs,
            post_refs=post_refs,
            sample_count=len(post),
            drift_status=drift_status,
            details=details,
        )
    return _finish(
        store,
        replacement=replacement,
        comparison=comparison,
        status="KEEP",
        reason="POST_REPLACEMENT_STABLE",
        baseline_metrics=baseline_metrics,
        post_metrics=post_metrics,
        baseline_refs=baseline_refs,
        post_refs=post_refs,
        sample_count=len(post),
        drift_status=drift_status,
        details=details,
    )
