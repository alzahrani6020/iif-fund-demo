"""Deterministic capability id scheme: snake_case name ↔ CAP-{SLUG}-{HASH8}."""

from __future__ import annotations

import hashlib
import re

_PROTECTED = frozenset({"CAP-AUDIT-001", "CAP-EVAL-001", "CAP-TRUTH-001"})


def is_protected_capability_id(capability_id: str) -> bool:
    return capability_id in _PROTECTED


def capability_id_for_name(name: str) -> str:
    name = str(name).strip()
    if not name:
        raise ValueError("capability name empty")
    slug = re.sub(r"[^A-Za-z0-9]+", "-", name.upper()).strip("-")
    if not slug:
        slug = "CAP"
    slug = slug[:48].rstrip("-")
    digest = hashlib.sha256(name.encode("utf-8")).hexdigest()[:8].upper()
    return f"CAP-{slug}-{digest}"


def map_names(names: list[str] | set[str] | tuple[str, ...]) -> dict[str, str]:
    """name → capability_id (skips empties)."""
    out: dict[str, str] = {}
    for raw in names:
        name = str(raw).strip()
        if not name:
            continue
        out[name] = capability_id_for_name(name)
    return out
