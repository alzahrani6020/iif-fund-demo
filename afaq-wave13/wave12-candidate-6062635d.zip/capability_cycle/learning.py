"""Evidence-derived learning observations and improvement proposals.

SELF_LEARNING here means: analyze verified runtime evidence and emit a
structured lesson or proposal. It does not generate code, train models,
activate capabilities, promote candidates, roll back, or change authority.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Mapping

from .drift import DriftEvaluation, evaluate_drift
from .performance_store import (
    PerformanceEvidence,
    PerformanceStore,
    StoreCorruptRecord,
    StoreReadFailed,
)

OBSERVATION_TYPES = frozenset(
    {
        "SUCCESS_PATTERN",
        "FAILURE_PATTERN",
        "REPLAN_PATTERN",
        "PERFORMANCE_DEGRADATION",
        "PERFORMANCE_IMPROVEMENT",
        "CONTRACT_FAILURE",
        "INSUFFICIENT_EVIDENCE",
        "NO_ACTION",
    }
)
PROPOSAL_CHANGE_TYPES = frozenset(
    {
        "INVESTIGATE",
        "CONTRACT_ADJUSTMENT_PROPOSAL",
        "IMPLEMENTATION_CHANGE_PROPOSAL",
        "ROUTING_CHANGE_PROPOSAL",
        "TEST_EXPANSION_PROPOSAL",
        "NO_ACTION",
    }
)
PROPOSAL_STATUSES = frozenset({"PROPOSED", "NO_ACTION", "INSUFFICIENT_EVIDENCE"})
CONTRACT_FAILURE_MARKERS = frozenset(
    {
        "OUTPUT_CONTRACT",
        "INPUT_CONTRACT",
        "CONTRACT_FAILURE",
        "CONTRACT_MISMATCH",
        "BEHAVIORAL_CONTRACT",
    }
)


class LearningError(RuntimeError):
    """Fail-closed learning rejection."""


class LearningEvidenceFailed(LearningError):
    """Required source records failed integrity and were not used."""


@dataclass(frozen=True)
class LearningThresholds:
    min_samples: int = 5
    min_comparative_samples: int = 5
    failure_rate_pattern: float = 0.40
    replan_frequency_pattern: float = 1.0
    duration_degradation_ratio: float = 2.0
    success_rate_stable: float = 0.80

    def as_dict(self) -> dict[str, Any]:
        return {
            "min_samples": self.min_samples,
            "min_comparative_samples": self.min_comparative_samples,
            "failure_rate_pattern": self.failure_rate_pattern,
            "replan_frequency_pattern": self.replan_frequency_pattern,
            "duration_degradation_ratio": self.duration_degradation_ratio,
            "success_rate_stable": self.success_rate_stable,
        }


@dataclass(frozen=True)
class LearningObservation:
    learning_observation_id: str
    capability_id: str
    artifact_hash: str | None
    evidence_scope: dict[str, Any]
    evidence_refs: tuple[str, ...]
    sample_count: int
    observation_type: str
    finding: str
    observed_facts: tuple[str, ...]
    derived_inference: str
    confidence: str
    created_at: str
    drift_evaluation_ref: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "learning_observation_id": self.learning_observation_id,
            "capability_id": self.capability_id,
            "artifact_hash": self.artifact_hash,
            "evidence_scope": dict(self.evidence_scope),
            "evidence_refs": list(self.evidence_refs),
            "sample_count": self.sample_count,
            "observation_type": self.observation_type,
            "finding": self.finding,
            "observed_facts": list(self.observed_facts),
            "derived_inference": self.derived_inference,
            "confidence": self.confidence,
            "created_at": self.created_at,
            "drift_evaluation_ref": self.drift_evaluation_ref,
        }


@dataclass(frozen=True)
class ImprovementProposal:
    proposal_id: str
    source_learning_observation_id: str
    target_capability_id: str
    target_artifact_hash: str | None
    problem_statement: str
    evidence_refs: tuple[str, ...]
    proposed_change_type: str
    expected_outcome: str
    acceptance_criteria: tuple[str, ...]
    risk: str
    confidence: str
    status: str
    created_at: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "proposal_id": self.proposal_id,
            "source_learning_observation_id": self.source_learning_observation_id,
            "target_capability_id": self.target_capability_id,
            "target_artifact_hash": self.target_artifact_hash,
            "problem_statement": self.problem_statement,
            "evidence_refs": list(self.evidence_refs),
            "proposed_change_type": self.proposed_change_type,
            "expected_outcome": self.expected_outcome,
            "acceptance_criteria": list(self.acceptance_criteria),
            "risk": self.risk,
            "confidence": self.confidence,
            "status": self.status,
            "created_at": self.created_at,
        }


@dataclass(frozen=True)
class LearningResult:
    observation: LearningObservation
    proposal: ImprovementProposal | None
    evidence_integrity: str
    learning_semantics: str = "EVIDENCE_ANALYSIS_AND_PROPOSAL_ONLY"
    runtime_mutated: bool = False
    training_activated: bool = False
    promotion_activated: bool = False
    genesis_invoked: bool = False
    code_generated: bool = False
    activation_invoked: bool = False
    rollback_invoked: bool = False
    historical_records_consulted: int = 0
    details: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "observation": self.observation.as_dict(),
            "proposal": None if self.proposal is None else self.proposal.as_dict(),
            "evidence_integrity": self.evidence_integrity,
            "learning_semantics": self.learning_semantics,
            "runtime_mutated": self.runtime_mutated,
            "training_activated": self.training_activated,
            "promotion_activated": self.promotion_activated,
            "genesis_invoked": self.genesis_invoked,
            "code_generated": self.code_generated,
            "activation_invoked": self.activation_invoked,
            "rollback_invoked": self.rollback_invoked,
            "historical_records_consulted": 0,
            "details": dict(self.details),
        }


EVALUATION_STATUSES = frozenset(
    {
        "APPROVED_FOR_CONTROLLED_IMPLEMENTATION",
        "REJECTED",
        "INSUFFICIENT_EVIDENCE",
        "NO_ACTION",
    }
)
FORBIDDEN_EVALUATION_STATUSES = frozenset(
    {"ACTIVE", "CERTIFIED", "PROMOTED", "IMPLEMENTED", "APPROVED"}
)
GENERATOR_IDENTITIES = frozenset(
    {"generator", "learner", "analyze_runtime_evidence"}
)
EVALUATOR_IDENTITIES = frozenset({"evaluator", "reviewer"})
_SCOPE_EXPANSION_MARKERS = (
    "governance",
    "constitution",
    "sandbox rule",
    "sandbox configuration",
    "certification rule",
    "global authority",
    "all capabilities",
    "model weight",
    "provider parameter",
    "widen authority",
    "tool policy",
    "handlers",
    "cap-exec-001",
    "cap-routing-001",
    "cap-mem-001",
)
_CIRCULAR_CRITERIA = (
    "approve this",
    "this proposal is accepted",
    "self-approv",
    "mark approved",
    "already safe",
)
_MEASURABLE_TOKENS = (
    "verified",
    "sample",
    "rate",
    "below",
    "over ",
    "final",
    "mission",
    "ms",
    "count",
    "threshold",
)

_OBSERVATIONS: dict[str, LearningObservation] = {}
_PROPOSALS: dict[str, ImprovementProposal] = {}
_EVALUATIONS: dict[str, "ImprovementProposalEvaluation"] = {}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def clear_learning() -> None:
    _OBSERVATIONS.clear()
    _PROPOSALS.clear()
    _EVALUATIONS.clear()


def get_learning_observation(learning_observation_id: str) -> LearningObservation | None:
    return _OBSERVATIONS.get(learning_observation_id)


def get_improvement_proposal(proposal_id: str) -> ImprovementProposal | None:
    return _PROPOSALS.get(proposal_id)


def get_proposal_evaluation(
    proposal_evaluation_id: str,
) -> ImprovementProposalEvaluation | None:
    return _EVALUATIONS.get(proposal_evaluation_id)


@dataclass(frozen=True)
class ImprovementProposalEvaluation:
    proposal_evaluation_id: str
    proposal_id: str
    source_learning_observation_id: str
    target_capability_id: str
    target_artifact_hash: str | None
    evidence_refs: tuple[str, ...]
    evidence_sufficiency: str
    scope_assessment: str
    risk_assessment: str
    acceptance_criteria_quality: str
    expected_outcome_assessment: str
    status: str
    reason: str
    reviewer_identity: str
    created_at: str
    implementation_authority: str = "NONE"

    def as_dict(self) -> dict[str, Any]:
        return {
            "proposal_evaluation_id": self.proposal_evaluation_id,
            "proposal_id": self.proposal_id,
            "source_learning_observation_id": self.source_learning_observation_id,
            "target_capability_id": self.target_capability_id,
            "target_artifact_hash": self.target_artifact_hash,
            "evidence_refs": list(self.evidence_refs),
            "evidence_sufficiency": self.evidence_sufficiency,
            "scope_assessment": self.scope_assessment,
            "risk_assessment": self.risk_assessment,
            "acceptance_criteria_quality": self.acceptance_criteria_quality,
            "expected_outcome_assessment": self.expected_outcome_assessment,
            "status": self.status,
            "reason": self.reason,
            "reviewer_identity": self.reviewer_identity,
            "created_at": self.created_at,
            "implementation_authority": "NONE",
        }


def _reject_claims(claims: Mapping[str, Any] | None) -> None:
    if claims:
        raise LearningError("FORBIDDEN_LEARNING_CLAIM")


def _is_final(record: PerformanceEvidence) -> bool:
    return record.record_kind == "FINAL"


def _is_verified_success(record: PerformanceEvidence) -> bool:
    return (
        record.record_kind == "FINAL"
        and record.mission_verification_status == "VERIFIED"
        and record.final_outcome == "SUCCESS"
    )


def _is_mission_failure(record: PerformanceEvidence) -> bool:
    if record.record_kind not in {"FINAL", "FAILED"}:
        return False
    if record.mission_verification_status in {"FAILED", "INSUFFICIENT_EVIDENCE"}:
        return True
    return record.final_outcome not in {None, "SUCCESS"} and not _is_verified_success(record)


def _is_contract_failure(record: PerformanceEvidence) -> bool:
    markers = " ".join(
        part
        for part in (
            record.failure_class or "",
            record.mission_verification_reason or "",
        )
        if part
    ).upper()
    return any(token in markers for token in CONTRACT_FAILURE_MARKERS)


def _is_synthetic_success(record: PerformanceEvidence) -> bool:
    return (
        record.execution_outcome == "SUCCESS"
        and record.mission_verification_status != "VERIFIED"
    )


def _versions_of(records: tuple[PerformanceEvidence, ...]) -> tuple[str, ...]:
    return tuple(
        dict.fromkeys(
            record.capability_version
            for record in records
            if record.capability_version
        )
    )


def _filter_scope(
    records: tuple[PerformanceEvidence, ...],
    *,
    capability_id: str,
    artifact_hash: str | None,
    mission_class: str | None,
    sample_window: int | None,
    allow_mixed_versions: bool,
    compare_artifact_hash: str | None = None,
) -> tuple[PerformanceEvidence, ...]:
    scoped: list[PerformanceEvidence] = []
    allowed_versions = None
    if artifact_hash and compare_artifact_hash:
        allowed_versions = {artifact_hash, compare_artifact_hash}
    for record in records:
        if record.capability_id != capability_id:
            raise LearningError("CROSS_CAPABILITY_EVIDENCE")
        if not record.correlation_id:
            raise LearningError("MISMATCHED_CORRELATION")
        if allowed_versions is not None:
            if record.capability_version not in allowed_versions:
                continue
        elif artifact_hash and record.capability_version not in {artifact_hash, None}:
            continue
        elif artifact_hash and record.capability_version is None:
            continue
        if mission_class and mission_class not in record.mission_ids:
            continue
        scoped.append(record)
    selected = tuple(scoped)
    if not allow_mixed_versions:
        versions = _versions_of(selected)
        has_unversioned = any(record.capability_version is None for record in selected)
        if artifact_hash is None and (len(versions) > 1 or (has_unversioned and versions)):
            raise LearningError("CROSS_VERSION_EVIDENCE")
    finals = tuple(record for record in selected if _is_final(record))
    if sample_window is not None and sample_window >= 0:
        finals = finals[-sample_window:]
        keep = {record.record_id for record in finals}
        selected = tuple(
            record
            for record in selected
            if record.record_id in keep or not _is_final(record)
        )
    return selected


def _facts(
    finals: tuple[PerformanceEvidence, ...],
    *,
    capability_id: str,
    artifact_hash: str | None,
) -> tuple[str, ...]:
    verified = sum(1 for record in finals if _is_verified_success(record))
    failed = sum(1 for record in finals if _is_mission_failure(record))
    contracts = sum(1 for record in finals if _is_contract_failure(record))
    synthetic = sum(1 for record in finals if _is_synthetic_success(record))
    replans = sum((record.replan_attempt or 0) for record in finals)
    identity = artifact_hash or "unspecified"
    facts = [
        f"capability_id={capability_id} artifact/version={identity}",
        f"{verified}/{len(finals)} FINAL missions VERIFIED SUCCESS",
        f"{failed}/{len(finals)} FINAL missions failed verification",
        f"{contracts}/{len(finals)} FINAL missions showed contract-failure markers",
        f"{synthetic}/{len(finals)} executions reported SUCCESS without mission VERIFIED",
        f"replan_attempt_sum={replans} across {len(finals)} FINAL records",
    ]
    if len(finals) == 1 and verified == 1:
        facts.append("mission succeeded once")
    if finals:
        mean_duration = round(sum(record.duration_ms for record in finals) / len(finals), 3)
        facts.append(f"mean_duration_ms={mean_duration}")
    return tuple(facts)


def _observation(
    *,
    capability_id: str,
    artifact_hash: str | None,
    scope: dict[str, Any],
    refs: tuple[str, ...],
    sample_count: int,
    observation_type: str,
    finding: str,
    facts: tuple[str, ...],
    inference: str,
    confidence: str,
    drift_ref: str | None,
) -> LearningObservation:
    if observation_type not in OBSERVATION_TYPES:
        raise LearningError("INVALID_OBSERVATION_TYPE")
    record = LearningObservation(
        learning_observation_id=uuid.uuid4().hex,
        capability_id=capability_id,
        artifact_hash=artifact_hash,
        evidence_scope=scope,
        evidence_refs=refs,
        sample_count=sample_count,
        observation_type=observation_type,
        finding=finding,
        observed_facts=facts,
        derived_inference=inference,
        confidence=confidence,
        created_at=_now(),
        drift_evaluation_ref=drift_ref,
    )
    _OBSERVATIONS[record.learning_observation_id] = record
    return record


def _proposal(
    observation: LearningObservation,
    *,
    change_type: str,
    problem: str,
    expected: str,
    criteria: tuple[str, ...],
    risk: str,
    confidence: str,
    status: str,
) -> ImprovementProposal:
    if change_type not in PROPOSAL_CHANGE_TYPES:
        raise LearningError("INVALID_PROPOSAL_CHANGE_TYPE")
    if status not in PROPOSAL_STATUSES:
        raise LearningError("INVALID_PROPOSAL_STATUS")
    if status in {"APPROVED", "CERTIFIED", "ACTIVE", "PROMOTED"}:
        raise LearningError("SELF_APPROVAL_FORBIDDEN")
    record = ImprovementProposal(
        proposal_id=uuid.uuid4().hex,
        source_learning_observation_id=observation.learning_observation_id,
        target_capability_id=observation.capability_id,
        target_artifact_hash=observation.artifact_hash,
        problem_statement=problem,
        evidence_refs=observation.evidence_refs,
        proposed_change_type=change_type,
        expected_outcome=expected,
        acceptance_criteria=criteria,
        risk=risk,
        confidence=confidence,
        status=status,
        created_at=_now(),
    )
    _PROPOSALS[record.proposal_id] = record
    return record


def _compare_versions(
    records: tuple[PerformanceEvidence, ...],
    *,
    capability_id: str,
    version_a: str,
    version_b: str,
    mission_class: str | None,
    thresholds: LearningThresholds,
) -> tuple[str, str, str, str] | None:
    def _by_version(version: str) -> tuple[PerformanceEvidence, ...]:
        selected = tuple(
            record
            for record in records
            if record.capability_version == version and _is_final(record)
        )
        if mission_class is not None:
            selected = tuple(
                record for record in selected if mission_class in record.mission_ids
            )
        return selected

    left = _by_version(version_a)
    right = _by_version(version_b)
    if (
        len(left) < thresholds.min_comparative_samples
        or len(right) < thresholds.min_comparative_samples
    ):
        return None
    left_missions = {mid for record in left for mid in record.mission_ids}
    right_missions = {mid for record in right for mid in record.mission_ids}
    if mission_class is None and left_missions != right_missions:
        return None
    left_rate = sum(1 for record in left if _is_verified_success(record)) / len(left)
    right_rate = sum(1 for record in right if _is_verified_success(record)) / len(right)
    if right_rate > left_rate:
        return (
            "PERFORMANCE_IMPROVEMENT",
            (
                f"{len(right)}/{len(right)} comparable FINAL samples for {version_b} "
                f"had verified success rate {right_rate:.3f} versus {left_rate:.3f} "
                f"on {version_a}"
            ),
            "version B may perform better on the comparable verified mission class",
            "MEDIUM",
        )
    if right_rate < left_rate:
        return (
            "PERFORMANCE_DEGRADATION",
            (
                f"{len(right)} comparable FINAL samples for {version_b} "
                f"had verified success rate {right_rate:.3f} versus {left_rate:.3f} "
                f"on {version_a}"
            ),
            "version B may have degraded relative to version A on comparable missions",
            "MEDIUM",
        )
    return (
        "NO_ACTION",
        "comparable versions produced equivalent verified success rates",
        "no performance difference is justified by the comparable evidence",
        "MEDIUM",
    )


def analyze_runtime_evidence(
    store: PerformanceStore,
    *,
    capability_id: str,
    artifact_hash: str | None = None,
    mission_class: str | None = None,
    sample_window: int | None = None,
    min_samples: int | None = None,
    compare_artifact_hash: str | None = None,
    drift: DriftEvaluation | None = None,
    thresholds: LearningThresholds | None = None,
    persist: bool = True,
    claims: Mapping[str, Any] | None = None,
    historical_records: tuple[Mapping[str, Any], ...] = (),
) -> LearningResult:
    """Analyze scoped verified evidence. Stops at observation/proposal."""
    _reject_claims(claims)
    del historical_records
    config = thresholds or LearningThresholds()
    required = min_samples if min_samples is not None else config.min_samples
    scope = {
        "capability_id": capability_id,
        "artifact_hash": artifact_hash,
        "mission_class": mission_class,
        "sample_window": sample_window,
        "min_samples": required,
        "compare_artifact_hash": compare_artifact_hash,
        "thresholds": config.as_dict(),
        "population": "FINAL performance_evidence rows matching explicit scope",
    }
    try:
        loaded = store.checked_by_capability_id(capability_id)
    except StoreCorruptRecord as exc:
        raise LearningEvidenceFailed(f"STORE_CORRUPT_RECORD: {exc}") from exc

    records = _filter_scope(
        loaded,
        capability_id=capability_id,
        artifact_hash=artifact_hash,
        mission_class=mission_class,
        sample_window=sample_window,
        allow_mixed_versions=compare_artifact_hash is not None,
        compare_artifact_hash=compare_artifact_hash,
    )
    finals = tuple(record for record in records if _is_final(record))
    refs = tuple(record.record_id for record in finals)
    versions = _versions_of(finals)
    resolved_hash = artifact_hash
    if resolved_hash is None and len(versions) == 1:
        resolved_hash = versions[0]
    facts = _facts(finals, capability_id=capability_id, artifact_hash=resolved_hash)
    drift_ref = None
    drift_status = None
    if drift is not None:
        if drift.capability_id != capability_id:
            raise LearningError("CROSS_CAPABILITY_EVIDENCE")
        drift_ref = drift.evaluation_id
        drift_status = drift.status

    if not finals:
        observation = _observation(
            capability_id=capability_id,
            artifact_hash=resolved_hash,
            scope=scope,
            refs=(),
            sample_count=0,
            observation_type="INSUFFICIENT_EVIDENCE",
            finding="no FINAL performance evidence in the explicit scope",
            facts=("0 FINAL records in scope",),
            inference="no performance conclusion is justified",
            confidence="INSUFFICIENT",
            drift_ref=drift_ref,
        )
        return _finish(store, observation, None, persist, {"reason": "NO_FINAL_EVIDENCE"})

    verified_n = sum(1 for record in finals if _is_verified_success(record))
    failed_n = sum(1 for record in finals if _is_mission_failure(record))
    contract_n = sum(1 for record in finals if _is_contract_failure(record))
    synthetic_n = sum(1 for record in finals if _is_synthetic_success(record))
    replan_mean = sum((record.replan_attempt or 0) for record in finals) / len(finals)
    success_rate = verified_n / len(finals)
    failure_rate = failed_n / len(finals)

    if compare_artifact_hash:
        if not artifact_hash:
            raise LearningError("COMPARATIVE_SCOPE_INCOMPLETE")
        comparative = _compare_versions(
            records,
            capability_id=capability_id,
            version_a=artifact_hash,
            version_b=compare_artifact_hash,
            mission_class=mission_class,
            thresholds=config,
        )
        if comparative is None:
            observation = _observation(
                capability_id=capability_id,
                artifact_hash=resolved_hash,
                scope=scope,
                refs=refs,
                sample_count=len(finals),
                observation_type="INSUFFICIENT_EVIDENCE",
                finding="comparative versions lack comparable verified sample volume or mission class",
                facts=facts,
                inference="version ranking is not justified",
                confidence="INSUFFICIENT",
                drift_ref=drift_ref,
            )
            return _finish(
                store, observation, None, persist, {"reason": "COMPARATIVE_INSUFFICIENT"}
            )
        obs_type, finding, inference, confidence = comparative
        change = "INVESTIGATE" if obs_type == "PERFORMANCE_DEGRADATION" else "NO_ACTION"
        observation = _observation(
            capability_id=capability_id,
            artifact_hash=resolved_hash,
            scope=scope,
            refs=refs,
            sample_count=len(finals),
            observation_type=obs_type,
            finding=finding,
            facts=facts,
            inference=inference,
            confidence=confidence,
            drift_ref=drift_ref,
        )
        proposal = _proposal(
            observation,
            change_type=change,
            problem=finding,
            expected="keep the better version only after owner-controlled evaluation",
            criteria=(
                "same or similar mission class",
                f"at least {config.min_comparative_samples} verified samples per version",
            ),
            risk="comparative ranking is not an activation or promotion decision",
            confidence=confidence,
            status="NO_ACTION" if change == "NO_ACTION" else "PROPOSED",
        )
        return _finish(
            store,
            observation,
            proposal,
            persist,
            {"reason": obs_type, "comparative": True, "authority": False},
        )

    if len(finals) < required:
        finding = (
            f"{len(finals)} FINAL sample(s) below minimum {required}; "
            + ("mission succeeded once" if verified_n == 1 and len(finals) == 1 else "no reliability claim")
        )
        observation = _observation(
            capability_id=capability_id,
            artifact_hash=resolved_hash,
            scope=scope,
            refs=refs,
            sample_count=len(finals),
            observation_type="INSUFFICIENT_EVIDENCE",
            finding=finding,
            facts=facts,
            inference="a reusable performance lesson is not justified from this sample volume",
            confidence="INSUFFICIENT",
            drift_ref=drift_ref,
        )
        proposal = None
        if failed_n or contract_n:
            proposal = _proposal(
                observation,
                change_type="INVESTIGATE",
                problem="failure facts exist but sample volume is below the minimum rule",
                expected="gather additional verified mission evidence before claiming a pattern",
                criteria=(
                    f"collect at least {required} FINAL scoped records",
                    "do not treat the current sample as a reliability claim",
                ),
                risk="acting on one or few samples may misattribute a transient failure",
                confidence="LOW",
                status="INSUFFICIENT_EVIDENCE",
            )
        return _finish(
            store,
            observation,
            proposal,
            persist,
            {"reason": "SAMPLE_BELOW_MINIMUM", "synthetic_untrusted": synthetic_n},
        )

    if contract_n / len(finals) >= config.failure_rate_pattern:
        obs_type = "CONTRACT_FAILURE"
        finding = f"{contract_n}/{len(finals)} FINAL missions failed a declared contract"
        inference = "failure pattern may originate in contract mapping or serialization"
        change = "CONTRACT_ADJUSTMENT_PROPOSAL"
        problem = "repeated contract-validation failures on verified evidence scope"
        expected = "contract checks pass on the same scoped mission class"
        criteria = (
            f"contract-failure rate below {config.failure_rate_pattern} over {required} FINAL samples",
            "mission verification VERIFIED on the original requirement",
        )
        risk = "contract change without re-verification may hide implementation defects"
        confidence = "HIGH"
    elif failure_rate >= config.failure_rate_pattern:
        obs_type = "FAILURE_PATTERN"
        finding = f"{failed_n}/{len(finals)} FINAL missions failed verification"
        inference = "failure pattern may originate in implementation or mission mapping"
        change = "IMPLEMENTATION_CHANGE_PROPOSAL"
        problem = "repeated mission verification failures on the scoped capability/version"
        expected = "mission verification VERIFIED on the original requirement class"
        criteria = (
            f"mission failure rate below {config.failure_rate_pattern} over {required} FINAL samples",
            "do not count handler ok without mission VERIFIED",
        )
        risk = "an implementation change without review may regress a working path"
        confidence = "HIGH"
    elif replan_mean >= config.replan_frequency_pattern:
        obs_type = "REPLAN_PATTERN"
        finding = f"mean replan_attempt={replan_mean:.3f} across {len(finals)} FINAL records"
        inference = "replans may originate in routing or alternative selection"
        change = "ROUTING_CHANGE_PROPOSAL"
        problem = "excessive replan frequency on the scoped evidence population"
        expected = "replan frequency falls below the configured threshold"
        criteria = (
            f"mean replan_attempt below {config.replan_frequency_pattern} over {required} FINAL samples",
        )
        risk = "routing change may starve a still-valid capability path"
        confidence = "MEDIUM"
    elif drift_status == "DEGRADED":
        obs_type = "PERFORMANCE_DEGRADATION"
        finding = f"drift evaluation {drift_ref} status=DEGRADED on capability {capability_id}"
        inference = "current window may have degraded relative to the verified baseline"
        change = "INVESTIGATE"
        problem = "persisted drift evidence reports DEGRADED for the scoped capability"
        expected = "identify the degraded metric without automatic rollback or retrain"
        criteria = (
            "confirm drift DEGRADED against the same capability/version scope",
            "no automatic rollback, retrain, or replacement from this observation",
        )
        risk = "treating drift as authority could trigger unjustified rollback"
        confidence = "MEDIUM"
    elif success_rate >= config.success_rate_stable and synthetic_n == 0:
        obs_type = "SUCCESS_PATTERN"
        finding = f"{verified_n}/{len(finals)} FINAL missions VERIFIED SUCCESS"
        inference = "current scoped implementation appears stable on this population"
        change = "NO_ACTION"
        problem = "no justified improvement action on stable verified success evidence"
        expected = "retain current capability without code or routing change"
        criteria = ("keep observation as a success-pattern lesson only",)
        risk = "none beyond over-generalizing beyond the stated scope"
        confidence = "HIGH"
    else:
        obs_type = "NO_ACTION"
        finding = "scoped evidence does not meet a configured pattern threshold"
        inference = "no reusable lesson beyond the observed counts is justified"
        change = "NO_ACTION"
        problem = "no pattern threshold crossed"
        expected = "continue collecting verified evidence"
        criteria = ("do not emit an implementation change from this observation",)
        risk = "none"
        confidence = "LOW"

    observation = _observation(
        capability_id=capability_id,
        artifact_hash=resolved_hash,
        scope=scope,
        refs=refs,
        sample_count=len(finals),
        observation_type=obs_type,
        finding=finding,
        facts=facts,
        inference=inference,
        confidence=confidence,
        drift_ref=drift_ref,
    )
    status = "NO_ACTION" if change == "NO_ACTION" else "PROPOSED"
    if obs_type == "INSUFFICIENT_EVIDENCE":
        status = "INSUFFICIENT_EVIDENCE"
    proposal = _proposal(
        observation,
        change_type=change,
        problem=problem,
        expected=expected,
        criteria=criteria,
        risk=risk,
        confidence=confidence,
        status=status,
    )
    details = {
        "reason": obs_type,
        "success_rate": success_rate,
        "failure_rate": failure_rate,
        "synthetic_untrusted": synthetic_n,
        "drift_status": drift_status,
        "authority": False,
    }
    if drift is None and len(finals) >= required:
        supporting = evaluate_drift(
            store,
            capability_id=capability_id,
            metric="mission_success_rate",
            persist=False,
        )
        details["supporting_drift_status"] = supporting.status
        details["supporting_drift_id"] = supporting.evaluation_id
    return _finish(store, observation, proposal, persist, details)


def _finish(
    store: PerformanceStore,
    observation: LearningObservation,
    proposal: ImprovementProposal | None,
    persist: bool,
    details: dict[str, Any],
) -> LearningResult:
    if persist:
        store.persist_learning_observation(observation.as_dict())
        if proposal is not None:
            store.persist_improvement_proposal(proposal.as_dict())
    return LearningResult(
        observation=observation,
        proposal=proposal,
        evidence_integrity="PASS",
        details=details,
    )


def _required_text(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise LearningError("MALFORMED_PROPOSAL")
    return value


def _proposal_from_mapping(data: Mapping[str, Any]) -> ImprovementProposal:
    change_type = _required_text(data.get("proposed_change_type"), "proposed_change_type")
    if change_type not in PROPOSAL_CHANGE_TYPES:
        raise LearningError("MALFORMED_PROPOSAL")
    criteria = data.get("acceptance_criteria") or ()
    refs = data.get("evidence_refs") or ()
    if not isinstance(criteria, (list, tuple)) or not isinstance(refs, (list, tuple)):
        raise LearningError("MALFORMED_PROPOSAL")
    return ImprovementProposal(
        proposal_id=_required_text(data.get("proposal_id"), "proposal_id"),
        source_learning_observation_id=_required_text(
            data.get("source_learning_observation_id"), "source_learning_observation_id"
        ),
        target_capability_id=_required_text(
            data.get("target_capability_id"), "target_capability_id"
        ),
        target_artifact_hash=data.get("target_artifact_hash"),
        problem_statement=_required_text(
            data.get("problem_statement"), "problem_statement"
        ),
        evidence_refs=tuple(str(item) for item in refs),
        proposed_change_type=change_type,
        expected_outcome=_required_text(
            data.get("expected_outcome"), "expected_outcome"
        ),
        acceptance_criteria=tuple(str(item) for item in criteria),
        risk=str(data.get("risk") or ""),
        confidence=_required_text(data.get("confidence"), "confidence"),
        status=_required_text(data.get("status"), "status"),
        created_at=_required_text(data.get("created_at"), "created_at"),
    )


def _observation_from_mapping(data: Mapping[str, Any]) -> LearningObservation:
    return LearningObservation(
        learning_observation_id=_required_text(
            data.get("learning_observation_id"), "learning_observation_id"
        ),
        capability_id=_required_text(data.get("capability_id"), "capability_id"),
        artifact_hash=data.get("artifact_hash"),
        evidence_scope=dict(data.get("evidence_scope") or {}),
        evidence_refs=tuple(data.get("evidence_refs") or ()),
        sample_count=int(data.get("sample_count") or 0),
        observation_type=_required_text(
            data.get("observation_type"), "observation_type"
        ),
        finding=_required_text(data.get("finding"), "finding"),
        observed_facts=tuple(data.get("observed_facts") or ()),
        derived_inference=str(data.get("derived_inference") or ""),
        confidence=_required_text(data.get("confidence"), "confidence"),
        created_at=_required_text(data.get("created_at"), "created_at"),
        drift_evaluation_ref=data.get("drift_evaluation_ref"),
    )


def _load_proposal(
    store: PerformanceStore,
    *,
    proposal_id: str | None,
    proposal: ImprovementProposal | None,
) -> ImprovementProposal:
    if proposal is not None:
        _PROPOSALS.setdefault(proposal.proposal_id, proposal)
        return _proposal_from_mapping(proposal.as_dict())
    if not proposal_id:
        raise LearningError("MALFORMED_PROPOSAL")
    local = get_improvement_proposal(proposal_id)
    if local is not None:
        return local
    try:
        return _proposal_from_mapping(store.get_improvement_proposal(proposal_id))
    except StoreReadFailed as exc:
        raise LearningError("UNKNOWN_PROPOSAL") from exc


def _load_observation(
    store: PerformanceStore, observation_id: str
) -> LearningObservation:
    local = get_learning_observation(observation_id)
    if local is not None:
        return local
    try:
        return _observation_from_mapping(store.get_learning_observation(observation_id))
    except StoreReadFailed as exc:
        raise LearningError("UNKNOWN_LEARNING_OBSERVATION") from exc
    except StoreCorruptRecord as exc:
        raise LearningEvidenceFailed(f"STORE_CORRUPT_RECORD: {exc}") from exc


def _joined_text(*parts: Any) -> str:
    chunks: list[str] = []
    for part in parts:
        if isinstance(part, (list, tuple)):
            chunks.extend(str(item) for item in part)
        elif part:
            chunks.append(str(part))
    return " ".join(chunks).lower()


def _criteria_quality(criteria: tuple[str, ...], target_capability_id: str) -> str:
    if not criteria or any(not str(item).strip() for item in criteria):
        return "MISSING"
    blob = _joined_text(criteria)
    if any(token in blob for token in _CIRCULAR_CRITERIA):
        return "CIRCULAR"
    if any(
        token.startswith("cap-") and token != target_capability_id.lower()
        for token in blob.replace(",", " ").split()
        if token.startswith("cap-")
    ):
        return "UNRELATED"
    measurable = False
    for item in criteria:
        text = item.lower()
        if any(ch.isdigit() for ch in item) or any(token in text for token in _MEASURABLE_TOKENS):
            measurable = True
            break
    if not measurable:
        return "UNVERIFIABLE"
    return "MEASURABLE"


def _scope_assessment(proposal: ImprovementProposal) -> str:
    blob = _joined_text(
        proposal.problem_statement,
        proposal.expected_outcome,
        proposal.acceptance_criteria,
        proposal.risk,
    )
    if any(marker in blob for marker in _SCOPE_EXPANSION_MARKERS):
        return "UNBOUNDED"
    if proposal.target_capability_id.count(",") or " and cap-" in blob:
        return "UNBOUNDED"
    return "BOUNDED"


def _risk_assessment(proposal: ImprovementProposal, scope: str) -> str:
    if scope == "UNBOUNDED":
        return "HIGH"
    blob = _joined_text(proposal.problem_statement, proposal.expected_outcome, proposal.risk)
    if any(marker in blob for marker in ("authority", "governance", "promote", "activate")):
        return "HIGH"
    if proposal.proposed_change_type in {
        "IMPLEMENTATION_CHANGE_PROPOSAL",
        "CONTRACT_ADJUSTMENT_PROPOSAL",
        "ROUTING_CHANGE_PROPOSAL",
    }:
        return "MEDIUM"
    return "LOW"


def _supported_change(observation: LearningObservation, change_type: str) -> bool:
    mapping = {
        "IMPLEMENTATION_CHANGE_PROPOSAL": {"FAILURE_PATTERN"},
        "CONTRACT_ADJUSTMENT_PROPOSAL": {"CONTRACT_FAILURE"},
        "ROUTING_CHANGE_PROPOSAL": {"REPLAN_PATTERN"},
        "TEST_EXPANSION_PROPOSAL": {
            "FAILURE_PATTERN",
            "CONTRACT_FAILURE",
            "REPLAN_PATTERN",
            "PERFORMANCE_DEGRADATION",
        },
        "INVESTIGATE": {
            "FAILURE_PATTERN",
            "CONTRACT_FAILURE",
            "REPLAN_PATTERN",
            "PERFORMANCE_DEGRADATION",
            "PERFORMANCE_IMPROVEMENT",
        },
        "NO_ACTION": {"SUCCESS_PATTERN", "NO_ACTION", "INSUFFICIENT_EVIDENCE"},
    }
    return observation.observation_type in mapping.get(change_type, set())


def _load_evidence_records(
    store: PerformanceStore,
    proposal: ImprovementProposal,
    observation: LearningObservation,
) -> tuple[PerformanceEvidence, ...]:
    if observation.capability_id != proposal.target_capability_id:
        raise LearningError("CROSS_CAPABILITY_EVIDENCE")
    compare = (observation.evidence_scope or {}).get("compare_artifact_hash")
    allowed_versions = {
        value
        for value in (
            proposal.target_artifact_hash,
            observation.artifact_hash,
            compare,
        )
        if value
    }
    records: list[PerformanceEvidence] = []
    for ref in proposal.evidence_refs:
        try:
            record = store.get(ref)
        except StoreCorruptRecord as exc:
            raise LearningEvidenceFailed(f"STORE_CORRUPT_RECORD: {exc}") from exc
        except StoreReadFailed as exc:
            raise LearningError("MISSING_EVIDENCE_REF") from exc
        if record.capability_id != proposal.target_capability_id:
            raise LearningError("CROSS_CAPABILITY_EVIDENCE")
        if (
            allowed_versions
            and record.capability_version
            and record.capability_version not in allowed_versions
        ):
            raise LearningError("CROSS_VERSION_EVIDENCE")
        if (
            proposal.target_artifact_hash
            and observation.artifact_hash
            and proposal.target_artifact_hash != observation.artifact_hash
            and not compare
        ):
            raise LearningError("CROSS_VERSION_EVIDENCE")
        records.append(record)
    return tuple(records)


def evaluate_improvement_proposal(
    store: PerformanceStore,
    *,
    proposal_id: str | None = None,
    proposal: ImprovementProposal | None = None,
    requester: str = "learner",
    persist: bool = True,
    claims: Mapping[str, Any] | None = None,
    historical_records: tuple[Mapping[str, Any], ...] = (),
) -> ImprovementProposalEvaluation:
    """Independently evaluate a learning proposal. Grants no runtime authority."""
    _reject_claims(claims)
    del historical_records
    if requester in GENERATOR_IDENTITIES:
        raise LearningError("SELF_EVALUATION_FORBIDDEN")
    if requester not in EVALUATOR_IDENTITIES:
        raise LearningError("SELF_EVALUATION_FORBIDDEN")

    loaded = _load_proposal(store, proposal_id=proposal_id, proposal=proposal)
    observation = _load_observation(store, loaded.source_learning_observation_id)
    records = _load_evidence_records(store, loaded, observation)
    min_samples = int((observation.evidence_scope or {}).get("min_samples") or 5)
    criteria_quality = _criteria_quality(
        loaded.acceptance_criteria, loaded.target_capability_id
    )
    scope = _scope_assessment(loaded)
    risk = _risk_assessment(loaded, scope)
    sample_count = observation.sample_count
    sufficient_samples = sample_count >= min_samples and len(records) >= min_samples
    supported = _supported_change(observation, loaded.proposed_change_type)
    outcome = "ALIGNED" if supported else "UNSUPPORTED"
    if loaded.proposed_change_type == "NO_ACTION" or loaded.status == "NO_ACTION":
        status = "NO_ACTION"
        reason = "NO_ACTION_PROPOSAL"
        sufficiency = "NOT_REQUIRED"
    elif scope == "UNBOUNDED":
        status = "REJECTED"
        reason = "UNBOUNDED_SCOPE"
        sufficiency = "FAIL"
    elif risk == "HIGH":
        status = "REJECTED"
        reason = "HIGH_RISK_NO_AUTHORITY"
        sufficiency = "FAIL"
    elif criteria_quality == "MISSING":
        status = "REJECTED"
        reason = "MISSING_ACCEPTANCE_CRITERIA"
        sufficiency = "FAIL" if not sufficient_samples else "PASS"
    elif criteria_quality in {"CIRCULAR", "UNVERIFIABLE", "UNRELATED"}:
        status = "REJECTED"
        reason = f"ACCEPTANCE_CRITERIA_{criteria_quality}"
        sufficiency = "PASS" if sufficient_samples else "INSUFFICIENT"
    elif loaded.proposed_change_type == "IMPLEMENTATION_CHANGE_PROPOSAL" and not loaded.target_artifact_hash:
        status = "INSUFFICIENT_EVIDENCE"
        reason = "MISSING_TARGET_ARTIFACT_IDENTITY"
        sufficiency = "INSUFFICIENT"
    elif observation.observation_type == "INSUFFICIENT_EVIDENCE" or not sufficient_samples:
        status = "INSUFFICIENT_EVIDENCE"
        reason = "SAMPLE_BELOW_MINIMUM"
        sufficiency = "INSUFFICIENT"
    elif not supported:
        status = "REJECTED"
        reason = "UNSUPPORTED_INFERENCE"
        sufficiency = "FAIL"
    elif loaded.proposed_change_type in {
        "IMPLEMENTATION_CHANGE_PROPOSAL",
        "CONTRACT_ADJUSTMENT_PROPOSAL",
        "ROUTING_CHANGE_PROPOSAL",
        "TEST_EXPANSION_PROPOSAL",
        "INVESTIGATE",
    }:
        status = "APPROVED_FOR_CONTROLLED_IMPLEMENTATION"
        reason = "EVIDENCE_BOUNDED_MEASURABLE"
        sufficiency = "PASS"
    else:
        status = "REJECTED"
        reason = "UNSUPPORTED_CHANGE_TYPE"
        sufficiency = "FAIL"

    if status not in EVALUATION_STATUSES or status in FORBIDDEN_EVALUATION_STATUSES:
        raise LearningError("INVALID_EVALUATION_STATUS")
    evaluation = ImprovementProposalEvaluation(
        proposal_evaluation_id=uuid.uuid4().hex,
        proposal_id=loaded.proposal_id,
        source_learning_observation_id=observation.learning_observation_id,
        target_capability_id=loaded.target_capability_id,
        target_artifact_hash=loaded.target_artifact_hash,
        evidence_refs=loaded.evidence_refs,
        evidence_sufficiency=sufficiency,
        scope_assessment=scope,
        risk_assessment=risk,
        acceptance_criteria_quality=criteria_quality,
        expected_outcome_assessment=outcome,
        status=status,
        reason=reason,
        reviewer_identity=requester,
        created_at=_now(),
    )
    _EVALUATIONS[evaluation.proposal_evaluation_id] = evaluation
    if persist:
        store.persist_proposal_evaluation(evaluation.as_dict())
    return evaluation
