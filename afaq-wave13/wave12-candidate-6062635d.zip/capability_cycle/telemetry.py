"""Base observability for capability-cycle operations.

Telemetry never grants authority. Missing required certification
evidence fails closed at the caller. Secrets are redacted.
"""

from __future__ import annotations

import hashlib
import json
import re
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

_SECRET_KEY = re.compile(
    r"(password|secret|token|api[_-]?key|authorization|credential|private[_-]?key)",
    re.IGNORECASE,
)
_SECRET_VALUE = re.compile(
    r"(?i)(bearer\s+[a-z0-9._\-]+|sk-[a-z0-9]{8,}|ghp_[a-z0-9]{20,})"
)


def new_correlation_id() -> str:
    return uuid.uuid4().hex


def redact(value: Any) -> Any:
    if isinstance(value, dict):
        out = {}
        for key, item in value.items():
            if _SECRET_KEY.search(str(key)):
                out[str(key)] = "[REDACTED]"
            else:
                out[str(key)] = redact(item)
        return out
    if isinstance(value, list):
        return [redact(item) for item in value]
    if isinstance(value, str):
        return _SECRET_VALUE.sub("[REDACTED]", value)
    return value


@dataclass
class TelemetryRecord:
    correlation_id: str
    capability_id: str | None
    capability_version: str | None
    stage: str
    started_at: float
    ended_at: float | None
    outcome: str
    failure_class: str | None
    duration_ms: float | None
    sandbox_result: str | None
    certification_state: str | None
    verification_result: str | None
    retry_count: int
    resource_evidence: dict[str, Any]
    details: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        payload = {
            "correlation_id": self.correlation_id,
            "capability_id": self.capability_id,
            "capability_version": self.capability_version,
            "stage": self.stage,
            "started_at": self.started_at,
            "ended_at": self.ended_at,
            "outcome": self.outcome,
            "failure_class": self.failure_class,
            "duration_ms": self.duration_ms,
            "sandbox_result": self.sandbox_result,
            "certification_state": self.certification_state,
            "verification_result": self.verification_result,
            "retry_count": self.retry_count,
            "resource_evidence": self.resource_evidence,
            "details": self.details,
        }
        return redact(payload)


class TelemetryStore:
    def __init__(self) -> None:
        self._records: list[TelemetryRecord] = []

    def emit(self, record: TelemetryRecord, *, required: bool = False) -> TelemetryRecord:
        safe = TelemetryRecord(**{**record.__dict__, "details": redact(record.details)})
        try:
            json.dumps(safe.as_dict(), sort_keys=True)
            self._records.append(safe)
        except (TypeError, ValueError) as exc:
            if required:
                raise TelemetryError("required telemetry evidence could not be recorded") from exc
            raise
        return safe

    def records(self) -> tuple[TelemetryRecord, ...]:
        return tuple(self._records)

    def evidence_hash(self) -> str:
        blob = json.dumps([r.as_dict() for r in self._records], sort_keys=True).encode("utf-8")
        return hashlib.sha256(blob).hexdigest()


class TelemetryError(RuntimeError):
    pass


def start_record(
    *,
    stage: str,
    capability_id: str | None = None,
    capability_version: str | None = None,
    correlation_id: str | None = None,
) -> dict[str, Any]:
    return {
        "correlation_id": correlation_id or new_correlation_id(),
        "capability_id": capability_id,
        "capability_version": capability_version,
        "stage": stage,
        "started_at": time.time(),
        "retry_count": 0,
    }


def finish_record(
    started: dict[str, Any],
    *,
    outcome: str,
    failure_class: str | None = None,
    sandbox_result: str | None = None,
    certification_state: str | None = None,
    verification_result: str | None = None,
    retry_count: int = 0,
    resource_evidence: dict[str, Any] | None = None,
    details: dict[str, Any] | None = None,
) -> TelemetryRecord:
    ended = time.time()
    return TelemetryRecord(
        correlation_id=started["correlation_id"],
        capability_id=started.get("capability_id"),
        capability_version=started.get("capability_version"),
        stage=started["stage"],
        started_at=started["started_at"],
        ended_at=ended,
        outcome=outcome,
        failure_class=failure_class,
        duration_ms=round((ended - started["started_at"]) * 1000, 3),
        sandbox_result=sandbox_result,
        certification_state=certification_state,
        verification_result=verification_result,
        retry_count=retry_count,
        resource_evidence=resource_evidence or {},
        details=details or {},
    )
