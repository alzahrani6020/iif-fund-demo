"""Single source-of-truth policy for executable capability candidate source."""

from __future__ import annotations

import ast
import dis
import types
from typing import Any

_FORBIDDEN_CALLS = frozenset(
    {
        "eval",
        "exec",
        "compile",
        "__import__",
        "open",
        "getattr",
        "setattr",
        "delattr",
        "globals",
        "locals",
        "vars",
        "dir",
        "type",
        "super",
        "breakpoint",
        "input",
    }
)
_FORBIDDEN_NAMES = frozenset(
    {
        "HANDLERS",
        "_ACTIVE",
        "activate_candidate",
        "register_candidate",
        "validate_candidate",
        "review_candidate",
        "evaluate_candidate",
        "certify_candidate",
        "generate_candidate",
        "generate_implementation_candidate",
        "eval",
        "exec",
        "compile",
        "__import__",
        "os",
        "subprocess",
        "environ",
    }
)
_FORBIDDEN_CLAIM_ASSIGNS = frozenset(
    {
        "sandbox_validated",
        "reviewed",
        "evaluated",
        "certified",
        "active",
        "promoted",
    }
)


class CandidateSourcePolicyError(ValueError):
    pass


def candidate_safe_builtins() -> dict[str, Any]:
    """Return a fresh minimal builtins dictionary for candidate execution."""
    return {
        "None": None,
        "True": True,
        "False": False,
        "dict": dict,
        "list": list,
        "tuple": tuple,
        "set": set,
        "str": str,
        "int": int,
        "float": float,
        "bool": bool,
        "len": len,
        "sorted": sorted,
        "isinstance": isinstance,
        "range": range,
        "enumerate": enumerate,
        "min": min,
        "max": max,
        "abs": abs,
        "sum": sum,
        "format": format,
        "hex": hex,
        "ord": ord,
        "chr": chr,
        "repr": repr,
        "zip": zip,
        "Exception": Exception,
        "ValueError": ValueError,
        "TypeError": TypeError,
        "KeyError": KeyError,
    }


_FORBIDDEN_BYTECODE_NAMES = frozenset(
    set(_FORBIDDEN_CALLS)
    | set(_FORBIDDEN_NAMES)
    | {
        "builtins",
        "sys",
        "socket",
        "pathlib",
        "importlib",
        "requests",
        "urllib",
        "ctypes",
        "multiprocessing",
    }
)
_FORBIDDEN_OPCODES = frozenset(
    {
        "IMPORT_NAME",
        "IMPORT_FROM",
        "IMPORT_STAR",
        "LOAD_BUILD_CLASS",
        "STORE_GLOBAL",
        "DELETE_GLOBAL",
    }
)


def validate_candidate_code_object(code: types.CodeType) -> None:
    """Reject ambient-authority bytecode before restoring a candidate handler."""
    if not isinstance(code, types.CodeType):
        raise CandidateSourcePolicyError("MALFORMED_BYTECODE")
    for instruction in dis.get_instructions(code):
        if instruction.opname in _FORBIDDEN_OPCODES:
            raise CandidateSourcePolicyError("FORBIDDEN_BYTECODE")
        if instruction.opname in {
            "LOAD_GLOBAL",
            "LOAD_NAME",
            "LOAD_ATTR",
            "LOAD_METHOD",
        }:
            name = str(instruction.argval or "")
            if (
                name in _FORBIDDEN_BYTECODE_NAMES
                or name.startswith("__")
            ):
                raise CandidateSourcePolicyError("FORBIDDEN_BYTECODE")
    for item in code.co_consts:
        if isinstance(item, types.CodeType):
            validate_candidate_code_object(item)


def validate_candidate_source(
    source: str,
    capability_id: str,
    *,
    entrypoint: str = "handle",
) -> None:
    """Validate self-contained source before registration or execution."""
    if not isinstance(source, str) or not source.strip():
        raise CandidateSourcePolicyError("MALFORMED_ARTIFACT")
    try:
        tree = ast.parse(source)
    except SyntaxError as exc:
        raise CandidateSourcePolicyError("MALFORMED_ARTIFACT") from exc

    functions = [
        node for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    ]
    handle = next((node for node in functions if node.name == entrypoint), None)
    if handle is None or not handle.args.args:
        raise CandidateSourcePolicyError("MISSING_ENTRYPOINT")

    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            raise CandidateSourcePolicyError("FORBIDDEN_SOURCE_CONSTRUCT")
        if isinstance(node, ast.Call):
            name = ""
            if isinstance(node.func, ast.Name):
                name = node.func.id
            elif isinstance(node.func, ast.Attribute):
                name = node.func.attr
            if name in _FORBIDDEN_CALLS or name.startswith("__"):
                raise CandidateSourcePolicyError("FORBIDDEN_SOURCE_CONSTRUCT")
        if isinstance(node, ast.Name):
            if node.id in _FORBIDDEN_NAMES or node.id.startswith("__"):
                raise CandidateSourcePolicyError("FORBIDDEN_SOURCE_CONSTRUCT")
        if isinstance(node, ast.Attribute):
            if node.attr in _FORBIDDEN_NAMES or node.attr.startswith("__"):
                raise CandidateSourcePolicyError("FORBIDDEN_SOURCE_CONSTRUCT")
        if isinstance(node, (ast.Assign, ast.AnnAssign, ast.NamedExpr)):
            targets = []
            if isinstance(node, ast.Assign):
                targets = list(node.targets)
            elif isinstance(node, ast.AnnAssign):
                targets = [node.target]
            else:
                targets = [node.target]
            for target in targets:
                if isinstance(target, ast.Name):
                    if (
                        target.id in _FORBIDDEN_CLAIM_ASSIGNS
                        or target.id in _FORBIDDEN_NAMES
                        or target.id.startswith("__")
                    ):
                        raise CandidateSourcePolicyError(
                            "FORBIDDEN_CANDIDATE_CLAIM"
                        )

    if capability_id not in source:
        raise CandidateSourcePolicyError("MALFORMED_ARTIFACT")
