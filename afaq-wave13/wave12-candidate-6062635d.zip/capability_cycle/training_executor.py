"""Governed training-job execution through replaceable provider adapters.

This module is intentionally separate from training.py's dataset/specification
foundation. It can execute an already-specified job through an allowlisted
provider adapter, but it cannot deploy, activate, promote, or widen authority.
"""

from __future__ import annotations

import hashlib
import json
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Mapping

from current_authority.resolver import AuthorityRequest, resolve
from provider_adapters import invoke_provider

from .training import TrainingJobSpec, get_training_job


@dataclass(frozen=True)
class TrainingExecutionResult:
    execution_id: str
    training_job_id: str
    provider_id: str
    state: str
    executed: bool
    provider_result_hash: str | None
    trained_artifact_ref: str | None
    evaluation_required: bool
    deployment_allowed: bool
    evidence_refs: tuple[str, ...]
    reason: str
    created_at: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "execution_id": self.execution_id,
            "training_job_id": self.training_job_id,
            "provider_id": self.provider_id,
            "state": self.state,
            "executed": self.executed,
            "provider_result_hash": self.provider_result_hash,
            "trained_artifact_ref": self.trained_artifact_ref,
            "evaluation_required": self.evaluation_required,
            "deployment_allowed": False,
            "evidence_refs": list(self.evidence_refs),
            "reason": self.reason,
            "created_at": self.created_at,
        }


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _digest(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, default=str, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _job(job_id: str) -> TrainingJobSpec:
    job = get_training_job(job_id)
    if job is None:
        raise ValueError("UNKNOWN_TRAINING_JOB")
    if job.status != "SPECIFIED":
        raise ValueError("TRAINING_JOB_NOT_SPECIFIED")
    if job.deployment_allowed:
        raise ValueError("TRAINING_SPEC_MUST_NOT_GRANT_DEPLOYMENT")
    return job


def execute_training_job(
    training_job_id: str,
    *,
    provider_id: str,
    operation: str = "train",
    processing_profile: Mapping[str, Any],
    compliance_decision: Mapping[str, Any] | None = None,
    extra_payload: Mapping[str, Any] | None = None,
) -> TrainingExecutionResult:
    job = _job(training_job_id)
    authority = resolve(
        AuthorityRequest(
            action="self_train",
            path=f"training:{training_job_id}:{provider_id}",
        )
    )
    if authority.outcome != "ALLOW":
        return TrainingExecutionResult(
            execution_id=uuid.uuid4().hex,
            training_job_id=training_job_id,
            provider_id=provider_id,
            state="BLOCKED",
            executed=False,
            provider_result_hash=None,
            trained_artifact_ref=None,
            evaluation_required=True,
            deployment_allowed=False,
            evidence_refs=(),
            reason=f"AUTHORITY_{authority.reason}",
            created_at=_now(),
        )

    payload = {
        "training_job_id": job.training_job_id,
        "dataset_id": job.dataset_id,
        "dataset_hash": job.dataset_hash,
        "target_model_scope": job.target_model_scope,
        "training_objective": job.training_objective,
        "base_model_reference": job.base_model_reference,
        "training_method": job.training_method,
        "hyperparameter_policy_reference": job.hyperparameter_policy_reference,
        "resource_constraints": dict(job.resource_constraints),
        "evaluation_plan": job.evaluation_plan,
        "rollback_plan": job.rollback_plan,
        "_processing_profile": dict(processing_profile),
    }
    if compliance_decision is not None:
        payload["_compliance_decision"] = dict(compliance_decision)
    payload.update(dict(extra_payload or {}))

    provider = invoke_provider(
        provider_id,
        operation=operation,
        payload=payload,
    )
    executed = bool(provider.get("network_invoked")) and provider.get("status") == "EXECUTED"
    result_hash = _digest(provider) if provider else None
    parsed = provider.get("result")
    artifact_ref = None
    if isinstance(parsed, Mapping):
        candidate = parsed.get("artifact_ref") or parsed.get("model_id") or parsed.get("job_result_ref")
        if candidate:
            artifact_ref = str(candidate)

    evidence_refs = tuple(
        ref
        for ref in (
            f"training-provider-result:{result_hash}" if result_hash else None,
            f"trained-artifact:{artifact_ref}" if artifact_ref else None,
        )
        if ref
    )
    state = "EXECUTED_EVALUATION_REQUIRED" if executed else str(provider.get("status") or "FAILED")
    return TrainingExecutionResult(
        execution_id=uuid.uuid4().hex,
        training_job_id=training_job_id,
        provider_id=provider_id,
        state=state,
        executed=executed,
        provider_result_hash=result_hash,
        trained_artifact_ref=artifact_ref,
        evaluation_required=True,
        deployment_allowed=False,
        evidence_refs=evidence_refs,
        reason=str(provider.get("reason") or "TRAINING_PROVIDER_RESULT"),
        created_at=_now(),
    )
