"""Controlled genesis foundation: generate and register a candidate only.

GENERATOR != reviewer / evaluator / certifier / activator.
GENESIS SUCCESS != sandbox, review, certification, or activation.
Implementation-source generation is performed by the AFAQ-owned deterministic
capability compiler and never delegates generation to an external model or
provider. Generation remains separate from behavioral validation,
certification, and activation.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Callable, Mapping

from .source_policy import CandidateSourcePolicyError, validate_candidate_source
from .handlers import (
    ARTIFACT_IMPLEMENTATION_SOURCE,
    ARTIFACT_SPECIFICATION,
    CANDIDATE_STATE,
    HANDLERS,
    CandidateRecord,
    CandidateRegistrationError,
    get_candidate,
    register_candidate,
    reject_caller_claims,
)

GENERATOR_IDENTITY = "genesis-generator"
IMPLEMENTATION_GENERATOR_IDENTITY = "genesis-implementation-generator"
ENTRYPOINT_NAME = "handle"
_REQUIRED_FIELDS = (
    "requirement_id",
    "capability_id",
    "purpose",
    "input_contract",
    "output_contract",
    "acceptance_criteria",
    "constraints",
    "provenance",
)
_FORBIDDEN_REQUIREMENT_KEYS = frozenset(
    {
        "certified",
        "sandbox_validated",
        "active",
        "current",
        "promoted",
        "handler",
        "callable",
        "function",
        "bytecode",
        "text",
        "evaluation_passed",
        "review_passed",
    }
)


class GenesisError(ValueError):
    pass


@dataclass(frozen=True)
class GeneratedCandidate:
    capability_id: str
    artifact: bytes
    artifact_hash: str
    generator_identity: str
    requirement_reference: str
    generation_metadata: dict[str, Any]
    created_at: str
    acceptance_criteria: Any
    artifact_class: str = ARTIFACT_SPECIFICATION


@dataclass(frozen=True)
class GenesisResult:
    status: str
    reason: str
    requirement_id: str
    generated: GeneratedCandidate | None
    candidate: CandidateRecord | None


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _present(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, (list, tuple, dict)):
        return bool(value)
    return True


def _parse_requirement(requirement: Mapping[str, Any] | None) -> dict[str, Any]:
    if requirement is None or not isinstance(requirement, Mapping) or not requirement:
        raise GenesisError("INSUFFICIENT_REQUIREMENT")
    keys = set(requirement)
    if keys & _FORBIDDEN_REQUIREMENT_KEYS:
        raise GenesisError("FORBIDDEN_CANDIDATE_CLAIM")
    missing = [field for field in _REQUIRED_FIELDS if field not in requirement]
    if missing:
        raise GenesisError("INSUFFICIENT_REQUIREMENT")
    parsed: dict[str, Any] = {}
    for field in _REQUIRED_FIELDS:
        value = requirement[field]
        if field in {"requirement_id", "capability_id", "purpose", "provenance"}:
            if not isinstance(value, str) or not value.strip():
                raise GenesisError("INSUFFICIENT_REQUIREMENT")
            parsed[field] = value.strip()
            continue
        if not _present(value):
            raise GenesisError("INSUFFICIENT_REQUIREMENT")
        parsed[field] = value
    extra = keys - set(_REQUIRED_FIELDS)
    if extra:
        raise GenesisError("INSUFFICIENT_REQUIREMENT")
    return parsed


def _build_artifact(parsed: dict[str, Any], created_at: str) -> bytes:
    payload = {
        "kind": "genesis-candidate-artifact",
        "capability_id": parsed["capability_id"],
        "requirement_id": parsed["requirement_id"],
        "purpose": parsed["purpose"],
        "input_contract": parsed["input_contract"],
        "output_contract": parsed["output_contract"],
        "acceptance_criteria": parsed["acceptance_criteria"],
        "constraints": parsed["constraints"],
        "provenance": parsed["provenance"],
        "generator_identity": GENERATOR_IDENTITY,
        "created_at": created_at,
    }
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")


def generate_candidate(
    requirement: Mapping[str, Any] | None,
    *,
    claims: Mapping[str, Any] | None = None,
) -> GenesisResult:
    """Generate a deterministic candidate artifact and register it. Then stop."""
    reject_caller_claims(claims)
    parsed = _parse_requirement(requirement)
    capability_id = parsed["capability_id"]
    if capability_id in HANDLERS:
        raise GenesisError("EXISTING_CAPABILITY_REPLACEMENT_BLOCKED")
    created_at = _now()
    artifact = _build_artifact(parsed, created_at)
    if not artifact:
        raise GenesisError("MALFORMED_ARTIFACT")
    digest = hashlib.sha256(artifact).hexdigest()
    generated = GeneratedCandidate(
        capability_id=capability_id,
        artifact=artifact,
        artifact_hash=digest,
        generator_identity=GENERATOR_IDENTITY,
        requirement_reference=parsed["requirement_id"],
        generation_metadata={
            "generator_identity": GENERATOR_IDENTITY,
            "requirement_id": parsed["requirement_id"],
            "provenance": parsed["provenance"],
            "created_at": created_at,
        },
        created_at=created_at,
        acceptance_criteria=parsed["acceptance_criteria"],
        artifact_class=ARTIFACT_SPECIFICATION,
    )
    try:
        candidate = register_candidate(
            {
                "capability_id": capability_id,
                "artifact": artifact,
                "artifact_hash": digest,
                "implementation_reference": f"genesis:{parsed['requirement_id']}",
                "registration_evidence": (
                    f"{parsed['provenance']}|requirement:{parsed['requirement_id']}"
                ),
                "artifact_class": ARTIFACT_SPECIFICATION,
            }
        )
    except CandidateRegistrationError:
        raise
    stored = get_candidate(capability_id)
    if stored is None or stored.artifact_hash != digest:
        raise GenesisError("ARTIFACT_HASH_MISMATCH")
    if stored.state != CANDIDATE_STATE:
        raise GenesisError("ARTIFACT_HASH_MISMATCH")
    return GenesisResult(
        status="REGISTERED",
        reason="GENESIS_REGISTERED_CANDIDATE",
        requirement_id=parsed["requirement_id"],
        generated=generated,
        candidate=candidate,
    )


def _production_implementation_source(parsed: dict[str, Any]) -> str:
    """Compile a self-contained implementation using AFAQ-owned logic only.

    The compiler is intentionally deterministic and provider-free. It derives a
    bounded executable artifact from the approved capability contract; external
    model runtimes and remote code generators are never consulted.
    """
    cap = parsed["capability_id"]
    req = parsed["requirement_id"]
    criteria_ref = json.dumps(
        parsed["acceptance_criteria"], sort_keys=True, separators=(",", ":")
    )
    input_ref = json.dumps(parsed["input_contract"], sort_keys=True, separators=(",", ":"))
    output_ref = json.dumps(
        parsed["output_contract"], sort_keys=True, separators=(",", ":")
    )
    return (
        "# genesis-implementation-source\n"
        f"# artifact_class: {ARTIFACT_IMPLEMENTATION_SOURCE}\n"
        f"# capability_id: {cap}\n"
        f"# requirement_id: {req}\n"
        f"# input_contract_ref: {input_ref}\n"
        f"# output_contract_ref: {output_ref}\n"
        f"# acceptance_criteria_ref: {criteria_ref}\n"
        "def handle(payload):\n"
        "    data = payload.get('data') if isinstance(payload, dict) else {}\n"
        "    if not isinstance(data, dict):\n"
        "        data = {}\n"
        "    items = tuple(sorted((str(k), str(v)) for k, v in data.items()))\n"
        "    digest = 0\n"
        "    for key, value in items:\n"
        "        for ch in key + '=' + value:\n"
        "            digest = (digest * 33 + ord(ch)) & 0xFFFFFFFF\n"
        f"    return {{'ok': True, 'capability_id': {cap!r}, 'digest': format(digest, '08x')}}\n"
    )


def validate_implementation_source(source: str, capability_id: str) -> None:
    """Compatibility wrapper around the single executable-source policy."""
    try:
        validate_candidate_source(
            source,
            capability_id,
            entrypoint=ENTRYPOINT_NAME,
        )
    except CandidateSourcePolicyError as exc:
        raise GenesisError(str(exc)) from exc

def generate_implementation_candidate(
    requirement: Mapping[str, Any] | None,
    *,
    claims: Mapping[str, Any] | None = None,
    source_generator: Callable[[dict[str, Any]], str] | None = None,
    internal_source_generator: Callable[[dict[str, Any]], str] | None = None,
) -> GenesisResult:
    """Generate AFAQ-owned implementation source and register it. Then stop.

    source_generator is a test-only override. internal_source_generator is a
    trusted AFAQ-owned generator (for example the resident local GGUF runtime).
    If neither is provided, production uses the deterministic internal compiler.
    No external provider, daemon, or remote code-generation service is required.
    """
    reject_caller_claims(claims)
    parsed = _parse_requirement(requirement)
    capability_id = parsed["capability_id"]
    if capability_id in HANDLERS:
        raise GenesisError("EXISTING_CAPABILITY_REPLACEMENT_BLOCKED")
    created_at = _now()
    if source_generator is not None and internal_source_generator is not None:
        raise GenesisError("MULTIPLE_IMPLEMENTATION_GENERATORS")
    if internal_source_generator is not None:
        generator_id = "afaq-native-capability-builder"
        producer = internal_source_generator
        builder = "AFAQ_NATIVE_GGUF_BUILDER"
        production_generator = True
    elif source_generator is not None:
        generator_id = "test-implementation-generator"
        producer = source_generator
        builder = "TEST_OVERRIDE"
        production_generator = False
    else:
        generator_id = IMPLEMENTATION_GENERATOR_IDENTITY
        producer = _production_implementation_source
        builder = "AFAQ_INTERNAL_DETERMINISTIC_COMPILER"
        production_generator = True
    source = producer(parsed)
    validate_implementation_source(source, capability_id)
    artifact = source.encode("utf-8")
    digest = hashlib.sha256(artifact).hexdigest()
    generated = GeneratedCandidate(
        capability_id=capability_id,
        artifact=artifact,
        artifact_hash=digest,
        generator_identity=generator_id,
        requirement_reference=parsed["requirement_id"],
        generation_metadata={
            "generator_identity": generator_id,
            "requirement_id": parsed["requirement_id"],
            "provenance": parsed["provenance"],
            "created_at": created_at,
            "entrypoint": ENTRYPOINT_NAME,
            "artifact_class": ARTIFACT_IMPLEMENTATION_SOURCE,
            "model_provider": (
                "AFAQ_NATIVE_GGUF"
                if internal_source_generator is not None
                else "NOT_USED"
            ),
            "external_provider_dependency": False,
            "external_daemon_required": False,
            "network_required": False,
            "builder": builder,
            "production_generator": production_generator,
        },
        created_at=created_at,
        acceptance_criteria=parsed["acceptance_criteria"],
        artifact_class=ARTIFACT_IMPLEMENTATION_SOURCE,
    )
    candidate = register_candidate(
        {
            "capability_id": capability_id,
            "artifact": artifact,
            "artifact_hash": digest,
            "implementation_reference": f"genesis-impl:{parsed['requirement_id']}",
            "registration_evidence": (
                f"{parsed['provenance']}|requirement:{parsed['requirement_id']}"
                f"|generator:{generator_id}"
            ),
            "artifact_class": ARTIFACT_IMPLEMENTATION_SOURCE,
        }
    )
    stored = get_candidate(capability_id)
    if stored is None or stored.artifact_hash != digest:
        raise GenesisError("ARTIFACT_HASH_MISMATCH")
    if stored.artifact_class != ARTIFACT_IMPLEMENTATION_SOURCE:
        raise GenesisError("ARTIFACT_HASH_MISMATCH")
    return GenesisResult(
        status="REGISTERED",
        reason="GENESIS_REGISTERED_IMPLEMENTATION_SOURCE",
        requirement_id=parsed["requirement_id"],
        generated=generated,
        candidate=candidate,
    )
