"""Backend-neutral logical Evidence Fabric."""

from __future__ import annotations

from typing import (
    Any,
    Mapping,
)

from .cycle_ports import (
    EvidencePort,
    EvidenceReceipt,
)


class EvidenceFabric:
    def __init__(
        self,
        backend: EvidencePort,
    ) -> None:
        self.backend = backend

    def append_event(
        self,
        *,
        cycle_id: str,
        event_type: str,
        event_sequence: int,
        state: str,
        payload: (
            Mapping[str, Any] | None
        ) = None,
        actor: str = "cycle-runtime",
        environment: (
            str | None
        ) = None,
        parent_event_id: (
            str | None
        ) = None,
        causation_id: (
            str | None
        ) = None,
        correlation_id: (
            str | None
        ) = None,
    ) -> EvidenceReceipt:
        return self.backend.append_event(
            cycle_id=cycle_id,
            event_type=event_type,
            event_sequence=(
                event_sequence
            ),
            state=state,
            payload=payload,
            actor=actor,
            environment=environment,
            parent_event_id=(
                parent_event_id
            ),
            causation_id=(
                causation_id
            ),
            correlation_id=(
                correlation_id
            ),
        )

    def verify_integrity(
        self,
    ) -> Mapping[str, Any]:
        return (
            self.backend
            .verify_integrity()
        )

    def close(
        self,
    ) -> None:
        self.backend.close()
