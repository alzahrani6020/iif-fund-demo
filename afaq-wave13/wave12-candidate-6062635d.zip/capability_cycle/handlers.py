"""Registered capability handlers.

A descriptor in the architecture map is not an implementation.
Only these handlers count as IMPLEMENTED for Phase-01.

Candidate registration is a separate process-local state. A registered
candidate is never an active handler and never becomes executable by
being registered.
"""

from __future__ import annotations

import base64
import hashlib
import importlib
import json
import marshal
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Callable, Mapping

from current_authority.resolver import AuthorityRequest, resolve
from .source_policy import (
    CandidateSourcePolicyError,
    candidate_safe_builtins,
    validate_candidate_source,
)

Handler = Callable[[dict[str, Any]], dict[str, Any]]


CANDIDATE_STATE = "REGISTERED_CANDIDATE"
CANDIDATE_SANDBOX_VALIDATED = "SANDBOX_VALIDATED"
CANDIDATE_INDEPENDENTLY_REVIEWED = "INDEPENDENTLY_REVIEWED"
CANDIDATE_EVALUATED_PASSED = "EVALUATED_PASSED"
CANDIDATE_CERTIFIED = "CERTIFIED_CANDIDATE"
CANDIDATE_BEHAVIORALLY_CERTIFIED = "BEHAVIORALLY_CERTIFIED_CANDIDATE"
CANDIDATE_ACTIVE_CERTIFIED = "ACTIVE_CERTIFIED_CAPABILITY"
ARTIFACT_SPECIFICATION = "SPECIFICATION_ARTIFACT"
ARTIFACT_IMPLEMENTATION_SOURCE = "IMPLEMENTATION_SOURCE"
CERTIFICATION_KIND_PIPELINE = "PIPELINE_EVIDENCE"
CERTIFICATION_KIND_BEHAVIORAL = "BEHAVIORAL"
_REQUIRED_CANDIDATE_FIELDS = (
    "capability_id",
    "artifact",
    "artifact_hash",
    "implementation_reference",
    "registration_evidence",
)
_ALLOWED_CANDIDATE_FIELDS = _REQUIRED_CANDIDATE_FIELDS + ("state", "artifact_class")
_FORBIDDEN_CANDIDATE_CLAIMS = frozenset(
    {
        "CERTIFIED",
        "SANDBOX_VALIDATED",
        "ACTIVE",
        "CURRENT",
        "PROMOTED",
    }
)
_FORBIDDEN_CANDIDATE_KEYS = frozenset(
    {
        "certified",
        "sandbox_validated",
        "active",
        "current",
        "promoted",
        "certified_by",
        "handler",
        "callable",
        "function",
    }
)


class CandidateRegistrationError(ValueError):
    pass


@dataclass(frozen=True)
class CandidateRecord:
    capability_id: str
    artifact_hash: str
    implementation_reference: str
    registration_evidence: str
    state: str
    artifact_class: str = ARTIFACT_SPECIFICATION


@dataclass(frozen=True)
class CandidateSandboxEvidence:
    capability_id: str
    artifact_hash: str
    validated: bool
    outcome: str
    failure_class: str | None
    evidence_ref: str
    correlation_id: str


@dataclass(frozen=True)
class CandidateBehaviorEvidence:
    behavior_evidence_id: str
    capability_id: str
    artifact_hash: str
    requirement_id: str
    correlation_id: str
    input_digest: str
    result_digest: str | None
    execution_status: str
    duration_ms: float | None
    isolation_profile: str
    timestamp: str
    failure_reason: str | None
    return_value: Any = None
    return_type: str | None = None


@dataclass(frozen=True)
class CriterionVerdict:
    criterion_id: str
    result: str
    reason: str
    evidence_refs: tuple[str, ...]


@dataclass(frozen=True)
class BehavioralEvaluationResult:
    evaluation_id: str
    capability_id: str
    artifact_hash: str
    requirement_id: str
    behavior_evidence_id: str
    criteria_reference: str
    status: str
    reason: str
    input_contract_result: str
    output_contract_result: str
    acceptance_criteria_results: tuple[CriterionVerdict, ...]
    constraint_results: tuple[CriterionVerdict, ...]
    evidence_refs: tuple[str, ...]
    evaluated_at: str


@dataclass(frozen=True)
class CandidateReviewRecord:
    capability_id: str
    artifact_hash: str
    state: str
    reason: str
    reviewed_by: str
    sandbox_evidence_ref: str
    registration_evidence: str


@dataclass(frozen=True)
class CandidateEvaluationRecord:
    evaluation_id: str
    capability_id: str
    artifact_hash: str
    criteria_reference: str
    result: str
    reason: str
    evidence_refs: tuple[str, ...]
    timestamp: str


@dataclass(frozen=True)
class CandidateCertificationRecord:
    certification_id: str
    capability_id: str
    artifact_hash: str
    sandbox_evidence_ref: str
    review_evidence_ref: str
    evaluation_evidence_ref: str
    certified_at: str
    certifier: str
    status: str
    certification_kind: str = CERTIFICATION_KIND_PIPELINE


@dataclass(frozen=True)
class BehavioralCertificationRecord:
    certification_id: str
    certification_kind: str
    capability_id: str
    artifact_hash: str
    requirement_id: str
    registration_ref: str
    sandbox_ref: str
    review_ref: str
    behavior_evidence_ref: str
    behavioral_evaluation_ref: str
    criteria_result_refs: tuple[str, ...]
    constraints_result_refs: tuple[str, ...]
    certified_at: str
    certifier: str
    status: str


@dataclass(frozen=True)
class CandidateActivationRecord:
    activation_id: str
    capability_id: str
    artifact_hash: str
    registration_ref: str
    sandbox_ref: str
    review_ref: str
    evaluation_ref: str
    certification_ref: str
    authority_result: str
    previous_binding: str | None
    new_binding: str
    post_activation_verification: str
    timestamp: str
    behavior_evidence_ref: str = ""
    behavioral_evaluation_ref: str = ""
    behavioral_certification_ref: str = ""


# Process-local candidate registry. Never merged into HANDLERS or _ACTIVE
# until explicit controlled activation of a new certified ID.
_CANDIDATES: dict[str, CandidateRecord] = {}
_CANDIDATE_ARTIFACTS: dict[str, bytes] = {}
_CANDIDATE_SANDBOX: dict[str, CandidateSandboxEvidence] = {}
_CANDIDATE_BEHAVIOR: dict[str, CandidateBehaviorEvidence] = {}
_CANDIDATE_BEHAVIOR_EVALUATIONS: dict[str, BehavioralEvaluationResult] = {}
_CANDIDATE_REVIEWS: dict[str, CandidateReviewRecord] = {}
_CANDIDATE_EVALUATIONS: dict[str, CandidateEvaluationRecord] = {}
_CANDIDATE_CERTIFICATIONS: dict[str, CandidateCertificationRecord] = {}
_CANDIDATE_BEHAVIOR_CERTIFICATIONS: dict[str, BehavioralCertificationRecord] = {}
_CANDIDATE_ACTIVATIONS: dict[str, CandidateActivationRecord] = {}


def handle_audit(payload: dict[str, Any]) -> dict[str, Any]:
    text = json.dumps(payload.get("data", {}), sort_keys=True)
    return {"digest": hashlib.sha256(text.encode("utf-8")).hexdigest(), "ok": True}


def handle_eval(payload: dict[str, Any]) -> dict[str, Any]:
    expected = payload.get("expected")
    actual = payload.get("actual")
    passed = expected == actual
    return {"passed": passed, "ok": passed}


def handle_truth(payload: dict[str, Any]) -> dict[str, Any]:
    edges = payload.get("edges") or []
    nodes: dict[str, list[str]] = {}
    for edge in edges:
        if not isinstance(edge, (list, tuple)) or len(edge) != 2:
            return {"ok": False, "cycle": False, "error": "invalid_edge"}
        nodes.setdefault(str(edge[0]), []).append(str(edge[1]))
    seen: set[str] = set()
    stack: set[str] = set()

    def visit(node: str) -> bool:
        if node in stack:
            return True
        if node in seen:
            return False
        stack.add(node)
        for nxt in nodes.get(node, []):
            if visit(nxt):
                return True
        stack.remove(node)
        seen.add(node)
        return False

    cycle = any(visit(node) for node in list(nodes))
    return {"ok": not cycle, "cycle": cycle}


HANDLERS: dict[str, Handler] = {
    "CAP-AUDIT-001": handle_audit,
    "CAP-EVAL-001": handle_eval,
    "CAP-TRUTH-001": handle_truth,
}

# Process-local version overlay. Keys must already exist in HANDLERS.
# Restore never adds capability IDs.
_ACTIVE: dict[str, tuple[str, Handler]] = {}


def implemented_ids() -> tuple[str, ...]:
    return tuple(sorted(HANDLERS))


def has_implementation(capability_id: str) -> bool:
    return capability_id in HANDLERS


def get_active_handler(capability_id: str) -> Handler | None:
    if capability_id in _ACTIVE:
        return _ACTIVE[capability_id][1]
    return HANDLERS.get(capability_id)


def active_version_id(capability_id: str) -> str | None:
    if capability_id in _ACTIVE:
        return _ACTIVE[capability_id][0]
    return artifact_hash(capability_id)


def artifact_hash(capability_id: str) -> str | None:
    handler = get_active_handler(capability_id)
    if handler is None:
        return None
    return hashlib.sha256(handler.__code__.co_code).hexdigest()


def handler_version(capability_id: str) -> str | None:
    digest = artifact_hash(capability_id)
    return digest[:16] if digest else None


def bind_active(capability_id: str, version_id: str, handler: Handler) -> None:
    if capability_id not in HANDLERS:
        raise ValueError("UNKNOWN_CAPABILITY")
    _ACTIVE[capability_id] = (version_id, handler)


def unbind_active(capability_id: str) -> None:
    _ACTIVE.pop(capability_id, None)


def active_overlay_ids() -> tuple[str, ...]:
    return tuple(sorted(_ACTIVE))


# Process-local restore artifacts for the sandbox subprocess.
# Lives with the overlay owner so sandbox does not import versions.
_RESTORE_BLOBS: dict[str, dict[str, str]] = {}


def export_active_restore(capability_id: str) -> dict[str, str] | None:
    blob = _RESTORE_BLOBS.get(capability_id)
    return dict(blob) if blob else None


def set_active_restore(capability_id: str, blob: Mapping[str, str]) -> None:
    if capability_id not in HANDLERS:
        raise ValueError("UNKNOWN_CAPABILITY")
    _RESTORE_BLOBS[capability_id] = dict(blob)


def clear_active_restore(capability_id: str) -> None:
    _RESTORE_BLOBS.pop(capability_id, None)


def _artifact_bytes(artifact: Any) -> bytes:
    if callable(artifact):
        raise CandidateRegistrationError("ARBITRARY_CALLABLE_INJECTION")
    if isinstance(artifact, bytes):
        return artifact
    if isinstance(artifact, str):
        return artifact.encode("utf-8")
    raise CandidateRegistrationError("MALFORMED_CANDIDATE")


def _normalize_hash(value: Any) -> str:
    if not isinstance(value, str) or not value.strip():
        raise CandidateRegistrationError("MISSING_ARTIFACT_IDENTITY")
    digest = value.strip().lower()
    if len(digest) != 64 or any(ch not in "0123456789abcdef" for ch in digest):
        raise CandidateRegistrationError("MISSING_ARTIFACT_IDENTITY")
    return digest


def _nonempty_str(value: Any, reason: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise CandidateRegistrationError(reason)
    return value.strip()


def register_candidate(candidate: Mapping[str, Any]) -> CandidateRecord:
    """Register a candidate without granting execution or activation.

    Does not write HANDLERS, _ACTIVE, or restore blobs.
    """
    if not isinstance(candidate, Mapping):
        raise CandidateRegistrationError("MALFORMED_CANDIDATE")
    keys = set(candidate)
    claim_keys = keys & _FORBIDDEN_CANDIDATE_KEYS
    if claim_keys:
        raise CandidateRegistrationError("FORBIDDEN_CANDIDATE_CLAIM")
    unknown = keys - set(_ALLOWED_CANDIDATE_FIELDS)
    if unknown:
        raise CandidateRegistrationError("MALFORMED_CANDIDATE")
    missing = [field for field in _REQUIRED_CANDIDATE_FIELDS if field not in candidate]
    if missing:
        if "artifact_hash" in missing or "artifact" in missing:
            raise CandidateRegistrationError("MISSING_ARTIFACT_IDENTITY")
        raise CandidateRegistrationError("MALFORMED_CANDIDATE")

    claimed_state = candidate.get("state")
    if claimed_state is not None:
        if not isinstance(claimed_state, str):
            raise CandidateRegistrationError("MALFORMED_CANDIDATE")
        if claimed_state.strip() in _FORBIDDEN_CANDIDATE_CLAIMS:
            raise CandidateRegistrationError("FORBIDDEN_CANDIDATE_CLAIM")
        if claimed_state.strip() != CANDIDATE_STATE:
            raise CandidateRegistrationError("FORBIDDEN_CANDIDATE_CLAIM")

    capability_id = _nonempty_str(candidate.get("capability_id"), "MALFORMED_CANDIDATE")
    implementation_reference = _nonempty_str(
        candidate.get("implementation_reference"), "MALFORMED_CANDIDATE"
    )
    registration_evidence = _nonempty_str(
        candidate.get("registration_evidence"), "MALFORMED_CANDIDATE"
    )
    supplied_hash = _normalize_hash(candidate.get("artifact_hash"))
    artifact = _artifact_bytes(candidate.get("artifact"))
    derived_hash = hashlib.sha256(artifact).hexdigest()
    if derived_hash != supplied_hash:
        raise CandidateRegistrationError("ARTIFACT_HASH_MISMATCH")

    if capability_id in HANDLERS:
        raise CandidateRegistrationError("ACTIVE_CAPABILITY_CONFLICT")
    if capability_id in _CANDIDATES:
        raise CandidateRegistrationError("DUPLICATE_CANDIDATE")

    artifact_class = candidate.get("artifact_class", ARTIFACT_SPECIFICATION)
    if artifact_class not in {ARTIFACT_SPECIFICATION, ARTIFACT_IMPLEMENTATION_SOURCE}:
        raise CandidateRegistrationError("MALFORMED_CANDIDATE")
    if artifact_class == ARTIFACT_IMPLEMENTATION_SOURCE:
        try:
            source = artifact.decode("utf-8")
            validate_candidate_source(source, capability_id)
        except (UnicodeDecodeError, CandidateSourcePolicyError) as exc:
            raise CandidateRegistrationError(
                str(exc) if isinstance(exc, CandidateSourcePolicyError)
                else "MALFORMED_ARTIFACT"
            ) from exc

    record = CandidateRecord(
        capability_id=capability_id,
        artifact_hash=derived_hash,
        implementation_reference=implementation_reference,
        registration_evidence=registration_evidence,
        state=CANDIDATE_STATE,
        artifact_class=str(artifact_class),
    )
    _CANDIDATES[capability_id] = record
    _CANDIDATE_ARTIFACTS[capability_id] = artifact
    return record


def get_candidate(capability_id: str) -> CandidateRecord | None:
    record = _CANDIDATES.get(capability_id)
    if record is None:
        return None
    blob = _CANDIDATE_ARTIFACTS.get(capability_id)
    if blob is None or hashlib.sha256(blob).hexdigest() != record.artifact_hash:
        raise CandidateRegistrationError("CANDIDATE_TAMPERED")
    return record


def candidate_ids() -> tuple[str, ...]:
    return tuple(sorted(_CANDIDATES))


def has_candidate(capability_id: str) -> bool:
    return capability_id in _CANDIDATES


def clear_candidates() -> None:
    for cap_id in list(_CANDIDATE_ACTIVATIONS):
        HANDLERS.pop(cap_id, None)
        unbind_active(cap_id)
        clear_active_restore(cap_id)
    _CANDIDATES.clear()
    _CANDIDATE_ARTIFACTS.clear()
    _CANDIDATE_SANDBOX.clear()
    _CANDIDATE_BEHAVIOR.clear()
    _CANDIDATE_BEHAVIOR_EVALUATIONS.clear()
    _CANDIDATE_REVIEWS.clear()
    _CANDIDATE_EVALUATIONS.clear()
    _CANDIDATE_CERTIFICATIONS.clear()
    _CANDIDATE_BEHAVIOR_CERTIFICATIONS.clear()
    _CANDIDATE_ACTIVATIONS.clear()


def reject_caller_claims(claims: Mapping[str, Any] | None) -> None:
    if claims:
        raise CandidateRegistrationError("FORBIDDEN_CANDIDATE_CLAIM")


def export_candidate_artifact(capability_id: str) -> tuple[CandidateRecord, bytes]:
    if capability_id in HANDLERS:
        raise CandidateRegistrationError("ACTIVE_CAPABILITY_CONFLICT")
    record = get_candidate(capability_id)
    if record is None:
        raise CandidateRegistrationError("UNKNOWN_CANDIDATE")
    blob = _CANDIDATE_ARTIFACTS.get(capability_id)
    if blob is None:
        raise CandidateRegistrationError("CANDIDATE_TAMPERED")
    current_hash = hashlib.sha256(blob).hexdigest()
    if current_hash != record.artifact_hash:
        raise CandidateRegistrationError("CANDIDATE_TAMPERED")
    return record, bytes(blob)


def record_candidate_sandbox(evidence: CandidateSandboxEvidence) -> None:
    record, blob = export_candidate_artifact(evidence.capability_id)
    current_hash = hashlib.sha256(blob).hexdigest()
    if (
        evidence.artifact_hash != record.artifact_hash
        or evidence.artifact_hash != current_hash
    ):
        raise CandidateRegistrationError("CANDIDATE_TAMPERED")
    _CANDIDATE_SANDBOX[evidence.capability_id] = evidence


def get_candidate_sandbox(capability_id: str) -> CandidateSandboxEvidence | None:
    return _CANDIDATE_SANDBOX.get(capability_id)


def record_candidate_behavior(evidence: CandidateBehaviorEvidence) -> None:
    record, blob = export_candidate_artifact(evidence.capability_id)
    current_hash = hashlib.sha256(blob).hexdigest()
    if (
        evidence.artifact_hash != record.artifact_hash
        or evidence.artifact_hash != current_hash
    ):
        raise CandidateRegistrationError("CANDIDATE_TAMPERED")
    _CANDIDATE_BEHAVIOR[evidence.capability_id] = evidence


def get_candidate_behavior(capability_id: str) -> CandidateBehaviorEvidence | None:
    return _CANDIDATE_BEHAVIOR.get(capability_id)


def record_candidate_behavior_evaluation(result: BehavioralEvaluationResult) -> None:
    record, blob = export_candidate_artifact(result.capability_id)
    current_hash = hashlib.sha256(blob).hexdigest()
    if (
        result.artifact_hash != record.artifact_hash
        or result.artifact_hash != current_hash
    ):
        raise CandidateRegistrationError("CANDIDATE_TAMPERED")
    _CANDIDATE_BEHAVIOR_EVALUATIONS[result.capability_id] = result


def get_candidate_behavior_evaluation(
    capability_id: str,
) -> BehavioralEvaluationResult | None:
    return _CANDIDATE_BEHAVIOR_EVALUATIONS.get(capability_id)


def record_candidate_review(review: CandidateReviewRecord) -> None:
    if review.state != CANDIDATE_INDEPENDENTLY_REVIEWED:
        return
    record, blob = export_candidate_artifact(review.capability_id)
    current_hash = hashlib.sha256(blob).hexdigest()
    if (
        review.artifact_hash != record.artifact_hash
        or review.artifact_hash != current_hash
    ):
        raise CandidateRegistrationError("CANDIDATE_TAMPERED")
    sandbox = _CANDIDATE_SANDBOX.get(review.capability_id)
    if sandbox is None or not sandbox.validated:
        raise CandidateRegistrationError("MISSING_SANDBOX_EVIDENCE")
    if sandbox.artifact_hash != review.artifact_hash:
        raise CandidateRegistrationError("CROSS_ARTIFACT_EVIDENCE")
    if sandbox.evidence_ref != review.sandbox_evidence_ref:
        raise CandidateRegistrationError("CROSS_ARTIFACT_EVIDENCE")
    _CANDIDATE_REVIEWS[review.capability_id] = review


def get_candidate_review(capability_id: str) -> CandidateReviewRecord | None:
    return _CANDIDATE_REVIEWS.get(capability_id)


def record_candidate_evaluation(evaluation: CandidateEvaluationRecord) -> None:
    record, blob = export_candidate_artifact(evaluation.capability_id)
    current_hash = hashlib.sha256(blob).hexdigest()
    if (
        evaluation.artifact_hash != record.artifact_hash
        or evaluation.artifact_hash != current_hash
    ):
        raise CandidateRegistrationError("CANDIDATE_TAMPERED")
    _CANDIDATE_EVALUATIONS[evaluation.capability_id] = evaluation


def get_candidate_evaluation(
    capability_id: str,
) -> CandidateEvaluationRecord | None:
    return _CANDIDATE_EVALUATIONS.get(capability_id)


def record_candidate_certification(
    certification: CandidateCertificationRecord,
) -> None:
    if certification.status != CANDIDATE_CERTIFIED:
        return
    record, blob = export_candidate_artifact(certification.capability_id)
    current_hash = hashlib.sha256(blob).hexdigest()
    if (
        certification.artifact_hash != record.artifact_hash
        or certification.artifact_hash != current_hash
    ):
        raise CandidateRegistrationError("CANDIDATE_TAMPERED")
    sandbox = _CANDIDATE_SANDBOX.get(certification.capability_id)
    review = _CANDIDATE_REVIEWS.get(certification.capability_id)
    evaluation = _CANDIDATE_EVALUATIONS.get(certification.capability_id)
    if sandbox is None or not sandbox.validated:
        raise CandidateRegistrationError("MISSING_SANDBOX_EVIDENCE")
    if review is None or review.state != CANDIDATE_INDEPENDENTLY_REVIEWED:
        raise CandidateRegistrationError("MISSING_REVIEW_EVIDENCE")
    if evaluation is None:
        raise CandidateRegistrationError("MISSING_EVALUATION_EVIDENCE")
    if evaluation.result != "PASSED":
        raise CandidateRegistrationError("EVALUATION_NOT_PASSED")
    if (
        sandbox.artifact_hash != certification.artifact_hash
        or review.artifact_hash != certification.artifact_hash
        or evaluation.artifact_hash != certification.artifact_hash
    ):
        raise CandidateRegistrationError("CROSS_ARTIFACT_EVIDENCE")
    if sandbox.evidence_ref != certification.sandbox_evidence_ref:
        raise CandidateRegistrationError("CROSS_ARTIFACT_EVIDENCE")
    if evaluation.evaluation_id not in certification.evaluation_evidence_ref:
        raise CandidateRegistrationError("CROSS_ARTIFACT_EVIDENCE")
    _CANDIDATE_CERTIFICATIONS[certification.capability_id] = certification


def get_candidate_certification(
    capability_id: str,
) -> CandidateCertificationRecord | None:
    return _CANDIDATE_CERTIFICATIONS.get(capability_id)


def record_candidate_behavior_certification(
    certification: BehavioralCertificationRecord,
) -> None:
    if (
        certification.status != CANDIDATE_BEHAVIORALLY_CERTIFIED
        or certification.certification_kind != CERTIFICATION_KIND_BEHAVIORAL
    ):
        raise CandidateRegistrationError("MALFORMED_CANDIDATE")
    record, blob = export_candidate_artifact(certification.capability_id)
    current_hash = hashlib.sha256(blob).hexdigest()
    if (
        certification.artifact_hash != record.artifact_hash
        or certification.artifact_hash != current_hash
    ):
        raise CandidateRegistrationError("CROSS_ARTIFACT_CERTIFICATION_DENIED")
    _CANDIDATE_BEHAVIOR_CERTIFICATIONS[certification.capability_id] = certification


def get_candidate_behavior_certification(
    capability_id: str,
) -> BehavioralCertificationRecord | None:
    return _CANDIDATE_BEHAVIOR_CERTIFICATIONS.get(capability_id)


def candidate_lifecycle_state(capability_id: str) -> str:
    record = get_candidate(capability_id)
    if record is None:
        raise CandidateRegistrationError("UNKNOWN_CANDIDATE")
    activation = _CANDIDATE_ACTIVATIONS.get(capability_id)
    if (
        activation is not None
        and activation.post_activation_verification == "VERIFIED"
        and activation.artifact_hash == record.artifact_hash
        and capability_id in HANDLERS
    ):
        return CANDIDATE_ACTIVE_CERTIFIED
    certification = _CANDIDATE_CERTIFICATIONS.get(capability_id)
    if (
        certification is not None
        and certification.status == CANDIDATE_CERTIFIED
        and certification.artifact_hash == record.artifact_hash
    ):
        return CANDIDATE_CERTIFIED
    evaluation = _CANDIDATE_EVALUATIONS.get(capability_id)
    if (
        evaluation is not None
        and evaluation.result == "PASSED"
        and evaluation.artifact_hash == record.artifact_hash
    ):
        return CANDIDATE_EVALUATED_PASSED
    review = _CANDIDATE_REVIEWS.get(capability_id)
    if (
        review is not None
        and review.state == CANDIDATE_INDEPENDENTLY_REVIEWED
        and review.artifact_hash == record.artifact_hash
    ):
        return CANDIDATE_INDEPENDENTLY_REVIEWED
    sandbox = _CANDIDATE_SANDBOX.get(capability_id)
    if (
        sandbox is not None
        and sandbox.validated
        and sandbox.artifact_hash == record.artifact_hash
    ):
        return CANDIDATE_SANDBOX_VALIDATED
    return CANDIDATE_STATE


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _make_activated_handler(capability_id: str, certified_hash: str) -> Handler:
    source = (
        "def handle_activated(payload):\n"
        f"    return {{'ok': True, 'capability_id': {capability_id!r},"
        f" 'artifact_hash': {certified_hash!r}}}\n"
    )
    namespace: dict[str, Any] = {}
    exec(source, {"__builtins__": {}}, namespace)
    handler = namespace["handle_activated"]
    handler.__name__ = "handle_activated"
    return handler


def _load_certified_handle(capability_id: str, source: str) -> Handler:
    try:
        validate_candidate_source(source, capability_id)
    except CandidateSourcePolicyError as exc:
        raise CandidateRegistrationError(str(exc)) from exc
    safe = candidate_safe_builtins()
    namespace: dict[str, Any] = {"__builtins__": safe}
    exec(compile(source, "<activated-candidate>", "exec"), namespace, namespace)
    handler = namespace.get("handle")
    if not callable(handler):
        raise CandidateRegistrationError("MISSING_ENTRYPOINT")
    handler.__name__ = "handle"
    return handler


def get_candidate_activation(
    capability_id: str,
) -> CandidateActivationRecord | None:
    return _CANDIDATE_ACTIVATIONS.get(capability_id)


def _bind_and_verify(
    capability_id: str,
    current_hash: str,
    handler: Handler,
    *,
    registration_ref: str,
    sandbox_ref: str,
    review_ref: str,
    evaluation_ref: str,
    certification_ref: str,
    authority_result: str,
    behavior_evidence_ref: str = "",
    behavioral_evaluation_ref: str = "",
    behavioral_certification_ref: str = "",
) -> CandidateActivationRecord:
    encoded = base64.b64encode(marshal.dumps(handler.__code__)).decode("ascii")
    handler_digest = hashlib.sha256(handler.__code__.co_code).hexdigest()
    sandbox_mod = importlib.import_module("capability_cycle.sandbox")
    try:
        HANDLERS[capability_id] = handler
        bind_active(capability_id, current_hash, handler)
        set_active_restore(
            capability_id,
            {
                "capability_id": capability_id,
                "artifact": encoded,
                "artifact_hash": handler_digest,
            },
        )
        if active_version_id(capability_id) != current_hash:
            raise CandidateRegistrationError("POST_ACTIVATION_VERIFICATION_FAILED")
        if get_active_handler(capability_id) is None:
            raise CandidateRegistrationError("POST_ACTIVATION_VERIFICATION_FAILED")
        isolated = sandbox_mod.run_sandboxed(
            capability_id,
            {"capability_id": capability_id, "data": {"activation": True}},
        )
        if not isolated.validated:
            raise CandidateRegistrationError("POST_ACTIVATION_VERIFICATION_FAILED")
        activation = CandidateActivationRecord(
            activation_id=uuid.uuid4().hex,
            capability_id=capability_id,
            artifact_hash=current_hash,
            registration_ref=registration_ref,
            sandbox_ref=sandbox_ref,
            review_ref=review_ref,
            evaluation_ref=evaluation_ref,
            certification_ref=certification_ref,
            authority_result=authority_result,
            previous_binding=None,
            new_binding=current_hash,
            post_activation_verification="VERIFIED",
            timestamp=_now(),
            behavior_evidence_ref=behavior_evidence_ref,
            behavioral_evaluation_ref=behavioral_evaluation_ref,
            behavioral_certification_ref=behavioral_certification_ref,
        )
        _CANDIDATE_ACTIVATIONS[capability_id] = activation
        return activation
    except Exception:
        HANDLERS.pop(capability_id, None)
        unbind_active(capability_id)
        clear_active_restore(capability_id)
        _CANDIDATE_ACTIVATIONS.pop(capability_id, None)
        raise


def deactivate_candidate(
    capability_id: str,
    *,
    requester: str = "generator",
) -> dict[str, str]:
    """Explicit rollback for a capability activated by the candidate lifecycle."""
    if requester == "generator":
        raise CandidateRegistrationError("SELF_ROLLBACK_FORBIDDEN")
    activation = _CANDIDATE_ACTIVATIONS.get(capability_id)
    if activation is None:
        raise CandidateRegistrationError("MISSING_ACTIVATION_EVIDENCE")
    if active_version_id(capability_id) != activation.new_binding:
        raise CandidateRegistrationError("ACTIVE_BINDING_MISMATCH")
    HANDLERS.pop(capability_id, None)
    unbind_active(capability_id)
    clear_active_restore(capability_id)
    _CANDIDATE_ACTIVATIONS.pop(capability_id, None)
    if capability_id in HANDLERS or active_version_id(capability_id) is not None:
        raise CandidateRegistrationError("ROLLBACK_VERIFICATION_FAILED")
    return {
        "capability_id": capability_id,
        "artifact_hash": activation.artifact_hash,
        "status": "ROLLED_BACK",
        "previous_activation_id": activation.activation_id,
    }


def activate_candidate(
    capability_id: str,
    *,
    requester: str = "generator",
    claims: Mapping[str, Any] | None = None,
) -> CandidateActivationRecord:
    """Explicitly activate a certified new candidate. Never replaces HANDLERS."""
    reject_caller_claims(claims)
    if requester == "generator":
        raise CandidateRegistrationError("SELF_ACTIVATION_FORBIDDEN")
    if capability_id in HANDLERS:
        raise CandidateRegistrationError("ACTIVE_CAPABILITY_CONFLICT")
    record, blob = export_candidate_artifact(capability_id)
    current_hash = hashlib.sha256(blob).hexdigest()
    sandbox = get_candidate_sandbox(capability_id)
    review = get_candidate_review(capability_id)
    if sandbox is None or not sandbox.validated:
        raise CandidateRegistrationError("MISSING_SANDBOX_EVIDENCE")
    if review is None or review.state != CANDIDATE_INDEPENDENTLY_REVIEWED:
        raise CandidateRegistrationError("MISSING_REVIEW_EVIDENCE")

    if record.artifact_class == ARTIFACT_IMPLEMENTATION_SOURCE:
        behavior = get_candidate_behavior(capability_id)
        behavioral_eval = get_candidate_behavior_evaluation(capability_id)
        behavioral_cert = get_candidate_behavior_certification(capability_id)
        if behavior is None:
            raise CandidateRegistrationError("MISSING_BEHAVIOR_EVIDENCE")
        if behavioral_eval is None:
            raise CandidateRegistrationError("MISSING_BEHAVIORAL_EVALUATION")
        if behavioral_eval.status == "FAILED":
            raise CandidateRegistrationError("FAILED_EVALUATION")
        if behavioral_eval.status != "PASSED":
            raise CandidateRegistrationError("INSUFFICIENT_EVIDENCE")
        if (
            behavioral_cert is None
            or behavioral_cert.certification_kind != CERTIFICATION_KIND_BEHAVIORAL
            or behavioral_cert.status != CANDIDATE_BEHAVIORALLY_CERTIFIED
        ):
            raise CandidateRegistrationError("BEHAVIORAL_CERTIFICATION_REQUIRED")
        hashes = {
            current_hash,
            record.artifact_hash,
            sandbox.artifact_hash,
            review.artifact_hash,
            behavior.artifact_hash,
            behavioral_eval.artifact_hash,
            behavioral_cert.artifact_hash,
        }
        if len(hashes) != 1:
            raise CandidateRegistrationError("CROSS_ARTIFACT_EVIDENCE")
        authority = resolve(AuthorityRequest(action="implement"))
        if authority.outcome != "ALLOW":
            raise CandidateRegistrationError("ACTIVATION_DENIED")
        try:
            source = blob.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise CandidateRegistrationError("MALFORMED_ARTIFACT") from exc
        handler = _load_certified_handle(capability_id, source)
        return _bind_and_verify(
            capability_id,
            current_hash,
            handler,
            registration_ref=record.registration_evidence,
            sandbox_ref=sandbox.evidence_ref,
            review_ref=f"candidate-review:{capability_id}:{review.artifact_hash[:16]}",
            evaluation_ref=f"candidate-behavior-eval:{behavioral_eval.evaluation_id}",
            certification_ref=f"candidate-behavior-cert:{behavioral_cert.certification_id}",
            authority_result=authority.outcome,
            behavior_evidence_ref=behavior.behavior_evidence_id,
            behavioral_evaluation_ref=behavioral_eval.evaluation_id,
            behavioral_certification_ref=behavioral_cert.certification_id,
        )

    evaluation = get_candidate_evaluation(capability_id)
    certification = get_candidate_certification(capability_id)
    if evaluation is None:
        raise CandidateRegistrationError("MISSING_EVALUATION_EVIDENCE")
    if evaluation.result == "FAILED":
        raise CandidateRegistrationError("FAILED_EVALUATION")
    if evaluation.result != "PASSED":
        raise CandidateRegistrationError("INSUFFICIENT_EVIDENCE")
    if certification is None or certification.status != CANDIDATE_CERTIFIED:
        raise CandidateRegistrationError("MISSING_CERTIFICATION_EVIDENCE")
    if getattr(certification, "certification_kind", CERTIFICATION_KIND_PIPELINE) != CERTIFICATION_KIND_PIPELINE:
        raise CandidateRegistrationError("MISSING_CERTIFICATION_EVIDENCE")
    hashes = {
        current_hash,
        record.artifact_hash,
        sandbox.artifact_hash,
        review.artifact_hash,
        evaluation.artifact_hash,
        certification.artifact_hash,
    }
    if len(hashes) != 1:
        raise CandidateRegistrationError("CROSS_ARTIFACT_EVIDENCE")
    authority = resolve(AuthorityRequest(action="implement"))
    if authority.outcome != "ALLOW":
        raise CandidateRegistrationError("ACTIVATION_DENIED")
    handler = _make_activated_handler(capability_id, current_hash)
    return _bind_and_verify(
        capability_id,
        current_hash,
        handler,
        registration_ref=record.registration_evidence,
        sandbox_ref=sandbox.evidence_ref,
        review_ref=f"candidate-review:{capability_id}:{review.artifact_hash[:16]}",
        evaluation_ref=f"candidate-eval:{evaluation.evaluation_id}",
        certification_ref=f"candidate-cert:{certification.certification_id}",
        authority_result=authority.outcome,
    )
