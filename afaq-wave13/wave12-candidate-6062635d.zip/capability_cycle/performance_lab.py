"""Benchmark laboratory and adaptive performance selection over existing AFAQ engines.

This module coordinates existing engine execution and performance evidence. It
does not grant execution authority, operational proof, production admission, or
promotion.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any, Mapping

from .performance_profiler import (
    ModelPerformanceProfile,
    RuntimeBenchmark,
    benchmark_executor,
    profile_declared_model,
)
from .performance_store import PerformanceStore


@dataclass(frozen=True)
class EngineBenchmarkReport:
    baseline_engine_id: str
    candidate_engine_id: str
    baseline: RuntimeBenchmark
    candidate: RuntimeBenchmark
    verdict: str
    metric_deltas: dict[str, float | None]
    evidence_refs: tuple[str, ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "baseline_engine_id": self.baseline_engine_id,
            "candidate_engine_id": self.candidate_engine_id,
            "baseline": self.baseline.as_dict(),
            "candidate": self.candidate.as_dict(),
            "verdict": self.verdict,
            "metric_deltas": dict(self.metric_deltas),
            "evidence_refs": list(self.evidence_refs),
        }


def _metric_number(benchmark: RuntimeBenchmark, name: str) -> float | None:
    metric = benchmark.metrics.get(name)
    if metric is None or metric.value is None:
        return None
    try:
        return float(metric.value)
    except (TypeError, ValueError):
        return None


def _delta(candidate: float | None, baseline: float | None) -> float | None:
    if candidate is None or baseline is None:
        return None
    return round(candidate - baseline, 6)


def _engine_executor(engine_id: str):
    if engine_id in {"ENG-CAP-093", "ENG-CAP-141", "ENG-CAP-152"}:
        raise ValueError("performance control engines cannot benchmark themselves recursively")

    def execute(payload: Mapping[str, Any]) -> Mapping[str, Any]:
        from engines_live import invoke

        result = invoke(engine_id, dict(payload))
        data = result.as_dict()
        return {
            "ok": bool(data.get("ok")),
            "engine_id": engine_id,
            "message": data.get("message"),
            "evidence": data.get("evidence"),
            "runtime_implementation": data.get("runtime_implementation"),
            "operationally_proven": data.get("operationally_proven"),
        }

    return execute


def benchmark_engines(
    *,
    baseline_engine_id: str,
    candidate_engine_id: str,
    cases: tuple[Mapping[str, Any], ...],
    evidence_refs: tuple[str, ...] = (),
) -> EngineBenchmarkReport:
    baseline = benchmark_executor(
        subject_id=baseline_engine_id,
        executor=_engine_executor(baseline_engine_id),
        cases=cases,
        evidence_refs=evidence_refs,
    )
    candidate = benchmark_executor(
        subject_id=candidate_engine_id,
        executor=_engine_executor(candidate_engine_id),
        cases=cases,
        evidence_refs=evidence_refs,
    )

    b_success = _metric_number(baseline, "success_rate")
    c_success = _metric_number(candidate, "success_rate")
    b_p95 = _metric_number(baseline, "latency_p95_ms")
    c_p95 = _metric_number(candidate, "latency_p95_ms")
    b_throughput = _metric_number(baseline, "throughput_cases_per_second")
    c_throughput = _metric_number(candidate, "throughput_cases_per_second")

    if c_success is not None and b_success is not None and c_success < b_success:
        verdict = "CANDIDATE_WORSE_RELIABILITY"
    elif (
        c_success is not None
        and b_success is not None
        and c_success > b_success
        and (c_p95 is None or b_p95 is None or c_p95 <= b_p95)
    ):
        verdict = "CANDIDATE_SUPERIOR_ON_OBSERVED_SUCCESS_AND_LATENCY"
    elif (
        c_success == b_success
        and c_p95 is not None
        and b_p95 is not None
        and c_p95 < b_p95
    ):
        verdict = "CANDIDATE_FASTER_AT_EQUAL_OBSERVED_SUCCESS"
    elif c_success == b_success and c_p95 == b_p95:
        verdict = "OBSERVED_EQUIVALENCE"
    else:
        verdict = "MIXED_REQUIRES_POLICY_TRADEOFF"

    refs = tuple(
        sorted(
            dict.fromkeys(
                (
                    *evidence_refs,
                    f"benchmark:{baseline.benchmark_hash}",
                    f"benchmark:{candidate.benchmark_hash}",
                )
            )
        )
    )
    return EngineBenchmarkReport(
        baseline_engine_id=baseline_engine_id,
        candidate_engine_id=candidate_engine_id,
        baseline=baseline,
        candidate=candidate,
        verdict=verdict,
        metric_deltas={
            "success_rate": _delta(c_success, b_success),
            "latency_p95_ms": _delta(c_p95, b_p95),
            "throughput_cases_per_second": _delta(c_throughput, b_throughput),
        },
        evidence_refs=refs,
    )


def performance_store(path: str | None = None) -> PerformanceStore:
    resolved = path or os.environ.get("AFAQ_PERFORMANCE_STORE") or ":memory:"
    return PerformanceStore(resolved)


def persist_profile(
    profile: ModelPerformanceProfile,
    *,
    store: PerformanceStore,
) -> dict[str, Any]:
    return store.persist_model_performance_profile(
        {
            **profile.as_dict(),
            "profile_hash": profile.profile_hash,
        }
    )


def persist_benchmark(
    benchmark: RuntimeBenchmark,
    *,
    store: PerformanceStore,
) -> dict[str, Any]:
    return store.persist_runtime_benchmark(
        {
            "subject_id": benchmark.subject_id,
            "benchmark_hash": benchmark.benchmark_hash,
            **benchmark.as_dict(),
        }
    )


def record_selection_feedback(
    *,
    store: PerformanceStore,
    selected_subject: str,
    outcome: str,
    mission_type: str | None = None,
    score: float | None = None,
    evidence_refs: tuple[str, ...] = (),
    environment: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    return store.persist_selection_feedback(
        {
            "selected_subject": selected_subject,
            "outcome": outcome,
            "mission_type": mission_type,
            "score": score,
            "evidence_refs": list(evidence_refs),
            "environment": dict(environment or {}),
            "learning_activated": False,
            "routing_mutated": False,
            "promotion_activated": False,
        }
    )


def latest_benchmark_metrics(
    store: PerformanceStore,
    subject_id: str,
) -> dict[str, Any] | None:
    records = store.list_runtime_benchmarks(subject_id)
    if not records:
        return None
    return dict(records[-1].get("metrics") or {})


def recommend_subject(
    candidates: tuple[Mapping[str, Any], ...],
    *,
    max_p95_ms: float | None = None,
    min_success_rate: float = 0.0,
    max_unit_cost: float | None = None,
    quality_floor: float = 0.0,
) -> dict[str, Any]:
    """Advisory selection only; UNKNOWN fails required constraints."""
    ranked: list[tuple[float, str, dict[str, Any]]] = []
    rejected: list[dict[str, Any]] = []

    for raw in candidates:
        item = dict(raw)
        subject_id = str(item.get("subject_id") or "")
        if not subject_id:
            rejected.append({"subject_id": "", "reason": "MISSING_SUBJECT_ID"})
            continue

        def num(key: str) -> float | None:
            value = item.get(key)
            try:
                return float(value) if value is not None else None
            except (TypeError, ValueError):
                return None

        success = num("success_rate")
        p95 = num("latency_p95_ms")
        cost = num("unit_cost")
        quality = num("quality")

        reasons: list[str] = []
        if success is None or success < min_success_rate:
            reasons.append("SUCCESS_RATE_UNKNOWN_OR_BELOW_FLOOR")
        if quality is None or quality < quality_floor:
            reasons.append("QUALITY_UNKNOWN_OR_BELOW_FLOOR")
        if max_p95_ms is not None and (p95 is None or p95 > max_p95_ms):
            reasons.append("P95_UNKNOWN_OR_OVER_BUDGET")
        if max_unit_cost is not None and (cost is None or cost > max_unit_cost):
            reasons.append("COST_UNKNOWN_OR_OVER_BUDGET")
        if reasons:
            rejected.append({"subject_id": subject_id, "reason": ",".join(reasons)})
            continue

        latency_score = 1.0 / (1.0 + max(0.0, p95 or 0.0))
        cost_score = 1.0 / (1.0 + max(0.0, cost or 0.0))
        score = (
            0.40 * (quality or 0.0)
            + 0.35 * (success or 0.0)
            + 0.15 * latency_score
            + 0.10 * cost_score
        )
        ranked.append((score, subject_id, item))

    ranked.sort(key=lambda row: (-row[0], row[1]))
    selected = ranked[0] if ranked else None
    return {
        "state": "RECOMMENDATION_AVAILABLE" if selected else "NO_ELIGIBLE_CANDIDATE",
        "selected_subject": selected[1] if selected else None,
        "score": round(selected[0], 6) if selected else None,
        "ranked": [
            {"subject_id": subject_id, "score": round(score, 6), "metrics": item}
            for score, subject_id, item in ranked
        ],
        "rejected": rejected,
        "advisory_only": True,
        "routing_mutated": False,
        "authority_granted": False,
    }


def profile_from_payload(payload: Mapping[str, Any]) -> ModelPerformanceProfile:
    metadata = payload.get("metadata")
    if not isinstance(metadata, Mapping):
        raise ValueError("metadata mapping required")
    subject_id = str(payload.get("subject_id") or metadata.get("subject_id") or "")
    if not subject_id:
        raise ValueError("subject_id required")
    return profile_declared_model(
        subject_id=subject_id,
        metadata=metadata,
        source=str(payload.get("source") or "DECLARED_INPUT"),
        source_confidence=str(payload.get("source_confidence") or "DECLARED"),
    )


def json_metric_value(metric: Mapping[str, Any] | Any) -> Any:
    if isinstance(metric, Mapping):
        return metric.get("value")
    return None
