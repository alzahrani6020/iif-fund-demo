"""Pure domain contracts for verification and reconciliation.

This module contains no:
- storage implementation
- engine dependency
- learning execution
- Genesis
- authority resolver
- policy mutation
- runtime mutation

References are opaque identifiers.
Referenced artifacts remain authoritative for their content.
"""

from __future__ import annotations

from dataclasses import (
    asdict,
    dataclass,
)
from enum import Enum
from typing import Any


VERIFICATION_SCHEMA_V1 = (
    "AFAQ_VERIFICATION_DECISION_V1"
)

RECONCILIATION_INPUT_SCHEMA_V1 = (
    "AFAQ_RECONCILIATION_INPUT_V1"
)

GAP_RECORD_SCHEMA_V1 = (
    "AFAQ_GAP_RECORD_V1"
)


class VerificationStatus(str, Enum):
    VERIFIED = "VERIFIED"
    FAILED = "FAILED"
    INSUFFICIENT_EVIDENCE = (
        "INSUFFICIENT_EVIDENCE"
    )


class GapType(str, Enum):
    MISSING_CAPABILITY = (
        "MISSING_CAPABILITY"
    )
    IMPLEMENTATION_GAP = (
        "IMPLEMENTATION_GAP"
    )
    VERIFICATION_GAP = (
        "VERIFICATION_GAP"
    )
    PERFORMANCE_GAP = (
        "PERFORMANCE_GAP"
    )
    CONTRACT_GAP = (
        "CONTRACT_GAP"
    )
    RUNTIME_GAP = (
        "RUNTIME_GAP"
    )
    AUTHORITY_GAP = (
        "AUTHORITY_GAP"
    )
    EVIDENCE_GAP = (
        "EVIDENCE_GAP"
    )


class GapSeverity(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class GapConfidence(str, Enum):
    INSUFFICIENT = "INSUFFICIENT"
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"


class GapStatus(str, Enum):
    DETECTED = "DETECTED"


def _require_text(
    value: str,
    field: str,
) -> None:
    if (
        not isinstance(value, str)
        or not value.strip()
    ):
        raise ValueError(
            f"{field} must be a non-empty string"
        )


def _require_optional_ref(
    value: str | None,
    field: str,
) -> None:
    if value is None:
        return

    _require_text(
        value,
        field,
    )


def _validate_refs(
    values: tuple[str, ...],
    field: str,
) -> None:
    if not isinstance(
        values,
        tuple,
    ):
        raise TypeError(
            f"{field} must be tuple[str, ...]"
        )

    for value in values:
        _require_text(
            value,
            field,
        )

    if len(set(values)) != len(values):
        raise ValueError(
            f"{field} contains duplicate references"
        )


def _validate_reason_codes(
    values: tuple[str, ...],
) -> None:
    _validate_refs(
        values,
        "reason_codes",
    )

    if not values:
        raise ValueError(
            "reason_codes must not be empty"
        )


@dataclass(frozen=True)
class VerificationDecision:
    """Independent verification result.

    This is not execution status.
    This is not authority.
    """

    verification_id: str
    cycle_id: str
    subject_ref: str

    expected_ref: str | None
    actual_ref: str | None

    contract_refs: tuple[str, ...]
    evidence_refs: tuple[str, ...]

    status: VerificationStatus
    reason_codes: tuple[str, ...]

    verifier_identity_ref: str

    observed_at: str
    recorded_at: str

    schema_version: str = (
        VERIFICATION_SCHEMA_V1
    )

    def __post_init__(
        self,
    ) -> None:
        if (
            self.schema_version
            != VERIFICATION_SCHEMA_V1
        ):
            raise ValueError(
                "unsupported VerificationDecision schema"
            )

        for field, value in (
            (
                "verification_id",
                self.verification_id,
            ),
            (
                "cycle_id",
                self.cycle_id,
            ),
            (
                "subject_ref",
                self.subject_ref,
            ),
            (
                "verifier_identity_ref",
                self.verifier_identity_ref,
            ),
            (
                "observed_at",
                self.observed_at,
            ),
            (
                "recorded_at",
                self.recorded_at,
            ),
        ):
            _require_text(
                value,
                field,
            )

        _require_optional_ref(
            self.expected_ref,
            "expected_ref",
        )

        _require_optional_ref(
            self.actual_ref,
            "actual_ref",
        )

        _validate_refs(
            self.contract_refs,
            "contract_refs",
        )

        _validate_refs(
            self.evidence_refs,
            "evidence_refs",
        )

        _validate_reason_codes(
            self.reason_codes
        )

        if not isinstance(
            self.status,
            VerificationStatus,
        ):
            raise TypeError(
                "status must be VerificationStatus"
            )

        if self.status in {
            VerificationStatus.VERIFIED,
            VerificationStatus.FAILED,
        }:
            if self.expected_ref is None:
                raise ValueError(
                    f"{self.status.value} "
                    "requires expected_ref"
                )

            if self.actual_ref is None:
                raise ValueError(
                    f"{self.status.value} "
                    "requires actual_ref"
                )

            if not self.evidence_refs:
                raise ValueError(
                    f"{self.status.value} "
                    "requires explicit evidence_refs"
                )

    def as_dict(
        self,
    ) -> dict[str, Any]:
        data = asdict(
            self
        )

        data["status"] = (
            self.status.value
        )

        data["contract_refs"] = list(
            self.contract_refs
        )

        data["evidence_refs"] = list(
            self.evidence_refs
        )

        data["reason_codes"] = list(
            self.reason_codes
        )

        return data


@dataclass(frozen=True)
class ReconciliationInput:
    """Reference-only envelope for future reconciliation."""

    reconciliation_id: str
    cycle_id: str
    subject_ref: str

    verification_ref: str | None

    contract_refs: tuple[str, ...]
    current_state_refs: tuple[str, ...]
    performance_evidence_refs: tuple[
        str,
        ...,
    ]
    drift_refs: tuple[str, ...]
    learning_observation_refs: tuple[
        str,
        ...,
    ]
    evidence_refs: tuple[str, ...]

    created_at: str

    schema_version: str = (
        RECONCILIATION_INPUT_SCHEMA_V1
    )

    def __post_init__(
        self,
    ) -> None:
        if (
            self.schema_version
            != RECONCILIATION_INPUT_SCHEMA_V1
        ):
            raise ValueError(
                "unsupported ReconciliationInput schema"
            )

        for field, value in (
            (
                "reconciliation_id",
                self.reconciliation_id,
            ),
            (
                "cycle_id",
                self.cycle_id,
            ),
            (
                "subject_ref",
                self.subject_ref,
            ),
            (
                "created_at",
                self.created_at,
            ),
        ):
            _require_text(
                value,
                field,
            )

        _require_optional_ref(
            self.verification_ref,
            "verification_ref",
        )

        for field, values in (
            (
                "contract_refs",
                self.contract_refs,
            ),
            (
                "current_state_refs",
                self.current_state_refs,
            ),
            (
                "performance_evidence_refs",
                self.performance_evidence_refs,
            ),
            (
                "drift_refs",
                self.drift_refs,
            ),
            (
                "learning_observation_refs",
                self.learning_observation_refs,
            ),
            (
                "evidence_refs",
                self.evidence_refs,
            ),
        ):
            _validate_refs(
                values,
                field,
            )

        has_basis = any(
            (
                self.verification_ref,
                self.contract_refs,
                self.current_state_refs,
                self.performance_evidence_refs,
                self.drift_refs,
                self.learning_observation_refs,
                self.evidence_refs,
            )
        )

        if not has_basis:
            raise ValueError(
                "ReconciliationInput requires "
                "at least one referenced basis"
            )

    def as_dict(
        self,
    ) -> dict[str, Any]:
        data = asdict(
            self
        )

        for field in (
            "contract_refs",
            "current_state_refs",
            "performance_evidence_refs",
            "drift_refs",
            "learning_observation_refs",
            "evidence_refs",
        ):
            data[field] = list(
                data[field]
            )

        return data


@dataclass(frozen=True)
class GapRecord:
    """Detected discrepancy only.

    A GapRecord has no implementation,
    promotion or mutation authority.
    """

    gap_id: str
    reconciliation_id: str

    gap_type: GapType

    subject_ref: str
    evidence_refs: tuple[str, ...]

    reason_codes: tuple[str, ...]

    severity: GapSeverity
    confidence: GapConfidence
    status: GapStatus

    detected_at: str

    schema_version: str = (
        GAP_RECORD_SCHEMA_V1
    )

    def __post_init__(
        self,
    ) -> None:
        if (
            self.schema_version
            != GAP_RECORD_SCHEMA_V1
        ):
            raise ValueError(
                "unsupported GapRecord schema"
            )

        for field, value in (
            (
                "gap_id",
                self.gap_id,
            ),
            (
                "reconciliation_id",
                self.reconciliation_id,
            ),
            (
                "subject_ref",
                self.subject_ref,
            ),
            (
                "detected_at",
                self.detected_at,
            ),
        ):
            _require_text(
                value,
                field,
            )

        if not isinstance(
            self.gap_type,
            GapType,
        ):
            raise TypeError(
                "gap_type must be GapType"
            )

        if not isinstance(
            self.severity,
            GapSeverity,
        ):
            raise TypeError(
                "severity must be GapSeverity"
            )

        if not isinstance(
            self.confidence,
            GapConfidence,
        ):
            raise TypeError(
                "confidence must be GapConfidence"
            )

        if not isinstance(
            self.status,
            GapStatus,
        ):
            raise TypeError(
                "status must be GapStatus"
            )

        if (
            self.status
            is not GapStatus.DETECTED
        ):
            raise ValueError(
                "V1 GapRecord status must be DETECTED"
            )

        _validate_refs(
            self.evidence_refs,
            "evidence_refs",
        )

        _validate_reason_codes(
            self.reason_codes
        )

        if (
            self.gap_type
            is not GapType.EVIDENCE_GAP
            and not self.evidence_refs
        ):
            raise ValueError(
                "non-EVIDENCE_GAP requires evidence_refs"
            )

    def as_dict(
        self,
    ) -> dict[str, Any]:
        data = asdict(
            self
        )

        data["gap_type"] = (
            self.gap_type.value
        )

        data["severity"] = (
            self.severity.value
        )

        data["confidence"] = (
            self.confidence.value
        )

        data["status"] = (
            self.status.value
        )

        data["evidence_refs"] = list(
            self.evidence_refs
        )

        data["reason_codes"] = list(
            self.reason_codes
        )

        return data
