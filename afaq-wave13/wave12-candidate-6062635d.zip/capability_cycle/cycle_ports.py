"""Infrastructure ports for the Cycle runtime."""

from __future__ import annotations

from dataclasses import dataclass
from typing import (
    Any,
    Mapping,
    Protocol,
)

from .cycle_core import (
    CycleRecord,
)


@dataclass(frozen=True)
class EvidenceReceipt:
    store: str
    record_id: str
    event_id: str
    cycle_id: str
    event_type: str
    event_sequence: int

    def as_dict(
        self,
    ) -> dict[str, Any]:
        return {
            "store": self.store,
            "record_id": self.record_id,
            "event_id": self.event_id,
            "cycle_id": self.cycle_id,
            "event_type": self.event_type,
            "event_sequence": (
                self.event_sequence
            ),
        }


class EvidencePort(Protocol):
    def append_event(
        self,
        *,
        cycle_id: str,
        event_type: str,
        event_sequence: int,
        state: str,
        payload: (
            Mapping[str, Any] | None
        ) = None,
        actor: str = "cycle-runtime",
        environment: (
            str | None
        ) = None,
        parent_event_id: (
            str | None
        ) = None,
        causation_id: (
            str | None
        ) = None,
        correlation_id: (
            str | None
        ) = None,
    ) -> EvidenceReceipt:
        ...

    def verify_integrity(
        self,
    ) -> Mapping[str, Any]:
        ...

    def close(
        self,
    ) -> None:
        ...


class CycleStatePort(Protocol):
    def save(
        self,
        cycle: CycleRecord,
        *,
        expected_previous_version: (
            int | None
        ) = None,
    ) -> str:
        ...

    def load(
        self,
        cycle_id: str,
    ) -> Mapping[str, Any]:
        ...
