"""Append-only remediation lifecycle contracts for M4B.

M4B records lifecycle facts around the existing M4A RemediationCase contract.
The event history is authoritative; RemediationCase is a derived snapshot.

This module does not provide approval, authorization, execution, reverification,
ResolutionDecision, runtime/policy mutation, Genesis, training, promotion,
deployment, or rollback.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import Enum
from typing import Any, Iterable

from .remediation_contracts import (
    RemediationCase,
    RemediationCaseStatus,
    RemediationDisposition,
)


REMEDIATION_EVENT_SCHEMA_V1 = "AFAQ_REMEDIATION_EVENT_V1"


class RemediationEventType(str, Enum):
    CASE_OPENED = "CASE_OPENED"
    PROPOSAL_LINKED = "PROPOSAL_LINKED"
    CRITERION_LINKED = "CRITERION_LINKED"
    EVIDENCE_LINKED = "EVIDENCE_LINKED"
    CASE_CLOSED = "CASE_CLOSED"


class RemediationLifecycleError(ValueError):
    pass


def _require_text(value: str, field: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field} must be a non-empty string")


def _require_optional_text(value: str | None, field: str) -> None:
    if value is not None:
        _require_text(value, field)


def _validate_refs(
    values: tuple[str, ...],
    field: str,
    *,
    required: bool = False,
) -> None:
    if not isinstance(values, tuple):
        raise TypeError(f"{field} must be tuple[str, ...]")

    for value in values:
        _require_text(value, field)

    if len(set(values)) != len(values):
        raise ValueError(f"{field} contains duplicate references")

    if required and not values:
        raise ValueError(f"{field} must not be empty")


@dataclass(frozen=True)
class RemediationEvent:
    remediation_event_id: str
    remediation_case_id: str
    event_type: RemediationEventType
    occurred_at: str

    subject_ref: str | None = None
    source_gap_refs: tuple[str, ...] = ()

    proposal_ref: str | None = None
    resolution_criterion_ref: str | None = None
    evidence_ref: str | None = None

    disposition: RemediationDisposition = RemediationDisposition.NONE

    schema_version: str = REMEDIATION_EVENT_SCHEMA_V1

    def __post_init__(self) -> None:
        if self.schema_version != REMEDIATION_EVENT_SCHEMA_V1:
            raise ValueError("unsupported RemediationEvent schema")

        _require_text(self.remediation_event_id, "remediation_event_id")
        _require_text(self.remediation_case_id, "remediation_case_id")
        _require_text(self.occurred_at, "occurred_at")

        if not isinstance(self.event_type, RemediationEventType):
            raise TypeError("event_type must be RemediationEventType")

        if not isinstance(self.disposition, RemediationDisposition):
            raise TypeError("disposition must be RemediationDisposition")

        _require_optional_text(self.subject_ref, "subject_ref")
        _require_optional_text(self.proposal_ref, "proposal_ref")
        _require_optional_text(
            self.resolution_criterion_ref,
            "resolution_criterion_ref",
        )
        _require_optional_text(self.evidence_ref, "evidence_ref")
        _validate_refs(self.source_gap_refs, "source_gap_refs")

        if self.event_type is RemediationEventType.CASE_OPENED:
            if self.subject_ref is None:
                raise ValueError("CASE_OPENED requires subject_ref")
            _validate_refs(
                self.source_gap_refs,
                "source_gap_refs",
                required=True,
            )
            if any(
                value is not None
                for value in (
                    self.proposal_ref,
                    self.resolution_criterion_ref,
                    self.evidence_ref,
                )
            ):
                raise ValueError(
                    "CASE_OPENED cannot carry linked artifact refs"
                )
            if self.disposition is not RemediationDisposition.NONE:
                raise ValueError(
                    "CASE_OPENED must have disposition NONE"
                )
            return

        if self.subject_ref is not None or self.source_gap_refs:
            raise ValueError(
                f"{self.event_type.value} cannot redefine case identity"
            )

        if self.event_type is RemediationEventType.PROPOSAL_LINKED:
            if self.proposal_ref is None:
                raise ValueError("PROPOSAL_LINKED requires proposal_ref")
            if (
                self.resolution_criterion_ref is not None
                or self.evidence_ref is not None
            ):
                raise ValueError(
                    "PROPOSAL_LINKED cannot carry unrelated refs"
                )
            if self.disposition is not RemediationDisposition.NONE:
                raise ValueError(
                    "PROPOSAL_LINKED must have disposition NONE"
                )
            return

        if self.event_type is RemediationEventType.CRITERION_LINKED:
            if self.resolution_criterion_ref is None:
                raise ValueError(
                    "CRITERION_LINKED requires resolution_criterion_ref"
                )
            if self.proposal_ref is not None or self.evidence_ref is not None:
                raise ValueError(
                    "CRITERION_LINKED cannot carry unrelated refs"
                )
            if self.disposition is not RemediationDisposition.NONE:
                raise ValueError(
                    "CRITERION_LINKED must have disposition NONE"
                )
            return

        if self.event_type is RemediationEventType.EVIDENCE_LINKED:
            if self.evidence_ref is None:
                raise ValueError("EVIDENCE_LINKED requires evidence_ref")
            if (
                self.proposal_ref is not None
                or self.resolution_criterion_ref is not None
            ):
                raise ValueError(
                    "EVIDENCE_LINKED cannot carry unrelated refs"
                )
            if self.disposition is not RemediationDisposition.NONE:
                raise ValueError(
                    "EVIDENCE_LINKED must have disposition NONE"
                )
            return

        if self.event_type is RemediationEventType.CASE_CLOSED:
            if any(
                value is not None
                for value in (
                    self.proposal_ref,
                    self.resolution_criterion_ref,
                    self.evidence_ref,
                )
            ):
                raise ValueError(
                    "CASE_CLOSED cannot carry linked artifact refs"
                )
            if self.disposition is RemediationDisposition.NONE:
                raise ValueError(
                    "CASE_CLOSED requires non-NONE disposition"
                )
            return

        raise ValueError("unsupported RemediationEventType")

    def as_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["event_type"] = self.event_type.value
        data["disposition"] = self.disposition.value
        data["source_gap_refs"] = list(self.source_gap_refs)
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RemediationEvent":
        return cls(
            remediation_event_id=str(data["remediation_event_id"]),
            remediation_case_id=str(data["remediation_case_id"]),
            event_type=RemediationEventType(str(data["event_type"])),
            occurred_at=str(data["occurred_at"]),
            subject_ref=(
                None
                if data.get("subject_ref") is None
                else str(data["subject_ref"])
            ),
            source_gap_refs=tuple(
                str(value)
                for value in data.get("source_gap_refs", ())
            ),
            proposal_ref=(
                None
                if data.get("proposal_ref") is None
                else str(data["proposal_ref"])
            ),
            resolution_criterion_ref=(
                None
                if data.get("resolution_criterion_ref") is None
                else str(data["resolution_criterion_ref"])
            ),
            evidence_ref=(
                None
                if data.get("evidence_ref") is None
                else str(data["evidence_ref"])
            ),
            disposition=RemediationDisposition(
                str(data.get("disposition", "NONE"))
            ),
            schema_version=str(
                data.get(
                    "schema_version",
                    REMEDIATION_EVENT_SCHEMA_V1,
                )
            ),
        )


def derive_remediation_case(
    events: Iterable[RemediationEvent],
) -> RemediationCase:
    ordered = tuple(events)

    if not ordered:
        raise RemediationLifecycleError(
            "remediation lifecycle requires CASE_OPENED"
        )

    first = ordered[0]
    if first.event_type is not RemediationEventType.CASE_OPENED:
        raise RemediationLifecycleError(
            "CASE_OPENED must be the first event"
        )

    case_id = first.remediation_case_id
    subject_ref = first.subject_ref
    if subject_ref is None:
        raise RemediationLifecycleError(
            "CASE_OPENED missing subject_ref"
        )

    source_gap_refs = first.source_gap_refs
    proposal_refs: list[str] = []
    criterion_refs: list[str] = []
    evidence_refs: list[str] = []
    seen_event_ids: set[str] = set()

    status = RemediationCaseStatus.OPEN
    disposition = RemediationDisposition.NONE
    closed_at: str | None = None

    for index, event in enumerate(ordered):
        if event.remediation_event_id in seen_event_ids:
            raise RemediationLifecycleError(
                "duplicate remediation_event_id in lifecycle"
            )
        seen_event_ids.add(event.remediation_event_id)

        if event.remediation_case_id != case_id:
            raise RemediationLifecycleError(
                "mixed remediation_case_id values"
            )

        if index > 0 and event.event_type is RemediationEventType.CASE_OPENED:
            raise RemediationLifecycleError(
                "CASE_OPENED may occur exactly once"
            )

        if status is RemediationCaseStatus.CLOSED:
            raise RemediationLifecycleError(
                "no events are allowed after CASE_CLOSED"
            )

        if event.event_type is RemediationEventType.CASE_OPENED:
            continue

        if event.event_type is RemediationEventType.PROPOSAL_LINKED:
            assert event.proposal_ref is not None
            if event.proposal_ref in proposal_refs:
                raise RemediationLifecycleError(
                    "duplicate proposal_ref in lifecycle"
                )
            proposal_refs.append(event.proposal_ref)
            continue

        if event.event_type is RemediationEventType.CRITERION_LINKED:
            assert event.resolution_criterion_ref is not None
            if event.resolution_criterion_ref in criterion_refs:
                raise RemediationLifecycleError(
                    "duplicate resolution_criterion_ref in lifecycle"
                )
            criterion_refs.append(event.resolution_criterion_ref)
            continue

        if event.event_type is RemediationEventType.EVIDENCE_LINKED:
            assert event.evidence_ref is not None
            if event.evidence_ref in evidence_refs:
                raise RemediationLifecycleError(
                    "duplicate evidence_ref in lifecycle"
                )
            evidence_refs.append(event.evidence_ref)
            continue

        if event.event_type is RemediationEventType.CASE_CLOSED:
            if event.disposition is RemediationDisposition.REMEDIATED:
                if not criterion_refs:
                    raise RemediationLifecycleError(
                        "REMEDIATED closure requires linked criterion"
                    )
                if not evidence_refs:
                    raise RemediationLifecycleError(
                        "REMEDIATED closure requires linked evidence"
                    )

            status = RemediationCaseStatus.CLOSED
            disposition = event.disposition
            closed_at = event.occurred_at
            continue

        raise RemediationLifecycleError(
            f"unsupported event type: {event.event_type.value}"
        )

    return RemediationCase(
        remediation_case_id=case_id,
        subject_ref=subject_ref,
        source_gap_refs=source_gap_refs,
        status=status,
        disposition=disposition,
        proposal_refs=tuple(proposal_refs),
        resolution_criterion_refs=tuple(criterion_refs),
        evidence_refs=tuple(evidence_refs),
        opened_at=first.occurred_at,
        closed_at=closed_at,
    )
