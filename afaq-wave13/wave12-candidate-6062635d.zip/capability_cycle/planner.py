"""Derive required capabilities, resolve existing ones, compose a plan.

Uses CanonicalReferenceResolver as the current architecture source.
Does not invent capabilities, acquire genesis, or consult historical GOV-DECs.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from afaq_intelligence_core.package_intelligence.canonical_resolver import (
    CanonicalReferenceResolver,
)
from afaq_intelligence_core.package_intelligence.models import UNKNOWN

from current_authority.resolver import AuthorityRequest, resolve

from .handlers import has_implementation


@dataclass(frozen=True)
class Requirement:
    text: str = ""
    explicit_capability_ids: tuple[str, ...] = ()
    historical_records: tuple[Mapping[str, Any], ...] = ()
    request_genesis: bool = False


@dataclass(frozen=True)
class CapabilityPlan:
    status: str
    reason: str
    required_ids: tuple[str, ...]
    resolved: tuple[dict[str, Any], ...]
    missing: tuple[str, ...]
    genesis_attempted: bool = False
    historical_records_consulted: int = 0
    details: dict[str, Any] = field(default_factory=dict)


def _capability_catalog(resolver: CanonicalReferenceResolver) -> dict[str, dict[str, Any]]:
    raw = resolver._registries.get("capabilities", {})
    return {str(k): v for k, v in raw.items() if isinstance(v, dict)}


def derive_required_capabilities(
    requirement: Requirement,
    catalog: Mapping[str, Mapping[str, Any]],
) -> tuple[str, ...]:
    if requirement.explicit_capability_ids:
        return tuple(dict.fromkeys(requirement.explicit_capability_ids))

    text = (requirement.text or "").strip().lower()
    if not text:
        return ()

    matched: list[str] = []
    for cap_id, record in catalog.items():
        tokens = {
            cap_id.lower(),
            str(record.get("name", "")).lower(),
            str(record.get("description", "")).lower(),
        }
        if any(token and token in text for token in tokens if token == cap_id.lower()):
            matched.append(cap_id)
            continue
        name = str(record.get("name", "")).lower()
        if name and name in text:
            matched.append(cap_id)
            continue
        keywords = [part for part in name.replace("/", " ").split() if len(part) > 3]
        if keywords and all(part in text for part in keywords):
            matched.append(cap_id)
    return tuple(dict.fromkeys(matched))


def plan_capabilities(
    requirement: Requirement,
    *,
    resolver: CanonicalReferenceResolver | None = None,
) -> CapabilityPlan:
    _ignored_history = requirement.historical_records
    del _ignored_history

    if requirement.request_genesis:
        authority = resolve(AuthorityRequest(action="self_train"))
        return CapabilityPlan(
            status="BLOCKED",
            reason="DESIGN_ONLY_IS_NOT_OPERATIONAL",
            required_ids=(),
            resolved=(),
            missing=(),
            genesis_attempted=True,
            historical_records_consulted=0,
            details={"authority": authority.reason},
        )

    authority = resolve(
        AuthorityRequest(
            action="capability_compose",
            capability_implemented_and_verified=True,
        )
    )
    if authority.outcome != "ALLOW":
        return CapabilityPlan(
            status="BLOCKED",
            reason=authority.reason,
            required_ids=(),
            resolved=(),
            missing=(),
            historical_records_consulted=0,
        )

    resolver = resolver or CanonicalReferenceResolver()
    catalog = _capability_catalog(resolver)
    required = derive_required_capabilities(requirement, catalog)
    if not required:
        return CapabilityPlan(
            status="BLOCKED",
            reason="NEEDS_MORE_EVIDENCE",
            required_ids=(),
            resolved=(),
            missing=(),
            historical_records_consulted=0,
        )

    resolved: list[dict[str, Any]] = []
    missing: list[str] = []
    for cap_id in required:
        record = resolver.resolve_capability(cap_id)
        if record == UNKNOWN or not isinstance(record, dict):
            if has_implementation(cap_id):
                resolved.append(
                    {
                        "capability_id": cap_id,
                        "name": cap_id,
                        "provider_candidates": [],
                        "authority_boundary": "activated_implementation",
                        "status": "RESOLVED_EXISTING",
                    }
                )
                continue
            missing.append(cap_id)
            continue
        resolved.append(
            {
                "capability_id": cap_id,
                "name": record.get("name"),
                "provider_candidates": record.get("provider_candidates", []),
                "authority_boundary": record.get("authority_boundary"),
                "status": "RESOLVED_EXISTING",
            }
        )

    if missing:
        return CapabilityPlan(
            status="BLOCKED",
            reason="EXISTING_CAPABILITY_MISSING",
            required_ids=required,
            resolved=tuple(resolved),
            missing=tuple(missing),
            historical_records_consulted=0,
            details={"note": "missing capabilities are not acquired by genesis"},
        )

    return CapabilityPlan(
        status="COMPOSED",
        reason="RESOLVED_EXISTING_COMPOSED",
        required_ids=required,
        resolved=tuple(resolved),
        missing=(),
        historical_records_consulted=0,
        details={"execution_authorized": False, "genesis": False},
    )
