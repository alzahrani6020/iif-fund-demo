"""Translate closed Cycle outcomes into inert performance evidence.

This module does NOT:
- learn
- train
- generate
- promote
- mutate policy
- mutate authority
- infer mission verification from execution success

Execution success is not mission verification.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from .performance_store import (
    PerformanceEvidence,
    PerformanceStore,
)


CLOSED_STATES = frozenset(
    {
        "CLOSED_SUCCESS",
        "CLOSED_FAILED",
        "CLOSED_UNKNOWN",
    }
)

VERIFICATION_STATUSES = frozenset(
    {
        "VERIFIED",
        "FAILED",
        "INSUFFICIENT_EVIDENCE",
    }
)


class CycleLearningBridgeError(RuntimeError):
    pass


@dataclass(frozen=True)
class MissionVerification:
    status: str
    final_outcome: str
    reason: str | None = None
    failure_class: str | None = None

    def __post_init__(self) -> None:
        if self.status not in VERIFICATION_STATUSES:
            raise ValueError(
                f"unsupported verification status: {self.status}"
            )

        if (
            self.final_outcome == "SUCCESS"
            and self.status != "VERIFIED"
        ):
            raise ValueError(
                "SUCCESS requires VERIFIED mission evidence"
            )


def _event_ref(
    value: Mapping[str, Any],
) -> str | None:
    store = str(value.get("store") or "").strip()
    record_id = str(
        value.get("record_id") or ""
    ).strip()
    event_id = str(
        value.get("event_id") or ""
    ).strip()

    if not record_id and not event_id:
        return None

    return ":".join(
        part
        for part in (
            store,
            record_id,
            event_id,
        )
        if part
    )


def cycle_to_performance_record(
    cycle_result: Mapping[str, Any],
    *,
    capability_id: str,
    capability_version: str | None = None,
    verification: MissionVerification | None = None,
    mission_id: str | None = None,
    plan_id: str | None = None,
) -> dict[str, Any]:
    """Build a PerformanceStore-compatible record.

    Fail-closed rule:
    without explicit mission verification, a successful execution
    is INTERMEDIATE evidence only.
    """

    capability = str(
        capability_id
    ).strip()

    if not capability:
        raise CycleLearningBridgeError(
            "CAPABILITY_ID_REQUIRED"
        )

    cycle = dict(
        cycle_result.get("cycle")
        or {}
    )

    cycle_id = str(
        cycle.get("cycle_id")
        or ""
    ).strip()

    if not cycle_id:
        raise CycleLearningBridgeError(
            "CYCLE_ID_REQUIRED"
        )

    state = str(
        cycle.get("state")
        or ""
    )

    if state not in CLOSED_STATES:
        raise CycleLearningBridgeError(
            f"CYCLE_NOT_CLOSED:{state}"
        )

    actual = dict(
        cycle.get("actual_outcome")
        or {}
    )

    raw_result = dict(
        cycle_result.get("result")
        or {}
    )

    evidence_refs = tuple(
        ref
        for ref in (
            _event_ref(item)
            for item in (
                cycle.get("evidence_refs")
                or []
            )
            if isinstance(item, Mapping)
        )
        if ref
    )

    duration = actual.get(
        "latency_ms",
        raw_result.get(
            "elapsed_ms",
            0.0,
        ),
    )

    execution_ok = bool(
        actual.get(
            "ok",
            cycle_result.get(
                "ok",
                False,
            ),
        )
    )

    executed = bool(
        actual.get(
            "executed",
            raw_result.get(
                "executed",
                execution_ok,
            ),
        )
    )

    if verification is None:
        record_kind = (
            "FAILED"
            if state == "CLOSED_FAILED"
            else "INTERMEDIATE"
        )

        verification_status = (
            None
        )

        verification_reason = (
            "cycle execution evidence is not "
            "independent mission verification"
        )

        failure_class = (
            "CYCLE_EXECUTION_FAILED"
            if state == "CLOSED_FAILED"
            else None
        )

        final_outcome = None

    else:
        record_kind = "FINAL"

        verification_status = (
            verification.status
        )

        verification_reason = (
            verification.reason
        )

        failure_class = (
            verification.failure_class
        )

        final_outcome = (
            verification.final_outcome
        )

    return {
        "correlation_id": cycle_id,
        "record_kind": record_kind,
        "mission_ids": [
            mission_id or cycle_id
        ],
        "plan_ids": (
            [plan_id]
            if plan_id
            else []
        ),
        "original_plan_ids": [],
        "capability_id": capability,
        "capability_version": (
            capability_version
        ),
        "attempt": 1,
        "replan_attempt": 0,
        "execution_outcome": (
            "SUCCESS"
            if execution_ok
            else "FAILURE"
        ),
        "mission_verification_status": (
            verification_status
        ),
        "mission_verification_reason": (
            verification_reason
        ),
        "failure_class": failure_class,
        "duration_ms": float(
            duration or 0.0
        ),
        "duration_scope": (
            "mission_cycle"
        ),
        "sandbox_status": None,
        "certification_status": None,
        "authority_refs": [],
        "evidence_refs": list(
            evidence_refs
        ),
        "final_outcome": (
            final_outcome
        ),
        # Informational only; PerformanceStore itself
        # forces these false.
        "learning_activated": False,
        "training_activated": False,
        "auto_promoted": False,
        "details": {
            "cycle_state": state,
            "cycle_execution_ok": (
                execution_ok
            ),
            "cycle_executed": executed,
            "bridge_semantics": (
                "EXECUTION_IS_NOT_VERIFICATION"
            ),
        },
    }


def persist_cycle_performance(
    store: PerformanceStore,
    cycle_result: Mapping[str, Any],
    *,
    capability_id: str,
    capability_version: str | None = None,
    verification: MissionVerification | None = None,
    mission_id: str | None = None,
    plan_id: str | None = None,
) -> PerformanceEvidence:
    record = cycle_to_performance_record(
        cycle_result,
        capability_id=capability_id,
        capability_version=(
            capability_version
        ),
        verification=verification,
        mission_id=mission_id,
        plan_id=plan_id,
    )

    return store.append(record)
