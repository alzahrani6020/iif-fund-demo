"""Resolve stable capability identities from the authoritative registry.

This module is a compatibility facade. It is read-only: discovering a
capability never creates an ID, mutates declarations, or grants execution.
"""

from __future__ import annotations

from typing import Any

from afaq_registry.loader import load_capability_identities, load_registry

_REGISTERED = False
_NAME_TO_ID: dict[str, str] = {}


def collect_capability_names(merged: dict[str, Any] | None = None) -> list[str]:
    data = merged if merged is not None else load_registry()
    names: set[str] = set()
    for eng in data.get("engines") or []:
        for capability in eng.get("required_capabilities") or []:
            if isinstance(capability, str) and capability.strip():
                names.add(capability.strip())
    for package in data.get("capability_packages") or []:
        for capability in package.get("capabilities") or []:
            if isinstance(capability, str) and capability.strip():
                names.add(capability.strip())
    return sorted(names)


def ensure_merged_handlers_registered(*, write_map: bool = False) -> dict[str, str]:
    """Load stable identities and fail closed on unregistered descriptors.

    write_map is retained only for compatibility with older callers and
    intentionally has no write effect. Identity creation is a governed
    registry mutation, never an import-time side effect.
    """
    del write_map
    global _REGISTERED, _NAME_TO_ID

    identities = load_capability_identities()
    mapping = dict(identities.get("name_to_id") or {})
    required = set(collect_capability_names())
    missing = sorted(required - set(mapping))
    if missing:
        raise RuntimeError(
            "UNREGISTERED_CAPABILITY_IDENTITIES: " + ", ".join(missing[:20])
        )

    _NAME_TO_ID = mapping
    _REGISTERED = True
    return dict(mapping)


def capability_id(name: str) -> str:
    if not _REGISTERED:
        ensure_merged_handlers_registered()
    try:
        return _NAME_TO_ID[name]
    except KeyError as exc:
        raise KeyError(f"unregistered capability identity: {name}") from exc


def name_to_id_map() -> dict[str, str]:
    if not _REGISTERED:
        ensure_merged_handlers_registered()
    return dict(_NAME_TO_ID)
