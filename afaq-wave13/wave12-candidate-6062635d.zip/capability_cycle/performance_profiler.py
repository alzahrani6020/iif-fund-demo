"""Model/capability performance profiling with explicit metric provenance.

The profiler never invents opaque model facts. Parameter/FLOP values are either
measured/introspected, provider-declared, user-declared, explicitly estimated,
or UNKNOWN with provenance retained.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
try:
    import resource
except ImportError:  # pragma: no cover - Windows fallback
    resource = None
import statistics
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping


MetricValue = int | float | str | bool | None


@dataclass(frozen=True)
class MeasuredMetric:
    value: MetricValue
    unit: str | None
    method: str
    source: str
    confidence: str
    measured_at: str | None = None
    limitations: tuple[str, ...] = ()

    def as_dict(self) -> dict[str, Any]:
        return {
            "value": self.value,
            "unit": self.unit,
            "method": self.method,
            "source": self.source,
            "confidence": self.confidence,
            "measured_at": self.measured_at,
            "limitations": list(self.limitations),
        }


@dataclass(frozen=True)
class ModelPerformanceProfile:
    subject_id: str
    subject_type: str
    version: str | None
    artifact_hash: str | None
    architecture: str | None
    metrics: dict[str, MeasuredMetric]
    evidence_refs: tuple[str, ...] = ()
    limitations: tuple[str, ...] = ()

    def as_dict(self) -> dict[str, Any]:
        return {
            "subject_id": self.subject_id,
            "subject_type": self.subject_type,
            "version": self.version,
            "artifact_hash": self.artifact_hash,
            "architecture": self.architecture,
            "metrics": {key: metric.as_dict() for key, metric in sorted(self.metrics.items())},
            "evidence_refs": list(self.evidence_refs),
            "limitations": list(self.limitations),
        }

    @property
    def profile_hash(self) -> str:
        raw = json.dumps(self.as_dict(), sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _now() -> str:
    from datetime import datetime, timezone

    return datetime.now(timezone.utc).isoformat()


def _metric(
    value: MetricValue,
    *,
    unit: str | None,
    method: str,
    source: str,
    confidence: str,
    limitations: tuple[str, ...] = (),
) -> MeasuredMetric:
    return MeasuredMetric(
        value=value,
        unit=unit,
        method=method,
        source=source,
        confidence=confidence,
        measured_at=_now(),
        limitations=limitations,
    )


def _unknown(name: str, source: str = "UNAVAILABLE") -> MeasuredMetric:
    return _metric(
        None,
        unit=None,
        method="UNKNOWN",
        source=source,
        confidence="UNKNOWN",
        limitations=(f"{name.upper()}_NOT_OBSERVED_OR_DECLARED",),
    )


def _percentile(values: list[float], percentile: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    if len(ordered) == 1:
        return round(ordered[0], 6)
    position = (len(ordered) - 1) * percentile
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return round(ordered[lower], 6)
    fraction = position - lower
    return round(ordered[lower] + (ordered[upper] - ordered[lower]) * fraction, 6)


def _precision_bytes(precision: str | None) -> float | None:
    if not precision:
        return None
    normalized = precision.lower().replace("torch.", "").strip()
    mapping = {
        "float64": 8.0,
        "fp64": 8.0,
        "float32": 4.0,
        "fp32": 4.0,
        "float16": 2.0,
        "fp16": 2.0,
        "bfloat16": 2.0,
        "bf16": 2.0,
        "int8": 1.0,
        "uint8": 1.0,
        "int4": 0.5,
        "fp8": 1.0,
    }
    return mapping.get(normalized)


def profile_declared_model(
    *,
    subject_id: str,
    metadata: Mapping[str, Any],
    source: str,
    source_confidence: str = "DECLARED",
) -> ModelPerformanceProfile:
    """Build a truthful profile from provider/model metadata without guessing."""
    metrics: dict[str, MeasuredMetric] = {}
    mapping = {
        "total_parameters": ("parameters", "count"),
        "trainable_parameters": ("parameters", "count"),
        "active_parameters": ("parameters", "count"),
        "context_length": ("tokens", "tokens"),
        "flops_per_token": ("FLOP/token", "FLOP/token"),
        "model_size_bytes": ("bytes", "bytes"),
        "peak_ram_bytes": ("bytes", "bytes"),
        "peak_vram_bytes": ("bytes", "bytes"),
        "tokens_per_second": ("tokens/s", "tokens/s"),
        "time_to_first_token_ms": ("ms", "ms"),
        "time_to_final_ms": ("ms", "ms"),
        "cost_per_million_input_tokens": ("currency/1M tokens", "currency/1M tokens"),
        "cost_per_million_output_tokens": ("currency/1M tokens", "currency/1M tokens"),
    }
    for key, (unit, _) in mapping.items():
        if metadata.get(key) is None:
            metrics[key] = _unknown(key, source)
        else:
            metrics[key] = _metric(
                metadata.get(key),
                unit=unit,
                method="DECLARED_METADATA",
                source=source,
                confidence=source_confidence,
            )

    precision = str(metadata.get("precision") or "") or None
    metrics["precision"] = (
        _metric(
            precision,
            unit=None,
            method="DECLARED_METADATA",
            source=source,
            confidence=source_confidence,
        )
        if precision
        else _unknown("precision", source)
    )

    total = metadata.get("total_parameters")
    if metadata.get("model_size_bytes") is None and isinstance(total, (int, float)):
        bytes_per = _precision_bytes(precision)
        if bytes_per is not None:
            estimated = int(float(total) * bytes_per)
            metrics["estimated_weight_bytes"] = _metric(
                estimated,
                unit="bytes",
                method="PARAMETER_COUNT_X_PRECISION",
                source=f"{source}:derived",
                confidence="ESTIMATED",
                limitations=("WEIGHTS_ONLY_EXCLUDES_RUNTIME_STATE_AND_KV_CACHE",),
            )
        else:
            metrics["estimated_weight_bytes"] = _unknown("estimated_weight_bytes", source)
    else:
        metrics["estimated_weight_bytes"] = _unknown("estimated_weight_bytes", source)

    return ModelPerformanceProfile(
        subject_id=subject_id,
        subject_type=str(metadata.get("subject_type") or "model"),
        version=str(metadata["version"]) if metadata.get("version") is not None else None,
        artifact_hash=str(metadata["artifact_hash"]) if metadata.get("artifact_hash") else None,
        architecture=str(metadata["architecture"]) if metadata.get("architecture") else None,
        metrics=metrics,
        evidence_refs=tuple(str(x) for x in (metadata.get("evidence_refs") or ())),
        limitations=tuple(str(x) for x in (metadata.get("limitations") or ())),
    )


def profile_local_artifact(
    *,
    subject_id: str,
    paths: Iterable[str | os.PathLike[str]],
    version: str | None = None,
    architecture: str | None = None,
) -> ModelPerformanceProfile:
    total_bytes = 0
    file_count = 0
    hasher = hashlib.sha256()
    missing: list[str] = []
    normalized_paths: list[str] = []

    for raw in paths:
        path = Path(raw).expanduser().resolve()
        normalized_paths.append(str(path))
        if not path.exists() or not path.is_file():
            missing.append(str(path))
            continue
        data = path.read_bytes()
        total_bytes += len(data)
        file_count += 1
        hasher.update(str(path.name).encode("utf-8"))
        hasher.update(data)

    metrics = {
        "model_size_bytes": _metric(
            total_bytes,
            unit="bytes",
            method="LOCAL_FILE_BYTES",
            source="local_artifact",
            confidence="MEASURED",
            limitations=tuple(f"MISSING:{item}" for item in missing),
        ),
        "artifact_file_count": _metric(
            file_count,
            unit="files",
            method="LOCAL_FILE_COUNT",
            source="local_artifact",
            confidence="MEASURED",
        ),
        "total_parameters": _unknown("total_parameters", "local_artifact"),
        "trainable_parameters": _unknown("trainable_parameters", "local_artifact"),
        "active_parameters": _unknown("active_parameters", "local_artifact"),
        "peak_ram_bytes": _unknown("peak_ram_bytes", "local_artifact"),
        "peak_vram_bytes": _unknown("peak_vram_bytes", "local_artifact"),
        "flops_per_token": _unknown("flops_per_token", "local_artifact"),
    }
    return ModelPerformanceProfile(
        subject_id=subject_id,
        subject_type="local_artifact",
        version=version,
        artifact_hash=hasher.hexdigest() if file_count else None,
        architecture=architecture,
        metrics=metrics,
        evidence_refs=tuple(f"file:{item}" for item in normalized_paths if item not in missing),
        limitations=tuple(f"MISSING_ARTIFACT:{item}" for item in missing),
    )


def profile_model_object(
    model: Any,
    *,
    subject_id: str,
    version: str | None = None,
    architecture: str | None = None,
) -> ModelPerformanceProfile:
    """Introspect framework-like model objects through a minimal parameters() contract."""
    if not hasattr(model, "parameters") or not callable(model.parameters):
        raise TypeError("model object must expose callable parameters()")

    total = 0
    trainable = 0
    storage_bytes = 0
    dtypes: set[str] = set()
    parameter_objects = 0

    for param in model.parameters():
        parameter_objects += 1
        if hasattr(param, "numel") and callable(param.numel):
            count = int(param.numel())
        else:
            try:
                count = len(param)
            except TypeError as exc:
                raise TypeError("parameter object does not expose numel() or len()") from exc
        total += count
        if bool(getattr(param, "requires_grad", False)):
            trainable += count

        element_size = None
        if hasattr(param, "element_size") and callable(param.element_size):
            try:
                element_size = int(param.element_size())
            except (TypeError, ValueError):
                element_size = None
        dtype = getattr(param, "dtype", None)
        if dtype is not None:
            dtypes.add(str(dtype))
        if element_size is not None:
            storage_bytes += count * element_size

    metrics = {
        "total_parameters": _metric(
            total,
            unit="parameters",
            method="MODEL_PARAMETERS_NUMEL",
            source="runtime_model_object",
            confidence="MEASURED",
        ),
        "trainable_parameters": _metric(
            trainable,
            unit="parameters",
            method="REQUIRES_GRAD_NUMEL",
            source="runtime_model_object",
            confidence="MEASURED",
        ),
        "parameter_storage_bytes": _metric(
            storage_bytes,
            unit="bytes",
            method="NUMEL_X_ELEMENT_SIZE",
            source="runtime_model_object",
            confidence="MEASURED" if parameter_objects else "UNKNOWN",
        ),
        "parameter_tensor_count": _metric(
            parameter_objects,
            unit="tensors",
            method="PARAMETERS_ITERATION",
            source="runtime_model_object",
            confidence="MEASURED",
        ),
        "precision": _metric(
            ",".join(sorted(dtypes)) if dtypes else None,
            unit=None,
            method="PARAMETER_DTYPE_INTROSPECTION",
            source="runtime_model_object",
            confidence="MEASURED" if dtypes else "UNKNOWN",
        ),
        "active_parameters": _unknown("active_parameters", "runtime_model_object"),
        "peak_ram_bytes": _unknown("peak_ram_bytes", "runtime_model_object"),
        "peak_vram_bytes": _unknown("peak_vram_bytes", "runtime_model_object"),
        "flops_per_token": _unknown("flops_per_token", "runtime_model_object"),
    }
    return ModelPerformanceProfile(
        subject_id=subject_id,
        subject_type="runtime_model",
        version=version,
        artifact_hash=None,
        architecture=architecture or type(model).__name__,
        metrics=metrics,
        limitations=("ACTIVE_PARAMETERS_REQUIRE_ROUTING_OR_ARCHITECTURE_SPECIFIC_INSTRUMENTATION",),
    )


@dataclass(frozen=True)
class RuntimeSample:
    case_id: str
    ok: bool
    elapsed_ms: float
    cpu_ms: float
    peak_rss_bytes: int | None
    peak_vram_bytes: int | None
    input_tokens: int | None
    output_tokens: int | None
    time_to_first_token_ms: float | None
    observed_cost: float | None
    output_hash: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "case_id": self.case_id,
            "ok": self.ok,
            "elapsed_ms": self.elapsed_ms,
            "cpu_ms": self.cpu_ms,
            "peak_rss_bytes": self.peak_rss_bytes,
            "peak_vram_bytes": self.peak_vram_bytes,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "time_to_first_token_ms": self.time_to_first_token_ms,
            "observed_cost": self.observed_cost,
            "output_hash": self.output_hash,
        }


@dataclass(frozen=True)
class RuntimeBenchmark:
    subject_id: str
    samples: tuple[RuntimeSample, ...]
    metrics: dict[str, MeasuredMetric]
    evidence_refs: tuple[str, ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "subject_id": self.subject_id,
            "samples": [sample.as_dict() for sample in self.samples],
            "metrics": {key: value.as_dict() for key, value in sorted(self.metrics.items())},
            "evidence_refs": list(self.evidence_refs),
        }

    @property
    def benchmark_hash(self) -> str:
        raw = json.dumps(self.as_dict(), sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()


Executor = Callable[[Mapping[str, Any]], Mapping[str, Any]]


def benchmark_executor(
    *,
    subject_id: str,
    executor: Executor,
    cases: tuple[Mapping[str, Any], ...],
    evidence_refs: tuple[str, ...] = (),
) -> RuntimeBenchmark:
    if not cases:
        raise ValueError("benchmark requires at least one case")

    samples: list[RuntimeSample] = []
    for index, case in enumerate(cases):
        case_id = str(case.get("case_id") or f"case-{index + 1}")
        payload = dict(case.get("input") if isinstance(case.get("input"), Mapping) else case)
        payload.pop("case_id", None)

        wall_start = time.perf_counter()
        cpu_start = time.process_time()
        if resource is not None:
            before_rss_raw = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        else:
            before_rss_raw = None

        torch_mod = None
        gpu_available = False
        try:
            import torch as torch_mod  # type: ignore
            gpu_available = bool(torch_mod.cuda.is_available())
            if gpu_available:
                torch_mod.cuda.reset_peak_memory_stats()
                torch_mod.cuda.synchronize()
        except Exception:  # noqa: BLE001
            torch_mod = None
            gpu_available = False

        try:
            output = dict(executor(payload))
            ok = bool(output.get("ok", True))
        except Exception as exc:  # noqa: BLE001
            output = {"ok": False, "error_class": type(exc).__name__}
            ok = False

        if gpu_available and torch_mod is not None:
            try:
                torch_mod.cuda.synchronize()
                peak_vram_bytes = int(torch_mod.cuda.max_memory_allocated())
            except Exception:  # noqa: BLE001
                peak_vram_bytes = None
        else:
            peak_vram_bytes = None

        elapsed_ms = (time.perf_counter() - wall_start) * 1000
        cpu_ms = (time.process_time() - cpu_start) * 1000

        peak_rss_bytes = None
        if resource is not None:
            after_rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            # Linux reports KiB; macOS reports bytes. Preserve platform limitation.
            if os.name == "posix" and "darwin" not in os.sys.platform.lower():
                peak_rss_bytes = int(after_rss * 1024)
            else:
                peak_rss_bytes = int(after_rss)

        usage = output.get("usage") if isinstance(output.get("usage"), Mapping) else {}
        def usage_int(*keys: str) -> int | None:
            for key in keys:
                value = usage.get(key) if isinstance(usage, Mapping) else None
                if value is None:
                    value = output.get(key)
                try:
                    return int(value) if value is not None else None
                except (TypeError, ValueError):
                    continue
            return None

        def usage_float(*keys: str) -> float | None:
            for key in keys:
                value = usage.get(key) if isinstance(usage, Mapping) else None
                if value is None:
                    value = output.get(key)
                try:
                    return float(value) if value is not None else None
                except (TypeError, ValueError):
                    continue
            return None

        input_tokens = usage_int("input_tokens", "prompt_tokens")
        output_tokens = usage_int("output_tokens", "completion_tokens")
        ttft_ms = usage_float("time_to_first_token_ms", "ttft_ms")
        observed_cost = usage_float("cost", "cost_usd", "observed_cost")

        raw = json.dumps(output, sort_keys=True, default=str, separators=(",", ":"))
        output_hash = hashlib.sha256(raw.encode("utf-8")).hexdigest()
        samples.append(
            RuntimeSample(
                case_id=case_id,
                ok=ok,
                elapsed_ms=round(elapsed_ms, 6),
                cpu_ms=round(cpu_ms, 6),
                peak_rss_bytes=peak_rss_bytes,
                peak_vram_bytes=peak_vram_bytes,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                time_to_first_token_ms=ttft_ms,
                observed_cost=observed_cost,
                output_hash=output_hash,
            )
        )

    latencies = [sample.elapsed_ms for sample in samples]
    cpu_times = [sample.cpu_ms for sample in samples]
    success_count = sum(sample.ok for sample in samples)
    total_ms = sum(latencies)
    throughput = len(samples) / (total_ms / 1000) if total_ms > 0 else None
    metrics = {
        "sample_count": _metric(
            len(samples), unit="cases", method="BENCHMARK_CASE_COUNT",
            source="runtime_benchmark", confidence="MEASURED"
        ),
        "success_rate": _metric(
            success_count / len(samples), unit="ratio", method="SUCCESS_CASES_OVER_TOTAL",
            source="runtime_benchmark", confidence="MEASURED"
        ),
        "latency_p50_ms": _metric(
            _percentile(latencies, 0.50), unit="ms", method="LINEAR_INTERPOLATED_PERCENTILE",
            source="runtime_benchmark", confidence="MEASURED"
        ),
        "latency_p95_ms": _metric(
            _percentile(latencies, 0.95), unit="ms", method="LINEAR_INTERPOLATED_PERCENTILE",
            source="runtime_benchmark", confidence="MEASURED"
        ),
        "latency_p99_ms": _metric(
            _percentile(latencies, 0.99), unit="ms", method="LINEAR_INTERPOLATED_PERCENTILE",
            source="runtime_benchmark", confidence="MEASURED"
        ),
        "latency_mean_ms": _metric(
            statistics.fmean(latencies), unit="ms", method="ARITHMETIC_MEAN",
            source="runtime_benchmark", confidence="MEASURED"
        ),
        "cpu_mean_ms": _metric(
            statistics.fmean(cpu_times), unit="ms", method="PROCESS_TIME_MEAN",
            source="runtime_benchmark", confidence="MEASURED"
        ),
        "throughput_cases_per_second": _metric(
            throughput, unit="cases/s", method="CASE_COUNT_OVER_TOTAL_WALL_TIME",
            source="runtime_benchmark", confidence="MEASURED"
        ),
        "peak_rss_bytes": _metric(
            max(
                (sample.peak_rss_bytes for sample in samples if sample.peak_rss_bytes is not None),
                default=None,
            ),
            unit="bytes", method="RESOURCE_RUSAGE_MAXRSS",
            source="runtime_benchmark",
            confidence=(
                "MEASURED"
                if any(sample.peak_rss_bytes is not None for sample in samples)
                else "UNKNOWN"
            ),
            limitations=("PROCESS_LEVEL_PEAK_NOT_PER_CASE_DELTA",)
        ),
        "peak_vram_bytes": _metric(
            max(
                (sample.peak_vram_bytes for sample in samples if sample.peak_vram_bytes is not None),
                default=None,
            ),
            unit="bytes", method="TORCH_CUDA_MAX_MEMORY_ALLOCATED",
            source="runtime_benchmark",
            confidence=(
                "MEASURED"
                if any(sample.peak_vram_bytes is not None for sample in samples)
                else "UNKNOWN"
            ),
            limitations=("AVAILABLE_ONLY_WHEN_TORCH_CUDA_IS_ACTIVE",)
        ),
        "input_tokens_total": _metric(
            sum(sample.input_tokens or 0 for sample in samples)
            if any(sample.input_tokens is not None for sample in samples) else None,
            unit="tokens", method="EXECUTOR_USAGE_AGGREGATION",
            source="runtime_benchmark",
            confidence=(
                "MEASURED"
                if any(sample.input_tokens is not None for sample in samples)
                else "UNKNOWN"
            )
        ),
        "output_tokens_total": _metric(
            sum(sample.output_tokens or 0 for sample in samples)
            if any(sample.output_tokens is not None for sample in samples) else None,
            unit="tokens", method="EXECUTOR_USAGE_AGGREGATION",
            source="runtime_benchmark",
            confidence=(
                "MEASURED"
                if any(sample.output_tokens is not None for sample in samples)
                else "UNKNOWN"
            )
        ),
        "tokens_per_second": _metric(
            (
                sum(sample.output_tokens or 0 for sample in samples) / (total_ms / 1000)
                if total_ms > 0 and any(sample.output_tokens is not None for sample in samples)
                else None
            ),
            unit="tokens/s", method="OUTPUT_TOKENS_OVER_TOTAL_WALL_TIME",
            source="runtime_benchmark",
            confidence=(
                "MEASURED"
                if any(sample.output_tokens is not None for sample in samples)
                else "UNKNOWN"
            )
        ),
        "time_to_first_token_p50_ms": _metric(
            _percentile(
                [
                    sample.time_to_first_token_ms
                    for sample in samples
                    if sample.time_to_first_token_ms is not None
                ],
                0.50,
            ),
            unit="ms", method="EXECUTOR_REPORTED_TTFT_PERCENTILE",
            source="runtime_benchmark",
            confidence=(
                "MEASURED"
                if any(sample.time_to_first_token_ms is not None for sample in samples)
                else "UNKNOWN"
            )
        ),
        "observed_cost_total": _metric(
            sum(sample.observed_cost or 0.0 for sample in samples)
            if any(sample.observed_cost is not None for sample in samples) else None,
            unit="provider_currency", method="EXECUTOR_REPORTED_COST_AGGREGATION",
            source="runtime_benchmark",
            confidence=(
                "MEASURED"
                if any(sample.observed_cost is not None for sample in samples)
                else "UNKNOWN"
            ),
            limitations=("CURRENCY_UNIT_REQUIRES_PROVIDER_CONTRACT",)
        ),
        "energy_joules": _unknown("energy_joules", "runtime_benchmark"),
        "flops": _unknown("flops", "runtime_benchmark"),
    }
    return RuntimeBenchmark(
        subject_id=subject_id,
        samples=tuple(samples),
        metrics=metrics,
        evidence_refs=tuple(evidence_refs),
    )
