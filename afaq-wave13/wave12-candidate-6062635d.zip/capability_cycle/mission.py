"""Mission-level outcome verification for the existing-capability runtime.

HANDLER_EXECUTION_SUCCESS != MISSION_OUTCOME_SUCCESS.
Verifier output is evidence only. It does not grant authority.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from afaq_intelligence_core.package_intelligence.canonical_resolver import (
    CanonicalReferenceResolver,
)

from .planner import Requirement, derive_required_capabilities
from .telemetry import redact


@dataclass(frozen=True)
class MissionVerification:
    status: str
    reason: str
    evidence_refs: tuple[str, ...]
    correlation_id: str | None
    plan_ids: tuple[str, ...]
    original_requirement_ids: tuple[str, ...]
    unsatisfied_ids: tuple[str, ...]
    handler_ok_ids: tuple[str, ...]
    failed_requirement: str | None
    details: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return redact(
            {
                "status": self.status,
                "reason": self.reason,
                "evidence_refs": list(self.evidence_refs),
                "correlation_id": self.correlation_id,
                "plan_ids": list(self.plan_ids),
                "original_requirement_ids": list(self.original_requirement_ids),
                "unsatisfied_ids": list(self.unsatisfied_ids),
                "handler_ok_ids": list(self.handler_ok_ids),
                "failed_requirement": self.failed_requirement,
                "details": self.details,
            }
        )


def _catalog() -> dict[str, dict[str, Any]]:
    raw = CanonicalReferenceResolver()._registries.get("capabilities", {})
    return {str(k): v for k, v in raw.items() if isinstance(v, dict)}


def mission_requirement_ids(requirement: Requirement) -> tuple[str, ...]:
    if requirement.explicit_capability_ids:
        return tuple(dict.fromkeys(requirement.explicit_capability_ids))
    return derive_required_capabilities(requirement, _catalog())


def _handler_ok_ids(
    observations: tuple[Mapping[str, Any], ...] | list[Mapping[str, Any]],
    performance: tuple[Any, ...] | list[Any],
) -> tuple[str, ...]:
    ok_obs: set[str] = set()
    for item in observations:
        if not isinstance(item, Mapping):
            continue
        cap_id = item.get("capability_id")
        if not isinstance(cap_id, str) or not cap_id:
            continue
        result = item.get("result")
        result_ok = isinstance(result, Mapping) and result.get("ok") is True
        if result_ok:
            ok_obs.add(cap_id)
    ok_perf = {
        record.capability_id
        for record in performance
        if record.outcome == "SUCCESS"
    }
    return tuple(sorted(ok_obs & ok_perf))


def verify_mission(
    *,
    requirement: Requirement,
    final_plan_ids: tuple[str, ...],
    observations: tuple[Mapping[str, Any], ...] | list[Mapping[str, Any]],
    performance: tuple[Any, ...] | list[Any],
    correlation_id: str | None = None,
    historical_records: tuple[Mapping[str, Any], ...] = (),
    sandbox_passed: bool = False,
    certified: bool = False,
    replan_completed: bool = False,
) -> MissionVerification:
    """Verify the original mission using execution evidence only.

    sandbox_passed, certified, and replan_completed are ignored as
    success signals. historical_records are discarded.
    """
    del historical_records
    required = mission_requirement_ids(requirement)
    handler_ok = _handler_ok_ids(observations, performance)
    refs = tuple(
        f"obs:{item.get('capability_id')}"
        for item in observations
        if isinstance(item, Mapping) and item.get("capability_id")
    ) + tuple(f"perf:{record.capability_id}:{record.outcome}" for record in performance)
    unsatisfied = tuple(cap_id for cap_id in required if cap_id not in handler_ok)

    ignored_signals = {
        "sandbox_passed": sandbox_passed,
        "certified": certified,
        "replan_completed": replan_completed,
        "handler_ok_ids": handler_ok,
    }

    if not required:
        return MissionVerification(
            status="INSUFFICIENT_EVIDENCE",
            reason="NO_MISSION_REQUIREMENT_IDS",
            evidence_refs=refs,
            correlation_id=correlation_id,
            plan_ids=final_plan_ids,
            original_requirement_ids=required,
            unsatisfied_ids=(),
            handler_ok_ids=handler_ok,
            failed_requirement=None,
            details=ignored_signals,
        )

    if not unsatisfied:
        return MissionVerification(
            status="VERIFIED",
            reason="ORIGINAL_MISSION_SATISFIED",
            evidence_refs=refs,
            correlation_id=correlation_id,
            plan_ids=final_plan_ids,
            original_requirement_ids=required,
            unsatisfied_ids=(),
            handler_ok_ids=handler_ok,
            failed_requirement=None,
            details=ignored_signals,
        )

    if not observations and not performance:
        return MissionVerification(
            status="INSUFFICIENT_EVIDENCE",
            reason="NO_EXECUTION_EVIDENCE",
            evidence_refs=(),
            correlation_id=correlation_id,
            plan_ids=final_plan_ids,
            original_requirement_ids=required,
            unsatisfied_ids=unsatisfied,
            handler_ok_ids=handler_ok,
            failed_requirement=unsatisfied[0],
            details=ignored_signals,
        )

    return MissionVerification(
        status="FAILED",
        reason="ORIGINAL_REQUIREMENT_NOT_SATISFIED",
        evidence_refs=refs,
        correlation_id=correlation_id,
        plan_ids=final_plan_ids,
        original_requirement_ids=required,
        unsatisfied_ids=unsatisfied,
        handler_ok_ids=handler_ok,
        failed_requirement=unsatisfied[0],
        details=ignored_signals,
    )
