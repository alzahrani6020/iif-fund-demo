"""Existing-capability runtime: load, compile, execute, observe, replan, record.

Planning does not authorize execution. Genesis is not implemented.
Performance records are evidence only and never activate learning.
Replan may only select catalogued, implemented capabilities.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Mapping

from afaq_intelligence_core.package_intelligence.canonical_resolver import (
    CanonicalReferenceResolver,
)
from afaq_intelligence_core.package_intelligence.models import UNKNOWN

from current_authority.resolver import AuthorityRequest, resolve

from .certification import CertificationRecord, evaluate, is_usable
from .handlers import handler_version, has_implementation, implemented_ids
from .mission import MissionVerification, verify_mission
from .performance_store import PerformanceStore, StoreWriteFailed
from .planner import CapabilityPlan, Requirement, plan_capabilities
from .sandbox import SandboxError, run_sandboxed
from .telemetry import TelemetryStore, finish_record, redact, start_record

MAX_RETRIES = 2

REPLAN_ALLOWED_CLASSES = frozenset(
    {
        "SANDBOX_VALIDATION_FAILED",
        "OUTCOME_VERIFICATION_FAILED",
        "MISSION_VERIFICATION_FAILED",
    }
)
NON_RETRYABLE_CLASSES = frozenset(
    {
        "NOT_IMPLEMENTED",
        "DESCRIPTOR_EXISTS_NOT_IMPLEMENTED",
        "UNREGISTERED_HANDLER",
        "SANDBOX_BYPASS_DENIED",
        "AUTHORITY",
        "EXISTING_CAPABILITY_MISSING",
        "GENESIS_DESIGN_ONLY",
        "CAPABILITY_NOT_USABLE",
    }
)


@dataclass(frozen=True)
class ExecutionGraph:
    nodes: tuple[str, ...]
    compiled: bool
    reason: str


@dataclass(frozen=True)
class PerformanceRecord:
    correlation_id: str
    capability_id: str
    duration_ms: float | None
    outcome: str
    learning_activated: bool
    training_activated: bool
    auto_promoted: bool


@dataclass(frozen=True)
class ReplanContext:
    original_requirement_ids: tuple[str, ...]
    original_plan_ids: tuple[str, ...]
    failed_capability_id: str
    failure_class: str
    observation: dict[str, Any]
    attempt: int
    attempted: tuple[str, ...]
    allowed_alternatives: tuple[str, ...]


@dataclass(frozen=True)
class RuntimeResult:
    status: str
    reason: str
    plan: CapabilityPlan | None
    graph: ExecutionGraph | None
    certification: tuple[CertificationRecord, ...]
    observations: tuple[dict[str, Any], ...]
    performance: tuple[PerformanceRecord, ...]
    retries: int
    historical_records_consulted: int = 0
    details: dict[str, Any] = field(default_factory=dict)
    original_plan: CapabilityPlan | None = None
    replan_records: tuple[dict[str, Any], ...] = ()
    mission_verification: MissionVerification | None = None
    performance_record_ids: tuple[str, ...] = ()


def compile_graph(plan: CapabilityPlan) -> ExecutionGraph:
    if plan.status != "COMPOSED":
        return ExecutionGraph((), False, plan.reason)
    return ExecutionGraph(plan.required_ids, True, "LINEAR_EXISTING_CAPABILITIES")


def _certify(
    capability_id: str,
    payload: dict[str, Any],
    *,
    shadow_restore: Mapping[str, str] | None = None,
) -> CertificationRecord:
    try:
        sandbox = run_sandboxed(
            capability_id, payload, shadow_restore=shadow_restore
        )
    except SandboxError:
        return evaluate(
            capability_id,
            sandbox=None,
            contract_valid=True,
            tests_present=True,
            evidence={"provenance": "handler_registry"},
            requester="runtime",
        )
    return evaluate(
        capability_id,
        sandbox=sandbox,
        contract_valid=True,
        tests_present=True,
        evidence={"provenance": "handler_registry"},
        requester="runtime",
    )


def attempt_genesis(requirement: Requirement) -> RuntimeResult:
    return RuntimeResult(
        status="BLOCKED",
        reason="GENESIS_DESIGN_ONLY",
        plan=None,
        graph=None,
        certification=(),
        observations=(),
        performance=(),
        retries=0,
        details={
            "blocker": "no safe executable generator exists; descriptor creation is not genesis",
        },
    )


def _in_catalog(capability_id: str, resolver: CanonicalReferenceResolver) -> bool:
    record = resolver.resolve_capability(capability_id)
    return record != UNKNOWN and isinstance(record, dict)


def implemented_alternatives(attempted: tuple[str, ...]) -> tuple[str, ...]:
    """Catalogued, currently implemented IDs not already attempted.

    Observation text is never consulted. IDs are not invented.
    """
    resolver = CanonicalReferenceResolver()
    return tuple(
        cap_id
        for cap_id in implemented_ids()
        if cap_id not in attempted
        and has_implementation(cap_id)
        and _in_catalog(cap_id, resolver)
    )


def replan_disposition(failure_class: str) -> str:
    if failure_class in REPLAN_ALLOWED_CLASSES:
        return "REPLAN_ALLOWED"
    if failure_class in NON_RETRYABLE_CLASSES:
        return "NON_RETRYABLE"
    return "FAIL_CLOSED"


def _payload_for(
    cap_id: str, payloads: Mapping[str, dict[str, Any]]
) -> dict[str, Any]:
    raw = payloads.get(cap_id) or {"data": {"capability_id": cap_id}}
    return dict(raw)


def _blocked(
    *,
    reason: str,
    plan: CapabilityPlan | None,
    graph: ExecutionGraph | None,
    certs: list[CertificationRecord],
    observations: list[dict[str, Any]],
    performance: list[PerformanceRecord],
    retries: int,
    original_plan: CapabilityPlan | None = None,
    replan_records: list[dict[str, Any]] | None = None,
    details: dict[str, Any] | None = None,
    status: str = "BLOCKED",
    mission_verification: MissionVerification | None = None,
    performance_record_ids: tuple[str, ...] | list[str] | None = None,
) -> RuntimeResult:
    extra = {"learning": False, "training": False, "promotion": False}
    if details:
        extra.update(details)
    if mission_verification is not None:
        extra["mission_verification"] = mission_verification.as_dict()
    return RuntimeResult(
        status=status,
        reason=reason,
        plan=plan,
        graph=graph,
        certification=tuple(certs),
        observations=tuple(observations),
        performance=tuple(performance),
        retries=retries,
        historical_records_consulted=0,
        details=extra,
        original_plan=original_plan,
        replan_records=tuple(replan_records or ()),
        mission_verification=mission_verification,
        performance_record_ids=tuple(performance_record_ids or ()),
    )


def _compose_alternative(selected: str) -> CapabilityPlan:
    return plan_capabilities(Requirement(explicit_capability_ids=(selected,)))


def _persist_evidence(
    store: PerformanceStore,
    persisted: list[str],
    record: dict[str, Any],
    *,
    required: bool = False,
) -> None:
    try:
        evidence = store.append(record)
    except StoreWriteFailed:
        if required:
            raise
        return
    persisted.append(evidence.record_id)


def execute_plan(
    requirement: Requirement,
    *,
    payloads: Mapping[str, dict[str, Any]] | None = None,
    telemetry: TelemetryStore | None = None,
    max_retries: int = MAX_RETRIES,
    historical_records: tuple[Mapping[str, Any], ...] = (),
    performance_store: PerformanceStore | None = None,
    shadow_bindings: Mapping[str, Mapping[str, str]] | None = None,
) -> RuntimeResult:
    del historical_records
    store = telemetry or TelemetryStore()
    evidence_store = performance_store or PerformanceStore(":memory:")
    persisted: list[str] = []
    shadows = {
        str(key): dict(value)
        for key, value in (shadow_bindings or {}).items()
        if isinstance(value, Mapping)
    }

    def version_of(cap_id: str | None) -> str | None:
        if not cap_id:
            return None
        meta = shadows.get(cap_id)
        if meta:
            source = str(
                meta.get("source_artifact_hash") or meta.get("artifact_hash") or ""
            )
            return f"shadow:{source[:16]}" if source else "shadow"
        return handler_version(cap_id)

    def finish_blocked(**kwargs: Any) -> RuntimeResult:
        kwargs.setdefault("performance_record_ids", persisted)
        return _blocked(**kwargs)

    def persist_final(
        mission: MissionVerification | None,
        *,
        final_outcome: str,
        capability_id: str | None = None,
        execution_outcome: str | None = None,
        failure_class: str | None = None,
        sandbox_status: str | None = None,
        certification_status: str | None = None,
    ) -> str | None:
        mission_ms = max(0.0, round((time.perf_counter() - mission_started) * 1000, 3))
        try:
            _persist_evidence(
                evidence_store,
                persisted,
                {
                    "correlation_id": started["correlation_id"],
                    "record_kind": "FINAL",
                    "mission_ids": requirement.explicit_capability_ids
                    or (
                        mission.original_requirement_ids
                        if mission
                        else ()
                    ),
                    "plan_ids": plan.required_ids if plan else (),
                    "original_plan_ids": original_plan.required_ids
                    if original_plan
                    else (),
                    "capability_id": capability_id,
                    "capability_version": version_of(capability_id),
                    "attempt": len(attempted) if attempted else 0,
                    "replan_attempt": replan_attempts,
                    "execution_outcome": execution_outcome,
                    "mission_verification_status": mission.status if mission else None,
                    "mission_verification_reason": mission.reason if mission else None,
                    "failure_class": failure_class,
                    "duration_ms": mission_ms,
                    "duration_scope": "mission_cycle",
                    "sandbox_status": sandbox_status,
                    "certification_status": certification_status,
                    "evidence_refs": list(mission.evidence_refs) if mission else [],
                    "final_outcome": final_outcome,
                },
                required=True,
            )
        except StoreWriteFailed:
            return "STORE_WRITE_FAILED"
        return None

    started = start_record(stage="EXECUTE")
    mission_started = time.perf_counter()
    authority = resolve(AuthorityRequest(action="execute_tool"))
    if authority.outcome != "ALLOW":
        rec = finish_record(started, outcome="BLOCKED", failure_class="AUTHORITY")
        store.emit(rec)
        return RuntimeResult(
            status="BLOCKED",
            reason=authority.reason,
            plan=None,
            graph=None,
            certification=(),
            observations=(),
            performance=(),
            retries=0,
            historical_records_consulted=0,
        )

    plan = plan_capabilities(requirement)
    if plan.status != "COMPOSED":
        rec = finish_record(started, outcome="BLOCKED", failure_class=plan.reason)
        store.emit(rec)
        return RuntimeResult(
            status="BLOCKED",
            reason=plan.reason
            if plan.missing or plan.reason != "RESOLVED_EXISTING_COMPOSED"
            else "EXPLICIT_GAP",
            plan=plan,
            graph=compile_graph(plan),
            certification=(),
            observations=(),
            performance=(),
            retries=0,
            historical_records_consulted=0,
            details={"missing": list(plan.missing)},
        )

    original_plan = plan
    graph = compile_graph(plan)
    certs: list[CertificationRecord] = []
    observations: list[dict[str, Any]] = []
    performance: list[PerformanceRecord] = []
    replan_records: list[dict[str, Any]] = []
    payloads = payloads or {}
    replan_attempts = 0
    attempted: list[str] = []
    queue = list(graph.nodes)
    bound = max(0, max_retries)

    while queue:
        cap_id = queue[0]
        if not has_implementation(cap_id):
            cert = evaluate(
                cap_id,
                sandbox=None,
                contract_valid=True,
                tests_present=False,
                evidence={"provenance": "architecture_descriptor"},
                requester="runtime",
            )
            certs.append(cert)
            rec = finish_record(
                started,
                outcome="BLOCKED",
                failure_class="NOT_IMPLEMENTED",
                certification_state=cert.state,
            )
            store.emit(rec, required=True)
            return finish_blocked(
                reason="CAPABILITY_NOT_USABLE",
                plan=plan,
                graph=graph,
                certs=certs,
                observations=observations,
                performance=performance,
                retries=replan_attempts,
                original_plan=original_plan,
                replan_records=replan_records,
            )

        payload = _payload_for(cap_id, payloads)
        cap_started = time.perf_counter()
        shadow = shadows.get(cap_id)
        certified = _certify(cap_id, payload, shadow_restore=shadow)
        certs.append(certified)
        if not is_usable(certified):
            observed = {
                "capability_id": cap_id,
                "class": "CERTIFICATION_FAILED",
                "state": certified.state,
                "reason": certified.reason,
            }
            observations.append(observed)
            failure_class = certified.reason or "UNKNOWN"
            duration_ms = max(0.0, round((time.perf_counter() - cap_started) * 1000, 3))
            performance.append(
                PerformanceRecord(
                    correlation_id=started["correlation_id"],
                    capability_id=cap_id,
                    duration_ms=duration_ms,
                    outcome="FAILED",
                    learning_activated=False,
                    training_activated=False,
                    auto_promoted=False,
                )
            )
            sandbox = None
            verified = False
        else:
            sandbox = run_sandboxed(cap_id, payload, shadow_restore=shadow)
            verified = bool(
                sandbox.validated
                and sandbox.result
                and sandbox.result.get("ok") is True
            )
            observed = {
                "capability_id": cap_id,
                "class": "OK" if verified else (sandbox.failure_class or "FAILED"),
                "result": sandbox.result,
            }
            observations.append(observed)
            failure_class = (
                "OK"
                if verified
                else (sandbox.failure_class or "OUTCOME_VERIFICATION_FAILED")
            )
            duration_ms = max(0.0, round((time.perf_counter() - cap_started) * 1000, 3))
            performance.append(
                PerformanceRecord(
                    correlation_id=started["correlation_id"],
                    capability_id=cap_id,
                    duration_ms=duration_ms,
                    outcome="SUCCESS" if verified else "FAILED",
                    learning_activated=False,
                    training_activated=False,
                    auto_promoted=False,
                )
            )

        attempted.append(cap_id)
        _persist_evidence(
            evidence_store,
            persisted,
            {
                "correlation_id": started["correlation_id"],
                "record_kind": "INTERMEDIATE" if verified else "FAILED",
                "mission_ids": requirement.explicit_capability_ids
                or (original_plan.required_ids if original_plan else ()),
                "plan_ids": plan.required_ids,
                "original_plan_ids": original_plan.required_ids,
                "capability_id": cap_id,
                "capability_version": version_of(cap_id),
                "attempt": len(attempted),
                "replan_attempt": replan_attempts,
                "execution_outcome": "SUCCESS" if verified else "FAILED",
                "failure_class": None if verified else failure_class,
                "duration_ms": duration_ms,
                "duration_scope": "capability_execution",
                "sandbox_status": sandbox.outcome if sandbox is not None else None,
                "certification_status": certified.state,
                "evidence_refs": [f"obs:{cap_id}", f"perf:{cap_id}"],
                "final_outcome": None,
            },
        )
        mission_v: MissionVerification | None = None
        if verified:
            rec = finish_record(
                started,
                outcome="PASSED",
                sandbox_result=sandbox.outcome if sandbox is not None else None,
                certification_state=certified.state,
                verification_result="HANDLER_OK",
                retry_count=replan_attempts,
                details={"capability_id": cap_id, "handler_ok": True},
            )
            store.emit(rec)
            queue.pop(0)
            mission_v = verify_mission(
                requirement=requirement,
                final_plan_ids=tuple(plan.required_ids),
                observations=observations,
                performance=performance,
                correlation_id=started["correlation_id"],
                sandbox_passed=bool(sandbox and sandbox.validated),
                certified=certified.state == "CERTIFIED",
                replan_completed=bool(replan_records),
            )
            rec = finish_record(
                started,
                outcome=mission_v.status,
                failure_class=None
                if mission_v.status == "VERIFIED"
                else mission_v.reason,
                verification_result=mission_v.status,
                retry_count=replan_attempts,
                details={
                    **mission_v.as_dict(),
                    "triggered_replan": False,
                },
            )
            store.emit(rec)
            if mission_v.status == "VERIFIED":
                rec = finish_record(
                    started,
                    outcome="PASSED",
                    verification_result="VERIFIED",
                    retry_count=replan_attempts,
                    details={"learning": False, "training": False, "promotion": False},
                )
                store.emit(rec)
                persist_error = persist_final(
                    mission_v,
                    final_outcome="SUCCESS",
                    capability_id=cap_id,
                    execution_outcome="SUCCESS",
                    sandbox_status=sandbox.outcome if sandbox is not None else None,
                    certification_status=certified.state,
                )
                if persist_error:
                    return finish_blocked(
                        status="FAILED",
                        reason=persist_error,
                        plan=plan,
                        graph=graph,
                        certs=certs,
                        observations=observations,
                        performance=performance,
                        retries=replan_attempts,
                        original_plan=original_plan,
                        replan_records=replan_records,
                        mission_verification=mission_v,
                    )
                return RuntimeResult(
                    status="PASSED",
                    reason="MISSION_VERIFIED",
                    plan=plan,
                    graph=graph,
                    certification=tuple(certs),
                    observations=tuple(observations),
                    performance=tuple(performance),
                    retries=replan_attempts,
                    historical_records_consulted=0,
                    details={
                        "learning": False,
                        "training": False,
                        "promotion": False,
                        "mission_verification": mission_v.as_dict(),
                    },
                    original_plan=original_plan,
                    replan_records=tuple(replan_records),
                    mission_verification=mission_v,
                    performance_record_ids=tuple(persisted),
                )
            pending_can_satisfy = any(
                item in mission_v.unsatisfied_ids for item in queue
            )
            if pending_can_satisfy:
                continue
            if mission_v.status == "INSUFFICIENT_EVIDENCE":
                persist_error = persist_final(
                    mission_v,
                    final_outcome="FAILED",
                    capability_id=cap_id,
                    execution_outcome="SUCCESS",
                    failure_class="INSUFFICIENT_EVIDENCE",
                )
                if persist_error:
                    return finish_blocked(
                        status="FAILED",
                        reason=persist_error,
                        plan=plan,
                        graph=graph,
                        certs=certs,
                        observations=observations,
                        performance=performance,
                        retries=replan_attempts,
                        original_plan=original_plan,
                        replan_records=replan_records,
                        mission_verification=mission_v,
                    )
                rec = finish_record(
                    started,
                    outcome="FAILED",
                    failure_class="INSUFFICIENT_EVIDENCE",
                    verification_result="INSUFFICIENT_EVIDENCE",
                    retry_count=replan_attempts,
                    details=mission_v.as_dict(),
                )
                store.emit(rec, required=True)
                return finish_blocked(
                    status="FAILED",
                    reason="INSUFFICIENT_EVIDENCE",
                    plan=plan,
                    graph=graph,
                    certs=certs,
                    observations=observations,
                    performance=performance,
                    retries=replan_attempts,
                    original_plan=original_plan,
                    replan_records=replan_records,
                    mission_verification=mission_v,
                    details={"replan_decision": "FAIL_CLOSED"},
                )
            failure_class = "MISSION_VERIFICATION_FAILED"
            verified = False

        disposition = replan_disposition(failure_class)
        if disposition != "REPLAN_ALLOWED":
            persist_error = persist_final(
                mission_v,
                final_outcome="FAILED",
                capability_id=cap_id,
                execution_outcome="FAILED",
                failure_class=failure_class,
                sandbox_status=sandbox.outcome if sandbox is not None else None,
                certification_status=certified.state,
            )
            if persist_error:
                return finish_blocked(
                    status="FAILED",
                    reason=persist_error,
                    plan=plan,
                    graph=graph,
                    certs=certs,
                    observations=observations,
                    performance=performance,
                    retries=replan_attempts,
                    original_plan=original_plan,
                    replan_records=replan_records,
                    mission_verification=mission_v,
                )
            rec = finish_record(
                started,
                outcome="BLOCKED",
                failure_class=failure_class,
                certification_state=certified.state,
                verification_result="FAILED",
                retry_count=replan_attempts,
            )
            store.emit(rec, required=True)
            return finish_blocked(
                status="FAILED" if failure_class == "OUTCOME_VERIFICATION_FAILED" else "BLOCKED",
                reason=failure_class
                if disposition == "FAIL_CLOSED" and failure_class not in NON_RETRYABLE_CLASSES
                else (
                    "CAPABILITY_NOT_USABLE"
                    if failure_class in NON_RETRYABLE_CLASSES
                    or failure_class == "SANDBOX_REQUIRED"
                    else failure_class
                ),
                plan=plan,
                graph=graph,
                certs=certs,
                observations=observations,
                performance=performance,
                retries=replan_attempts,
                original_plan=original_plan,
                replan_records=replan_records,
                mission_verification=mission_v,
                details={"replan_decision": "FAIL_CLOSED", "failure_class": failure_class},
            )

        if replan_attempts >= bound:
            persist_error = persist_final(
                mission_v,
                final_outcome="FAILED",
                capability_id=cap_id,
                execution_outcome="FAILED",
                failure_class="REPLAN_EXHAUSTED",
                sandbox_status=sandbox.outcome if sandbox is not None else None,
                certification_status=certified.state,
            )
            if persist_error:
                return finish_blocked(
                    status="FAILED",
                    reason=persist_error,
                    plan=plan,
                    graph=graph,
                    certs=certs,
                    observations=observations,
                    performance=performance,
                    retries=replan_attempts,
                    original_plan=original_plan,
                    replan_records=replan_records,
                    mission_verification=mission_v,
                )
            rec = finish_record(
                started,
                outcome="FAILED",
                failure_class="REPLAN_EXHAUSTED",
                certification_state=certified.state,
                verification_result="FAILED",
                retry_count=replan_attempts,
                details={"failed_capability": cap_id, "failure_class": failure_class},
            )
            store.emit(rec, required=True)
            return finish_blocked(
                status="FAILED",
                reason="REPLAN_EXHAUSTED",
                plan=plan,
                graph=graph,
                certs=certs,
                observations=observations,
                performance=performance,
                retries=replan_attempts,
                original_plan=original_plan,
                replan_records=replan_records,
                mission_verification=mission_v,
                details={"replan_decision": "EXHAUSTED", "failure_class": failure_class},
            )

        replan_auth = resolve(AuthorityRequest(action="replan"))
        if replan_auth.outcome != "ALLOW":
            rec = finish_record(
                started,
                outcome="BLOCKED",
                failure_class="AUTHORITY",
                retry_count=replan_attempts,
                details={"authority_action": "replan", "reason": replan_auth.reason},
            )
            store.emit(rec, required=True)
            return finish_blocked(
                reason=replan_auth.reason,
                plan=plan,
                graph=graph,
                certs=certs,
                observations=observations,
                performance=performance,
                retries=replan_attempts,
                original_plan=original_plan,
                replan_records=replan_records,
                mission_verification=mission_v,
                details={"replan_decision": "DENIED", "authority_action": "replan"},
            )

        replan_attempts += 1
        allowed = implemented_alternatives(tuple(attempted))
        context = ReplanContext(
            original_requirement_ids=requirement.explicit_capability_ids,
            original_plan_ids=original_plan.required_ids,
            failed_capability_id=cap_id,
            failure_class=failure_class,
            observation=redact(observed),
            attempt=replan_attempts,
            attempted=tuple(attempted),
            allowed_alternatives=allowed,
        )
        if not allowed:
            record = {
                "original_plan_ids": original_plan.required_ids,
                "replan_input": {
                    "failed_capability_id": context.failed_capability_id,
                    "failure_class": context.failure_class,
                    "attempt": context.attempt,
                    "attempted": context.attempted,
                    "allowed_alternatives": (),
                },
                "new_plan_ids": (),
                "graph_change": False,
                "attempt": replan_attempts,
                "decision": "NO_VALID_ALTERNATIVE",
                "alternative_selected": None,
                "correlation_id": started["correlation_id"],
            }
            replan_records.append(record)
            rec = finish_record(
                started,
                outcome="FAILED",
                failure_class="REPLAN_NO_VALID_ALTERNATIVE",
                retry_count=replan_attempts,
                details=record,
            )
            store.emit(rec, required=True)
            return finish_blocked(
                status="FAILED",
                reason="REPLAN_NO_VALID_ALTERNATIVE",
                plan=plan,
                graph=graph,
                certs=certs,
                observations=observations,
                performance=performance,
                retries=replan_attempts,
                original_plan=original_plan,
                replan_records=replan_records,
                mission_verification=mission_v,
                details={"replan_decision": "NO_VALID_ALTERNATIVE"},
            )

        selected = allowed[0]
        if selected == cap_id:
            rec = finish_record(
                started,
                outcome="FAILED",
                failure_class="REPLAN_NO_VALID_ALTERNATIVE",
                retry_count=replan_attempts,
                details={"same_capability": selected},
            )
            store.emit(rec, required=True)
            return finish_blocked(
                status="FAILED",
                reason="REPLAN_NO_VALID_ALTERNATIVE",
                plan=plan,
                graph=graph,
                certs=certs,
                observations=observations,
                performance=performance,
                retries=replan_attempts,
                original_plan=original_plan,
                replan_records=replan_records,
                mission_verification=mission_v,
                details={"replan_decision": "SAME_CAPABILITY_NOT_REPLAN"},
            )

        new_plan = _compose_alternative(selected)
        if new_plan.status != "COMPOSED" or selected not in new_plan.required_ids:
            rec = finish_record(
                started,
                outcome="FAILED",
                failure_class="REPLAN_NO_VALID_ALTERNATIVE",
                retry_count=replan_attempts,
            )
            store.emit(rec, required=True)
            return finish_blocked(
                status="FAILED",
                reason="REPLAN_NO_VALID_ALTERNATIVE",
                plan=plan,
                graph=graph,
                certs=certs,
                observations=observations,
                performance=performance,
                retries=replan_attempts,
                original_plan=original_plan,
                replan_records=replan_records,
                mission_verification=mission_v,
                details={"replan_decision": "COMPOSE_FAILED"},
            )

        if new_plan.required_ids == (cap_id,):
            rec = finish_record(
                started,
                outcome="FAILED",
                failure_class="REPLAN_NO_VALID_ALTERNATIVE",
                retry_count=replan_attempts,
            )
            store.emit(rec, required=True)
            return finish_blocked(
                status="FAILED",
                reason="REPLAN_NO_VALID_ALTERNATIVE",
                plan=plan,
                graph=graph,
                certs=certs,
                observations=observations,
                performance=performance,
                retries=replan_attempts,
                original_plan=original_plan,
                replan_records=replan_records,
                mission_verification=mission_v,
                details={"replan_decision": "SAME_PLAN_NOT_REPLAN"},
            )

        execute_auth = resolve(AuthorityRequest(action="execute_tool"))
        if execute_auth.outcome != "ALLOW":
            rec = finish_record(
                started,
                outcome="BLOCKED",
                failure_class="AUTHORITY",
                retry_count=replan_attempts,
                details={"authority_action": "execute_tool", "reason": execute_auth.reason},
            )
            store.emit(rec, required=True)
            return finish_blocked(
                reason=execute_auth.reason,
                plan=new_plan,
                graph=compile_graph(new_plan),
                certs=certs,
                observations=observations,
                performance=performance,
                retries=replan_attempts,
                original_plan=original_plan,
                replan_records=replan_records,
                mission_verification=mission_v,
                details={
                    "replan_decision": "PLAN_COMPOSED_EXECUTE_DENIED",
                    "authority_action": "execute_tool",
                    "new_plan_ids": new_plan.required_ids,
                },
            )

        new_graph = compile_graph(new_plan)
        record = {
            "original_plan_ids": original_plan.required_ids,
            "replan_input": {
                "failed_capability_id": context.failed_capability_id,
                "failure_class": context.failure_class,
                "attempt": context.attempt,
                "attempted": context.attempted,
                "allowed_alternatives": context.allowed_alternatives,
            },
            "new_plan_ids": new_plan.required_ids,
            "graph_change": new_graph.nodes != graph.nodes,
            "attempt": replan_attempts,
            "decision": "SELECTED",
            "alternative_selected": selected,
            "new_graph_ids": new_graph.nodes,
            "correlation_id": started["correlation_id"],
        }
        replan_records.append(record)
        rec = finish_record(
            started,
            outcome="REPLANNED",
            failure_class=failure_class,
            retry_count=replan_attempts,
            details={
                **record,
                "triggered_replan": True,
                "mission_status": mission_v.status if mission_v else None,
            },
        )
        store.emit(rec)
        _persist_evidence(
            evidence_store,
            persisted,
            {
                "correlation_id": started["correlation_id"],
                "record_kind": "REPLANNED",
                "mission_ids": requirement.explicit_capability_ids
                or original_plan.required_ids,
                "plan_ids": new_plan.required_ids,
                "original_plan_ids": original_plan.required_ids,
                "capability_id": selected,
                "capability_version": version_of(selected),
                "attempt": len(attempted),
                "replan_attempt": replan_attempts,
                "execution_outcome": "REPLANNED",
                "failure_class": failure_class,
                "duration_ms": duration_ms,
                "duration_scope": "capability_execution",
                "evidence_refs": [
                    f"failed:{cap_id}",
                    f"alternative:{selected}",
                ],
                "final_outcome": None,
            },
        )
        plan = new_plan
        graph = new_graph
        queue = list(new_graph.nodes)

    mission_v = verify_mission(
        requirement=requirement,
        final_plan_ids=tuple(plan.required_ids) if plan else (),
        observations=observations,
        performance=performance,
        correlation_id=started["correlation_id"],
        replan_completed=bool(replan_records),
    )
    rec = finish_record(
        started,
        outcome=mission_v.status,
        failure_class=None if mission_v.status == "VERIFIED" else mission_v.reason,
        verification_result=mission_v.status,
        retry_count=replan_attempts,
        details=mission_v.as_dict(),
    )
    store.emit(rec, required=mission_v.status != "VERIFIED")
    if mission_v.status != "VERIFIED":
        persist_error = persist_final(
            mission_v,
            final_outcome="FAILED",
            failure_class=mission_v.reason,
        )
        if persist_error:
            return finish_blocked(
                status="FAILED",
                reason=persist_error,
                plan=plan,
                graph=graph,
                certs=certs,
                observations=observations,
                performance=performance,
                retries=replan_attempts,
                original_plan=original_plan,
                replan_records=replan_records,
                mission_verification=mission_v,
            )
        return finish_blocked(
            status="FAILED",
            reason=mission_v.reason
            if mission_v.status == "INSUFFICIENT_EVIDENCE"
            else "MISSION_VERIFICATION_FAILED",
            plan=plan,
            graph=graph,
            certs=certs,
            observations=observations,
            performance=performance,
            retries=replan_attempts,
            original_plan=original_plan,
            replan_records=replan_records,
            mission_verification=mission_v,
        )
    rec = finish_record(
        started,
        outcome="PASSED",
        verification_result="VERIFIED",
        retry_count=replan_attempts,
        details={"learning": False, "training": False, "promotion": False},
    )
    store.emit(rec)
    persist_error = persist_final(
        mission_v,
        final_outcome="SUCCESS",
        execution_outcome="SUCCESS",
    )
    if persist_error:
        return finish_blocked(
            status="FAILED",
            reason=persist_error,
            plan=plan,
            graph=graph,
            certs=certs,
            observations=observations,
            performance=performance,
            retries=replan_attempts,
            original_plan=original_plan,
            replan_records=replan_records,
            mission_verification=mission_v,
        )
    return RuntimeResult(
        status="PASSED",
        reason="MISSION_VERIFIED",
        plan=plan,
        graph=graph,
        certification=tuple(certs),
        observations=tuple(observations),
        performance=tuple(performance),
        retries=replan_attempts,
        historical_records_consulted=0,
        details={
            "learning": False,
            "training": False,
            "promotion": False,
            "mission_verification": mission_v.as_dict(),
        },
        original_plan=original_plan,
        replan_records=tuple(replan_records),
        mission_verification=mission_v,
        performance_record_ids=tuple(persisted),
    )
