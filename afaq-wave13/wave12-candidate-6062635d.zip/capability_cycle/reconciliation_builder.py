from __future__ import annotations

from dataclasses import dataclass

from .reconciliation_contracts import (
    ReconciliationInput,
    VerificationDecision,
)

from .reconciliation_engine import (
    ReconciliationFacts,
)


@dataclass(frozen=True)
class ReconciliationBuildRequest:
    reconciliation_id: str
    cycle_id: str
    subject_ref: str
    created_at: str
    verification_ref: str | None = None
    contract_refs: tuple[str, ...] = ()
    current_state_refs: tuple[str, ...] = ()
    performance_evidence_refs: tuple[str, ...] = ()
    drift_refs: tuple[str, ...] = ()
    learning_observation_refs: tuple[str, ...] = ()
    evidence_refs: tuple[str, ...] = ()


@dataclass(frozen=True)
class ReconciliationBundle:
    reconciliation_input: ReconciliationInput
    facts: ReconciliationFacts
    verification: VerificationDecision | None


def _require_text(value: str, field: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field} must be non-empty")


def build_reconciliation_bundle(
    request: ReconciliationBuildRequest,
    facts: ReconciliationFacts,
    *,
    verification: VerificationDecision | None = None,
) -> ReconciliationBundle:
    for field, value in (
        ("reconciliation_id", request.reconciliation_id),
        ("cycle_id", request.cycle_id),
        ("subject_ref", request.subject_ref),
        ("created_at", request.created_at),
    ):
        _require_text(value, field)

    if facts.subject_ref != request.subject_ref:
        raise ValueError(
            "FACT_SUBJECT_MISMATCH"
        )

    verification_ref = (
        request.verification_ref
    )

    if verification is not None:
        if (
            verification.cycle_id
            != request.cycle_id
        ):
            raise ValueError(
                "VERIFICATION_CYCLE_MISMATCH"
            )

        if (
            verification.subject_ref
            != request.subject_ref
        ):
            raise ValueError(
                "VERIFICATION_SUBJECT_MISMATCH"
            )

        expected_ref = (
            "verification:"
            + verification.verification_id
        )

        if verification_ref is None:
            verification_ref = expected_ref

        elif verification_ref != expected_ref:
            raise ValueError(
                "VERIFICATION_REF_MISMATCH"
            )

    state_refs = set(
        request.current_state_refs
    )

    state_refs.update(
        facts.capability_evidence_refs
    )

    state_refs.update(
        facts.implementation_evidence_refs
    )

    state_refs.update(
        facts.runtime_evidence_refs
    )

    state_refs.update(
        facts.authority_evidence_refs
    )

    contract_refs = set(
        request.contract_refs
    )

    contract_refs.update(
        facts.contract_evidence_refs
    )

    if verification is not None:
        contract_refs.update(
            verification.contract_refs
        )

    drift_refs = set(
        request.drift_refs
    )

    drift_refs.update(
        facts.drift_evidence_refs
    )

    evidence_refs = set(
        request.evidence_refs
    )

    if verification is not None:
        evidence_refs.update(
            verification.evidence_refs
        )

    reconciliation_input = (
        ReconciliationInput(
            reconciliation_id=(
                request.reconciliation_id
            ),
            cycle_id=(
                request.cycle_id
            ),
            subject_ref=(
                request.subject_ref
            ),
            verification_ref=(
                verification_ref
            ),
            contract_refs=tuple(
                sorted(
                    contract_refs
                )
            ),
            current_state_refs=tuple(
                sorted(
                    state_refs
                )
            ),
            performance_evidence_refs=tuple(
                sorted(
                    set(
                        request.performance_evidence_refs
                    )
                )
            ),
            drift_refs=tuple(
                sorted(
                    drift_refs
                )
            ),
            learning_observation_refs=tuple(
                sorted(
                    set(
                        request.learning_observation_refs
                    )
                )
            ),
            evidence_refs=tuple(
                sorted(
                    evidence_refs
                )
            ),
            created_at=(
                request.created_at
            ),
        )
    )

    return ReconciliationBundle(
        reconciliation_input=(
            reconciliation_input
        ),
        facts=facts,
        verification=verification,
    )
