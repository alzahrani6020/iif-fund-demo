"""Out-of-band evidence consumer.

This module is deliberately outside CycleRunner's hot path.

It may:
- inspect persisted performance evidence
- evaluate drift
- create LearningObservation
- create ImprovementProposal

It may NOT:
- execute proposals
- mutate runtime
- mutate policy
- change authority
- invoke Genesis
- train
- promote
- publish
- deploy
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .drift import (
    DriftEvaluation,
    evaluate_drift,
)
from .learning import (
    LearningResult,
    LearningThresholds,
    analyze_runtime_evidence,
)
from .performance_store import (
    PerformanceStore,
)


@dataclass(frozen=True)
class LearningConsumerResult:
    capability_id: str
    final_sample_count: int
    drift: DriftEvaluation
    learning: LearningResult
    runtime_mutated: bool = False
    policy_mutated: bool = False
    authority_mutated: bool = False
    genesis_invoked: bool = False
    training_activated: bool = False
    promotion_activated: bool = False
    publish_activated: bool = False

    def as_dict(
        self,
    ) -> dict[str, Any]:
        return {
            "capability_id": (
                self.capability_id
            ),
            "final_sample_count": (
                self.final_sample_count
            ),
            "drift": (
                self.drift.as_dict()
            ),
            "learning": (
                self.learning.as_dict()
            ),
            "runtime_mutated": False,
            "policy_mutated": False,
            "authority_mutated": False,
            "genesis_invoked": False,
            "training_activated": False,
            "promotion_activated": False,
            "publish_activated": False,
        }


def consume_learning(
    store: PerformanceStore,
    *,
    capability_id: str,
    artifact_hash: str | None = None,
    mission_class: str | None = None,
    sample_window: int | None = None,
    min_samples: int | None = None,
    thresholds: LearningThresholds | None = None,
) -> LearningConsumerResult:
    """Analyze already-persisted evidence.

    Calling this function does not mean the capability learned
    operationally. It records an observation/proposal only.
    """

    records = (
        store.checked_by_capability_id(
            capability_id
        )
    )

    finals = tuple(
        record
        for record in records
        if record.record_kind == "FINAL"
    )

    drift = evaluate_drift(
        store,
        capability_id=capability_id,
        metric="mission_success_rate",
        persist=True,
    )

    learning = analyze_runtime_evidence(
        store,
        capability_id=capability_id,
        artifact_hash=artifact_hash,
        mission_class=mission_class,
        sample_window=sample_window,
        min_samples=min_samples,
        drift=drift,
        thresholds=thresholds,
        persist=True,
        claims=None,
    )

    # Belt-and-suspenders enforcement.
    if any(
        (
            learning.runtime_mutated,
            learning.training_activated,
            learning.promotion_activated,
            learning.genesis_invoked,
            learning.code_generated,
            learning.activation_invoked,
            learning.rollback_invoked,
        )
    ):
        raise RuntimeError(
            "LEARNING_CONSUMER_MUTATION_BOUNDARY_VIOLATION"
        )

    return LearningConsumerResult(
        capability_id=(
            capability_id
        ),
        final_sample_count=len(
            finals
        ),
        drift=drift,
        learning=learning,
    )
