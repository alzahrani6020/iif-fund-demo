"""Concrete analytical primitives for existing W8-P24 and W8-P37 semantics.

These functions provide measurement and advisory decisions only. They do not
perform GPU scheduling, routing changes, activation, or authority changes.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Mapping


def percentile(values: tuple[float, ...], fraction: float) -> float | None:
    if not values:
        return None
    ordered = sorted(float(x) for x in values)
    if len(ordered) == 1:
        return round(ordered[0], 6)
    pos = (len(ordered) - 1) * fraction
    lo = math.floor(pos)
    hi = math.ceil(pos)
    if lo == hi:
        return round(ordered[lo], 6)
    w = pos - lo
    return round(ordered[lo] + (ordered[hi] - ordered[lo]) * w, 6)


def latency_summary(values_ms: tuple[float, ...]) -> dict[str, Any]:
    if not values_ms:
        return {
            "sample_count": 0,
            "p50_ms": None,
            "p95_ms": None,
            "p99_ms": None,
            "mean_ms": None,
        }
    values = tuple(float(x) for x in values_ms)
    return {
        "sample_count": len(values),
        "p50_ms": percentile(values, 0.50),
        "p95_ms": percentile(values, 0.95),
        "p99_ms": percentile(values, 0.99),
        "mean_ms": round(sum(values) / len(values), 6),
    }


def latency_budget_check(
    metrics: Mapping[str, Any],
    *,
    p95_budget_ms: float | None = None,
    p99_budget_ms: float | None = None,
    ttft_budget_ms: float | None = None,
) -> dict[str, Any]:
    failures: list[str] = []

    def value(name: str) -> float | None:
        raw = metrics.get(name)
        if isinstance(raw, Mapping):
            raw = raw.get("value")
        try:
            return float(raw) if raw is not None else None
        except (TypeError, ValueError):
            return None

    checks = (
        ("latency_p95_ms", p95_budget_ms, "P95"),
        ("latency_p99_ms", p99_budget_ms, "P99"),
        ("time_to_first_token_p50_ms", ttft_budget_ms, "TTFT"),
    )
    observed: dict[str, float | None] = {}
    for metric_name, budget, label in checks:
        if budget is None:
            continue
        measured = value(metric_name)
        observed[metric_name] = measured
        if measured is None:
            failures.append(f"{label}_UNKNOWN")
        elif measured > float(budget):
            failures.append(f"{label}_OVER_BUDGET")

    return {
        "state": "WITHIN_BUDGET" if not failures else "BUDGET_VIOLATION",
        "failures": failures,
        "observed": observed,
        "advisory_only": True,
    }


def detect_performance_regression(
    baseline: Mapping[str, Any],
    current: Mapping[str, Any],
    *,
    max_latency_increase_ratio: float = 0.10,
    max_success_rate_drop: float = 0.01,
    max_cost_increase_ratio: float = 0.10,
) -> dict[str, Any]:
    def num(data: Mapping[str, Any], key: str) -> float | None:
        raw = data.get(key)
        if isinstance(raw, Mapping):
            raw = raw.get("value")
        try:
            return float(raw) if raw is not None else None
        except (TypeError, ValueError):
            return None

    b_latency = num(baseline, "latency_p95_ms")
    c_latency = num(current, "latency_p95_ms")
    b_success = num(baseline, "success_rate")
    c_success = num(current, "success_rate")
    b_cost = num(baseline, "observed_cost_total")
    c_cost = num(current, "observed_cost_total")

    signals: list[str] = []
    unknowns: list[str] = []

    if b_latency is None or c_latency is None:
        unknowns.append("LATENCY")
    elif b_latency > 0 and (c_latency - b_latency) / b_latency > max_latency_increase_ratio:
        signals.append("LATENCY_REGRESSION")

    if b_success is None or c_success is None:
        unknowns.append("SUCCESS_RATE")
    elif b_success - c_success > max_success_rate_drop:
        signals.append("RELIABILITY_REGRESSION")

    if b_cost is None or c_cost is None:
        unknowns.append("COST")
    elif b_cost > 0 and (c_cost - b_cost) / b_cost > max_cost_increase_ratio:
        signals.append("COST_REGRESSION")

    return {
        "state": (
            "REGRESSION_DETECTED"
            if signals
            else "INSUFFICIENT_EVIDENCE"
            if unknowns
            else "NO_REGRESSION_DETECTED"
        ),
        "signals": signals,
        "unknowns": unknowns,
        "advisory_only": True,
    }


def bottleneck_localization(step_metrics: tuple[Mapping[str, Any], ...]) -> dict[str, Any]:
    rows: list[tuple[float, str, dict[str, Any]]] = []
    for raw in step_metrics:
        row = dict(raw)
        step_id = str(row.get("step_id") or "")
        try:
            latency = float(row.get("latency_ms"))
        except (TypeError, ValueError):
            continue
        rows.append((latency, step_id, row))
    rows.sort(key=lambda item: (-item[0], item[1]))
    total = sum(item[0] for item in rows)
    return {
        "state": "LOCALIZED" if rows else "INSUFFICIENT_EVIDENCE",
        "critical_path": [
            {
                "step_id": step_id,
                "latency_ms": latency,
                "share": round(latency / total, 6) if total > 0 else None,
            }
            for latency, step_id, _ in rows
        ],
        "advisory_only": True,
    }


def cost_per_unit(
    *,
    total_cost: float,
    units: float,
    unit_name: str,
) -> dict[str, Any]:
    if units <= 0:
        return {
            "state": "UNKNOWN",
            "value": None,
            "unit": f"cost/{unit_name}",
            "reason": "NON_POSITIVE_UNIT_COUNT",
        }
    return {
        "state": "MEASURED",
        "value": round(float(total_cost) / float(units), 9),
        "unit": f"cost/{unit_name}",
    }


def resource_efficiency(
    *,
    quality: float,
    success_rate: float,
    latency_ms: float,
    cost: float,
    peak_memory_bytes: float | None = None,
) -> dict[str, Any]:
    if quality < 0 or success_rate < 0 or latency_ms < 0 or cost < 0:
        raise ValueError("resource efficiency inputs must be non-negative")
    effective_cost = max(cost, 1e-9)
    effective_latency = max(latency_ms, 1e-9)
    memory_penalty = 1.0
    if peak_memory_bytes is not None and peak_memory_bytes > 0:
        memory_penalty = 1.0 + math.log10(max(1.0, peak_memory_bytes / 1_000_000))
    score = (quality * success_rate) / (effective_cost * effective_latency * memory_penalty)
    return {
        "state": "SCORED",
        "score": score,
        "components": {
            "quality": quality,
            "success_rate": success_rate,
            "latency_ms": latency_ms,
            "cost": cost,
            "peak_memory_bytes": peak_memory_bytes,
            "memory_penalty": memory_penalty,
        },
        "advisory_only": True,
    }


def quality_cost_latency_optimizer(
    candidates: tuple[Mapping[str, Any], ...],
    *,
    quality_floor: float = 0.0,
    success_floor: float = 0.0,
    latency_ceiling_ms: float | None = None,
    cost_ceiling: float | None = None,
) -> dict[str, Any]:
    scored: list[dict[str, Any]] = []
    rejected: list[dict[str, Any]] = []
    for raw in candidates:
        row = dict(raw)
        subject_id = str(row.get("subject_id") or "")
        try:
            quality = float(row["quality"])
            success = float(row["success_rate"])
            latency = float(row["latency_ms"])
            cost = float(row["cost"])
        except (KeyError, TypeError, ValueError):
            rejected.append({"subject_id": subject_id, "reason": "REQUIRED_METRIC_UNKNOWN"})
            continue

        reasons: list[str] = []
        if quality < quality_floor:
            reasons.append("QUALITY_BELOW_FLOOR")
        if success < success_floor:
            reasons.append("SUCCESS_BELOW_FLOOR")
        if latency_ceiling_ms is not None and latency > latency_ceiling_ms:
            reasons.append("LATENCY_OVER_CEILING")
        if cost_ceiling is not None and cost > cost_ceiling:
            reasons.append("COST_OVER_CEILING")
        if reasons:
            rejected.append({"subject_id": subject_id, "reason": ",".join(reasons)})
            continue

        efficiency = resource_efficiency(
            quality=quality,
            success_rate=success,
            latency_ms=latency,
            cost=cost,
            peak_memory_bytes=(
                float(row["peak_memory_bytes"])
                if row.get("peak_memory_bytes") is not None
                else None
            ),
        )
        scored.append(
            {
                "subject_id": subject_id,
                "score": efficiency["score"],
                "metrics": row,
            }
        )

    scored.sort(key=lambda row: (-float(row["score"]), str(row["subject_id"])))
    return {
        "state": "OPTIMUM_CANDIDATE_AVAILABLE" if scored else "NO_ELIGIBLE_CANDIDATE",
        "selected_subject": scored[0]["subject_id"] if scored else None,
        "ranked": scored,
        "rejected": rejected,
        "advisory_only": True,
        "routing_mutated": False,
    }


def roi(
    *,
    benefit: float,
    cost: float,
) -> dict[str, Any]:
    if cost <= 0:
        return {
            "state": "UNKNOWN",
            "roi": None,
            "reason": "NON_POSITIVE_COST",
        }
    return {
        "state": "MEASURED",
        "roi": round((benefit - cost) / cost, 9),
    }


def time_saved(
    *,
    baseline_seconds: float,
    candidate_seconds: float,
    runs: int = 1,
) -> dict[str, Any]:
    saved = (float(baseline_seconds) - float(candidate_seconds)) * int(runs)
    return {
        "state": "MEASURED",
        "seconds_saved": round(saved, 6),
        "runs": int(runs),
    }
