"""Evidence-based performance drift detection over PerformanceStore.

Read-only detector. Output is structured evidence, not authority.
Does not learn, train, promote, rollback, route, or invoke Genesis.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Mapping

from .performance_store import PerformanceEvidence, PerformanceStore, StoreCorruptRecord

DRIFT_CONFIG_VERSION = 1
DRIFT_STATES = frozenset(
    {"INSUFFICIENT_EVIDENCE", "STABLE", "WARNING", "DEGRADED"}
)
DRIFT_METRICS = frozenset(
    {
        "mission_success_rate",
        "verification_failure_rate",
        "duration_ms",
        "replan_frequency",
    }
)


class DriftEvidenceFailed(RuntimeError):
    """Required source records failed integrity and were not used."""


@dataclass(frozen=True)
class DriftThresholds:
    version: int = DRIFT_CONFIG_VERSION
    min_baseline_samples: int = 5
    min_current_samples: int = 5
    success_rate_warning_drop: float = 0.15
    success_rate_degraded_drop: float = 0.30
    verification_failure_warning: float = 0.15
    verification_failure_degraded: float = 0.30
    duration_warning_ratio: float = 1.5
    duration_degraded_ratio: float = 2.0
    replan_warning_delta: float = 0.5
    replan_degraded_delta: float = 1.0

    def as_dict(self) -> dict[str, Any]:
        return {
            "version": self.version,
            "min_baseline_samples": self.min_baseline_samples,
            "min_current_samples": self.min_current_samples,
            "success_rate_warning_drop": self.success_rate_warning_drop,
            "success_rate_degraded_drop": self.success_rate_degraded_drop,
            "verification_failure_warning": self.verification_failure_warning,
            "verification_failure_degraded": self.verification_failure_degraded,
            "duration_warning_ratio": self.duration_warning_ratio,
            "duration_degraded_ratio": self.duration_degraded_ratio,
            "replan_warning_delta": self.replan_warning_delta,
            "replan_degraded_delta": self.replan_degraded_delta,
        }


@dataclass(frozen=True)
class DriftEvaluation:
    evaluation_id: str
    timestamp: str
    capability_id: str
    mission_id: str | None
    metric: str
    baseline_window: dict[str, Any]
    current_window: dict[str, Any]
    baseline_value: float | None
    current_value: float | None
    delta: float | None
    threshold: dict[str, Any]
    status: str
    evidence_refs: tuple[str, ...]
    config_version: int
    details: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "evaluation_id": self.evaluation_id,
            "timestamp": self.timestamp,
            "capability_id": self.capability_id,
            "mission_id": self.mission_id,
            "metric": self.metric,
            "baseline_window": self.baseline_window,
            "current_window": self.current_window,
            "baseline_value": self.baseline_value,
            "current_value": self.current_value,
            "delta": self.delta,
            "threshold": self.threshold,
            "status": self.status,
            "evidence_refs": list(self.evidence_refs),
            "config_version": self.config_version,
            "details": self.details,
            "learning_activated": False,
            "training_activated": False,
            "auto_promoted": False,
            "rollback_activated": False,
        }


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _is_verified_final(record: PerformanceEvidence) -> bool:
    return (
        record.record_kind == "FINAL"
        and record.mission_verification_status == "VERIFIED"
        and record.final_outcome == "SUCCESS"
    )


def _is_final(record: PerformanceEvidence) -> bool:
    return record.record_kind == "FINAL"


def _window(records: tuple[PerformanceEvidence, ...]) -> dict[str, Any]:
    ids = [record.record_id for record in records]
    return {
        "record_ids": ids,
        "sample_count": len(ids),
        "start": records[0].timestamp if records else None,
        "end": records[-1].timestamp if records else None,
    }


def _metric_value(metric: str, records: tuple[PerformanceEvidence, ...]) -> float:
    n = len(records)
    if n == 0:
        raise ValueError("empty window")
    if metric == "mission_success_rate":
        hits = sum(
            1
            for record in records
            if record.mission_verification_status == "VERIFIED"
            and record.final_outcome == "SUCCESS"
        )
        return round(hits / n, 6)
    if metric == "verification_failure_rate":
        hits = sum(
            1
            for record in records
            if record.mission_verification_status
            in {"FAILED", "INSUFFICIENT_EVIDENCE"}
        )
        return round(hits / n, 6)
    if metric == "duration_ms":
        return round(sum(record.duration_ms for record in records) / n, 3)
    if metric == "replan_frequency":
        return round(sum((record.replan_attempt or 0) for record in records) / n, 6)
    raise ValueError(f"unsupported metric: {metric}")


def _classify(
    metric: str,
    baseline: float,
    current: float,
    thresholds: DriftThresholds,
) -> tuple[str, float, dict[str, Any]]:
    if metric == "mission_success_rate":
        delta = round(current - baseline, 6)
        worse = baseline - current
        applied = {
            "warning": thresholds.success_rate_warning_drop,
            "degraded": thresholds.success_rate_degraded_drop,
            "direction": "drop",
        }
        if worse >= thresholds.success_rate_degraded_drop:
            return "DEGRADED", delta, applied
        if worse >= thresholds.success_rate_warning_drop:
            return "WARNING", delta, applied
        return "STABLE", delta, applied
    if metric == "verification_failure_rate":
        delta = round(current - baseline, 6)
        applied = {
            "warning": thresholds.verification_failure_warning,
            "degraded": thresholds.verification_failure_degraded,
            "direction": "increase",
        }
        if delta >= thresholds.verification_failure_degraded:
            return "DEGRADED", delta, applied
        if delta >= thresholds.verification_failure_warning:
            return "WARNING", delta, applied
        return "STABLE", delta, applied
    if metric == "duration_ms":
        if baseline <= 0:
            delta = round(current - baseline, 3)
            applied = {
                "warning": thresholds.duration_warning_ratio,
                "degraded": thresholds.duration_degraded_ratio,
                "direction": "ratio",
            }
            if current > 0:
                return "DEGRADED", delta, applied
            return "STABLE", delta, applied
        ratio = current / baseline
        delta = round(current - baseline, 3)
        applied = {
            "warning": thresholds.duration_warning_ratio,
            "degraded": thresholds.duration_degraded_ratio,
            "direction": "ratio",
            "ratio": round(ratio, 6),
        }
        if ratio >= thresholds.duration_degraded_ratio:
            return "DEGRADED", delta, applied
        if ratio >= thresholds.duration_warning_ratio:
            return "WARNING", delta, applied
        return "STABLE", delta, applied
    if metric == "replan_frequency":
        delta = round(current - baseline, 6)
        applied = {
            "warning": thresholds.replan_warning_delta,
            "degraded": thresholds.replan_degraded_delta,
            "direction": "increase",
        }
        if delta >= thresholds.replan_degraded_delta:
            return "DEGRADED", delta, applied
        if delta >= thresholds.replan_warning_delta:
            return "WARNING", delta, applied
        return "STABLE", delta, applied
    raise ValueError(f"unsupported metric: {metric}")


def _insufficient(
    *,
    capability_id: str,
    mission_id: str | None,
    metric: str,
    thresholds: DriftThresholds,
    baseline_records: tuple[PerformanceEvidence, ...],
    current_records: tuple[PerformanceEvidence, ...],
    reason: str,
) -> DriftEvaluation:
    refs = tuple(
        record.record_id for record in (*baseline_records, *current_records)
    )
    return DriftEvaluation(
        evaluation_id=uuid.uuid4().hex,
        timestamp=_now(),
        capability_id=capability_id,
        mission_id=mission_id,
        metric=metric,
        baseline_window=_window(baseline_records),
        current_window=_window(current_records),
        baseline_value=None,
        current_value=None,
        delta=None,
        threshold=thresholds.as_dict(),
        status="INSUFFICIENT_EVIDENCE",
        evidence_refs=refs,
        config_version=thresholds.version,
        details={"reason": reason, "authority": False},
    )


def evaluate_drift(
    store: PerformanceStore,
    *,
    capability_id: str,
    metric: str,
    mission_id: str | None = None,
    thresholds: DriftThresholds | None = None,
    persist: bool = True,
    historical_records: tuple[Mapping[str, Any], ...] = (),
) -> DriftEvaluation:
    """Compare current FINAL evidence to a VERIFIED baseline.

    historical_records are accepted and discarded. History has zero authority.
    DEGRADED is a report only. This function does not change runtime state.
    """
    del historical_records
    if metric not in DRIFT_METRICS:
        raise ValueError(f"unsupported metric: {metric}")
    config = thresholds or DriftThresholds()
    try:
        records = store.checked_by_capability_id(capability_id)
    except StoreCorruptRecord as exc:
        raise DriftEvidenceFailed(f"STORE_CORRUPT_RECORD: {exc}") from exc
    if mission_id is not None:
        records = tuple(
            record for record in records if mission_id in record.mission_ids
        )

    finals = tuple(record for record in records if _is_final(record))
    verified = tuple(record for record in finals if _is_verified_final(record))
    baseline_records = verified[: config.min_baseline_samples]
    current_records = finals[-config.min_current_samples :] if finals else ()

    if len(verified) < config.min_baseline_samples:
        evaluation = _insufficient(
            capability_id=capability_id,
            mission_id=mission_id,
            metric=metric,
            thresholds=config,
            baseline_records=verified,
            current_records=current_records,
            reason="BASELINE_SAMPLE_BELOW_MINIMUM",
        )
    elif len(finals) < config.min_current_samples:
        evaluation = _insufficient(
            capability_id=capability_id,
            mission_id=mission_id,
            metric=metric,
            thresholds=config,
            baseline_records=baseline_records,
            current_records=finals,
            reason="CURRENT_SAMPLE_BELOW_MINIMUM",
        )
    else:
        baseline_value = _metric_value(metric, baseline_records)
        current_value = _metric_value(metric, current_records)
        status, delta, applied = _classify(
            metric, baseline_value, current_value, config
        )
        refs = tuple(
            dict.fromkeys(
                [record.record_id for record in baseline_records]
                + [record.record_id for record in current_records]
            )
        )
        evaluation = DriftEvaluation(
            evaluation_id=uuid.uuid4().hex,
            timestamp=_now(),
            capability_id=capability_id,
            mission_id=mission_id,
            metric=metric,
            baseline_window=_window(baseline_records),
            current_window=_window(current_records),
            baseline_value=baseline_value,
            current_value=current_value,
            delta=delta,
            threshold=applied,
            status=status,
            evidence_refs=refs,
            config_version=config.version,
            details={"authority": False, "config": config.as_dict()},
        )

    if persist:
        store.persist_drift_evaluation(evaluation.as_dict())
    return evaluation
