from __future__ import annotations

import hashlib
import json
import sqlite3

from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterator

from .reconciliation_contracts import (
    GapRecord,
)


SCHEMA_VERSION = 1


class GapStoreCorruptRecord(
    RuntimeError
):
    pass


@dataclass(frozen=True)
class ObservedGap:
    fingerprint: str
    subject_ref: str
    gap_type: str
    occurrence_count: int
    first_seen_at: str
    last_seen_at: str
    latest_gap_id: str
    latest_reconciliation_id: str
    severity: str
    confidence: str
    reason_codes: tuple[str, ...]
    evidence_refs: tuple[str, ...]


def _canonical_json(
    value: Any,
) -> str:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )


def gap_fingerprint(
    gap: GapRecord,
) -> str:
    reason_scope = ",".join(
        sorted(
            set(
                gap.reason_codes
            )
        )
    )

    material = "|".join(
        (
            gap.subject_ref,
            gap.gap_type.value,
            reason_scope,
        )
    )

    return (
        "GF-"
        + hashlib.sha256(
            material.encode(
                "utf-8"
            )
        ).hexdigest()[:24]
    )


def observation_key(
    gap: GapRecord,
) -> str:
    material = _canonical_json(
        gap.as_dict()
    )

    return (
        "GO-"
        + hashlib.sha256(
            material.encode(
                "utf-8"
            )
        ).hexdigest()
    )


class GapStore:
    def __init__(
        self,
        path: str | Path,
    ) -> None:
        self.path = Path(
            path
        )

        self.path.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        self._init_schema()


    def _open_connection(
        self,
    ) -> sqlite3.Connection:
        connection = sqlite3.connect(
            str(
                self.path
            ),
            timeout=30.0,
        )

        connection.row_factory = (
            sqlite3.Row
        )

        return connection


    @contextmanager
    def _connection(
        self,
    ) -> Iterator[
        sqlite3.Connection
    ]:
        connection = (
            self._open_connection()
        )

        try:
            yield connection
            connection.commit()

        except BaseException:
            connection.rollback()
            raise

        finally:
            connection.close()


    def _init_schema(
        self,
    ) -> None:
        with self._connection() as db:
            db.execute(
                """
                CREATE TABLE IF NOT EXISTS gap_observations (
                    sequence INTEGER PRIMARY KEY AUTOINCREMENT,
                    schema_version INTEGER NOT NULL,
                    observation_key TEXT NOT NULL UNIQUE,
                    fingerprint TEXT NOT NULL,
                    gap_id TEXT NOT NULL,
                    reconciliation_id TEXT NOT NULL,
                    subject_ref TEXT NOT NULL,
                    gap_type TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    confidence TEXT NOT NULL,
                    detected_at TEXT NOT NULL,
                    reason_codes_json TEXT NOT NULL,
                    evidence_refs_json TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    previous_hash TEXT NOT NULL,
                    record_hash TEXT NOT NULL UNIQUE
                )
                """
            )

            db.execute(
                """
                CREATE INDEX IF NOT EXISTS
                idx_gap_observations_fingerprint
                ON gap_observations(fingerprint)
                """
            )


    def append(
        self,
        gap: GapRecord,
    ) -> str:
        fingerprint = (
            gap_fingerprint(
                gap
            )
        )

        obs_key = (
            observation_key(
                gap
            )
        )

        payload = (
            gap.as_dict()
        )

        payload_json = (
            _canonical_json(
                payload
            )
        )

        reason_codes_json = (
            _canonical_json(
                list(
                    gap.reason_codes
                )
            )
        )

        evidence_refs_json = (
            _canonical_json(
                list(
                    gap.evidence_refs
                )
            )
        )

        with self._connection() as db:
            db.execute(
                "BEGIN IMMEDIATE"
            )

            existing = db.execute(
                """
                SELECT record_hash
                FROM gap_observations
                WHERE observation_key = ?
                """,
                (
                    obs_key,
                ),
            ).fetchone()

            if existing is not None:
                return str(
                    existing[
                        "record_hash"
                    ]
                )

            previous = db.execute(
                """
                SELECT record_hash
                FROM gap_observations
                ORDER BY sequence DESC
                LIMIT 1
                """
            ).fetchone()

            previous_hash = (
                str(
                    previous[
                        "record_hash"
                    ]
                )
                if previous
                else "GENESIS"
            )

            material = (
                _canonical_json(
                    {
                        "schema_version": (
                            SCHEMA_VERSION
                        ),
                        "observation_key": (
                            obs_key
                        ),
                        "fingerprint": (
                            fingerprint
                        ),
                        "gap_id": (
                            gap.gap_id
                        ),
                        "reconciliation_id": (
                            gap.reconciliation_id
                        ),
                        "subject_ref": (
                            gap.subject_ref
                        ),
                        "gap_type": (
                            gap.gap_type.value
                        ),
                        "severity": (
                            gap.severity.value
                        ),
                        "confidence": (
                            gap.confidence.value
                        ),
                        "detected_at": (
                            gap.detected_at
                        ),
                        "reason_codes": list(
                            gap.reason_codes
                        ),
                        "evidence_refs": list(
                            gap.evidence_refs
                        ),
                        "payload": (
                            payload
                        ),
                        "previous_hash": (
                            previous_hash
                        ),
                    }
                )
            )

            record_hash = (
                hashlib.sha256(
                    material.encode(
                        "utf-8"
                    )
                ).hexdigest()
            )

            db.execute(
                """
                INSERT INTO gap_observations (
                    schema_version,
                    observation_key,
                    fingerprint,
                    gap_id,
                    reconciliation_id,
                    subject_ref,
                    gap_type,
                    severity,
                    confidence,
                    detected_at,
                    reason_codes_json,
                    evidence_refs_json,
                    payload_json,
                    previous_hash,
                    record_hash
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    SCHEMA_VERSION,
                    obs_key,
                    fingerprint,
                    gap.gap_id,
                    gap.reconciliation_id,
                    gap.subject_ref,
                    gap.gap_type.value,
                    gap.severity.value,
                    gap.confidence.value,
                    gap.detected_at,
                    reason_codes_json,
                    evidence_refs_json,
                    payload_json,
                    previous_hash,
                    record_hash,
                ),
            )

            return (
                record_hash
            )


    def append_many(
        self,
        gaps: tuple[
            GapRecord,
            ...,
        ],
    ) -> tuple[str, ...]:
        return tuple(
            self.append(
                gap
            )
            for gap in gaps
        )


    def observation_count(
        self,
    ) -> int:
        with self._connection() as db:
            row = db.execute(
                """
                SELECT COUNT(*) AS count
                FROM gap_observations
                """
            ).fetchone()

            return int(
                row[
                    "count"
                ]
            )


    def observed_gaps(
        self,
    ) -> tuple[
        ObservedGap,
        ...,
    ]:
        with self._connection() as db:
            rows = db.execute(
                """
                SELECT *
                FROM gap_observations
                ORDER BY sequence ASC
                """
            ).fetchall()

        grouped: dict[
            str,
            list[
                sqlite3.Row
            ],
        ] = {}

        for row in rows:
            grouped.setdefault(
                str(
                    row[
                        "fingerprint"
                    ]
                ),
                [],
            ).append(
                row
            )

        result: list[
            ObservedGap
        ] = []

        for (
            fingerprint,
            group,
        ) in grouped.items():
            first = group[0]
            latest = group[-1]

            reasons: set[str] = set()
            evidence: set[str] = set()

            for row in group:
                reasons.update(
                    str(
                        item
                    )
                    for item in json.loads(
                        str(
                            row[
                                "reason_codes_json"
                            ]
                        )
                    )
                )

                evidence.update(
                    str(
                        item
                    )
                    for item in json.loads(
                        str(
                            row[
                                "evidence_refs_json"
                            ]
                        )
                    )
                )

            result.append(
                ObservedGap(
                    fingerprint=(
                        fingerprint
                    ),
                    subject_ref=str(
                        latest[
                            "subject_ref"
                        ]
                    ),
                    gap_type=str(
                        latest[
                            "gap_type"
                        ]
                    ),
                    occurrence_count=(
                        len(
                            group
                        )
                    ),
                    first_seen_at=str(
                        first[
                            "detected_at"
                        ]
                    ),
                    last_seen_at=str(
                        latest[
                            "detected_at"
                        ]
                    ),
                    latest_gap_id=str(
                        latest[
                            "gap_id"
                        ]
                    ),
                    latest_reconciliation_id=str(
                        latest[
                            "reconciliation_id"
                        ]
                    ),
                    severity=str(
                        latest[
                            "severity"
                        ]
                    ),
                    confidence=str(
                        latest[
                            "confidence"
                        ]
                    ),
                    reason_codes=tuple(
                        sorted(
                            reasons
                        )
                    ),
                    evidence_refs=tuple(
                        sorted(
                            evidence
                        )
                    ),
                )
            )

        return tuple(
            sorted(
                result,
                key=lambda item: (
                    item.fingerprint
                ),
            )
        )


    def verify_integrity(
        self,
    ) -> None:
        with self._connection() as db:
            rows = db.execute(
                """
                SELECT *
                FROM gap_observations
                ORDER BY sequence ASC
                """
            ).fetchall()

        expected_previous = (
            "GENESIS"
        )

        seen_observations: set[
            str
        ] = set()

        for row in rows:
            actual_previous = str(
                row[
                    "previous_hash"
                ]
            )

            if (
                actual_previous
                != expected_previous
            ):
                raise GapStoreCorruptRecord(
                    "HASH_CHAIN_PREVIOUS_MISMATCH"
                )

            payload = json.loads(
                str(
                    row[
                        "payload_json"
                    ]
                )
            )

            calculated_observation_key = (
                "GO-"
                + hashlib.sha256(
                    _canonical_json(
                        payload
                    ).encode(
                        "utf-8"
                    )
                ).hexdigest()
            )

            stored_observation_key = str(
                row[
                    "observation_key"
                ]
            )

            if (
                calculated_observation_key
                != stored_observation_key
            ):
                raise GapStoreCorruptRecord(
                    "OBSERVATION_KEY_MISMATCH"
                )

            if (
                stored_observation_key
                in seen_observations
            ):
                raise GapStoreCorruptRecord(
                    "DUPLICATE_OBSERVATION_KEY"
                )

            seen_observations.add(
                stored_observation_key
            )

            material = (
                _canonical_json(
                    {
                        "schema_version": int(
                            row[
                                "schema_version"
                            ]
                        ),
                        "observation_key": (
                            stored_observation_key
                        ),
                        "fingerprint": str(
                            row[
                                "fingerprint"
                            ]
                        ),
                        "gap_id": str(
                            row[
                                "gap_id"
                            ]
                        ),
                        "reconciliation_id": str(
                            row[
                                "reconciliation_id"
                            ]
                        ),
                        "subject_ref": str(
                            row[
                                "subject_ref"
                            ]
                        ),
                        "gap_type": str(
                            row[
                                "gap_type"
                            ]
                        ),
                        "severity": str(
                            row[
                                "severity"
                            ]
                        ),
                        "confidence": str(
                            row[
                                "confidence"
                            ]
                        ),
                        "detected_at": str(
                            row[
                                "detected_at"
                            ]
                        ),
                        "reason_codes": json.loads(
                            str(
                                row[
                                    "reason_codes_json"
                                ]
                            )
                        ),
                        "evidence_refs": json.loads(
                            str(
                                row[
                                    "evidence_refs_json"
                                ]
                            )
                        ),
                        "payload": (
                            payload
                        ),
                        "previous_hash": (
                            actual_previous
                        ),
                    }
                )
            )

            calculated_hash = (
                hashlib.sha256(
                    material.encode(
                        "utf-8"
                    )
                ).hexdigest()
            )

            stored_hash = str(
                row[
                    "record_hash"
                ]
            )

            if (
                calculated_hash
                != stored_hash
            ):
                raise GapStoreCorruptRecord(
                    "HASH_CHAIN_RECORD_MISMATCH"
                )

            expected_previous = (
                stored_hash
            )
