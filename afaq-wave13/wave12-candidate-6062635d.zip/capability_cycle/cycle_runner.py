"""Task-first Minimum Viable Execution Cycle.

Does not know:
- engine registry
- engine ids
- provider implementation
- evidence backend
- state backend
- learning
- genesis
- training
- promotion
"""

from __future__ import annotations

import time

from dataclasses import (
    dataclass,
    field,
)
from typing import (
    Any,
    Callable,
    Mapping,
)

from .cycle_core import (
    CycleState,
    new_execution_cycle,
    outcome_delta,
    stable_digest,
)
from .cycle_ports import (
    CycleStatePort,
    EvidencePort,
)


Executor = Callable[
    [Mapping[str, Any]],
    Mapping[str, Any],
]


@dataclass(frozen=True)
class ExecutionCycleRequest:
    task: str

    payload: dict[str, Any] = field(
        default_factory=dict
    )

    context: dict[str, Any] = field(
        default_factory=dict
    )

    required_capabilities: (
        tuple[str, ...]
    ) = ()

    expected_outcome: (
        dict[str, Any]
    ) = field(
        default_factory=dict
    )

    cycle_id: (
        str | None
    ) = None

    parent_cycle_id: (
        str | None
    ) = None

    environment: str = "local"


class CycleRunner:
    def __init__(
        self,
        *,
        state_port: CycleStatePort,
        evidence_port: EvidencePort,
    ) -> None:
        self.state_port = state_port
        self.evidence_port = evidence_port

    def run(
        self,
        request: ExecutionCycleRequest,
        *,
        decision: Mapping[str, Any],
        executor: Executor,
    ) -> dict[str, Any]:
        cycle = new_execution_cycle(
            task=request.task,
            context=request.context,
            required_capabilities=(
                request.required_capabilities
            ),
            expected_outcome=(
                request.expected_outcome
            ),
            cycle_id=request.cycle_id,
            parent_cycle_id=(
                request.parent_cycle_id
            ),
        )

        persisted_version: (
            int | None
        ) = None

        event_sequence = 0

        last_event_id: (
            str | None
        ) = None

        def save() -> None:
            nonlocal persisted_version

            self.state_port.save(
                cycle,
                expected_previous_version=(
                    persisted_version
                ),
            )

            persisted_version = (
                cycle.state_version
            )

        def emit(
            event_type: str,
            payload: (
                Mapping[str, Any]
                | None
            ) = None,
        ) -> dict[str, Any]:
            nonlocal event_sequence, last_event_id

            event_sequence += 1

            receipt = (
                self.evidence_port
                .append_event(
                    cycle_id=(
                        cycle.cycle_id
                    ),
                    event_type=(
                        event_type
                    ),
                    event_sequence=(
                        event_sequence
                    ),
                    state=(
                        cycle.state.value
                    ),
                    payload=payload,
                    environment=(
                        request.environment
                    ),
                    parent_event_id=(
                        last_event_id
                    ),
                    causation_id=(
                        last_event_id
                    ),
                    correlation_id=(
                        cycle.cycle_id
                    ),
                )
            )

            last_event_id = (
                receipt.event_id
            )

            ref = (
                receipt.as_dict()
            )

            cycle.evidence_refs.append(
                ref
            )

            return ref

        save()

        emit(
            "CYCLE_CREATED",
            {
                "cycle_type": (
                    cycle.cycle_type
                ),
                "task": cycle.task,
                "context_fingerprint": (
                    cycle.context_fingerprint
                ),
                "required_capabilities": (
                    cycle.required_capabilities
                ),
            },
        )

        cycle.transition(
            CycleState.OBSERVED
        )

        save()

        emit(
            "CONTEXT_OBSERVED",
            {
                "context_fingerprint": (
                    cycle.context_fingerprint
                ),
                "expected_outcome": (
                    cycle.expected_outcome
                ),
            },
        )

        normalized_decision = dict(
            decision
        )

        cycle.decisions.append(
            normalized_decision
        )

        cycle.transition(
            CycleState.DECIDED
        )

        save()

        emit(
            "DECISION_RECORDED",
            normalized_decision,
        )

        cycle.transition(
            CycleState.EXECUTING
        )

        save()

        emit(
            "EXECUTION_STARTED",
            {
                "payload_digest": (
                    stable_digest(
                        request.payload
                    )
                ),
            },
        )

        started = time.perf_counter()

        execution_error: (
            str | None
        ) = None

        try:
            raw_result = dict(
                executor(
                    dict(
                        request.payload
                    )
                )
            )

        except Exception as exc:
            raw_result = {}

            execution_error = (
                f"{type(exc).__name__}: "
                f"{exc}"
            )

        elapsed_ms = round(
            (
                time.perf_counter()
                - started
            )
            * 1000.0,
            3,
        )

        if execution_error is None:
            ok = bool(
                raw_result.get(
                    "ok",
                    False,
                )
            )

            executed = bool(
                raw_result.get(
                    "executed",
                    ok,
                )
            )

            cycle.actual_outcome = {
                "status": (
                    "SUCCESS"
                    if ok
                    else "FAILURE"
                ),
                "ok": ok,
                "executed": executed,
                "latency_ms": (
                    raw_result.get(
                        "elapsed_ms",
                        elapsed_ms,
                    )
                ),
            }

            cycle.outcome_delta = (
                outcome_delta(
                    cycle.expected_outcome,
                    cycle.actual_outcome,
                )
            )

            cycle.execution_refs.append(
                {
                    "result_digest": (
                        stable_digest(
                            raw_result
                        )
                    ),
                    "run_path": (
                        raw_result.get(
                            "run_path"
                        )
                    ),
                }
            )

            cycle.transition(
                CycleState.OUTCOME_OBSERVED
            )

            save()

            emit(
                "OUTCOME_OBSERVED",
                {
                    "expected_outcome": (
                        cycle.expected_outcome
                    ),
                    "actual_outcome": (
                        cycle.actual_outcome
                    ),
                    "outcome_delta": (
                        cycle.outcome_delta
                    ),
                    "execution_ref": (
                        cycle.execution_refs[
                            -1
                        ]
                    ),
                },
            )

            cycle.transition(
                CycleState.EVIDENCE_RECORDED
            )

            save()

            emit(
                "EVIDENCE_RECORDED",
                {
                    "learning_eligible": False,
                    "reason": (
                        "foundation milestone "
                        "records evidence only"
                    ),
                },
            )

            cycle.transition(
                (
                    CycleState.CLOSED_SUCCESS
                    if ok
                    else CycleState.CLOSED_FAILED
                )
            )

        else:
            cycle.actual_outcome = {
                "status": "FAILURE",
                "ok": False,
                "executed": False,
                "latency_ms": (
                    elapsed_ms
                ),
                "error": (
                    execution_error
                ),
            }

            cycle.outcome_delta = (
                outcome_delta(
                    cycle.expected_outcome,
                    cycle.actual_outcome,
                )
            )

            cycle.transition(
                CycleState.FAILED
            )

            save()

            emit(
                "EXECUTION_FAILED",
                {
                    "actual_outcome": (
                        cycle.actual_outcome
                    ),
                    "outcome_delta": (
                        cycle.outcome_delta
                    ),
                },
            )

            cycle.transition(
                CycleState.CLOSED_FAILED
            )

        save()

        emit(
            "CYCLE_CLOSED",
            {
                "closure": (
                    cycle.state.value
                ),
                "learning_activated": False,
                "training_activated": False,
                "genesis_activated": False,
                "policy_updated": False,
                "promotion_activated": False,
                "publish_activated": False,
            },
        )

        # Same state version, but new evidence ref was appended.
        self.state_port.save(
            cycle,
            expected_previous_version=(
                cycle.state_version
            ),
        )

        return {
            "ok": (
                cycle.state
                is CycleState.CLOSED_SUCCESS
            ),
            "cycle": (
                cycle.as_dict()
            ),
            "result": (
                raw_result
            ),
            "autonomy": {
                "learning_activated": False,
                "training_activated": False,
                "genesis_activated": False,
                "policy_updated": False,
                "promotion_activated": False,
                "publish_activated": False,
            },
        }
