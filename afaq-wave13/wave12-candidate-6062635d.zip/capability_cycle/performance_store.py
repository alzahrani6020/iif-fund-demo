"""Append-only persisted performance evidence for the capability runtime.

Inert data only. Writes do not rank, route, learn, train, promote, or genesis.
TELEMETRY != PERFORMANCE EVIDENCE.
Does not use MemoryService or the host AuditLedger (incompatible contracts).
Reuses the local SHA256 hash-chain pattern from the host audit ledger.
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from threading import RLock
from typing import Any, Mapping

from .telemetry import redact

SCHEMA_VERSION = 1

RECORD_KINDS = frozenset({"INTERMEDIATE", "FAILED", "REPLANNED", "FINAL"})
DURATION_SCOPES = frozenset({"capability_execution", "mission_cycle"})
LIVE_PERFORMANCE_STORE_FILENAME = "capability_performance.db"


def live_performance_store_path(var_dir: str | Path) -> Path:
    """Dedicated live evidence file. Do not mix into aic_runtime/aic_audit."""
    return Path(var_dir) / LIVE_PERFORMANCE_STORE_FILENAME


class StoreWriteFailed(RuntimeError):
    pass


class StoreReadFailed(RuntimeError):
    pass


class StoreCorruptRecord(RuntimeError):
    pass


class StoreSchemaMismatch(RuntimeError):
    pass


_SCHEMA = """
CREATE TABLE IF NOT EXISTS schema_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS performance_evidence (
    record_id TEXT PRIMARY KEY,
    schema_version INTEGER NOT NULL,
    correlation_id TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    record_kind TEXT NOT NULL,
    mission_ids TEXT NOT NULL,
    plan_ids TEXT NOT NULL,
    original_plan_ids TEXT,
    capability_id TEXT,
    capability_version TEXT,
    attempt INTEGER,
    replan_attempt INTEGER,
    execution_outcome TEXT,
    mission_verification_status TEXT,
    mission_verification_reason TEXT,
    failure_class TEXT,
    duration_ms REAL NOT NULL,
    duration_scope TEXT NOT NULL,
    sandbox_status TEXT,
    certification_status TEXT,
    authority_refs TEXT,
    evidence_refs TEXT,
    final_outcome TEXT,
    learning_activated INTEGER NOT NULL DEFAULT 0,
    training_activated INTEGER NOT NULL DEFAULT 0,
    auto_promoted INTEGER NOT NULL DEFAULT 0,
    prev_hash TEXT,
    entry_hash TEXT NOT NULL,
    payload TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS perf_corr_idx
    ON performance_evidence (correlation_id, timestamp);
CREATE INDEX IF NOT EXISTS perf_cap_idx
    ON performance_evidence (capability_id, timestamp);
CREATE TABLE IF NOT EXISTS drift_evaluations (
    evaluation_id TEXT PRIMARY KEY,
    timestamp TEXT NOT NULL,
    capability_id TEXT NOT NULL,
    mission_id TEXT,
    metric TEXT NOT NULL,
    baseline_window TEXT NOT NULL,
    current_window TEXT NOT NULL,
    baseline_value REAL,
    current_value REAL,
    delta REAL,
    threshold_json TEXT NOT NULL,
    status TEXT NOT NULL,
    evidence_refs TEXT NOT NULL,
    config_version INTEGER NOT NULL,
    learning_activated INTEGER NOT NULL DEFAULT 0,
    training_activated INTEGER NOT NULL DEFAULT 0,
    auto_promoted INTEGER NOT NULL DEFAULT 0,
    entry_hash TEXT NOT NULL,
    payload TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS drift_cap_idx
    ON drift_evaluations (capability_id, timestamp);
CREATE TABLE IF NOT EXISTS capability_snapshots (
    snapshot_id TEXT PRIMARY KEY,
    capability_id TEXT NOT NULL,
    version_id TEXT NOT NULL,
    artifact_hash TEXT NOT NULL,
    artifact_blob TEXT NOT NULL,
    implementation_reference TEXT NOT NULL,
    provenance TEXT NOT NULL,
    sandbox_validation_reference TEXT,
    certification_reference TEXT,
    created_at TEXT NOT NULL,
    source_runtime_identity TEXT,
    status TEXT NOT NULL,
    evidence_refs TEXT NOT NULL,
    entry_hash TEXT NOT NULL,
    payload TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS snap_cap_idx
    ON capability_snapshots (capability_id, created_at);
CREATE TABLE IF NOT EXISTS capability_bindings (
    capability_id TEXT PRIMARY KEY,
    snapshot_id TEXT NOT NULL,
    version_id TEXT NOT NULL,
    artifact_hash TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS capability_restores (
    rollback_id TEXT PRIMARY KEY,
    correlation_id TEXT NOT NULL,
    capability_id TEXT NOT NULL,
    from_version TEXT,
    to_version TEXT,
    reason TEXT,
    drift_evaluation_id TEXT,
    authority_result TEXT,
    snapshot_id TEXT,
    snapshot_hash TEXT,
    restore_result TEXT NOT NULL,
    post_restore_verification TEXT,
    timestamp TEXT NOT NULL,
    entry_hash TEXT NOT NULL,
    payload TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS learning_observations (
    learning_observation_id TEXT PRIMARY KEY,
    capability_id TEXT NOT NULL,
    artifact_hash TEXT,
    evidence_scope TEXT NOT NULL,
    evidence_refs TEXT NOT NULL,
    sample_count INTEGER NOT NULL,
    observation_type TEXT NOT NULL,
    finding TEXT NOT NULL,
    observed_facts TEXT NOT NULL,
    derived_inference TEXT NOT NULL,
    confidence TEXT NOT NULL,
    created_at TEXT NOT NULL,
    drift_evaluation_ref TEXT,
    entry_hash TEXT NOT NULL,
    payload TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS learn_obs_cap_idx
    ON learning_observations (capability_id, created_at);
CREATE TABLE IF NOT EXISTS improvement_proposals (
    proposal_id TEXT PRIMARY KEY,
    source_learning_observation_id TEXT NOT NULL,
    target_capability_id TEXT NOT NULL,
    target_artifact_hash TEXT,
    problem_statement TEXT NOT NULL,
    evidence_refs TEXT NOT NULL,
    proposed_change_type TEXT NOT NULL,
    expected_outcome TEXT NOT NULL,
    acceptance_criteria TEXT NOT NULL,
    risk TEXT NOT NULL,
    confidence TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL,
    entry_hash TEXT NOT NULL,
    payload TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS learn_prop_cap_idx
    ON improvement_proposals (target_capability_id, created_at);
CREATE TABLE IF NOT EXISTS proposal_evaluations (
    proposal_evaluation_id TEXT PRIMARY KEY,
    proposal_id TEXT NOT NULL,
    source_learning_observation_id TEXT NOT NULL,
    target_capability_id TEXT NOT NULL,
    target_artifact_hash TEXT,
    evidence_refs TEXT NOT NULL,
    evidence_sufficiency TEXT NOT NULL,
    scope_assessment TEXT NOT NULL,
    risk_assessment TEXT NOT NULL,
    acceptance_criteria_quality TEXT NOT NULL,
    expected_outcome_assessment TEXT NOT NULL,
    status TEXT NOT NULL,
    reason TEXT NOT NULL,
    reviewer_identity TEXT NOT NULL,
    created_at TEXT NOT NULL,
    entry_hash TEXT NOT NULL,
    payload TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS learn_eval_prop_idx
    ON proposal_evaluations (proposal_id, created_at);
CREATE TABLE IF NOT EXISTS improvement_comparisons (
    comparison_id TEXT PRIMARY KEY,
    target_capability_id TEXT NOT NULL,
    baseline_artifact_hash TEXT,
    candidate_artifact_hash TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL,
    entry_hash TEXT NOT NULL,
    payload TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS learn_cmp_cap_idx
    ON improvement_comparisons (target_capability_id, created_at);
CREATE TABLE IF NOT EXISTS training_datasets (
    dataset_id TEXT PRIMARY KEY,
    content_hash TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL,
    entry_hash TEXT NOT NULL,
    payload TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS training_dataset_validations (
    validation_id TEXT PRIMARY KEY,
    dataset_id TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL,
    entry_hash TEXT NOT NULL,
    payload TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS training_job_specs (
    training_job_id TEXT PRIMARY KEY,
    dataset_id TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL,
    entry_hash TEXT NOT NULL,
    payload TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS capability_replacements (
    replacement_id TEXT PRIMARY KEY,
    comparison_id TEXT NOT NULL,
    target_capability_id TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL,
    entry_hash TEXT NOT NULL,
    payload TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS model_performance_profiles (
    profile_id TEXT PRIMARY KEY,
    subject_id TEXT NOT NULL,
    version TEXT,
    profile_hash TEXT NOT NULL,
    created_at TEXT NOT NULL,
    entry_hash TEXT NOT NULL,
    payload TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS model_perf_subject_idx
    ON model_performance_profiles (subject_id, created_at);
CREATE TABLE IF NOT EXISTS runtime_benchmarks (
    benchmark_id TEXT PRIMARY KEY,
    subject_id TEXT NOT NULL,
    benchmark_hash TEXT NOT NULL,
    created_at TEXT NOT NULL,
    entry_hash TEXT NOT NULL,
    payload TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS runtime_bench_subject_idx
    ON runtime_benchmarks (subject_id, created_at);
CREATE TABLE IF NOT EXISTS performance_selection_feedback (
    feedback_id TEXT PRIMARY KEY,
    mission_type TEXT,
    selected_subject TEXT NOT NULL,
    outcome TEXT NOT NULL,
    score REAL,
    created_at TEXT NOT NULL,
    entry_hash TEXT NOT NULL,
    payload TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS perf_select_subject_idx
    ON performance_selection_feedback (selected_subject, created_at);

CREATE TABLE IF NOT EXISTS post_replacement_decisions (
    decision_id TEXT PRIMARY KEY,
    replacement_id TEXT NOT NULL,
    target_capability_id TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL,
    entry_hash TEXT NOT NULL,
    payload TEXT NOT NULL
);
"""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _canonical(value: Any) -> str:
    return json.dumps(redact(value), sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def _hash_entry(payload: Mapping[str, Any], prev_hash: str | None) -> str:
    blob = _canonical({"prev_hash": prev_hash or "", "record": payload})
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class PerformanceEvidence:
    record_id: str
    schema_version: int
    correlation_id: str
    timestamp: str
    record_kind: str
    mission_ids: tuple[str, ...]
    plan_ids: tuple[str, ...]
    original_plan_ids: tuple[str, ...]
    capability_id: str | None
    capability_version: str | None
    attempt: int | None
    replan_attempt: int | None
    execution_outcome: str | None
    mission_verification_status: str | None
    mission_verification_reason: str | None
    failure_class: str | None
    duration_ms: float
    duration_scope: str
    sandbox_status: str | None
    certification_status: str | None
    authority_refs: tuple[str, ...]
    evidence_refs: tuple[str, ...]
    final_outcome: str | None
    learning_activated: bool
    training_activated: bool
    auto_promoted: bool
    prev_hash: str | None
    entry_hash: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "record_id": self.record_id,
            "schema_version": self.schema_version,
            "correlation_id": self.correlation_id,
            "timestamp": self.timestamp,
            "record_kind": self.record_kind,
            "mission_ids": list(self.mission_ids),
            "plan_ids": list(self.plan_ids),
            "original_plan_ids": list(self.original_plan_ids),
            "capability_id": self.capability_id,
            "capability_version": self.capability_version,
            "attempt": self.attempt,
            "replan_attempt": self.replan_attempt,
            "execution_outcome": self.execution_outcome,
            "mission_verification_status": self.mission_verification_status,
            "mission_verification_reason": self.mission_verification_reason,
            "failure_class": self.failure_class,
            "duration_ms": self.duration_ms,
            "duration_scope": self.duration_scope,
            "sandbox_status": self.sandbox_status,
            "certification_status": self.certification_status,
            "authority_refs": list(self.authority_refs),
            "evidence_refs": list(self.evidence_refs),
            "final_outcome": self.final_outcome,
            "learning_activated": self.learning_activated,
            "training_activated": self.training_activated,
            "auto_promoted": self.auto_promoted,
            "prev_hash": self.prev_hash,
            "entry_hash": self.entry_hash,
        }


def _row_to_evidence(row: sqlite3.Row) -> PerformanceEvidence:
    payload = json.loads(row["payload"])
    return PerformanceEvidence(
        record_id=row["record_id"],
        schema_version=int(row["schema_version"]),
        correlation_id=row["correlation_id"],
        timestamp=row["timestamp"],
        record_kind=row["record_kind"],
        mission_ids=tuple(payload.get("mission_ids") or []),
        plan_ids=tuple(payload.get("plan_ids") or []),
        original_plan_ids=tuple(payload.get("original_plan_ids") or []),
        capability_id=row["capability_id"],
        capability_version=row["capability_version"],
        attempt=row["attempt"],
        replan_attempt=row["replan_attempt"],
        execution_outcome=row["execution_outcome"],
        mission_verification_status=row["mission_verification_status"],
        mission_verification_reason=row["mission_verification_reason"],
        failure_class=row["failure_class"],
        duration_ms=round(float(row["duration_ms"]), 3),
        duration_scope=row["duration_scope"],
        sandbox_status=row["sandbox_status"],
        certification_status=row["certification_status"],
        authority_refs=tuple(payload.get("authority_refs") or []),
        evidence_refs=tuple(payload.get("evidence_refs") or []),
        final_outcome=row["final_outcome"],
        learning_activated=bool(row["learning_activated"]),
        training_activated=bool(row["training_activated"]),
        auto_promoted=bool(row["auto_promoted"]),
        prev_hash=row["prev_hash"],
        entry_hash=row["entry_hash"],
    )


class PerformanceStore:
    def __init__(self, path: str | Path = ":memory:") -> None:
        self.path = str(path)
        self._lock = RLock()
        try:
            if self.path != ":memory:":
                Path(self.path).parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(
                self.path, check_same_thread=False, isolation_level=None
            )
            self._conn.row_factory = sqlite3.Row
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.executescript(_SCHEMA)
            self._check_schema()
        except StoreSchemaMismatch:
            self.close()
            raise
        except sqlite3.Error as exc:
            if getattr(self, "_conn", None) is not None:
                self.close()
            raise StoreWriteFailed(f"STORE_WRITE_FAILED: {exc}") from exc

    def _check_schema(self) -> None:
        row = self._conn.execute(
            "SELECT value FROM schema_meta WHERE key='schema_version'"
        ).fetchone()
        if row is None:
            self._conn.execute(
                "INSERT INTO schema_meta(key, value) VALUES ('schema_version', ?)",
                (str(SCHEMA_VERSION),),
            )
            return
        current = int(row["value"])
        if current != SCHEMA_VERSION:
            raise StoreSchemaMismatch(
                f"STORE_SCHEMA_MISMATCH: store={current} expected={SCHEMA_VERSION}"
            )

    def _head_hash(self) -> str | None:
        row = self._conn.execute(
            "SELECT entry_hash FROM performance_evidence ORDER BY timestamp DESC, record_id DESC LIMIT 1"
        ).fetchone()
        return row["entry_hash"] if row else None

    def append(self, record: Mapping[str, Any]) -> PerformanceEvidence:
        kind = str(record.get("record_kind") or "")
        scope = str(record.get("duration_scope") or "")
        duration = record.get("duration_ms")
        if kind not in RECORD_KINDS:
            raise StoreWriteFailed(f"STORE_WRITE_FAILED: invalid record_kind={kind}")
        if scope not in DURATION_SCOPES:
            raise StoreWriteFailed(f"STORE_WRITE_FAILED: invalid duration_scope={scope}")
        if duration is None:
            raise StoreWriteFailed("STORE_WRITE_FAILED: duration_ms required")
        try:
            duration_ms = float(duration)
        except (TypeError, ValueError) as exc:
            raise StoreWriteFailed("STORE_WRITE_FAILED: duration_ms invalid") from exc
        if duration_ms < 0:
            raise StoreWriteFailed("STORE_WRITE_FAILED: duration_ms must be >= 0")
        duration_ms = round(duration_ms, 3)
        if kind == "FINAL" and record.get("final_outcome") == "SUCCESS":
            if record.get("mission_verification_status") != "VERIFIED":
                raise StoreWriteFailed(
                    "STORE_WRITE_FAILED: FINAL SUCCESS requires mission VERIFIED"
                )

        record_id = str(record.get("record_id") or uuid.uuid4().hex)
        payload = {
            "mission_ids": list(record.get("mission_ids") or ()),
            "plan_ids": list(record.get("plan_ids") or ()),
            "original_plan_ids": list(record.get("original_plan_ids") or ()),
            "authority_refs": list(record.get("authority_refs") or ()),
            "evidence_refs": list(redact(record.get("evidence_refs") or ())),
        }
        body = {
            "record_id": record_id,
            "schema_version": SCHEMA_VERSION,
            "correlation_id": record["correlation_id"],
            "timestamp": record.get("timestamp") or _now(),
            "record_kind": kind,
            "capability_id": record.get("capability_id"),
            "capability_version": record.get("capability_version"),
            "attempt": record.get("attempt"),
            "replan_attempt": record.get("replan_attempt"),
            "execution_outcome": record.get("execution_outcome"),
            "mission_verification_status": record.get("mission_verification_status"),
            "mission_verification_reason": record.get("mission_verification_reason"),
            "failure_class": record.get("failure_class"),
            "duration_ms": duration_ms,
            "duration_scope": scope,
            "sandbox_status": record.get("sandbox_status"),
            "certification_status": record.get("certification_status"),
            "final_outcome": record.get("final_outcome"),
            "learning_activated": False,
            "training_activated": False,
            "auto_promoted": False,
            "payload": payload,
        }
        with self._lock:
            prev = self._head_hash()
            entry_hash = _hash_entry(body, prev)
            try:
                self._conn.execute(
                    """
                    INSERT INTO performance_evidence (
                        record_id, schema_version, correlation_id, timestamp,
                        record_kind, mission_ids, plan_ids, original_plan_ids,
                        capability_id, capability_version, attempt, replan_attempt,
                        execution_outcome, mission_verification_status,
                        mission_verification_reason, failure_class, duration_ms,
                        duration_scope, sandbox_status, certification_status,
                        authority_refs, evidence_refs, final_outcome,
                        learning_activated, training_activated, auto_promoted,
                        prev_hash, entry_hash, payload
                    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    """,
                    (
                        record_id,
                        SCHEMA_VERSION,
                        body["correlation_id"],
                        body["timestamp"],
                        kind,
                        _canonical(payload["mission_ids"]),
                        _canonical(payload["plan_ids"]),
                        _canonical(payload["original_plan_ids"]),
                        body["capability_id"],
                        body["capability_version"],
                        body["attempt"],
                        body["replan_attempt"],
                        body["execution_outcome"],
                        body["mission_verification_status"],
                        body["mission_verification_reason"],
                        body["failure_class"],
                        duration_ms,
                        scope,
                        body["sandbox_status"],
                        body["certification_status"],
                        _canonical(payload["authority_refs"]),
                        _canonical(payload["evidence_refs"]),
                        body["final_outcome"],
                        0,
                        0,
                        0,
                        prev,
                        entry_hash,
                        _canonical(payload),
                    ),
                )
            except sqlite3.IntegrityError as exc:
                raise StoreWriteFailed(
                    f"STORE_WRITE_FAILED: record_id already exists: {record_id}"
                ) from exc
            except sqlite3.Error as exc:
                raise StoreWriteFailed(f"STORE_WRITE_FAILED: {exc}") from exc
        return self.get(record_id)

    def get(self, record_id: str) -> PerformanceEvidence:
        try:
            row = self._conn.execute(
                "SELECT * FROM performance_evidence WHERE record_id=?",
                (record_id,),
            ).fetchone()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        if row is None:
            raise StoreReadFailed(f"STORE_READ_FAILED: missing {record_id}")
        evidence = _row_to_evidence(row)
        reconstructed = {
            "record_id": evidence.record_id,
            "schema_version": evidence.schema_version,
            "correlation_id": evidence.correlation_id,
            "timestamp": evidence.timestamp,
            "record_kind": evidence.record_kind,
            "capability_id": evidence.capability_id,
            "capability_version": evidence.capability_version,
            "attempt": evidence.attempt,
            "replan_attempt": evidence.replan_attempt,
            "execution_outcome": evidence.execution_outcome,
            "mission_verification_status": evidence.mission_verification_status,
            "mission_verification_reason": evidence.mission_verification_reason,
            "failure_class": evidence.failure_class,
            "duration_ms": evidence.duration_ms,
            "duration_scope": evidence.duration_scope,
            "sandbox_status": evidence.sandbox_status,
            "certification_status": evidence.certification_status,
            "final_outcome": evidence.final_outcome,
            "learning_activated": False,
            "training_activated": False,
            "auto_promoted": False,
            "payload": {
                "mission_ids": list(evidence.mission_ids),
                "plan_ids": list(evidence.plan_ids),
                "original_plan_ids": list(evidence.original_plan_ids),
                "authority_refs": list(evidence.authority_refs),
                "evidence_refs": list(evidence.evidence_refs),
            },
        }
        expected = _hash_entry(reconstructed, evidence.prev_hash)
        if expected != evidence.entry_hash:
            raise StoreCorruptRecord(
                f"STORE_CORRUPT_RECORD: hash mismatch for {record_id}"
            )
        return evidence

    def by_correlation_id(self, correlation_id: str) -> tuple[PerformanceEvidence, ...]:
        try:
            rows = self._conn.execute(
                "SELECT * FROM performance_evidence WHERE correlation_id=? "
                "ORDER BY timestamp, record_id",
                (correlation_id,),
            ).fetchall()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        return tuple(_row_to_evidence(row) for row in rows)

    def by_capability_id(self, capability_id: str) -> tuple[PerformanceEvidence, ...]:
        try:
            rows = self._conn.execute(
                "SELECT * FROM performance_evidence WHERE capability_id=? "
                "ORDER BY timestamp, record_id",
                (capability_id,),
            ).fetchall()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        return tuple(_row_to_evidence(row) for row in rows)

    def checked_by_capability_id(
        self, capability_id: str
    ) -> tuple[PerformanceEvidence, ...]:
        """Load capability records and fail closed on corrupt required evidence."""
        records = self.by_capability_id(capability_id)
        return tuple(self.get(record.record_id) for record in records)

    def checked_by_mission_id(self, mission_id: str) -> tuple[PerformanceEvidence, ...]:
        try:
            rows = self._conn.execute(
                "SELECT * FROM performance_evidence ORDER BY timestamp, record_id"
            ).fetchall()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        matched: list[PerformanceEvidence] = []
        for row in rows:
            evidence = self.get(row["record_id"])
            if mission_id in evidence.mission_ids:
                matched.append(evidence)
        return tuple(matched)

    def persist_drift_evaluation(
        self, evaluation: Mapping[str, Any]
    ) -> dict[str, Any]:
        evaluation_id = str(evaluation.get("evaluation_id") or uuid.uuid4().hex)
        timestamp = evaluation.get("timestamp") or _now()
        payload = {
            "evaluation_id": evaluation_id,
            "timestamp": timestamp,
            "capability_id": evaluation["capability_id"],
            "mission_id": evaluation.get("mission_id"),
            "metric": evaluation["metric"],
            "baseline_window": evaluation["baseline_window"],
            "current_window": evaluation["current_window"],
            "baseline_value": evaluation.get("baseline_value"),
            "current_value": evaluation.get("current_value"),
            "delta": evaluation.get("delta"),
            "threshold": evaluation["threshold"],
            "status": evaluation["status"],
            "evidence_refs": list(evaluation.get("evidence_refs") or ()),
            "config_version": evaluation.get("config_version", 1),
            "learning_activated": False,
            "training_activated": False,
            "auto_promoted": False,
        }
        entry_hash = _hash_entry(payload, None)
        with self._lock:
            try:
                self._conn.execute(
                    """
                    INSERT INTO drift_evaluations (
                        evaluation_id, timestamp, capability_id, mission_id, metric,
                        baseline_window, current_window, baseline_value, current_value,
                        delta, threshold_json, status, evidence_refs, config_version,
                        learning_activated, training_activated, auto_promoted,
                        entry_hash, payload
                    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    """,
                    (
                        evaluation_id,
                        timestamp,
                        payload["capability_id"],
                        payload["mission_id"],
                        payload["metric"],
                        _canonical(payload["baseline_window"]),
                        _canonical(payload["current_window"]),
                        payload["baseline_value"],
                        payload["current_value"],
                        payload["delta"],
                        _canonical(payload["threshold"]),
                        payload["status"],
                        _canonical(payload["evidence_refs"]),
                        payload["config_version"],
                        0,
                        0,
                        0,
                        entry_hash,
                        _canonical(payload),
                    ),
                )
            except sqlite3.IntegrityError as exc:
                raise StoreWriteFailed(
                    f"STORE_WRITE_FAILED: evaluation_id already exists: {evaluation_id}"
                ) from exc
            except sqlite3.Error as exc:
                raise StoreWriteFailed(f"STORE_WRITE_FAILED: {exc}") from exc
        return self.get_drift_evaluation(evaluation_id)

    def get_drift_evaluation(self, evaluation_id: str) -> dict[str, Any]:
        try:
            row = self._conn.execute(
                "SELECT * FROM drift_evaluations WHERE evaluation_id=?",
                (evaluation_id,),
            ).fetchone()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        if row is None:
            raise StoreReadFailed(f"STORE_READ_FAILED: missing {evaluation_id}")
        payload = json.loads(row["payload"])
        expected = _hash_entry(payload, None)
        if expected != row["entry_hash"]:
            raise StoreCorruptRecord(
                f"STORE_CORRUPT_RECORD: hash mismatch for {evaluation_id}"
            )
        return payload

    def persist_snapshot(self, record: Mapping[str, Any]) -> dict[str, Any]:
        snapshot_id = str(record.get("snapshot_id") or uuid.uuid4().hex)
        created_at = record.get("created_at") or _now()
        status = str(record.get("status") or "AVAILABLE")
        if status not in {"CURRENT", "AVAILABLE", "RETIRED", "INVALID"}:
            raise StoreWriteFailed(f"STORE_WRITE_FAILED: invalid status={status}")
        payload = {
            "snapshot_id": snapshot_id,
            "capability_id": record["capability_id"],
            "version_id": record["version_id"],
            "artifact_hash": record["artifact_hash"],
            "artifact_blob": record["artifact_blob"],
            "implementation_reference": record["implementation_reference"],
            "provenance": record["provenance"],
            "sandbox_validation_reference": record.get(
                "sandbox_validation_reference"
            ),
            "certification_reference": record.get("certification_reference"),
            "created_at": created_at,
            "source_runtime_identity": record.get("source_runtime_identity"),
            "status": status,
            "evidence_refs": list(record.get("evidence_refs") or ()),
        }
        entry_hash = _hash_entry(payload, None)
        with self._lock:
            try:
                self._conn.execute(
                    """
                    INSERT INTO capability_snapshots (
                        snapshot_id, capability_id, version_id, artifact_hash,
                        artifact_blob, implementation_reference, provenance,
                        sandbox_validation_reference, certification_reference,
                        created_at, source_runtime_identity, status,
                        evidence_refs, entry_hash, payload
                    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    """,
                    (
                        snapshot_id,
                        payload["capability_id"],
                        payload["version_id"],
                        payload["artifact_hash"],
                        payload["artifact_blob"],
                        payload["implementation_reference"],
                        payload["provenance"],
                        payload["sandbox_validation_reference"],
                        payload["certification_reference"],
                        created_at,
                        payload["source_runtime_identity"],
                        status,
                        _canonical(payload["evidence_refs"]),
                        entry_hash,
                        _canonical(payload),
                    ),
                )
            except sqlite3.IntegrityError as exc:
                raise StoreWriteFailed(
                    f"STORE_WRITE_FAILED: snapshot_id already exists: {snapshot_id}"
                ) from exc
            except sqlite3.Error as exc:
                raise StoreWriteFailed(f"STORE_WRITE_FAILED: {exc}") from exc
        return self.get_snapshot(snapshot_id)

    def get_snapshot(self, snapshot_id: str) -> dict[str, Any]:
        try:
            row = self._conn.execute(
                "SELECT * FROM capability_snapshots WHERE snapshot_id=?",
                (snapshot_id,),
            ).fetchone()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        if row is None:
            raise StoreReadFailed(f"STORE_READ_FAILED: missing {snapshot_id}")
        payload = json.loads(row["payload"])
        expected = _hash_entry(payload, None)
        if expected != row["entry_hash"]:
            raise StoreCorruptRecord(
                f"STORE_CORRUPT_RECORD: hash mismatch for {snapshot_id}"
            )
        payload["status"] = row["status"]
        return payload

    def list_snapshots(self, capability_id: str) -> tuple[dict[str, Any], ...]:
        try:
            rows = self._conn.execute(
                "SELECT snapshot_id FROM capability_snapshots "
                "WHERE capability_id=? ORDER BY created_at, snapshot_id",
                (capability_id,),
            ).fetchall()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        return tuple(self.get_snapshot(row["snapshot_id"]) for row in rows)

    def set_snapshot_status(self, snapshot_id: str, status: str) -> None:
        if status not in {"CURRENT", "AVAILABLE", "RETIRED", "INVALID"}:
            raise StoreWriteFailed(f"STORE_WRITE_FAILED: invalid status={status}")
        snap = self.get_snapshot(snapshot_id)
        snap["status"] = status
        entry_hash = _hash_entry(snap, None)
        with self._lock:
            self._conn.execute(
                "UPDATE capability_snapshots SET status=?, entry_hash=?, payload=? "
                "WHERE snapshot_id=?",
                (status, entry_hash, _canonical(snap), snapshot_id),
            )

    def get_binding(self, capability_id: str) -> dict[str, Any] | None:
        row = self._conn.execute(
            "SELECT * FROM capability_bindings WHERE capability_id=?",
            (capability_id,),
        ).fetchone()
        if row is None:
            return None
        return {
            "capability_id": row["capability_id"],
            "snapshot_id": row["snapshot_id"],
            "version_id": row["version_id"],
            "artifact_hash": row["artifact_hash"],
            "updated_at": row["updated_at"],
        }

    def set_binding(self, binding: Mapping[str, Any]) -> None:
        with self._lock:
            self._conn.execute(
                """
                INSERT INTO capability_bindings (
                    capability_id, snapshot_id, version_id, artifact_hash, updated_at
                ) VALUES (?,?,?,?,?)
                ON CONFLICT(capability_id) DO UPDATE SET
                    snapshot_id=excluded.snapshot_id,
                    version_id=excluded.version_id,
                    artifact_hash=excluded.artifact_hash,
                    updated_at=excluded.updated_at
                """,
                (
                    binding["capability_id"],
                    binding["snapshot_id"],
                    binding["version_id"],
                    binding["artifact_hash"],
                    binding.get("updated_at") or _now(),
                ),
            )

    def persist_restore(self, record: Mapping[str, Any]) -> dict[str, Any]:
        rollback_id = str(record.get("rollback_id") or uuid.uuid4().hex)
        timestamp = record.get("timestamp") or _now()
        payload = {
            "rollback_id": rollback_id,
            "correlation_id": record["correlation_id"],
            "capability_id": record["capability_id"],
            "from_version": record.get("from_version"),
            "to_version": record.get("to_version"),
            "reason": record.get("reason"),
            "drift_evaluation_id": record.get("drift_evaluation_id"),
            "authority_result": record.get("authority_result"),
            "snapshot_id": record.get("snapshot_id"),
            "snapshot_hash": record.get("snapshot_hash"),
            "restore_result": record["restore_result"],
            "post_restore_verification": record.get("post_restore_verification"),
            "timestamp": timestamp,
            "learning_activated": False,
            "training_activated": False,
            "auto_promoted": False,
        }
        entry_hash = _hash_entry(payload, None)
        with self._lock:
            try:
                self._conn.execute(
                    """
                    INSERT INTO capability_restores (
                        rollback_id, correlation_id, capability_id, from_version,
                        to_version, reason, drift_evaluation_id, authority_result,
                        snapshot_id, snapshot_hash, restore_result,
                        post_restore_verification, timestamp, entry_hash, payload
                    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    """,
                    (
                        rollback_id,
                        payload["correlation_id"],
                        payload["capability_id"],
                        payload["from_version"],
                        payload["to_version"],
                        payload["reason"],
                        payload["drift_evaluation_id"],
                        payload["authority_result"],
                        payload["snapshot_id"],
                        payload["snapshot_hash"],
                        payload["restore_result"],
                        _canonical(payload["post_restore_verification"]),
                        timestamp,
                        entry_hash,
                        _canonical(payload),
                    ),
                )
            except sqlite3.IntegrityError as exc:
                raise StoreWriteFailed(
                    f"STORE_WRITE_FAILED: rollback_id already exists: {rollback_id}"
                ) from exc
            except sqlite3.Error as exc:
                raise StoreWriteFailed(f"STORE_WRITE_FAILED: {exc}") from exc
        return self.get_restore(rollback_id)

    def get_restore(self, rollback_id: str) -> dict[str, Any]:
        try:
            row = self._conn.execute(
                "SELECT * FROM capability_restores WHERE rollback_id=?",
                (rollback_id,),
            ).fetchone()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        if row is None:
            raise StoreReadFailed(f"STORE_READ_FAILED: missing {rollback_id}")
        payload = json.loads(row["payload"])
        expected = _hash_entry(payload, None)
        if expected != row["entry_hash"]:
            raise StoreCorruptRecord(
                f"STORE_CORRUPT_RECORD: hash mismatch for {rollback_id}"
            )
        return payload

    def persist_learning_observation(self, record: Mapping[str, Any]) -> dict[str, Any]:
        observation_id = str(
            record.get("learning_observation_id") or uuid.uuid4().hex
        )
        created_at = record.get("created_at") or _now()
        payload = {
            "learning_observation_id": observation_id,
            "capability_id": record["capability_id"],
            "artifact_hash": record.get("artifact_hash"),
            "evidence_scope": dict(record.get("evidence_scope") or {}),
            "evidence_refs": list(record.get("evidence_refs") or ()),
            "sample_count": int(record.get("sample_count") or 0),
            "observation_type": record["observation_type"],
            "finding": record["finding"],
            "observed_facts": list(record.get("observed_facts") or ()),
            "derived_inference": record.get("derived_inference") or "",
            "confidence": record["confidence"],
            "created_at": created_at,
            "drift_evaluation_ref": record.get("drift_evaluation_ref"),
        }
        entry_hash = _hash_entry(payload, None)
        with self._lock:
            try:
                self._conn.execute(
                    """
                    INSERT INTO learning_observations (
                        learning_observation_id, capability_id, artifact_hash,
                        evidence_scope, evidence_refs, sample_count,
                        observation_type, finding, observed_facts,
                        derived_inference, confidence, created_at,
                        drift_evaluation_ref, entry_hash, payload
                    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    """,
                    (
                        observation_id,
                        payload["capability_id"],
                        payload["artifact_hash"],
                        _canonical(payload["evidence_scope"]),
                        _canonical(payload["evidence_refs"]),
                        payload["sample_count"],
                        payload["observation_type"],
                        payload["finding"],
                        _canonical(payload["observed_facts"]),
                        payload["derived_inference"],
                        payload["confidence"],
                        created_at,
                        payload["drift_evaluation_ref"],
                        entry_hash,
                        _canonical(payload),
                    ),
                )
            except sqlite3.IntegrityError as exc:
                raise StoreWriteFailed(
                    f"STORE_WRITE_FAILED: learning_observation_id already exists: {observation_id}"
                ) from exc
            except sqlite3.Error as exc:
                raise StoreWriteFailed(f"STORE_WRITE_FAILED: {exc}") from exc
        return self.get_learning_observation(observation_id)

    def get_learning_observation(self, learning_observation_id: str) -> dict[str, Any]:
        try:
            row = self._conn.execute(
                "SELECT * FROM learning_observations WHERE learning_observation_id=?",
                (learning_observation_id,),
            ).fetchone()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        if row is None:
            raise StoreReadFailed(f"STORE_READ_FAILED: missing {learning_observation_id}")
        payload = json.loads(row["payload"])
        expected = _hash_entry(payload, None)
        if expected != row["entry_hash"]:
            raise StoreCorruptRecord(
                f"STORE_CORRUPT_RECORD: hash mismatch for {learning_observation_id}"
            )
        return payload

    def list_learning_observations(
        self, capability_id: str
    ) -> tuple[dict[str, Any], ...]:
        try:
            rows = self._conn.execute(
                "SELECT learning_observation_id FROM learning_observations "
                "WHERE capability_id=? ORDER BY created_at, learning_observation_id",
                (capability_id,),
            ).fetchall()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        return tuple(
            self.get_learning_observation(row["learning_observation_id"])
            for row in rows
        )

    def persist_improvement_proposal(self, record: Mapping[str, Any]) -> dict[str, Any]:
        proposal_id = str(record.get("proposal_id") or uuid.uuid4().hex)
        created_at = record.get("created_at") or _now()
        status = str(record.get("status") or "PROPOSED")
        if status not in {"PROPOSED", "NO_ACTION", "INSUFFICIENT_EVIDENCE"}:
            raise StoreWriteFailed(f"STORE_WRITE_FAILED: invalid proposal status={status}")
        payload = {
            "proposal_id": proposal_id,
            "source_learning_observation_id": record["source_learning_observation_id"],
            "target_capability_id": record["target_capability_id"],
            "target_artifact_hash": record.get("target_artifact_hash"),
            "problem_statement": record["problem_statement"],
            "evidence_refs": list(record.get("evidence_refs") or ()),
            "proposed_change_type": record["proposed_change_type"],
            "expected_outcome": record["expected_outcome"],
            "acceptance_criteria": list(record.get("acceptance_criteria") or ()),
            "risk": record.get("risk") or "",
            "confidence": record["confidence"],
            "status": status,
            "created_at": created_at,
        }
        entry_hash = _hash_entry(payload, None)
        with self._lock:
            try:
                self._conn.execute(
                    """
                    INSERT INTO improvement_proposals (
                        proposal_id, source_learning_observation_id,
                        target_capability_id, target_artifact_hash,
                        problem_statement, evidence_refs, proposed_change_type,
                        expected_outcome, acceptance_criteria, risk, confidence,
                        status, created_at, entry_hash, payload
                    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    """,
                    (
                        proposal_id,
                        payload["source_learning_observation_id"],
                        payload["target_capability_id"],
                        payload["target_artifact_hash"],
                        payload["problem_statement"],
                        _canonical(payload["evidence_refs"]),
                        payload["proposed_change_type"],
                        payload["expected_outcome"],
                        _canonical(payload["acceptance_criteria"]),
                        payload["risk"],
                        payload["confidence"],
                        status,
                        created_at,
                        entry_hash,
                        _canonical(payload),
                    ),
                )
            except sqlite3.IntegrityError as exc:
                raise StoreWriteFailed(
                    f"STORE_WRITE_FAILED: proposal_id already exists: {proposal_id}"
                ) from exc
            except sqlite3.Error as exc:
                raise StoreWriteFailed(f"STORE_WRITE_FAILED: {exc}") from exc
        return self.get_improvement_proposal(proposal_id)

    def get_improvement_proposal(self, proposal_id: str) -> dict[str, Any]:
        try:
            row = self._conn.execute(
                "SELECT * FROM improvement_proposals WHERE proposal_id=?",
                (proposal_id,),
            ).fetchone()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        if row is None:
            raise StoreReadFailed(f"STORE_READ_FAILED: missing {proposal_id}")
        payload = json.loads(row["payload"])
        expected = _hash_entry(payload, None)
        if expected != row["entry_hash"]:
            raise StoreCorruptRecord(
                f"STORE_CORRUPT_RECORD: hash mismatch for {proposal_id}"
            )
        return payload

    def list_improvement_proposals(
        self, capability_id: str
    ) -> tuple[dict[str, Any], ...]:
        try:
            rows = self._conn.execute(
                "SELECT proposal_id FROM improvement_proposals "
                "WHERE target_capability_id=? ORDER BY created_at, proposal_id",
                (capability_id,),
            ).fetchall()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        return tuple(self.get_improvement_proposal(row["proposal_id"]) for row in rows)

    def persist_proposal_evaluation(self, record: Mapping[str, Any]) -> dict[str, Any]:
        evaluation_id = str(
            record.get("proposal_evaluation_id") or uuid.uuid4().hex
        )
        created_at = record.get("created_at") or _now()
        status = str(record["status"])
        if status not in {
            "APPROVED_FOR_CONTROLLED_IMPLEMENTATION",
            "REJECTED",
            "INSUFFICIENT_EVIDENCE",
            "NO_ACTION",
        }:
            raise StoreWriteFailed(
                f"STORE_WRITE_FAILED: invalid proposal evaluation status={status}"
            )
        payload = {
            "proposal_evaluation_id": evaluation_id,
            "proposal_id": record["proposal_id"],
            "source_learning_observation_id": record["source_learning_observation_id"],
            "target_capability_id": record["target_capability_id"],
            "target_artifact_hash": record.get("target_artifact_hash"),
            "evidence_refs": list(record.get("evidence_refs") or ()),
            "evidence_sufficiency": record["evidence_sufficiency"],
            "scope_assessment": record["scope_assessment"],
            "risk_assessment": record["risk_assessment"],
            "acceptance_criteria_quality": record["acceptance_criteria_quality"],
            "expected_outcome_assessment": record["expected_outcome_assessment"],
            "status": status,
            "reason": record["reason"],
            "reviewer_identity": record["reviewer_identity"],
            "created_at": created_at,
        }
        entry_hash = _hash_entry(payload, None)
        with self._lock:
            try:
                self._conn.execute(
                    """
                    INSERT INTO proposal_evaluations (
                        proposal_evaluation_id, proposal_id,
                        source_learning_observation_id, target_capability_id,
                        target_artifact_hash, evidence_refs, evidence_sufficiency,
                        scope_assessment, risk_assessment,
                        acceptance_criteria_quality, expected_outcome_assessment,
                        status, reason, reviewer_identity, created_at,
                        entry_hash, payload
                    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    """,
                    (
                        evaluation_id,
                        payload["proposal_id"],
                        payload["source_learning_observation_id"],
                        payload["target_capability_id"],
                        payload["target_artifact_hash"],
                        _canonical(payload["evidence_refs"]),
                        payload["evidence_sufficiency"],
                        payload["scope_assessment"],
                        payload["risk_assessment"],
                        payload["acceptance_criteria_quality"],
                        payload["expected_outcome_assessment"],
                        status,
                        payload["reason"],
                        payload["reviewer_identity"],
                        created_at,
                        entry_hash,
                        _canonical(payload),
                    ),
                )
            except sqlite3.IntegrityError as exc:
                raise StoreWriteFailed(
                    f"STORE_WRITE_FAILED: proposal_evaluation_id already exists: {evaluation_id}"
                ) from exc
            except sqlite3.Error as exc:
                raise StoreWriteFailed(f"STORE_WRITE_FAILED: {exc}") from exc
        return self.get_proposal_evaluation(evaluation_id)

    def get_proposal_evaluation(self, proposal_evaluation_id: str) -> dict[str, Any]:
        try:
            row = self._conn.execute(
                "SELECT * FROM proposal_evaluations WHERE proposal_evaluation_id=?",
                (proposal_evaluation_id,),
            ).fetchone()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        if row is None:
            raise StoreReadFailed(f"STORE_READ_FAILED: missing {proposal_evaluation_id}")
        payload = json.loads(row["payload"])
        expected = _hash_entry(payload, None)
        if expected != row["entry_hash"]:
            raise StoreCorruptRecord(
                f"STORE_CORRUPT_RECORD: hash mismatch for {proposal_evaluation_id}"
            )
        return payload

    def list_proposal_evaluations(
        self, proposal_id: str
    ) -> tuple[dict[str, Any], ...]:
        try:
            rows = self._conn.execute(
                "SELECT proposal_evaluation_id FROM proposal_evaluations "
                "WHERE proposal_id=? ORDER BY created_at, proposal_evaluation_id",
                (proposal_id,),
            ).fetchall()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        return tuple(
            self.get_proposal_evaluation(row["proposal_evaluation_id"]) for row in rows
        )

    def persist_improvement_comparison(self, record: Mapping[str, Any]) -> dict[str, Any]:
        comparison_id = str(record.get("comparison_id") or uuid.uuid4().hex)
        created_at = record.get("created_at") or _now()
        status = str(record["status"])
        if status not in {
            "PROVEN_IMPROVEMENT",
            "EQUIVALENT",
            "WORSE",
            "INSUFFICIENT_COMPARATIVE_EVIDENCE",
        }:
            raise StoreWriteFailed(
                f"STORE_WRITE_FAILED: invalid comparison status={status}"
            )
        payload = {
            "comparison_id": comparison_id,
            "target_capability_id": record["target_capability_id"],
            "baseline_artifact_hash": record.get("baseline_artifact_hash"),
            "candidate_artifact_hash": record["candidate_artifact_hash"],
            "workload_definition": dict(record.get("workload_definition") or {}),
            "sample_count_baseline": int(record.get("sample_count_baseline") or 0),
            "sample_count_candidate": int(record.get("sample_count_candidate") or 0),
            "baseline_metrics": dict(record.get("baseline_metrics") or {}),
            "candidate_metrics": dict(record.get("candidate_metrics") or {}),
            "acceptance_criteria_results": dict(
                record.get("acceptance_criteria_results") or {}
            ),
            "performance_delta": dict(record.get("performance_delta") or {}),
            "reliability_delta": dict(record.get("reliability_delta") or {}),
            "status": status,
            "reason": record["reason"],
            "evidence_refs": list(record.get("evidence_refs") or ()),
            "created_at": created_at,
            "proposal_id": record.get("proposal_id"),
            "proposal_evaluation_id": record.get("proposal_evaluation_id"),
            "expected_outcome": record.get("expected_outcome"),
            "expected_outcome_metric": record.get("expected_outcome_metric"),
            "expected_outcome_tested": bool(record.get("expected_outcome_tested")),
            "replacement_eligibility": record.get("replacement_eligibility") or "NO",
        }
        entry_hash = _hash_entry(payload, None)
        with self._lock:
            try:
                self._conn.execute(
                    """
                    INSERT INTO improvement_comparisons (
                        comparison_id, target_capability_id,
                        baseline_artifact_hash, candidate_artifact_hash,
                        status, created_at, entry_hash, payload
                    ) VALUES (?,?,?,?,?,?,?,?)
                    """,
                    (
                        comparison_id,
                        payload["target_capability_id"],
                        payload["baseline_artifact_hash"],
                        payload["candidate_artifact_hash"],
                        status,
                        created_at,
                        entry_hash,
                        _canonical(payload),
                    ),
                )
            except sqlite3.IntegrityError as exc:
                raise StoreWriteFailed(
                    f"STORE_WRITE_FAILED: comparison_id already exists: {comparison_id}"
                ) from exc
            except sqlite3.Error as exc:
                raise StoreWriteFailed(f"STORE_WRITE_FAILED: {exc}") from exc
        return self.get_improvement_comparison(comparison_id)

    def get_improvement_comparison(self, comparison_id: str) -> dict[str, Any]:
        try:
            row = self._conn.execute(
                "SELECT * FROM improvement_comparisons WHERE comparison_id=?",
                (comparison_id,),
            ).fetchone()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        if row is None:
            raise StoreReadFailed(f"STORE_READ_FAILED: missing {comparison_id}")
        payload = json.loads(row["payload"])
        expected = _hash_entry(payload, None)
        if expected != row["entry_hash"]:
            raise StoreCorruptRecord(
                f"STORE_CORRUPT_RECORD: hash mismatch for {comparison_id}"
            )
        return payload

    def list_improvement_comparisons(
        self, capability_id: str
    ) -> tuple[dict[str, Any], ...]:
        try:
            rows = self._conn.execute(
                "SELECT comparison_id FROM improvement_comparisons "
                "WHERE target_capability_id=? ORDER BY created_at, comparison_id",
                (capability_id,),
            ).fetchall()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        return tuple(
            self.get_improvement_comparison(row["comparison_id"]) for row in rows
        )

    def persist_training_dataset(self, record: Mapping[str, Any]) -> dict[str, Any]:
        dataset_id = str(record.get("dataset_id") or uuid.uuid4().hex)
        created_at = record.get("created_at") or _now()
        status = str(record["status"])
        if status not in {
            "CANDIDATE",
            "VALIDATED",
            "REJECTED",
            "INSUFFICIENT_EVIDENCE",
        }:
            raise StoreWriteFailed(f"STORE_WRITE_FAILED: invalid dataset status={status}")
        payload = dict(record)
        payload["dataset_id"] = dataset_id
        payload["created_at"] = created_at
        payload["status"] = status
        entry_hash = _hash_entry(payload, None)
        with self._lock:
            try:
                self._conn.execute(
                    """
                    INSERT INTO training_datasets (
                        dataset_id, content_hash, status, created_at, entry_hash, payload
                    ) VALUES (?,?,?,?,?,?)
                    """,
                    (
                        dataset_id,
                        payload.get("content_hash") or "",
                        status,
                        created_at,
                        entry_hash,
                        _canonical(payload),
                    ),
                )
            except sqlite3.IntegrityError as exc:
                raise StoreWriteFailed(
                    f"STORE_WRITE_FAILED: dataset_id already exists: {dataset_id}"
                ) from exc
            except sqlite3.Error as exc:
                raise StoreWriteFailed(f"STORE_WRITE_FAILED: {exc}") from exc
        return self.get_training_dataset(dataset_id)

    def get_training_dataset(self, dataset_id: str) -> dict[str, Any]:
        try:
            row = self._conn.execute(
                "SELECT * FROM training_datasets WHERE dataset_id=?",
                (dataset_id,),
            ).fetchone()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        if row is None:
            raise StoreReadFailed(f"STORE_READ_FAILED: missing {dataset_id}")
        payload = json.loads(row["payload"])
        expected = _hash_entry(payload, None)
        if expected != row["entry_hash"]:
            raise StoreCorruptRecord(f"STORE_CORRUPT_RECORD: hash mismatch for {dataset_id}")
        return payload

    def persist_training_validation(self, record: Mapping[str, Any]) -> dict[str, Any]:
        validation_id = str(record.get("validation_id") or uuid.uuid4().hex)
        created_at = record.get("validated_at") or record.get("created_at") or _now()
        status = str(record["status"])
        if status not in {"VALIDATED", "REJECTED", "INSUFFICIENT_EVIDENCE"}:
            raise StoreWriteFailed(
                f"STORE_WRITE_FAILED: invalid dataset validation status={status}"
            )
        payload = dict(record)
        payload["validation_id"] = validation_id
        payload["validated_at"] = created_at
        entry_hash = _hash_entry(payload, None)
        with self._lock:
            try:
                self._conn.execute(
                    """
                    INSERT INTO training_dataset_validations (
                        validation_id, dataset_id, status, created_at, entry_hash, payload
                    ) VALUES (?,?,?,?,?,?)
                    """,
                    (
                        validation_id,
                        payload["dataset_id"],
                        status,
                        created_at,
                        entry_hash,
                        _canonical(payload),
                    ),
                )
            except sqlite3.IntegrityError as exc:
                raise StoreWriteFailed(
                    f"STORE_WRITE_FAILED: validation_id already exists: {validation_id}"
                ) from exc
            except sqlite3.Error as exc:
                raise StoreWriteFailed(f"STORE_WRITE_FAILED: {exc}") from exc
        return self.get_training_validation(validation_id)

    def get_training_validation(self, validation_id: str) -> dict[str, Any]:
        try:
            row = self._conn.execute(
                "SELECT * FROM training_dataset_validations WHERE validation_id=?",
                (validation_id,),
            ).fetchone()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        if row is None:
            raise StoreReadFailed(f"STORE_READ_FAILED: missing {validation_id}")
        payload = json.loads(row["payload"])
        expected = _hash_entry(payload, None)
        if expected != row["entry_hash"]:
            raise StoreCorruptRecord(
                f"STORE_CORRUPT_RECORD: hash mismatch for {validation_id}"
            )
        return payload

    def persist_training_job(self, record: Mapping[str, Any]) -> dict[str, Any]:
        training_job_id = str(record.get("training_job_id") or uuid.uuid4().hex)
        created_at = record.get("created_at") or _now()
        status = str(record["status"])
        if status not in {"SPECIFIED", "NOT_READY", "REJECTED"}:
            raise StoreWriteFailed(f"STORE_WRITE_FAILED: invalid job status={status}")
        payload = dict(record)
        payload["training_job_id"] = training_job_id
        payload["created_at"] = created_at
        payload["deployment_allowed"] = False
        entry_hash = _hash_entry(payload, None)
        with self._lock:
            try:
                self._conn.execute(
                    """
                    INSERT INTO training_job_specs (
                        training_job_id, dataset_id, status, created_at, entry_hash, payload
                    ) VALUES (?,?,?,?,?,?)
                    """,
                    (
                        training_job_id,
                        payload["dataset_id"],
                        status,
                        created_at,
                        entry_hash,
                        _canonical(payload),
                    ),
                )
            except sqlite3.IntegrityError as exc:
                raise StoreWriteFailed(
                    f"STORE_WRITE_FAILED: training_job_id already exists: {training_job_id}"
                ) from exc
            except sqlite3.Error as exc:
                raise StoreWriteFailed(f"STORE_WRITE_FAILED: {exc}") from exc
        return self.get_training_job(training_job_id)

    def get_training_job(self, training_job_id: str) -> dict[str, Any]:
        try:
            row = self._conn.execute(
                "SELECT * FROM training_job_specs WHERE training_job_id=?",
                (training_job_id,),
            ).fetchone()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        if row is None:
            raise StoreReadFailed(f"STORE_READ_FAILED: missing {training_job_id}")
        payload = json.loads(row["payload"])
        expected = _hash_entry(payload, None)
        if expected != row["entry_hash"]:
            raise StoreCorruptRecord(
                f"STORE_CORRUPT_RECORD: hash mismatch for {training_job_id}"
            )
        return payload

    def persist_capability_replacement(self, record: Mapping[str, Any]) -> dict[str, Any]:
        replacement_id = str(record.get("replacement_id") or uuid.uuid4().hex)
        created_at = record.get("created_at") or _now()
        status = str(record["status"])
        if status not in {"APPLIED", "DENIED", "RESTORED"}:
            raise StoreWriteFailed(
                f"STORE_WRITE_FAILED: invalid replacement status={status}"
            )
        payload = {
            "replacement_id": replacement_id,
            "comparison_id": record["comparison_id"],
            "proposal_id": record.get("proposal_id"),
            "proposal_evaluation_id": record.get("proposal_evaluation_id"),
            "target_capability_id": record["target_capability_id"],
            "candidate_capability_id": record.get("candidate_capability_id"),
            "old_artifact_hash": record.get("old_artifact_hash"),
            "candidate_artifact_hash": record["candidate_artifact_hash"],
            "behavioral_certification_ref": record.get("behavioral_certification_ref"),
            "authority_result": record.get("authority_result"),
            "pre_replacement_snapshot_ref": record.get("pre_replacement_snapshot_ref"),
            "switch_result": record.get("switch_result"),
            "post_switch_verification": dict(record.get("post_switch_verification") or {}),
            "runtime_verification_ref": record.get("runtime_verification_ref"),
            "replacement_eligibility": record.get("replacement_eligibility"),
            "status": status,
            "reason": record.get("reason"),
            "created_at": created_at,
            "created_by": record.get("created_by"),
            "auto_replacement": False,
            "auto_rollback": False,
            "promotion_activated": False,
            "training_activated": False,
        }
        entry_hash = _hash_entry(payload, None)
        with self._lock:
            try:
                self._conn.execute(
                    """
                    INSERT INTO capability_replacements (
                        replacement_id, comparison_id, target_capability_id,
                        status, created_at, entry_hash, payload
                    ) VALUES (?,?,?,?,?,?,?)
                    """,
                    (
                        replacement_id,
                        payload["comparison_id"],
                        payload["target_capability_id"],
                        status,
                        created_at,
                        entry_hash,
                        _canonical(payload),
                    ),
                )
            except sqlite3.IntegrityError as exc:
                raise StoreWriteFailed(
                    f"STORE_WRITE_FAILED: replacement_id already exists: {replacement_id}"
                ) from exc
            except sqlite3.Error as exc:
                raise StoreWriteFailed(f"STORE_WRITE_FAILED: {exc}") from exc
        return self.get_capability_replacement(replacement_id)

    def get_capability_replacement(self, replacement_id: str) -> dict[str, Any]:
        try:
            row = self._conn.execute(
                "SELECT * FROM capability_replacements WHERE replacement_id=?",
                (replacement_id,),
            ).fetchone()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        if row is None:
            raise StoreReadFailed(f"STORE_READ_FAILED: missing {replacement_id}")
        payload = json.loads(row["payload"])
        expected = _hash_entry(payload, None)
        if expected != row["entry_hash"]:
            raise StoreCorruptRecord(
                f"STORE_CORRUPT_RECORD: hash mismatch for {replacement_id}"
            )
        return payload

    def persist_post_replacement_decision(self, record: Mapping[str, Any]) -> dict[str, Any]:
        decision_id = str(record.get("decision_id") or uuid.uuid4().hex)
        created_at = record.get("created_at") or _now()
        status = str(record["status"])
        if status not in {"KEEP", "ROLLBACK_RECOMMENDED", "INSUFFICIENT_EVIDENCE"}:
            raise StoreWriteFailed(
                f"STORE_WRITE_FAILED: invalid post-replacement status={status}"
            )
        payload = {
            "decision_id": decision_id,
            "replacement_id": record["replacement_id"],
            "comparison_id": record.get("comparison_id"),
            "target_capability_id": record["target_capability_id"],
            "old_artifact_hash": record.get("old_artifact_hash"),
            "new_artifact_hash": record.get("new_artifact_hash"),
            "baseline_evidence_refs": list(record.get("baseline_evidence_refs") or ()),
            "post_replacement_evidence_refs": list(
                record.get("post_replacement_evidence_refs") or ()
            ),
            "baseline_metrics": dict(record.get("baseline_metrics") or {}),
            "post_metrics": dict(record.get("post_metrics") or {}),
            "sample_count": int(record.get("sample_count") or 0),
            "mission_success_delta": record.get("mission_success_delta"),
            "failure_rate_delta": record.get("failure_rate_delta"),
            "duration_delta": record.get("duration_delta"),
            "replan_delta": record.get("replan_delta"),
            "drift_status": record.get("drift_status"),
            "status": status,
            "reason": record.get("reason"),
            "created_at": created_at,
            "sample_rule": record.get("sample_rule"),
            "auto_rollback": False,
            "promotion_activated": False,
            "training_activated": False,
            "details": dict(record.get("details") or {}),
        }
        entry_hash = _hash_entry(payload, None)
        with self._lock:
            try:
                self._conn.execute(
                    """
                    INSERT INTO post_replacement_decisions (
                        decision_id, replacement_id, target_capability_id,
                        status, created_at, entry_hash, payload
                    ) VALUES (?,?,?,?,?,?,?)
                    """,
                    (
                        decision_id,
                        payload["replacement_id"],
                        payload["target_capability_id"],
                        status,
                        created_at,
                        entry_hash,
                        _canonical(payload),
                    ),
                )
            except sqlite3.IntegrityError as exc:
                raise StoreWriteFailed(
                    f"STORE_WRITE_FAILED: decision_id already exists: {decision_id}"
                ) from exc
            except sqlite3.Error as exc:
                raise StoreWriteFailed(f"STORE_WRITE_FAILED: {exc}") from exc
        return self.get_post_replacement_decision(decision_id)

    def get_post_replacement_decision(self, decision_id: str) -> dict[str, Any]:
        try:
            row = self._conn.execute(
                "SELECT * FROM post_replacement_decisions WHERE decision_id=?",
                (decision_id,),
            ).fetchone()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        if row is None:
            raise StoreReadFailed(f"STORE_READ_FAILED: missing {decision_id}")
        payload = json.loads(row["payload"])
        expected = _hash_entry(payload, None)
        if expected != row["entry_hash"]:
            raise StoreCorruptRecord(
                f"STORE_CORRUPT_RECORD: hash mismatch for {decision_id}"
            )
        return payload


    def persist_model_performance_profile(self, record: Mapping[str, Any]) -> dict[str, Any]:
        profile_id = str(record.get("profile_id") or uuid.uuid4().hex)
        created_at = record.get("created_at") or _now()
        payload = dict(record)
        payload["profile_id"] = profile_id
        payload["created_at"] = created_at
        profile_hash = str(payload.get("profile_hash") or "")
        if not profile_hash:
            profile_hash = hashlib.sha256(_canonical(payload).encode("utf-8")).hexdigest()
            payload["profile_hash"] = profile_hash
        subject_id = str(payload.get("subject_id") or "")
        if not subject_id:
            raise StoreWriteFailed("STORE_WRITE_FAILED: subject_id required")
        entry_hash = _hash_entry(payload, None)
        with self._lock:
            try:
                self._conn.execute(
                    """
                    INSERT INTO model_performance_profiles (
                        profile_id, subject_id, version, profile_hash,
                        created_at, entry_hash, payload
                    ) VALUES (?,?,?,?,?,?,?)
                    """,
                    (
                        profile_id,
                        subject_id,
                        payload.get("version"),
                        profile_hash,
                        created_at,
                        entry_hash,
                        _canonical(payload),
                    ),
                )
            except sqlite3.IntegrityError as exc:
                raise StoreWriteFailed(
                    f"STORE_WRITE_FAILED: profile_id already exists: {profile_id}"
                ) from exc
            except sqlite3.Error as exc:
                raise StoreWriteFailed(f"STORE_WRITE_FAILED: {exc}") from exc
        return self.get_model_performance_profile(profile_id)

    def get_model_performance_profile(self, profile_id: str) -> dict[str, Any]:
        try:
            row = self._conn.execute(
                "SELECT * FROM model_performance_profiles WHERE profile_id=?",
                (profile_id,),
            ).fetchone()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        if row is None:
            raise StoreReadFailed(f"STORE_READ_FAILED: missing {profile_id}")
        payload = json.loads(row["payload"])
        if _hash_entry(payload, None) != row["entry_hash"]:
            raise StoreCorruptRecord(
                f"STORE_CORRUPT_RECORD: hash mismatch for {profile_id}"
            )
        return payload

    def list_model_performance_profiles(
        self, subject_id: str
    ) -> tuple[dict[str, Any], ...]:
        try:
            rows = self._conn.execute(
                "SELECT profile_id FROM model_performance_profiles "
                "WHERE subject_id=? ORDER BY created_at, profile_id",
                (subject_id,),
            ).fetchall()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        return tuple(
            self.get_model_performance_profile(row["profile_id"]) for row in rows
        )

    def persist_runtime_benchmark(self, record: Mapping[str, Any]) -> dict[str, Any]:
        benchmark_id = str(record.get("benchmark_id") or uuid.uuid4().hex)
        created_at = record.get("created_at") or _now()
        payload = dict(record)
        payload["benchmark_id"] = benchmark_id
        payload["created_at"] = created_at
        subject_id = str(payload.get("subject_id") or "")
        if not subject_id:
            raise StoreWriteFailed("STORE_WRITE_FAILED: subject_id required")
        benchmark_hash = str(payload.get("benchmark_hash") or "")
        if not benchmark_hash:
            benchmark_hash = hashlib.sha256(_canonical(payload).encode("utf-8")).hexdigest()
            payload["benchmark_hash"] = benchmark_hash
        entry_hash = _hash_entry(payload, None)
        with self._lock:
            try:
                self._conn.execute(
                    """
                    INSERT INTO runtime_benchmarks (
                        benchmark_id, subject_id, benchmark_hash,
                        created_at, entry_hash, payload
                    ) VALUES (?,?,?,?,?,?)
                    """,
                    (
                        benchmark_id,
                        subject_id,
                        benchmark_hash,
                        created_at,
                        entry_hash,
                        _canonical(payload),
                    ),
                )
            except sqlite3.IntegrityError as exc:
                raise StoreWriteFailed(
                    f"STORE_WRITE_FAILED: benchmark_id already exists: {benchmark_id}"
                ) from exc
            except sqlite3.Error as exc:
                raise StoreWriteFailed(f"STORE_WRITE_FAILED: {exc}") from exc
        return self.get_runtime_benchmark(benchmark_id)

    def get_runtime_benchmark(self, benchmark_id: str) -> dict[str, Any]:
        try:
            row = self._conn.execute(
                "SELECT * FROM runtime_benchmarks WHERE benchmark_id=?",
                (benchmark_id,),
            ).fetchone()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        if row is None:
            raise StoreReadFailed(f"STORE_READ_FAILED: missing {benchmark_id}")
        payload = json.loads(row["payload"])
        if _hash_entry(payload, None) != row["entry_hash"]:
            raise StoreCorruptRecord(
                f"STORE_CORRUPT_RECORD: hash mismatch for {benchmark_id}"
            )
        return payload

    def list_runtime_benchmarks(
        self, subject_id: str
    ) -> tuple[dict[str, Any], ...]:
        try:
            rows = self._conn.execute(
                "SELECT benchmark_id FROM runtime_benchmarks "
                "WHERE subject_id=? ORDER BY created_at, benchmark_id",
                (subject_id,),
            ).fetchall()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        return tuple(
            self.get_runtime_benchmark(row["benchmark_id"]) for row in rows
        )

    def persist_selection_feedback(self, record: Mapping[str, Any]) -> dict[str, Any]:
        feedback_id = str(record.get("feedback_id") or uuid.uuid4().hex)
        created_at = record.get("created_at") or _now()
        payload = dict(record)
        payload["feedback_id"] = feedback_id
        payload["created_at"] = created_at
        selected_subject = str(payload.get("selected_subject") or "")
        outcome = str(payload.get("outcome") or "")
        if not selected_subject or not outcome:
            raise StoreWriteFailed(
                "STORE_WRITE_FAILED: selected_subject and outcome required"
            )
        entry_hash = _hash_entry(payload, None)
        with self._lock:
            try:
                self._conn.execute(
                    """
                    INSERT INTO performance_selection_feedback (
                        feedback_id, mission_type, selected_subject, outcome,
                        score, created_at, entry_hash, payload
                    ) VALUES (?,?,?,?,?,?,?,?)
                    """,
                    (
                        feedback_id,
                        payload.get("mission_type"),
                        selected_subject,
                        outcome,
                        payload.get("score"),
                        created_at,
                        entry_hash,
                        _canonical(payload),
                    ),
                )
            except sqlite3.IntegrityError as exc:
                raise StoreWriteFailed(
                    f"STORE_WRITE_FAILED: feedback_id already exists: {feedback_id}"
                ) from exc
            except sqlite3.Error as exc:
                raise StoreWriteFailed(f"STORE_WRITE_FAILED: {exc}") from exc
        return self.get_selection_feedback(feedback_id)

    def get_selection_feedback(self, feedback_id: str) -> dict[str, Any]:
        try:
            row = self._conn.execute(
                "SELECT * FROM performance_selection_feedback WHERE feedback_id=?",
                (feedback_id,),
            ).fetchone()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        if row is None:
            raise StoreReadFailed(f"STORE_READ_FAILED: missing {feedback_id}")
        payload = json.loads(row["payload"])
        if _hash_entry(payload, None) != row["entry_hash"]:
            raise StoreCorruptRecord(
                f"STORE_CORRUPT_RECORD: hash mismatch for {feedback_id}"
            )
        return payload

    def list_selection_feedback(
        self, selected_subject: str
    ) -> tuple[dict[str, Any], ...]:
        try:
            rows = self._conn.execute(
                "SELECT feedback_id FROM performance_selection_feedback "
                "WHERE selected_subject=? ORDER BY created_at, feedback_id",
                (selected_subject,),
            ).fetchall()
        except sqlite3.Error as exc:
            raise StoreReadFailed(f"STORE_READ_FAILED: {exc}") from exc
        return tuple(
            self.get_selection_feedback(row["feedback_id"]) for row in rows
        )

    def close(self) -> None:
        self._conn.close()
