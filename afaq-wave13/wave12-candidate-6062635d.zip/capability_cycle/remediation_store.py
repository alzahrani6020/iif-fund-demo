"""Durable append-only store for M4B remediation lifecycle events."""

from __future__ import annotations

import hashlib
import json
import sqlite3

from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

from .remediation_contracts import RemediationCase
from .remediation_lifecycle import (
    RemediationEvent,
    RemediationLifecycleError,
    derive_remediation_case,
)


STORE_SCHEMA_VERSION = 1


class RemediationStoreError(RuntimeError):
    pass


class RemediationEventConflict(RemediationStoreError):
    pass


class RemediationStoreCorruptRecord(RemediationStoreError):
    pass


def _canonical_json(value: Any) -> str:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )


class RemediationStore:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init_schema()

    def _open_connection(self) -> sqlite3.Connection:
        connection = sqlite3.connect(
            str(self.path),
            timeout=30.0,
        )
        connection.row_factory = sqlite3.Row
        return connection

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        connection = self._open_connection()
        try:
            yield connection
            connection.commit()
        except BaseException:
            connection.rollback()
            raise
        finally:
            connection.close()

    def _init_schema(self) -> None:
        with self._connection() as db:
            db.execute(
                """
                CREATE TABLE IF NOT EXISTS remediation_events (
                    sequence INTEGER PRIMARY KEY AUTOINCREMENT,
                    store_schema_version INTEGER NOT NULL,
                    remediation_event_id TEXT NOT NULL UNIQUE,
                    remediation_case_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    occurred_at TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    previous_hash TEXT NOT NULL,
                    record_hash TEXT NOT NULL UNIQUE
                )
                """
            )
            db.execute(
                """
                CREATE INDEX IF NOT EXISTS
                idx_remediation_events_case
                ON remediation_events(
                    remediation_case_id,
                    sequence
                )
                """
            )

    @staticmethod
    def _row_to_event(row: sqlite3.Row) -> RemediationEvent:
        payload = json.loads(str(row["payload_json"]))
        return RemediationEvent.from_dict(payload)

    @staticmethod
    def _record_material(
        *,
        remediation_event_id: str,
        remediation_case_id: str,
        event_type: str,
        occurred_at: str,
        payload: dict[str, Any],
        previous_hash: str,
    ) -> str:
        return _canonical_json(
            {
                "store_schema_version": STORE_SCHEMA_VERSION,
                "remediation_event_id": remediation_event_id,
                "remediation_case_id": remediation_case_id,
                "event_type": event_type,
                "occurred_at": occurred_at,
                "payload": payload,
                "previous_hash": previous_hash,
            }
        )

    def append(self, event: RemediationEvent) -> str:
        payload = event.as_dict()
        payload_json = _canonical_json(payload)

        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")

            existing = db.execute(
                """
                SELECT payload_json, record_hash
                FROM remediation_events
                WHERE remediation_event_id = ?
                """,
                (event.remediation_event_id,),
            ).fetchone()

            if existing is not None:
                if str(existing["payload_json"]) == payload_json:
                    return str(existing["record_hash"])
                raise RemediationEventConflict(
                    "remediation_event_id already exists with different payload"
                )

            case_rows = db.execute(
                """
                SELECT *
                FROM remediation_events
                WHERE remediation_case_id = ?
                ORDER BY sequence ASC
                """,
                (event.remediation_case_id,),
            ).fetchall()

            case_events = tuple(
                self._row_to_event(row)
                for row in case_rows
            )

            try:
                derive_remediation_case(
                    (*case_events, event)
                )
            except (ValueError, TypeError, RemediationLifecycleError) as exc:
                raise RemediationStoreError(
                    f"invalid remediation lifecycle append: {exc}"
                ) from exc

            previous = db.execute(
                """
                SELECT record_hash
                FROM remediation_events
                ORDER BY sequence DESC
                LIMIT 1
                """
            ).fetchone()

            previous_hash = (
                str(previous["record_hash"])
                if previous is not None
                else "GENESIS"
            )

            material = self._record_material(
                remediation_event_id=event.remediation_event_id,
                remediation_case_id=event.remediation_case_id,
                event_type=event.event_type.value,
                occurred_at=event.occurred_at,
                payload=payload,
                previous_hash=previous_hash,
            )

            record_hash = hashlib.sha256(
                material.encode("utf-8")
            ).hexdigest()

            db.execute(
                """
                INSERT INTO remediation_events (
                    store_schema_version,
                    remediation_event_id,
                    remediation_case_id,
                    event_type,
                    occurred_at,
                    payload_json,
                    previous_hash,
                    record_hash
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    STORE_SCHEMA_VERSION,
                    event.remediation_event_id,
                    event.remediation_case_id,
                    event.event_type.value,
                    event.occurred_at,
                    payload_json,
                    previous_hash,
                    record_hash,
                ),
            )

            return record_hash

    def append_many(
        self,
        events: tuple[RemediationEvent, ...],
    ) -> tuple[str, ...]:
        return tuple(
            self.append(event)
            for event in events
        )

    def event_count(self) -> int:
        with self._connection() as db:
            row = db.execute(
                "SELECT COUNT(*) AS count FROM remediation_events"
            ).fetchone()
        return int(row["count"])

    def events_for_case(
        self,
        remediation_case_id: str,
    ) -> tuple[RemediationEvent, ...]:
        if not isinstance(remediation_case_id, str) or not remediation_case_id.strip():
            raise ValueError(
                "remediation_case_id must be a non-empty string"
            )

        with self._connection() as db:
            rows = db.execute(
                """
                SELECT *
                FROM remediation_events
                WHERE remediation_case_id = ?
                ORDER BY sequence ASC
                """,
                (remediation_case_id,),
            ).fetchall()

        return tuple(
            self._row_to_event(row)
            for row in rows
        )

    def snapshot(
        self,
        remediation_case_id: str,
    ) -> RemediationCase:
        events = self.events_for_case(
            remediation_case_id
        )
        try:
            return derive_remediation_case(events)
        except RemediationLifecycleError as exc:
            raise RemediationStoreError(str(exc)) from exc

    def verify_integrity(self) -> None:
        with self._connection() as db:
            rows = db.execute(
                """
                SELECT *
                FROM remediation_events
                ORDER BY sequence ASC
                """
            ).fetchall()

        expected_previous = "GENESIS"
        seen_event_ids: set[str] = set()
        by_case: dict[str, list[RemediationEvent]] = {}

        for row in rows:
            if int(row["store_schema_version"]) != STORE_SCHEMA_VERSION:
                raise RemediationStoreCorruptRecord(
                    "STORE_SCHEMA_VERSION_MISMATCH"
                )

            previous_hash = str(row["previous_hash"])
            if previous_hash != expected_previous:
                raise RemediationStoreCorruptRecord(
                    "HASH_CHAIN_PREVIOUS_MISMATCH"
                )

            event_id = str(row["remediation_event_id"])
            if event_id in seen_event_ids:
                raise RemediationStoreCorruptRecord(
                    "DUPLICATE_REMEDIATION_EVENT_ID"
                )
            seen_event_ids.add(event_id)

            payload = json.loads(str(row["payload_json"]))
            try:
                event = RemediationEvent.from_dict(payload)
            except (ValueError, TypeError, KeyError) as exc:
                raise RemediationStoreCorruptRecord(
                    "INVALID_EVENT_PAYLOAD"
                ) from exc

            if event.remediation_event_id != event_id:
                raise RemediationStoreCorruptRecord(
                    "EVENT_ID_PAYLOAD_MISMATCH"
                )
            if event.remediation_case_id != str(row["remediation_case_id"]):
                raise RemediationStoreCorruptRecord(
                    "CASE_ID_PAYLOAD_MISMATCH"
                )
            if event.event_type.value != str(row["event_type"]):
                raise RemediationStoreCorruptRecord(
                    "EVENT_TYPE_PAYLOAD_MISMATCH"
                )
            if event.occurred_at != str(row["occurred_at"]):
                raise RemediationStoreCorruptRecord(
                    "EVENT_TIME_PAYLOAD_MISMATCH"
                )

            material = self._record_material(
                remediation_event_id=event_id,
                remediation_case_id=event.remediation_case_id,
                event_type=event.event_type.value,
                occurred_at=event.occurred_at,
                payload=payload,
                previous_hash=previous_hash,
            )
            calculated = hashlib.sha256(
                material.encode("utf-8")
            ).hexdigest()

            stored_hash = str(row["record_hash"])
            if calculated != stored_hash:
                raise RemediationStoreCorruptRecord(
                    "HASH_CHAIN_RECORD_MISMATCH"
                )

            expected_previous = stored_hash
            by_case.setdefault(
                event.remediation_case_id,
                [],
            ).append(event)

        for case_id, events in by_case.items():
            try:
                derived = derive_remediation_case(
                    tuple(events)
                )
            except (
                ValueError,
                TypeError,
                RemediationLifecycleError,
            ) as exc:
                raise RemediationStoreCorruptRecord(
                    f"INVALID_CASE_LIFECYCLE:{case_id}"
                ) from exc

            if derived.remediation_case_id != case_id:
                raise RemediationStoreCorruptRecord(
                    "DERIVED_CASE_ID_MISMATCH"
                )
