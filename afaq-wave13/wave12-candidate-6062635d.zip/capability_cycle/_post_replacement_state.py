"""Shared process-local decision cache; no orchestration dependencies."""

from typing import Any

_DECISIONS: dict[str, Any] = {}


def clear_post_replacement_decisions() -> None:
    _DECISIONS.clear()
