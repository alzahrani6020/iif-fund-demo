"""Pure Cycle domain.

No storage implementation.
No engine dependency.
No authority implementation.
No learning/genesis/training dependency.
"""

from __future__ import annotations

import hashlib
import json
import uuid

from dataclasses import (
    asdict,
    dataclass,
    field,
)
from datetime import (
    datetime,
    timezone,
)
from enum import Enum
from typing import (
    Any,
    Mapping,
)


EXECUTION_CYCLE = "EXECUTION_CYCLE"


def utcnow() -> str:
    return datetime.now(
        timezone.utc
    ).isoformat()


def stable_digest(
    value: Any,
) -> str:
    payload = json.dumps(
        value,
        sort_keys=True,
        ensure_ascii=False,
        separators=(",", ":"),
        default=str,
    )

    return hashlib.sha256(
        payload.encode("utf-8")
    ).hexdigest()


class CycleState(str, Enum):
    CREATED = "CREATED"
    OBSERVED = "OBSERVED"
    DECIDED = "DECIDED"
    EXECUTING = "EXECUTING"
    OUTCOME_OBSERVED = "OUTCOME_OBSERVED"
    EVIDENCE_RECORDED = "EVIDENCE_RECORDED"

    BLOCKED = "BLOCKED"
    FAILED = "FAILED"
    UNKNOWN = "UNKNOWN"
    CANCELLED = "CANCELLED"

    CLOSED_SUCCESS = "CLOSED_SUCCESS"
    CLOSED_FAILED = "CLOSED_FAILED"
    CLOSED_UNKNOWN = "CLOSED_UNKNOWN"


TERMINAL_STATES = frozenset(
    {
        CycleState.CLOSED_SUCCESS,
        CycleState.CLOSED_FAILED,
        CycleState.CLOSED_UNKNOWN,
        CycleState.CANCELLED,
    }
)


ALLOWED_TRANSITIONS = {
    CycleState.CREATED: frozenset(
        {
            CycleState.OBSERVED,
            CycleState.BLOCKED,
            CycleState.FAILED,
            CycleState.CANCELLED,
        }
    ),
    CycleState.OBSERVED: frozenset(
        {
            CycleState.DECIDED,
            CycleState.BLOCKED,
            CycleState.FAILED,
            CycleState.CANCELLED,
        }
    ),
    CycleState.DECIDED: frozenset(
        {
            CycleState.EXECUTING,
            CycleState.BLOCKED,
            CycleState.FAILED,
            CycleState.CANCELLED,
        }
    ),
    CycleState.EXECUTING: frozenset(
        {
            CycleState.OUTCOME_OBSERVED,
            CycleState.UNKNOWN,
            CycleState.FAILED,
        }
    ),
    CycleState.OUTCOME_OBSERVED: frozenset(
        {
            CycleState.EVIDENCE_RECORDED,
            CycleState.FAILED,
        }
    ),
    CycleState.EVIDENCE_RECORDED: frozenset(
        {
            CycleState.CLOSED_SUCCESS,
            CycleState.CLOSED_FAILED,
            CycleState.CLOSED_UNKNOWN,
        }
    ),
    CycleState.BLOCKED: frozenset(
        {
            CycleState.CLOSED_FAILED,
        }
    ),
    CycleState.FAILED: frozenset(
        {
            CycleState.CLOSED_FAILED,
        }
    ),
    CycleState.UNKNOWN: frozenset(
        {
            CycleState.EVIDENCE_RECORDED,
            CycleState.CLOSED_UNKNOWN,
        }
    ),
    CycleState.CANCELLED: frozenset(),
    CycleState.CLOSED_SUCCESS: frozenset(),
    CycleState.CLOSED_FAILED: frozenset(),
    CycleState.CLOSED_UNKNOWN: frozenset(),
}


class InvalidCycleTransition(
    RuntimeError
):
    pass


@dataclass
class CycleRecord:
    cycle_id: str
    task: str

    cycle_type: str = EXECUTION_CYCLE

    state: CycleState = (
        CycleState.CREATED
    )

    state_version: int = 0

    parent_cycle_id: (
        str | None
    ) = None

    related_cycle_ids: list[str] = field(
        default_factory=list
    )

    context: dict[str, Any] = field(
        default_factory=dict
    )

    context_fingerprint: str = ""

    required_capabilities: list[str] = field(
        default_factory=list
    )

    expected_outcome: dict[str, Any] = field(
        default_factory=dict
    )

    actual_outcome: dict[str, Any] = field(
        default_factory=dict
    )

    outcome_delta: dict[str, Any] = field(
        default_factory=dict
    )

    decisions: list[
        dict[str, Any]
    ] = field(
        default_factory=list
    )

    execution_refs: list[
        dict[str, Any]
    ] = field(
        default_factory=list
    )

    evidence_refs: list[
        dict[str, Any]
    ] = field(
        default_factory=list
    )

    created_at: str = field(
        default_factory=utcnow
    )

    updated_at: str = field(
        default_factory=utcnow
    )

    closed_at: (
        str | None
    ) = None

    def transition(
        self,
        target: CycleState,
    ) -> None:
        if self.state in TERMINAL_STATES:
            raise InvalidCycleTransition(
                "terminal cycle cannot transition: "
                f"{self.state.value}"
                " -> "
                f"{target.value}"
            )

        allowed = (
            ALLOWED_TRANSITIONS.get(
                self.state,
                frozenset(),
            )
        )

        if target not in allowed:
            raise InvalidCycleTransition(
                "invalid cycle transition: "
                f"{self.state.value}"
                " -> "
                f"{target.value}"
            )

        self.state = target
        self.state_version += 1
        self.updated_at = utcnow()

        if target in TERMINAL_STATES:
            self.closed_at = (
                self.updated_at
            )

    def as_dict(
        self,
    ) -> dict[str, Any]:
        data = asdict(self)

        data["state"] = (
            self.state.value
        )

        return data


def new_execution_cycle(
    *,
    task: str,
    context: (
        Mapping[str, Any] | None
    ) = None,
    required_capabilities: (
        tuple[str, ...]
        | list[str]
    ) = (),
    expected_outcome: (
        Mapping[str, Any] | None
    ) = None,
    cycle_id: (
        str | None
    ) = None,
    parent_cycle_id: (
        str | None
    ) = None,
) -> CycleRecord:
    normalized_task = str(
        task
    ).strip()

    if not normalized_task:
        raise ValueError(
            "cycle task is required"
        )

    ctx = dict(
        context or {}
    )

    return CycleRecord(
        cycle_id=(
            cycle_id
            or (
                "CYC-"
                + uuid.uuid4().hex[:20]
            )
        ),
        task=normalized_task,
        cycle_type=EXECUTION_CYCLE,
        parent_cycle_id=(
            parent_cycle_id
        ),
        context=ctx,
        context_fingerprint=(
            stable_digest(ctx)
        ),
        required_capabilities=[
            str(item)
            for item
            in required_capabilities
            if str(item).strip()
        ],
        expected_outcome=dict(
            expected_outcome
            or {}
        ),
    )


def outcome_delta(
    expected: (
        Mapping[str, Any] | None
    ),
    actual: (
        Mapping[str, Any] | None
    ),
) -> dict[str, Any]:
    if not expected or not actual:
        return {}

    delta: dict[str, Any] = {}

    for (
        key,
        expected_value,
    ) in expected.items():
        if key not in actual:
            continue

        actual_value = actual[
            key
        ]

        numeric_expected = (
            isinstance(
                expected_value,
                (int, float),
            )
            and not isinstance(
                expected_value,
                bool,
            )
        )

        numeric_actual = (
            isinstance(
                actual_value,
                (int, float),
            )
            and not isinstance(
                actual_value,
                bool,
            )
        )

        if (
            numeric_expected
            and numeric_actual
        ):
            delta[key] = (
                actual_value
                - expected_value
            )
            continue

        scalar_types = (
            str,
            bool,
            type(None),
        )

        if (
            isinstance(
                expected_value,
                scalar_types,
            )
            and isinstance(
                actual_value,
                scalar_types,
            )
        ):
            delta[key] = {
                "expected": (
                    expected_value
                ),
                "actual": (
                    actual_value
                ),
                "changed": (
                    expected_value
                    != actual_value
                ),
            }

    return delta
