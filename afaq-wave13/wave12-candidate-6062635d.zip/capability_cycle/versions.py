"""Capability version snapshots and explicit verified restore.

Narrow binding for already-registered capability IDs only.
Does not register new IDs, learn, train, promote, or genesis.
Drift evaluations may be referenced as a reason; they do not authorize restore.
"""

from __future__ import annotations

import base64
import hashlib
import json
import marshal
import types
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Mapping

from current_authority.resolver import AuthorityRequest, resolve

from .certification import evaluate, is_usable
from .handlers import (
    HANDLERS,
    artifact_hash,
    bind_active,
    clear_active_restore,
    export_active_restore,
    get_active_handler,
    has_implementation,
    set_active_restore,
    unbind_active,
)
from .mission import verify_mission
from .performance_store import PerformanceStore, StoreCorruptRecord, StoreReadFailed
from .planner import Requirement
from .sandbox import run_sandboxed

_SAFE_GLOBALS = {"json": json, "hashlib": hashlib}


class SnapshotFailed(RuntimeError):
    pass


class RestoreFailed(RuntimeError):
    pass


@dataclass(frozen=True)
class CapabilitySnapshot:
    snapshot_id: str
    capability_id: str
    version_id: str
    artifact_hash: str
    implementation_reference: str
    provenance: str
    sandbox_validation_reference: str | None
    certification_reference: str | None
    created_at: str
    source_runtime_identity: str | None
    status: str
    evidence_refs: tuple[str, ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "snapshot_id": self.snapshot_id,
            "capability_id": self.capability_id,
            "version_id": self.version_id,
            "artifact_hash": self.artifact_hash,
            "implementation_reference": self.implementation_reference,
            "provenance": self.provenance,
            "sandbox_validation_reference": self.sandbox_validation_reference,
            "certification_reference": self.certification_reference,
            "created_at": self.created_at,
            "source_runtime_identity": self.source_runtime_identity,
            "status": self.status,
            "evidence_refs": list(self.evidence_refs),
        }


@dataclass(frozen=True)
class RestoreResult:
    rollback_id: str
    capability_id: str
    from_version: str | None
    to_version: str | None
    snapshot_id: str | None
    restore_result: str
    post_restore_verification: dict[str, Any]
    reason: str | None
    drift_evaluation_id: str | None
    authority_result: str | None
    details: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "rollback_id": self.rollback_id,
            "capability_id": self.capability_id,
            "from_version": self.from_version,
            "to_version": self.to_version,
            "snapshot_id": self.snapshot_id,
            "restore_result": self.restore_result,
            "post_restore_verification": self.post_restore_verification,
            "reason": self.reason,
            "drift_evaluation_id": self.drift_evaluation_id,
            "authority_result": self.authority_result,
            "details": self.details,
            "learning_activated": False,
            "training_activated": False,
            "auto_promoted": False,
            "automatic_rollback": False,
        }


@dataclass(frozen=True)
class RuntimeIdentity:
    capability_id: str
    version_id: str | None
    artifact_hash: str | None
    snapshot_id: str | None


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def active_identity(
    capability_id: str, store: PerformanceStore | None = None
) -> RuntimeIdentity:
    binding = store.get_binding(capability_id) if store is not None else None
    return RuntimeIdentity(
        capability_id=capability_id,
        version_id=binding["version_id"] if binding else artifact_hash(capability_id),
        artifact_hash=artifact_hash(capability_id),
        snapshot_id=binding["snapshot_id"] if binding else None,
    )


def _capture(capability_id: str) -> tuple[str, str, Any]:
    handler = get_active_handler(capability_id)
    if handler is None:
        raise SnapshotFailed("UNKNOWN_IMPLEMENTATION")
    blob = marshal.dumps(handler.__code__)
    digest = hashlib.sha256(handler.__code__.co_code).hexdigest()
    encoded = base64.b64encode(blob).decode("ascii")
    return encoded, digest, handler


def _rebuild(artifact_blob: str, expected_hash: str, name: str):
    code = marshal.loads(base64.b64decode(artifact_blob))
    digest = hashlib.sha256(code.co_code).hexdigest()
    if digest != expected_hash:
        raise RestoreFailed("ARTIFACT_HASH_MISMATCH")
    return types.FunctionType(code, dict(_SAFE_GLOBALS), name)


def _simple_perf(capability_id: str, outcome: str) -> Any:
    return types.SimpleNamespace(capability_id=capability_id, outcome=outcome)


def _to_snapshot(row: Mapping[str, Any]) -> CapabilitySnapshot:
    return CapabilitySnapshot(
        snapshot_id=row["snapshot_id"],
        capability_id=row["capability_id"],
        version_id=row["version_id"],
        artifact_hash=row["artifact_hash"],
        implementation_reference=row["implementation_reference"],
        provenance=row["provenance"],
        sandbox_validation_reference=row.get("sandbox_validation_reference"),
        certification_reference=row.get("certification_reference"),
        created_at=row["created_at"],
        source_runtime_identity=row.get("source_runtime_identity"),
        status=row["status"],
        evidence_refs=tuple(row.get("evidence_refs") or ()),
    )


def snapshot_capability(
    capability_id: str,
    *,
    store: PerformanceStore,
    payload: dict[str, Any] | None = None,
) -> CapabilitySnapshot:
    if not has_implementation(capability_id):
        raise SnapshotFailed("DESCRIPTOR_ONLY_NOT_ELIGIBLE")
    payload = payload or {"data": {"capability_id": capability_id}}
    sandbox = run_sandboxed(capability_id, payload)
    if not sandbox.validated:
        raise SnapshotFailed(sandbox.failure_class or "SANDBOX_VALIDATION_FAILED")
    certified = evaluate(
        capability_id,
        sandbox=sandbox,
        contract_valid=True,
        tests_present=True,
        evidence={"provenance": "handler_registry"},
        requester="runtime",
    )
    if not is_usable(certified):
        raise SnapshotFailed(certified.reason or "UNCERTIFIED")
    outcome = (
        "SUCCESS"
        if sandbox.result and sandbox.result.get("ok") is True
        else "FAILED"
    )
    mission = verify_mission(
        requirement=Requirement(explicit_capability_ids=(capability_id,)),
        final_plan_ids=(capability_id,),
        observations=(
            {
                "capability_id": capability_id,
                "class": "OK" if outcome == "SUCCESS" else "FAILED",
                "result": sandbox.result,
            },
        ),
        performance=(_simple_perf(capability_id, outcome),),
    )
    if mission.status != "VERIFIED":
        raise SnapshotFailed(mission.reason or "MISSION_NOT_VERIFIED")

    encoded, digest, handler = _capture(capability_id)
    for existing in store.list_snapshots(capability_id):
        if existing["artifact_hash"] == digest and existing["status"] != "INVALID":
            return _to_snapshot(existing)

    for existing in store.list_snapshots(capability_id):
        if existing["status"] == "CURRENT":
            store.set_snapshot_status(existing["snapshot_id"], "AVAILABLE")

    created = _now()
    snapshot_id = uuid.uuid4().hex
    row = store.persist_snapshot(
        {
            "snapshot_id": snapshot_id,
            "capability_id": capability_id,
            "version_id": digest,
            "artifact_hash": digest,
            "artifact_blob": encoded,
            "implementation_reference": getattr(handler, "__name__", capability_id),
            "provenance": "handler_registry",
            "sandbox_validation_reference": sandbox.outcome,
            "certification_reference": certified.state,
            "created_at": created,
            "source_runtime_identity": digest,
            "status": "CURRENT",
            "evidence_refs": [
                f"sandbox:{sandbox.outcome}",
                f"cert:{certified.state}",
                f"mission:{mission.status}",
            ],
        }
    )
    store.set_binding(
        {
            "capability_id": capability_id,
            "snapshot_id": snapshot_id,
            "version_id": digest,
            "artifact_hash": digest,
            "updated_at": created,
        }
    )
    set_active_restore(
        capability_id,
        {
            "capability_id": capability_id,
            "artifact_hash": digest,
            "artifact": encoded,
        },
    )
    bind_active(capability_id, digest, handler)
    return _to_snapshot(row)


def _record_restore(
    store: PerformanceStore,
    *,
    rollback_id: str,
    capability_id: str,
    from_version: str | None,
    to_version: str | None,
    snapshot_id: str | None,
    snapshot_hash: str | None,
    restore_result: str,
    reason: str | None,
    drift_evaluation_id: str | None,
    authority_result: str | None,
    verification: dict[str, Any],
) -> RestoreResult:
    store.persist_restore(
        {
            "rollback_id": rollback_id,
            "correlation_id": rollback_id,
            "capability_id": capability_id,
            "from_version": from_version,
            "to_version": to_version,
            "reason": reason,
            "drift_evaluation_id": drift_evaluation_id,
            "authority_result": authority_result,
            "snapshot_id": snapshot_id,
            "snapshot_hash": snapshot_hash,
            "restore_result": restore_result,
            "post_restore_verification": verification,
        }
    )
    return RestoreResult(
        rollback_id=rollback_id,
        capability_id=capability_id,
        from_version=from_version,
        to_version=to_version,
        snapshot_id=snapshot_id,
        restore_result=restore_result,
        post_restore_verification=verification,
        reason=reason,
        drift_evaluation_id=drift_evaluation_id,
        authority_result=authority_result,
        details={"authority": False, "automatic_rollback": False},
    )


def restore_capability(
    capability_id: str,
    *,
    store: PerformanceStore,
    snapshot_id: str | None = None,
    version_id: str | None = None,
    reason: str | None = None,
    drift_evaluation_id: str | None = None,
    historical_records: tuple[Mapping[str, Any], ...] = (),
    payload: dict[str, Any] | None = None,
) -> RestoreResult:
    """Explicit restore. Drift IDs are references only and do not authorize."""
    del historical_records
    rollback_id = uuid.uuid4().hex
    previous = store.get_binding(capability_id)
    previous_overlay = get_active_handler(capability_id)
    previous_blob = export_active_restore(capability_id)
    previous_version = previous["version_id"] if previous else artifact_hash(capability_id)
    authority = resolve(AuthorityRequest(action="recoverable_defect_correction"))
    if authority.outcome != "ALLOW":
        return _record_restore(
            store,
            rollback_id=rollback_id,
            capability_id=capability_id,
            from_version=previous_version,
            to_version=version_id,
            snapshot_id=snapshot_id,
            snapshot_hash=None,
            restore_result="FAILED",
            reason=reason,
            drift_evaluation_id=drift_evaluation_id,
            authority_result=authority.reason,
            verification={"failed": "AUTHORITY"},
        )

    if not has_implementation(capability_id):
        return _record_restore(
            store,
            rollback_id=rollback_id,
            capability_id=capability_id,
            from_version=previous_version,
            to_version=version_id,
            snapshot_id=snapshot_id,
            snapshot_hash=None,
            restore_result="FAILED",
            reason=reason,
            drift_evaluation_id=drift_evaluation_id,
            authority_result=authority.reason,
            verification={"failed": "DESCRIPTOR_ONLY_NOT_ELIGIBLE"},
        )

    if snapshot_id is None and version_id is None:
        return _record_restore(
            store,
            rollback_id=rollback_id,
            capability_id=capability_id,
            from_version=previous_version,
            to_version=None,
            snapshot_id=None,
            snapshot_hash=None,
            restore_result="FAILED",
            reason=reason,
            drift_evaluation_id=drift_evaluation_id,
            authority_result=authority.reason,
            verification={"failed": "MISSING_SNAPSHOT"},
        )

    try:
        if snapshot_id:
            snap = store.get_snapshot(snapshot_id)
        else:
            matches = [
                item
                for item in store.list_snapshots(capability_id)
                if item["version_id"] == version_id
            ]
            if not matches:
                raise StoreReadFailed("STORE_READ_FAILED: unknown version")
            snap = matches[-1]
    except StoreCorruptRecord as exc:
        return _record_restore(
            store,
            rollback_id=rollback_id,
            capability_id=capability_id,
            from_version=previous_version,
            to_version=version_id,
            snapshot_id=snapshot_id,
            snapshot_hash=None,
            restore_result="FAILED",
            reason=reason,
            drift_evaluation_id=drift_evaluation_id,
            authority_result=authority.reason,
            verification={"failed": "STORE_CORRUPT_RECORD", "error": str(exc)},
        )
    except StoreReadFailed as exc:
        return _record_restore(
            store,
            rollback_id=rollback_id,
            capability_id=capability_id,
            from_version=previous_version,
            to_version=version_id,
            snapshot_id=snapshot_id,
            snapshot_hash=None,
            restore_result="FAILED",
            reason=reason,
            drift_evaluation_id=drift_evaluation_id,
            authority_result=authority.reason,
            verification={"failed": "MISSING_SNAPSHOT", "error": str(exc)},
        )

    if snap["capability_id"] != capability_id:
        return _record_restore(
            store,
            rollback_id=rollback_id,
            capability_id=capability_id,
            from_version=previous_version,
            to_version=snap.get("version_id"),
            snapshot_id=snap["snapshot_id"],
            snapshot_hash=snap.get("artifact_hash"),
            restore_result="FAILED",
            reason=reason,
            drift_evaluation_id=drift_evaluation_id,
            authority_result=authority.reason,
            verification={"failed": "CAPABILITY_MISMATCH"},
        )
    if snap["status"] == "INVALID":
        return _record_restore(
            store,
            rollback_id=rollback_id,
            capability_id=capability_id,
            from_version=previous_version,
            to_version=snap["version_id"],
            snapshot_id=snap["snapshot_id"],
            snapshot_hash=snap["artifact_hash"],
            restore_result="FAILED",
            reason=reason,
            drift_evaluation_id=drift_evaluation_id,
            authority_result=authority.reason,
            verification={"failed": "INVALID_TARGET"},
        )
    if snap.get("certification_reference") != "CERTIFIED":
        return _record_restore(
            store,
            rollback_id=rollback_id,
            capability_id=capability_id,
            from_version=previous_version,
            to_version=snap["version_id"],
            snapshot_id=snap["snapshot_id"],
            snapshot_hash=snap["artifact_hash"],
            restore_result="FAILED",
            reason=reason,
            drift_evaluation_id=drift_evaluation_id,
            authority_result=authority.reason,
            verification={"failed": "UNCERTIFIED_TARGET"},
        )

    try:
        rebuilt = _rebuild(
            snap["artifact_blob"], snap["artifact_hash"], capability_id
        )
    except RestoreFailed as exc:
        return _record_restore(
            store,
            rollback_id=rollback_id,
            capability_id=capability_id,
            from_version=previous_version,
            to_version=snap["version_id"],
            snapshot_id=snap["snapshot_id"],
            snapshot_hash=snap["artifact_hash"],
            restore_result="FAILED",
            reason=reason,
            drift_evaluation_id=drift_evaluation_id,
            authority_result=authority.reason,
            verification={"failed": str(exc)},
        )
    except Exception as exc:
        return _record_restore(
            store,
            rollback_id=rollback_id,
            capability_id=capability_id,
            from_version=previous_version,
            to_version=snap["version_id"],
            snapshot_id=snap["snapshot_id"],
            snapshot_hash=snap["artifact_hash"],
            restore_result="FAILED",
            reason=reason,
            drift_evaluation_id=drift_evaluation_id,
            authority_result=authority.reason,
            verification={"failed": "CORRUPT_SNAPSHOT", "error": str(exc)},
        )

    bind_active(capability_id, snap["version_id"], rebuilt)
    set_active_restore(
        capability_id,
        {
            "capability_id": capability_id,
            "artifact_hash": snap["artifact_hash"],
            "artifact": snap["artifact_blob"],
        },
    )
    store.set_binding(
        {
            "capability_id": capability_id,
            "snapshot_id": snap["snapshot_id"],
            "version_id": snap["version_id"],
            "artifact_hash": snap["artifact_hash"],
            "updated_at": _now(),
        }
    )

    verification = _verify_active(capability_id, snap, payload)
    if not verification.get("ok"):
        if previous_overlay is not None and previous:
            bind_active(capability_id, previous["version_id"], previous_overlay)
            if previous_blob:
                set_active_restore(capability_id, previous_blob)
            store.set_binding(previous)
        else:
            unbind_active(capability_id)
            clear_active_restore(capability_id)
        return _record_restore(
            store,
            rollback_id=rollback_id,
            capability_id=capability_id,
            from_version=previous_version,
            to_version=snap["version_id"],
            snapshot_id=snap["snapshot_id"],
            snapshot_hash=snap["artifact_hash"],
            restore_result="FAILED",
            reason=reason,
            drift_evaluation_id=drift_evaluation_id,
            authority_result=authority.reason,
            verification=verification,
        )

    for existing in store.list_snapshots(capability_id):
        if existing["snapshot_id"] == snap["snapshot_id"]:
            store.set_snapshot_status(existing["snapshot_id"], "CURRENT")
        elif existing["status"] == "CURRENT":
            store.set_snapshot_status(existing["snapshot_id"], "AVAILABLE")

    return _record_restore(
        store,
        rollback_id=rollback_id,
        capability_id=capability_id,
        from_version=previous_version,
        to_version=snap["version_id"],
        snapshot_id=snap["snapshot_id"],
        snapshot_hash=snap["artifact_hash"],
        restore_result="VERIFIED",
        reason=reason,
        drift_evaluation_id=drift_evaluation_id,
        authority_result=authority.reason,
        verification=verification,
    )


def _verify_active(
    capability_id: str,
    snap: Mapping[str, Any],
    payload: dict[str, Any] | None,
) -> dict[str, Any]:
    payload = payload or {"data": {"capability_id": capability_id}}
    current_hash = artifact_hash(capability_id)
    identity_ok = (
        current_hash == snap["artifact_hash"]
        and capability_id in HANDLERS
    )
    blocked = run_sandboxed(capability_id, payload, bypass=True)
    sandbox = run_sandboxed(capability_id, payload)
    certified = evaluate(
        capability_id,
        sandbox=sandbox,
        contract_valid=True,
        tests_present=True,
        evidence={"provenance": "handler_registry"},
        requester="runtime",
    )
    ok = (
        identity_ok
        and blocked.failure_class == "SANDBOX_BYPASS_DENIED"
        and sandbox.validated
        and is_usable(certified)
    )
    return {
        "ok": ok,
        "active_capability_id": capability_id,
        "active_artifact_hash": current_hash,
        "snapshot_artifact_hash": snap["artifact_hash"],
        "sandbox_bypass_denied": blocked.failure_class == "SANDBOX_BYPASS_DENIED",
        "sandbox_validated": sandbox.validated,
        "certification_state": certified.state,
        "certification_usable": is_usable(certified),
        "handlers_keys_unchanged": capability_id in HANDLERS,
    }
