"""Replaceable local adapters for Cycle ports."""

from __future__ import annotations

import json
import os
import uuid

from datetime import (
    datetime,
    timezone,
)
from pathlib import Path
from typing import (
    Any,
    Mapping,
)

from afaq_agent_runtime.audit_ledger import (
    AuditLedger,
)

from .cycle_core import (
    CycleRecord,
)
from .cycle_ports import (
    EvidenceReceipt,
)


def utcnow() -> str:
    return datetime.now(
        timezone.utc
    ).isoformat()


class AuditLedgerEvidenceAdapter:
    """Current local EvidencePort implementation."""

    def __init__(
        self,
        path: str | Path,
    ) -> None:
        self.path = Path(path)

        self._ledger = AuditLedger(
            self.path
        )

    def append_event(
        self,
        *,
        cycle_id: str,
        event_type: str,
        event_sequence: int,
        state: str,
        payload: (
            Mapping[str, Any] | None
        ) = None,
        actor: str = "cycle-runtime",
        environment: (
            str | None
        ) = None,
        parent_event_id: (
            str | None
        ) = None,
        causation_id: (
            str | None
        ) = None,
        correlation_id: (
            str | None
        ) = None,
    ) -> EvidenceReceipt:
        event_id = (
            "EVT-"
            + uuid.uuid4().hex[:20]
        )

        detail = {
            "schema": (
                "AFAQ_CYCLE_EVENT_V1"
            ),
            "event_id": event_id,
            "cycle_id": cycle_id,
            "event_type": (
                event_type
            ),
            "event_sequence": (
                event_sequence
            ),
            "state": state,
            "parent_event_id": (
                parent_event_id
            ),
            "causation_id": (
                causation_id
            ),
            "correlation_id": (
                correlation_id
            ),
            "environment": (
                environment
            ),
            "payload": dict(
                payload or {}
            ),
            "recorded_at": utcnow(),
            "truth_semantics": (
                "HISTORICAL_RECORD_"
                "NOT_AUTOMATIC_VERIFIED_TRUTH"
            ),
        }

        sequence = (
            self._ledger.record(
                "cycle_event",
                task_id=cycle_id,
                actor=actor,
                environment=environment,
                detail=detail,
            )
        )

        return EvidenceReceipt(
            store="AuditLedger",
            record_id=str(
                sequence
            ),
            event_id=event_id,
            cycle_id=cycle_id,
            event_type=event_type,
            event_sequence=(
                event_sequence
            ),
        )

    def verify_integrity(
        self,
    ) -> dict[str, Any]:
        return self._ledger.verify()

    def close(
        self,
    ) -> None:
        self._ledger.close()


class CycleStateConflict(
    RuntimeError
):
    pass


class LocalJsonCycleStateAdapter:
    """Local-development state adapter.

    Uses optimistic concurrency.

    JSON is an implementation choice,
    not an architecture invariant.
    """

    def __init__(
        self,
        root: str | Path,
    ) -> None:
        self.root = Path(root)

        self.root.mkdir(
            parents=True,
            exist_ok=True,
        )

    def _path(
        self,
        cycle_id: str,
    ) -> Path:
        safe = "".join(
            char
            for char in cycle_id
            if (
                char.isalnum()
                or char in "-_"
            )
        )

        if not safe:
            raise ValueError(
                "invalid cycle id"
            )

        return (
            self.root
            / f"{safe}.json"
        )

    def save(
        self,
        cycle: CycleRecord,
        *,
        expected_previous_version: (
            int | None
        ) = None,
    ) -> str:
        path = self._path(
            cycle.cycle_id
        )

        if (
            expected_previous_version
            is None
        ):
            if path.exists():
                raise CycleStateConflict(
                    "cycle already exists: "
                    f"{cycle.cycle_id}"
                )

        else:
            if not path.exists():
                raise CycleStateConflict(
                    "expected existing cycle: "
                    f"{cycle.cycle_id}"
                )

            existing = json.loads(
                path.read_text(
                    encoding="utf-8"
                )
            )

            current_version = int(
                existing.get(
                    "state_version",
                    -1,
                )
            )

            if (
                current_version
                != expected_previous_version
            ):
                raise CycleStateConflict(
                    "stale cycle state: "
                    f"expected "
                    f"{expected_previous_version}, "
                    f"found "
                    f"{current_version}"
                )

        temporary = path.with_name(
            path.name
            + ".tmp"
        )

        temporary.write_text(
            json.dumps(
                cycle.as_dict(),
                ensure_ascii=False,
                indent=2,
            )
            + "\n",
            encoding="utf-8",
        )

        os.replace(
            temporary,
            path,
        )

        return str(path)

    def load(
        self,
        cycle_id: str,
    ) -> dict[str, Any]:
        return json.loads(
            self._path(
                cycle_id
            ).read_text(
                encoding="utf-8"
            )
        )
