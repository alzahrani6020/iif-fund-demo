"""Controlled improvement: approved proposal → candidate → comparison → replacement.

Replacement is owner-gated, same-ID only, and never automatic.
Does not promote, train, orchestrate, or bind dormant capabilities.
"""

from __future__ import annotations

import hashlib
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Mapping

from current_authority.resolver import AuthorityRequest, resolve

from .certification import (
    certify_candidate_behavior,
    evaluate,
    evaluate_candidate_behavior,
    is_usable,
    review_candidate,
)
from .genesis import (
    ARTIFACT_IMPLEMENTATION_SOURCE,
    IMPLEMENTATION_GENERATOR_IDENTITY,
    GenesisResult,
    generate_implementation_candidate,
)
from .handlers import (
    CANDIDATE_BEHAVIORALLY_CERTIFIED,
    CANDIDATE_INDEPENDENTLY_REVIEWED,
    CANDIDATE_STATE,
    CERTIFICATION_KIND_BEHAVIORAL,
    HANDLERS,
    _ACTIVE,
    _load_certified_handle,
    active_version_id,
    artifact_hash,
    bind_active,
    export_active_restore,
    export_candidate_artifact,
    get_active_handler,
    get_candidate,
    get_candidate_behavior,
    get_candidate_behavior_certification,
    get_candidate_behavior_evaluation,
    get_candidate_sandbox,
    has_implementation,
    set_active_restore,
)
from .versions import SnapshotFailed, restore_capability, snapshot_capability
from .sandbox import (
    execute_candidate_behavior,
    isolated_shadow_restore,
    validate_candidate,
)
from .learning import (
    ImprovementProposal,
    ImprovementProposalEvaluation,
    LearningError,
    LearningObservation,
    LearningThresholds,
    _observation_from_mapping,
    _proposal_from_mapping,
    _reject_claims,
    get_improvement_proposal,
    get_learning_observation,
    get_proposal_evaluation,
)
from .performance_store import PerformanceStore, StoreReadFailed
from .planner import Requirement
from .runtime import execute_plan
from ._post_replacement_state import clear_post_replacement_decisions

_IMPLEMENTER_IDENTITIES = frozenset({"implementer"})
_VALIDATOR_IDENTITIES = frozenset({"validator", "reviewer"})
_COMPARATOR_IDENTITIES = frozenset({"comparator", "evaluator", "reviewer"})
_REPLACER_IDENTITIES = frozenset({"replacer", "owner"})
_BLOCKED_REPLACERS = frozenset(
    {
        "learner",
        "generator",
        "analyze_runtime_evidence",
        "implementer",
        "evaluator",
        "reviewer",
        "comparator",
        "certifier",
        "activator",
    }
)
_BLOCKED_COMPARATORS = frozenset(
    {
        "learner",
        "generator",
        "analyze_runtime_evidence",
        "implementer",
        "certifier",
        "activator",
    }
)
COMPARISON_STATUSES = frozenset(
    {
        "PROVEN_IMPROVEMENT",
        "EQUIVALENT",
        "WORSE",
        "INSUFFICIENT_COMPARATIVE_EVIDENCE",
    }
)
_COMPARISON_OUTPUT_CONTRACT = {"ok": "bool", "digest": "hex"}
_SAMPLE_RULE = (
    "minimum 5 comparable executions per side "
    "(LearningThresholds.min_comparative_samples); "
    "deterministic digest agreement is recorded and does not waive the minimum"
)
_BLOCKED_VALIDATORS = frozenset(
    {
        "learner",
        "generator",
        "analyze_runtime_evidence",
        "evaluator",
        "implementer",
        "certifier",
        "activator",
    }
)
_BLOCKED_IMPLEMENTERS = frozenset(
    {
        "learner",
        "generator",
        "analyze_runtime_evidence",
        "reviewer",
        "evaluator",
        "certifier",
        "activator",
    }
)
_SCOPE_MARKERS = (
    "governance",
    "sandbox rule",
    "certification rule",
    "global authority",
    "all capabilities",
    "model weight",
    "provider parameter",
)
_DEFAULT_INPUT = {"data": "object"}
_DEFAULT_OUTPUT = {"ok": "bool", "capability_id": "string", "digest": "hex"}
_DEFAULT_CONSTRAINTS = {
    "no_network": True,
    "no_subprocess": True,
    "no_filesystem_mutation": True,
    "no_credentials": True,
    "no_activation": True,
}

_REQUIREMENTS: dict[str, "ImprovementRequirement"] = {}
_IMPLEMENTATIONS: dict[str, "ImprovementImplementation"] = {}
_COMPARISONS: dict[str, "ImprovementComparison"] = {}
_VALIDATIONS: dict[str, "ImprovementValidation"] = {}
_REPLACEMENTS: dict[str, "CapabilityReplacement"] = {}


class ImprovementError(LearningError):
    """Fail-closed improvement implementation rejection."""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def clear_improvements() -> None:
    _REQUIREMENTS.clear()
    _IMPLEMENTATIONS.clear()
    _COMPARISONS.clear()
    _VALIDATIONS.clear()
    _REPLACEMENTS.clear()
    clear_post_replacement_decisions()


@dataclass(frozen=True)
class ImprovementRequirement:
    requirement_id: str
    source_proposal_id: str
    source_proposal_evaluation_id: str
    target_capability_id: str
    target_artifact_hash: str | None
    improvement_candidate_id: str
    problem_statement: str
    proposed_change_type: str
    expected_outcome: str
    input_contract: dict[str, Any]
    output_contract: dict[str, Any]
    acceptance_criteria: tuple[str, ...]
    constraints: dict[str, Any]
    evidence_refs: tuple[str, ...]
    provenance: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "requirement_id": self.requirement_id,
            "source_proposal_id": self.source_proposal_id,
            "source_proposal_evaluation_id": self.source_proposal_evaluation_id,
            "target_capability_id": self.target_capability_id,
            "target_artifact_hash": self.target_artifact_hash,
            "improvement_candidate_id": self.improvement_candidate_id,
            "problem_statement": self.problem_statement,
            "proposed_change_type": self.proposed_change_type,
            "expected_outcome": self.expected_outcome,
            "input_contract": dict(self.input_contract),
            "output_contract": dict(self.output_contract),
            "acceptance_criteria": list(self.acceptance_criteria),
            "constraints": dict(self.constraints),
            "evidence_refs": list(self.evidence_refs),
            "provenance": self.provenance,
        }

    def generator_payload(self) -> dict[str, Any]:
        return {
            "requirement_id": self.requirement_id,
            "capability_id": self.improvement_candidate_id,
            "purpose": self.problem_statement,
            "input_contract": dict(self.input_contract),
            "output_contract": dict(self.output_contract),
            "acceptance_criteria": {
                "expected_capability_id": self.improvement_candidate_id,
                "expected_ok": True,
                "required_output_keys": ["ok", "capability_id", "digest"],
                "digest_is_hex": True,
                "approved_proposal_criteria": list(self.acceptance_criteria),
            },
            "constraints": {"bounded_duration_ms": 5000},
            "provenance": self.provenance,
        }


@dataclass(frozen=True)
class ImprovementImplementation:
    requirement: ImprovementRequirement
    genesis: GenesisResult
    new_candidate_id: str
    old_active_capability: str | None
    old_active_version: str | None
    provenance_chain: tuple[str, ...]
    created_at: str
    auto_sandbox: bool = False
    auto_review: bool = False
    auto_certification: bool = False
    auto_activation: bool = False
    details: dict[str, Any] = field(default_factory=dict)


def _evaluation_from_mapping(data: Mapping[str, Any]) -> ImprovementProposalEvaluation:
    return ImprovementProposalEvaluation(
        proposal_evaluation_id=str(data["proposal_evaluation_id"]),
        proposal_id=str(data["proposal_id"]),
        source_learning_observation_id=str(data["source_learning_observation_id"]),
        target_capability_id=str(data["target_capability_id"]),
        target_artifact_hash=data.get("target_artifact_hash"),
        evidence_refs=tuple(data.get("evidence_refs") or ()),
        evidence_sufficiency=str(data["evidence_sufficiency"]),
        scope_assessment=str(data["scope_assessment"]),
        risk_assessment=str(data["risk_assessment"]),
        acceptance_criteria_quality=str(data["acceptance_criteria_quality"]),
        expected_outcome_assessment=str(data["expected_outcome_assessment"]),
        status=str(data["status"]),
        reason=str(data["reason"]),
        reviewer_identity=str(data["reviewer_identity"]),
        created_at=str(data["created_at"]),
        implementation_authority=str(data.get("implementation_authority") or "NONE"),
    )


def _load_evaluation(
    store: PerformanceStore, evaluation_id: str
) -> ImprovementProposalEvaluation:
    local = get_proposal_evaluation(evaluation_id)
    if local is not None:
        return local
    try:
        return _evaluation_from_mapping(store.get_proposal_evaluation(evaluation_id))
    except StoreReadFailed as exc:
        raise ImprovementError("UNKNOWN_PROPOSAL_EVALUATION") from exc


def _load_proposal(store: PerformanceStore, proposal_id: str) -> ImprovementProposal:
    local = get_improvement_proposal(proposal_id)
    if local is not None:
        return local
    try:
        return _proposal_from_mapping(store.get_improvement_proposal(proposal_id))
    except StoreReadFailed as exc:
        raise ImprovementError("UNKNOWN_PROPOSAL") from exc


def _load_observation(store: PerformanceStore, observation_id: str) -> LearningObservation:
    local = get_learning_observation(observation_id)
    if local is not None:
        return local
    try:
        return _observation_from_mapping(store.get_learning_observation(observation_id))
    except StoreReadFailed as exc:
        raise ImprovementError("UNKNOWN_LEARNING_OBSERVATION") from exc


def _candidate_id(target_capability_id: str, evaluation_id: str) -> str:
    suffix = target_capability_id[4:] if target_capability_id.startswith("CAP-") else target_capability_id
    return f"CAP-IMP-{suffix}-{evaluation_id[:8]}"


def _current_target_identity(target_capability_id: str, intended: str | None) -> str | None:
    if target_capability_id in HANDLERS:
        return active_version_id(target_capability_id)
    return intended


def implement_approved_proposal(
    store: PerformanceStore,
    *,
    proposal_evaluation_id: str,
    requester: str = "learner",
    claims: Mapping[str, Any] | None = None,
    historical_records: tuple[Mapping[str, Any], ...] = (),
) -> ImprovementImplementation:
    """Turn one approved proposal into a new registered candidate. Then stop."""
    _reject_claims(claims)
    del historical_records
    if requester in _BLOCKED_IMPLEMENTERS or requester not in _IMPLEMENTER_IDENTITIES:
        raise ImprovementError("SELF_IMPLEMENTATION_FORBIDDEN")

    evaluation = _load_evaluation(store, proposal_evaluation_id)
    if evaluation.implementation_authority != "NONE":
        raise ImprovementError("PROPOSAL_HAS_IMPLEMENTATION_AUTHORITY")
    if evaluation.status == "REJECTED":
        raise ImprovementError("PROPOSAL_REJECTED")
    if evaluation.status == "INSUFFICIENT_EVIDENCE":
        raise ImprovementError("PROPOSAL_INSUFFICIENT_EVIDENCE")
    if evaluation.status == "NO_ACTION":
        raise ImprovementError("PROPOSAL_NO_ACTION")
    if evaluation.status != "APPROVED_FOR_CONTROLLED_IMPLEMENTATION":
        raise ImprovementError("PROPOSAL_NOT_APPROVED")

    proposal = _load_proposal(store, evaluation.proposal_id)
    observation = _load_observation(store, evaluation.source_learning_observation_id)
    if (
        proposal.target_capability_id != evaluation.target_capability_id
        or observation.capability_id != evaluation.target_capability_id
    ):
        raise ImprovementError("CROSS_CAPABILITY_PROPOSAL")
    if proposal.source_learning_observation_id != evaluation.source_learning_observation_id:
        raise ImprovementError("PROPOSAL_OBSERVATION_MISMATCH")

    intended = evaluation.target_artifact_hash or proposal.target_artifact_hash
    current = _current_target_identity(evaluation.target_capability_id, intended)
    if intended and current and intended != current:
        raise ImprovementError("STALE_TARGET")

    scope_text = " ".join(
        (
            proposal.problem_statement,
            proposal.expected_outcome,
            " ".join(proposal.acceptance_criteria),
        )
    ).lower()
    if any(marker in scope_text for marker in _SCOPE_MARKERS):
        raise ImprovementError("SCOPE_EXPANSION_FORBIDDEN")

    criteria = tuple(proposal.acceptance_criteria)
    if not criteria:
        raise ImprovementError("ACCEPTANCE_CRITERIA_WEAKENED")

    new_id = _candidate_id(evaluation.target_capability_id, evaluation.proposal_evaluation_id)
    if new_id in HANDLERS or has_implementation(new_id):
        raise ImprovementError("EXISTING_CAPABILITY_REPLACEMENT_BLOCKED")
    if new_id == evaluation.target_capability_id:
        raise ImprovementError("EXISTING_CAPABILITY_REPLACEMENT_BLOCKED")

    old_active_cap = evaluation.target_capability_id if evaluation.target_capability_id in HANDLERS else None
    old_active_version = active_version_id(evaluation.target_capability_id) if old_active_cap else None
    old_handler = get_active_handler(evaluation.target_capability_id) if old_active_cap else None
    handlers_before = dict(HANDLERS)
    active_before = dict(_ACTIVE)

    requirement_id = f"REQ-IMP-{evaluation.proposal_evaluation_id[:12]}"
    provenance = (
        "controlled-improvement"
        f"|observation:{observation.learning_observation_id}"
        f"|proposal:{proposal.proposal_id}"
        f"|evaluation:{evaluation.proposal_evaluation_id}"
        f"|target:{evaluation.target_capability_id}"
        f"|artifact:{intended or ''}"
    )
    requirement = ImprovementRequirement(
        requirement_id=requirement_id,
        source_proposal_id=proposal.proposal_id,
        source_proposal_evaluation_id=evaluation.proposal_evaluation_id,
        target_capability_id=evaluation.target_capability_id,
        target_artifact_hash=intended,
        improvement_candidate_id=new_id,
        problem_statement=proposal.problem_statement,
        proposed_change_type=proposal.proposed_change_type,
        expected_outcome=proposal.expected_outcome,
        input_contract=dict(_DEFAULT_INPUT),
        output_contract=dict(_DEFAULT_OUTPUT),
        acceptance_criteria=criteria,
        constraints=dict(_DEFAULT_CONSTRAINTS),
        evidence_refs=tuple(proposal.evidence_refs),
        provenance=provenance,
    )
    if tuple(requirement.acceptance_criteria) != criteria:
        raise ImprovementError("ACCEPTANCE_CRITERIA_WEAKENED")

    genesis = generate_implementation_candidate(requirement.generator_payload())
    stored = get_candidate(new_id)
    if stored is None or stored.state != CANDIDATE_STATE:
        raise ImprovementError("CANDIDATE_NOT_REGISTERED")
    generated_criteria = genesis.generated.acceptance_criteria if genesis.generated else None
    if not isinstance(generated_criteria, Mapping):
        raise ImprovementError("ACCEPTANCE_CRITERIA_WEAKENED")
    if list(generated_criteria.get("approved_proposal_criteria") or ()) != list(criteria):
        raise ImprovementError("ACCEPTANCE_CRITERIA_WEAKENED")

    if dict(HANDLERS) != handlers_before or dict(_ACTIVE) != active_before:
        raise ImprovementError("ACTIVE_RUNTIME_MUTATED")
    if old_active_cap:
        if get_active_handler(old_active_cap) is not old_handler:
            raise ImprovementError("ACTIVE_RUNTIME_MUTATED")
        if active_version_id(old_active_cap) != old_active_version:
            raise ImprovementError("ACTIVE_RUNTIME_MUTATED")
    if has_implementation(new_id) or new_id in HANDLERS or new_id in _ACTIVE:
        raise ImprovementError("NEW_CANDIDATE_ACTIVATED")

    chain = (
        f"performance:{','.join(proposal.evidence_refs)}",
        f"observation:{observation.learning_observation_id}",
        f"proposal:{proposal.proposal_id}",
        f"evaluation:{evaluation.proposal_evaluation_id}",
        f"requirement:{requirement.requirement_id}",
        f"artifact:{genesis.generated.artifact_hash if genesis.generated else ''}",
        f"candidate:{new_id}",
    )
    result = ImprovementImplementation(
        requirement=requirement,
        genesis=genesis,
        new_candidate_id=new_id,
        old_active_capability=old_active_cap,
        old_active_version=old_active_version,
        provenance_chain=chain,
        created_at=_now(),
        details={
            "generator_identity": IMPLEMENTATION_GENERATOR_IDENTITY,
            "artifact_class": ARTIFACT_IMPLEMENTATION_SOURCE,
            "candidate_state": stored.state,
            "implementation_authority": "NONE",
        },
    )
    _REQUIREMENTS[requirement.requirement_id] = requirement
    _IMPLEMENTATIONS[new_id] = result
    return result


@dataclass(frozen=True)
class ImprovementValidation:
    candidate_id: str
    artifact_hash: str
    proposal_id: str
    proposal_evaluation_id: str
    requirement_id: str
    sandbox_ref: str
    review_ref: str
    behavior_evidence_ref: str
    behavioral_evaluation_ref: str
    behavioral_certification_ref: str
    behavioral_evaluation_status: str
    certification_kind: str
    improvement_effect: str
    provenance_chain: tuple[str, ...]
    acceptance_criteria: tuple[str, ...]
    created_at: str
    auto_activation: bool = False
    auto_promotion: bool = False
    auto_rollback: bool = False
    training_activated: bool = False


def get_improvement_implementation(candidate_id: str) -> ImprovementImplementation | None:
    return _IMPLEMENTATIONS.get(candidate_id)


def _behavior_contract(implementation: ImprovementImplementation) -> dict[str, Any]:
    requirement = implementation.requirement
    payload = requirement.generator_payload()
    digest = implementation.genesis.generated.artifact_hash if implementation.genesis.generated else ""
    return {
        "requirement_id": requirement.requirement_id,
        "capability_id": requirement.improvement_candidate_id,
        "input_contract": dict(requirement.input_contract),
        "output_contract": dict(requirement.output_contract),
        "acceptance_criteria": dict(payload["acceptance_criteria"]),
        "constraints": {"bounded_duration_ms": 5000},
        "artifact_hash": digest,
    }


def _test_input(implementation: ImprovementImplementation) -> dict[str, Any]:
    contract = _behavior_contract(implementation)
    return {
        "capability_id": implementation.new_candidate_id,
        "requirement_id": implementation.requirement.requirement_id,
        "input_contract": dict(contract["input_contract"]),
        "test_payload": {"data": {"value": "improvement-validation"}},
        "acceptance_criteria_reference": dict(contract["acceptance_criteria"]),
    }


def _assert_hash(expected: str, actual: str | None, label: str) -> None:
    if actual != expected:
        raise ImprovementError("ARTIFACT_IDENTITY_MISMATCH")


def validate_improvement_candidate(
    store: PerformanceStore,
    *,
    candidate_id: str | None = None,
    implementation: ImprovementImplementation | None = None,
    requester: str = "learner",
    claims: Mapping[str, Any] | None = None,
    historical_records: tuple[Mapping[str, Any], ...] = (),
) -> ImprovementValidation:
    """Run the existing generated-candidate safety chain. Never activates."""
    _reject_claims(claims)
    del historical_records
    if requester in _BLOCKED_VALIDATORS or requester not in _VALIDATOR_IDENTITIES:
        raise ImprovementError("SELF_REVIEW_FORBIDDEN")

    loaded = implementation or get_improvement_implementation(candidate_id or "")
    if loaded is None:
        raise ImprovementError("UNKNOWN_IMPROVEMENT_CANDIDATE")
    candidate_id = loaded.new_candidate_id
    evaluation = _load_evaluation(store, loaded.requirement.source_proposal_evaluation_id)
    proposal = _load_proposal(store, loaded.requirement.source_proposal_id)
    if evaluation.status != "APPROVED_FOR_CONTROLLED_IMPLEMENTATION":
        raise ImprovementError("PROPOSAL_NOT_APPROVED")
    if (
        proposal.target_artifact_hash
        and evaluation.target_artifact_hash
        and proposal.target_artifact_hash != evaluation.target_artifact_hash
    ):
        raise ImprovementError("CROSS_VERSION_EVIDENCE")
    intended = evaluation.target_artifact_hash or proposal.target_artifact_hash
    current = _current_target_identity(evaluation.target_capability_id, intended)
    if intended and current and intended != current:
        raise ImprovementError("STALE_TARGET")
    approved = tuple(proposal.acceptance_criteria)
    if approved != tuple(loaded.requirement.acceptance_criteria):
        raise ImprovementError("ACCEPTANCE_CRITERIA_WEAKENED")
    contract = _behavior_contract(loaded)
    bound = tuple(contract["acceptance_criteria"].get("approved_proposal_criteria") or ())
    if bound != approved:
        raise ImprovementError("ACCEPTANCE_CRITERIA_WEAKENED")

    record = get_candidate(candidate_id)
    if record is None:
        raise ImprovementError("CANDIDATE_NOT_REGISTERED")
    expected_hash = loaded.genesis.generated.artifact_hash if loaded.genesis.generated else ""
    _assert_hash(expected_hash, record.artifact_hash, "registration")

    handlers_before = dict(HANDLERS)
    active_before = dict(_ACTIVE)
    test_input = _test_input(loaded)
    behavior = execute_candidate_behavior(candidate_id, test_input=test_input)
    _assert_hash(expected_hash, behavior.evidence.artifact_hash, "behavior")
    if behavior.evidence.execution_status != "BEHAVIOR_EXECUTED":
        raise ImprovementError("BEHAVIORAL_SANDBOX_FAILED")
    sandbox = validate_candidate(candidate_id)
    if not sandbox.validated:
        raise ImprovementError("BEHAVIORAL_SANDBOX_FAILED")
    stored_sandbox = get_candidate_sandbox(candidate_id)
    if stored_sandbox is None or not stored_sandbox.validated:
        raise ImprovementError("BEHAVIORAL_SANDBOX_FAILED")
    _assert_hash(expected_hash, stored_sandbox.artifact_hash, "sandbox")

    review = review_candidate(candidate_id, requester="reviewer")
    if review.state != CANDIDATE_INDEPENDENTLY_REVIEWED:
        raise ImprovementError("INDEPENDENT_REVIEW_FAILED")
    _assert_hash(expected_hash, review.artifact_hash, "review")

    evaluation_result = evaluate_candidate_behavior(
        candidate_id,
        requirement=contract,
        test_input=test_input,
        requester="evaluator",
    )
    if evaluation_result.status == "FAILED":
        raise ImprovementError("BEHAVIORAL_EVALUATION_FAILED")
    if evaluation_result.status != "PASSED":
        raise ImprovementError("BEHAVIORAL_EVALUATION_INSUFFICIENT")
    _assert_hash(expected_hash, evaluation_result.artifact_hash, "evaluation")

    certification = certify_candidate_behavior(candidate_id, requester="certifier")
    if (
        certification.status != CANDIDATE_BEHAVIORALLY_CERTIFIED
        or certification.certification_kind != CERTIFICATION_KIND_BEHAVIORAL
    ):
        raise ImprovementError("BEHAVIORAL_CERTIFICATION_FAILED")
    _assert_hash(expected_hash, certification.artifact_hash, "certification")
    stored_cert = get_candidate_behavior_certification(candidate_id)
    if stored_cert is None or stored_cert.certification_id != certification.certification_id:
        raise ImprovementError("BEHAVIORAL_CERTIFICATION_FAILED")

    if dict(HANDLERS) != handlers_before or dict(_ACTIVE) != active_before:
        raise ImprovementError("ACTIVE_RUNTIME_MUTATED")
    if has_implementation(candidate_id) or candidate_id in HANDLERS or candidate_id in _ACTIVE:
        raise ImprovementError("NEW_CANDIDATE_ACTIVATED")

    chain = loaded.provenance_chain + (
        f"behavior:{behavior.evidence.behavior_evidence_id}",
        f"sandbox:{stored_sandbox.evidence_ref}",
        f"review:{review.capability_id}:{review.artifact_hash[:16]}",
        f"behavior_eval:{evaluation_result.evaluation_id}",
        f"behavior_cert:{certification.certification_id}",
    )
    result = ImprovementValidation(
        candidate_id=candidate_id,
        artifact_hash=expected_hash,
        proposal_id=proposal.proposal_id,
        proposal_evaluation_id=evaluation.proposal_evaluation_id,
        requirement_id=loaded.requirement.requirement_id,
        sandbox_ref=stored_sandbox.evidence_ref,
        review_ref=f"candidate-review:{review.capability_id}:{review.artifact_hash[:16]}",
        behavior_evidence_ref=behavior.evidence.behavior_evidence_id,
        behavioral_evaluation_ref=evaluation_result.evaluation_id,
        behavioral_certification_ref=certification.certification_id,
        behavioral_evaluation_status=evaluation_result.status,
        certification_kind=certification.certification_kind,
        improvement_effect="INSUFFICIENT_COMPARATIVE_EVIDENCE",
        provenance_chain=chain,
        acceptance_criteria=approved,
        created_at=_now(),
    )
    _VALIDATIONS[candidate_id] = result
    return result


@dataclass(frozen=True)
class ImprovementComparison:
    comparison_id: str
    target_capability_id: str
    baseline_artifact_hash: str | None
    candidate_artifact_hash: str
    workload_definition: dict[str, Any]
    sample_count_baseline: int
    sample_count_candidate: int
    baseline_metrics: dict[str, Any]
    candidate_metrics: dict[str, Any]
    acceptance_criteria_results: dict[str, Any]
    performance_delta: dict[str, Any]
    reliability_delta: dict[str, Any]
    status: str
    reason: str
    evidence_refs: tuple[str, ...]
    created_at: str
    expected_outcome: str
    expected_outcome_metric: str | None
    expected_outcome_tested: bool
    replacement_eligibility: str
    sample_rule: str = _SAMPLE_RULE
    auto_replacement: bool = False
    auto_promotion: bool = False
    auto_rollback: bool = False
    training_activated: bool = False

    def as_dict(self) -> dict[str, Any]:
        return {
            "comparison_id": self.comparison_id,
            "target_capability_id": self.target_capability_id,
            "baseline_artifact_hash": self.baseline_artifact_hash,
            "candidate_artifact_hash": self.candidate_artifact_hash,
            "workload_definition": dict(self.workload_definition),
            "sample_count_baseline": self.sample_count_baseline,
            "sample_count_candidate": self.sample_count_candidate,
            "baseline_metrics": dict(self.baseline_metrics),
            "candidate_metrics": dict(self.candidate_metrics),
            "acceptance_criteria_results": dict(self.acceptance_criteria_results),
            "performance_delta": dict(self.performance_delta),
            "reliability_delta": dict(self.reliability_delta),
            "status": self.status,
            "reason": self.reason,
            "evidence_refs": list(self.evidence_refs),
            "created_at": self.created_at,
            "expected_outcome": self.expected_outcome,
            "expected_outcome_metric": self.expected_outcome_metric,
            "expected_outcome_tested": self.expected_outcome_tested,
            "replacement_eligibility": self.replacement_eligibility,
            "sample_rule": self.sample_rule,
            "proposal_id": self.workload_definition.get("proposal_id"),
            "proposal_evaluation_id": self.workload_definition.get(
                "proposal_evaluation_id"
            ),
        }


def get_improvement_validation(candidate_id: str) -> ImprovementValidation | None:
    return _VALIDATIONS.get(candidate_id)


def get_improvement_comparison(comparison_id: str) -> ImprovementComparison | None:
    return _COMPARISONS.get(comparison_id)


def _is_hex_digest(value: Any) -> bool:
    if not isinstance(value, str) or len(value) < 8:
        return False
    try:
        int(value, 16)
    except ValueError:
        return False
    return True


def _output_contract_holds(value: Any) -> bool:
    if not isinstance(value, Mapping):
        return False
    if value.get("ok") is not True and value.get("ok") is not False:
        return False
    return _is_hex_digest(value.get("digest"))


def _bind_expected_outcome(expected: str) -> str | None:
    text = expected.lower()
    if "mission verification verified" in text:
        return "verified_success_rate"
    if "contract checks pass" in text or "output contract" in text:
        return "output_contract_pass_rate"
    if "replan" in text:
        return "replan_rate"
    if "duration" in text:
        return "mean_duration_ms"
    if "execution succeeds" in text or "execution success" in text:
        return "execution_success_rate"
    if "failure rate" in text:
        return "failure_rate"
    return None


def _empty_metrics() -> dict[str, Any]:
    return {
        "execution_success_rate": None,
        "output_contract_pass_rate": None,
        "acceptance_criteria_pass_rate": None,
        "failure_rate": None,
        "mean_duration_ms": None,
        "replan_rate": None,
        "determinism": "INCOMPARABLE",
        "verified_success_rate": None,
    }


def _metrics_from_runs(
    runs: list[dict[str, Any]],
    *,
    criteria_pass_rate: float | None,
) -> dict[str, Any]:
    if not runs:
        return _empty_metrics()
    n = len(runs)
    success = sum(1 for run in runs if run["execution_success"])
    contract = sum(1 for run in runs if run["output_contract"])
    durations = [run["duration_ms"] for run in runs if run["duration_ms"] is not None]
    replans = sum(1 for run in runs if run.get("replan"))
    verified = sum(1 for run in runs if run.get("verified_success"))
    digests = [run.get("result_digest") for run in runs if run.get("result_digest")]
    determinism = "INCOMPARABLE"
    if len(digests) == n and n > 0:
        determinism = "DETERMINISTIC" if len(set(digests)) == 1 else "NONDETERMINISTIC"
    return {
        "execution_success_rate": round(success / n, 3),
        "output_contract_pass_rate": round(contract / n, 3),
        "acceptance_criteria_pass_rate": criteria_pass_rate,
        "failure_rate": round((n - success) / n, 3),
        "mean_duration_ms": round(sum(durations) / len(durations), 3) if durations else None,
        "replan_rate": round(replans / n, 3),
        "determinism": determinism,
        "verified_success_rate": round(verified / n, 3),
    }


def _score_criterion(text: str, metrics: Mapping[str, Any], *, side: str) -> dict[str, str]:
    blob = text.lower()
    if "do not count handler ok without mission" in blob:
        return {"result": "PASS", "reason": "HANDLER_OK_NOT_COUNTED_AS_MISSION"}
    if "mission verification verified" in blob or (
        "mission failure rate" in blob and "handler" not in blob
    ):
        rate = metrics.get("verified_success_rate")
        if rate is None:
            return {"result": "INSUFFICIENT_EVIDENCE", "reason": "NO_VERIFIED_SAMPLES"}
        if "below" in blob:
            return {
                "result": "PASS" if (1.0 - rate) < 0.4 else "FAIL",
                "reason": f"{side.upper()}_MISSION_FAILURE_RATE",
            }
        return {
            "result": "PASS" if rate >= 1.0 else "FAIL",
            "reason": f"{side.upper()}_MISSION_VERIFIED_RATE",
        }
    if "execution success" in blob:
        rate = metrics.get("execution_success_rate")
        if rate is None:
            return {"result": "INSUFFICIENT_EVIDENCE", "reason": "NO_EXECUTION_SAMPLES"}
        required = 1.0 if "1.0" in blob or "at or above 1" in blob else 0.6
        return {
            "result": "PASS" if rate >= required else "FAIL",
            "reason": "EXECUTION_SUCCESS_RATE",
        }
    if "output contract" in blob or "contract-failure rate below" in blob:
        rate = metrics.get("output_contract_pass_rate")
        if rate is None:
            return {"result": "INSUFFICIENT_EVIDENCE", "reason": "NO_CONTRACT_SAMPLES"}
        if "below" in blob:
            return {
                "result": "PASS" if (1.0 - rate) < 0.4 else "FAIL",
                "reason": "CONTRACT_FAILURE_RATE",
            }
        return {
            "result": "PASS" if rate >= 1.0 else "FAIL",
            "reason": "OUTPUT_CONTRACT_PASS_RATE",
        }
    if "digest" in blob and "hex" in blob:
        rate = metrics.get("output_contract_pass_rate")
        if rate is None:
            return {"result": "INSUFFICIENT_EVIDENCE", "reason": "NO_DIGEST_SAMPLES"}
        return {
            "result": "PASS" if rate >= 1.0 else "FAIL",
            "reason": "DIGEST_HEX",
        }
    return {"result": "INSUFFICIENT_EVIDENCE", "reason": "CRITERION_NOT_MACHINE_VERIFIABLE"}


def _delta(baseline: Mapping[str, Any], candidate: Mapping[str, Any], key: str) -> Any:
    left = baseline.get(key)
    right = candidate.get(key)
    if not isinstance(left, (int, float)) or not isinstance(right, (int, float)):
        return None
    return round(right - left, 3)


def compare_improvement_candidate(
    store: PerformanceStore,
    *,
    candidate_id: str | None = None,
    implementation: ImprovementImplementation | None = None,
    requester: str = "learner",
    sample_count: int | None = None,
    workload: Mapping[str, Any] | None = None,
    claims: Mapping[str, Any] | None = None,
    historical_records: tuple[Mapping[str, Any], ...] = (),
) -> ImprovementComparison:
    """Compare a certified improvement candidate to the current active baseline.

    Never activates, replaces, promotes, trains, or rolls back.
    """
    _reject_claims(claims)
    del historical_records
    if requester in _BLOCKED_COMPARATORS or requester not in _COMPARATOR_IDENTITIES:
        raise ImprovementError("SELF_COMPARISON_FORBIDDEN")

    loaded = implementation or get_improvement_implementation(candidate_id or "")
    if loaded is None:
        raise ImprovementError("UNKNOWN_IMPROVEMENT_CANDIDATE")
    candidate_id = loaded.new_candidate_id
    evaluation = _load_evaluation(store, loaded.requirement.source_proposal_evaluation_id)
    proposal = _load_proposal(store, loaded.requirement.source_proposal_id)
    if evaluation.status != "APPROVED_FOR_CONTROLLED_IMPLEMENTATION":
        raise ImprovementError("PROPOSAL_NOT_APPROVED")
    if (
        proposal.target_capability_id != evaluation.target_capability_id
        or loaded.requirement.target_capability_id != evaluation.target_capability_id
    ):
        raise ImprovementError("CROSS_CAPABILITY_EVIDENCE")
    if (
        proposal.target_artifact_hash
        and evaluation.target_artifact_hash
        and proposal.target_artifact_hash != evaluation.target_artifact_hash
    ):
        raise ImprovementError("CROSS_VERSION_EVIDENCE")
    intended = evaluation.target_artifact_hash or proposal.target_artifact_hash
    target = evaluation.target_capability_id
    current = _current_target_identity(target, intended)
    if intended and current and intended != current:
        raise ImprovementError("STALE_TARGET")
    approved = tuple(proposal.acceptance_criteria)
    if approved != tuple(loaded.requirement.acceptance_criteria):
        raise ImprovementError("ACCEPTANCE_CRITERIA_WEAKENED")
    bound = tuple(
        loaded.requirement.generator_payload()["acceptance_criteria"].get(
            "approved_proposal_criteria"
        )
        or ()
    )
    if bound != approved:
        raise ImprovementError("ACCEPTANCE_CRITERIA_WEAKENED")

    record = get_candidate(candidate_id)
    if record is None:
        raise ImprovementError("CANDIDATE_NOT_REGISTERED")
    expected_hash = loaded.genesis.generated.artifact_hash if loaded.genesis.generated else ""
    _assert_hash(expected_hash, record.artifact_hash, "registration")
    cert = get_candidate_behavior_certification(candidate_id)
    if (
        cert is None
        or cert.certification_kind != CERTIFICATION_KIND_BEHAVIORAL
        or cert.status != CANDIDATE_BEHAVIORALLY_CERTIFIED
    ):
        raise ImprovementError("BEHAVIORAL_CERTIFICATION_REQUIRED")
    _assert_hash(expected_hash, cert.artifact_hash, "certification")

    handlers_before = dict(HANDLERS)
    active_before = dict(_ACTIVE)
    restore_before = export_active_restore(target) if target in HANDLERS else None
    old_handler = get_active_handler(target) if target in HANDLERS else None
    old_version = active_version_id(target) if target in HANDLERS else None
    payload = {"data": {"value": "improvement-comparison"}}
    if workload is not None:
        if not isinstance(workload, Mapping) or "data" not in workload:
            raise ImprovementError("INCOMPARABLE_WORKLOAD")
        payload = {"data": dict(workload["data"])} if isinstance(workload.get("data"), Mapping) else dict(workload)
    required_n = LearningThresholds().min_comparative_samples
    n = required_n if sample_count is None else int(sample_count)
    expected_metric = _bind_expected_outcome(proposal.expected_outcome)
    workload_definition = {
        "input_payload": dict(payload),
        "input_contract": dict(loaded.requirement.input_contract),
        "output_contract": dict(_COMPARISON_OUTPUT_CONTRACT),
        "acceptance_criteria": list(approved),
        "mission_class": target,
        "proposal_id": proposal.proposal_id,
        "proposal_evaluation_id": evaluation.proposal_evaluation_id,
        "expected_outcome": proposal.expected_outcome,
        "same_workload_both_sides": True,
        "candidate_execution": "ISOLATED_SHADOW_RUNTIME",
        "baseline_execution": "NORMAL_RUNTIME",
    }
    refs: list[str] = [
        f"proposal:{proposal.proposal_id}",
        f"evaluation:{evaluation.proposal_evaluation_id}",
        f"requirement:{loaded.requirement.requirement_id}",
        f"candidate:{candidate_id}",
        f"behavior_cert:{cert.certification_id}",
        f"baseline:{target}:{old_version or ''}",
        f"candidate_artifact:{expected_hash}",
    ]

    def _finish(
        *,
        status: str,
        reason: str,
        baseline_runs: list[dict[str, Any]] | None = None,
        candidate_runs: list[dict[str, Any]] | None = None,
        criteria_results: dict[str, Any] | None = None,
        expected_tested: bool = False,
        extra_refs: tuple[str, ...] = (),
    ) -> ImprovementComparison:
        if status not in COMPARISON_STATUSES:
            raise ImprovementError("INVALID_COMPARISON_STATUS")
        baseline_runs = baseline_runs or []
        candidate_runs = candidate_runs or []
        baseline_metrics = _metrics_from_runs(
            baseline_runs,
            criteria_pass_rate=(
                (criteria_results or {}).get("baseline_pass_rate")
            ),
        )
        candidate_metrics = _metrics_from_runs(
            candidate_runs,
            criteria_pass_rate=(
                (criteria_results or {}).get("candidate_pass_rate")
            ),
        )
        if dict(HANDLERS) != handlers_before or dict(_ACTIVE) != active_before:
            raise ImprovementError("ACTIVE_RUNTIME_MUTATED")
        if export_active_restore(target) != restore_before:
            raise ImprovementError("ACTIVE_RUNTIME_MUTATED")
        if has_implementation(candidate_id) or candidate_id in HANDLERS or candidate_id in _ACTIVE:
            raise ImprovementError("NEW_CANDIDATE_ACTIVATED")
        if target in HANDLERS:
            if get_active_handler(target) is not old_handler:
                raise ImprovementError("ACTIVE_RUNTIME_MUTATED")
            if active_version_id(target) != old_version:
                raise ImprovementError("ACTIVE_RUNTIME_MUTATED")
        eligibility = (
            "ELIGIBLE_FOR_CONTROLLED_REPLACEMENT"
            if status == "PROVEN_IMPROVEMENT"
            else "NO"
        )
        comparison = ImprovementComparison(
            comparison_id=uuid.uuid4().hex,
            target_capability_id=target,
            baseline_artifact_hash=old_version,
            candidate_artifact_hash=expected_hash,
            workload_definition=workload_definition,
            sample_count_baseline=len(baseline_runs),
            sample_count_candidate=len(candidate_runs),
            baseline_metrics=baseline_metrics,
            candidate_metrics=candidate_metrics,
            acceptance_criteria_results=dict(criteria_results or {}),
            performance_delta={
                "mean_duration_ms": _delta(
                    baseline_metrics, candidate_metrics, "mean_duration_ms"
                )
            },
            reliability_delta={
                "execution_success_rate": _delta(
                    baseline_metrics, candidate_metrics, "execution_success_rate"
                ),
                "failure_rate": _delta(
                    baseline_metrics, candidate_metrics, "failure_rate"
                ),
                "output_contract_pass_rate": _delta(
                    baseline_metrics, candidate_metrics, "output_contract_pass_rate"
                ),
                "verified_success_rate": _delta(
                    baseline_metrics, candidate_metrics, "verified_success_rate"
                ),
            },
            status=status,
            reason=reason,
            evidence_refs=tuple(refs) + extra_refs,
            created_at=_now(),
            expected_outcome=proposal.expected_outcome,
            expected_outcome_metric=expected_metric,
            expected_outcome_tested=expected_tested,
            replacement_eligibility=eligibility,
        )
        _COMPARISONS[comparison.comparison_id] = comparison
        store.persist_improvement_comparison(comparison.as_dict())
        return comparison

    if target not in HANDLERS:
        return _finish(
            status="INSUFFICIENT_COMPARATIVE_EVIDENCE",
            reason="NO_COMPARABLE_BASELINE",
        )
    if n < required_n:
        return _finish(
            status="INSUFFICIENT_COMPARATIVE_EVIDENCE",
            reason="INSUFFICIENT_SAMPLES",
        )

    shadow = isolated_shadow_restore(candidate_id, target)
    if shadow.get("source_artifact_hash") != expected_hash:
        raise ImprovementError("ARTIFACT_IDENTITY_MISMATCH")

    def _score_runtime(runtime: Any) -> dict[str, Any]:
        observation = next(
            (
                item.get("result")
                for item in runtime.observations
                if isinstance(item, Mapping) and item.get("capability_id") == target
            ),
            None,
        )
        target_perf = next(
            (
                record
                for record in runtime.performance
                if record.capability_id == target
            ),
            None,
        )
        target_ok = bool(target_perf and target_perf.outcome == "SUCCESS")
        handler_ok_ids = (
            runtime.mission_verification.handler_ok_ids
            if runtime.mission_verification is not None
            else ()
        )
        verified = (
            target_ok
            and runtime.mission_verification is not None
            and runtime.mission_verification.status == "VERIFIED"
            and target in handler_ok_ids
        )
        return {
            "execution_success": target_ok,
            "output_contract": _output_contract_holds(observation),
            "duration_ms": target_perf.duration_ms if target_perf is not None else None,
            "replan": bool(runtime.retries),
            "verified_success": verified,
            "result_digest": (
                observation.get("digest") if isinstance(observation, Mapping) else None
            ),
        }

    baseline_runs: list[dict[str, Any]] = []
    candidate_runs: list[dict[str, Any]] = []
    for _ in range(n):
        runtime = execute_plan(
            Requirement(explicit_capability_ids=(target,)),
            payloads={target: dict(payload)},
            performance_store=store,
            max_retries=0,
        )
        baseline_runs.append(_score_runtime(runtime))
        refs.extend(f"baseline_perf:{rid}" for rid in runtime.performance_record_ids)

    for _ in range(n):
        runtime = execute_plan(
            Requirement(explicit_capability_ids=(target,)),
            payloads={target: dict(payload)},
            performance_store=store,
            max_retries=0,
            shadow_bindings={target: shadow},
        )
        candidate_runs.append(_score_runtime(runtime))
        refs.extend(f"shadow_perf:{rid}" for rid in runtime.performance_record_ids)
        refs.append(f"shadow:{candidate_id}:{expected_hash[:16]}")

    if dict(HANDLERS) != handlers_before or dict(_ACTIVE) != active_before:
        raise ImprovementError("ACTIVE_RUNTIME_MUTATED")
    if export_active_restore(target) != restore_before:
        raise ImprovementError("ACTIVE_RUNTIME_MUTATED")

    baseline_metrics = _metrics_from_runs(baseline_runs, criteria_pass_rate=None)
    candidate_metrics = _metrics_from_runs(candidate_runs, criteria_pass_rate=None)
    baseline_verdicts = [
        {**_score_criterion(item, baseline_metrics, side="baseline"), "criterion": item}
        for item in approved
    ]
    candidate_verdicts = [
        {**_score_criterion(item, candidate_metrics, side="candidate"), "criterion": item}
        for item in approved
    ]
    def _rate(verdicts: list[dict[str, str]]) -> float | None:
        scored = [item for item in verdicts if item["result"] in {"PASS", "FAIL"}]
        if not scored:
            return None
        return round(sum(1 for item in scored if item["result"] == "PASS") / len(scored), 3)

    criteria_results = {
        "approved": list(approved),
        "baseline": baseline_verdicts,
        "candidate": candidate_verdicts,
        "baseline_pass_rate": _rate(baseline_verdicts),
        "candidate_pass_rate": _rate(candidate_verdicts),
    }
    candidate_results = [item["result"] for item in candidate_verdicts]
    baseline_results = [item["result"] for item in baseline_verdicts]
    required_insufficient = "INSUFFICIENT_EVIDENCE" in candidate_results
    required_fail = "FAIL" in candidate_results
    required_regression = any(
        left == "PASS" and right == "FAIL"
        for left, right in zip(baseline_results, candidate_results)
    )
    success_delta = _delta(
        baseline_metrics, candidate_metrics, "execution_success_rate"
    )
    contract_delta = _delta(
        baseline_metrics, candidate_metrics, "output_contract_pass_rate"
    )
    verified_delta = _delta(
        baseline_metrics, candidate_metrics, "verified_success_rate"
    )
    reliability_regression = (
        (success_delta is not None and success_delta < 0)
        or (contract_delta is not None and contract_delta < 0)
        or (verified_delta is not None and verified_delta < 0)
    )
    expected_tested = expected_metric is not None
    targeted_delta = (
        _delta(baseline_metrics, candidate_metrics, expected_metric)
        if expected_metric
        else None
    )
    if expected_metric == "failure_rate" and targeted_delta is not None:
        targeted_improved = targeted_delta < 0
        targeted_equal = targeted_delta == 0
        targeted_worse = targeted_delta > 0
    elif expected_metric == "mean_duration_ms" and targeted_delta is not None:
        targeted_improved = targeted_delta < 0
        targeted_equal = targeted_delta == 0
        targeted_worse = targeted_delta > 0
    elif targeted_delta is not None:
        targeted_improved = targeted_delta > 0
        targeted_equal = targeted_delta == 0
        targeted_worse = targeted_delta < 0
    else:
        targeted_improved = False
        targeted_equal = False
        targeted_worse = False

    if not expected_tested:
        return _finish(
            status="INSUFFICIENT_COMPARATIVE_EVIDENCE",
            reason="EXPECTED_OUTCOME_NOT_MEASURABLE",
            baseline_runs=baseline_runs,
            candidate_runs=candidate_runs,
            criteria_results=criteria_results,
            expected_tested=False,
        )
    if required_insufficient:
        return _finish(
            status="INSUFFICIENT_COMPARATIVE_EVIDENCE",
            reason="REQUIRED_CRITERION_INSUFFICIENT_EVIDENCE",
            baseline_runs=baseline_runs,
            candidate_runs=candidate_runs,
            criteria_results=criteria_results,
            expected_tested=True,
        )
    if required_regression or required_fail or reliability_regression:
        return _finish(
            status="WORSE",
            reason="REQUIRED_CORRECTNESS_REGRESSION"
            if required_regression or reliability_regression
            else "REQUIRED_CRITERION_FAILED",
            baseline_runs=baseline_runs,
            candidate_runs=candidate_runs,
            criteria_results=criteria_results,
            expected_tested=True,
        )
    if targeted_improved and not reliability_regression:
        conflicting = (
            expected_metric != "mean_duration_ms"
            and _delta(baseline_metrics, candidate_metrics, "mean_duration_ms") is not None
            and expected_metric != "execution_success_rate"
            and success_delta is not None
            and success_delta < 0
        )
        if conflicting:
            return _finish(
                status="INSUFFICIENT_COMPARATIVE_EVIDENCE",
                reason="CONFLICTING_REQUIRED_METRICS",
                baseline_runs=baseline_runs,
                candidate_runs=candidate_runs,
                criteria_results=criteria_results,
                expected_tested=True,
            )
        return _finish(
            status="PROVEN_IMPROVEMENT",
            reason="TARGETED_OUTCOME_IMPROVED_WITHOUT_REQUIRED_REGRESSION",
            baseline_runs=baseline_runs,
            candidate_runs=candidate_runs,
            criteria_results=criteria_results,
            expected_tested=True,
        )
    if targeted_worse:
        return _finish(
            status="WORSE",
            reason="TARGETED_OUTCOME_REGRESSED",
            baseline_runs=baseline_runs,
            candidate_runs=candidate_runs,
            criteria_results=criteria_results,
            expected_tested=True,
        )
    if targeted_equal:
        return _finish(
            status="EQUIVALENT",
            reason="TARGETED_OUTCOME_UNCHANGED",
            baseline_runs=baseline_runs,
            candidate_runs=candidate_runs,
            criteria_results=criteria_results,
            expected_tested=True,
        )
    return _finish(
        status="INSUFFICIENT_COMPARATIVE_EVIDENCE",
        reason="TARGETED_OUTCOME_INCOMPARABLE",
        baseline_runs=baseline_runs,
        candidate_runs=candidate_runs,
        criteria_results=criteria_results,
        expected_tested=expected_tested,
    )


@dataclass(frozen=True)
class CapabilityReplacement:
    replacement_id: str
    comparison_id: str
    proposal_id: str
    proposal_evaluation_id: str
    target_capability_id: str
    candidate_capability_id: str
    old_artifact_hash: str
    candidate_artifact_hash: str
    behavioral_certification_ref: str
    authority_result: str
    pre_replacement_snapshot_ref: str
    switch_result: str
    post_switch_verification: dict[str, Any]
    runtime_verification_ref: str | None
    replacement_eligibility: str
    status: str
    reason: str
    created_at: str
    created_by: str
    auto_replacement: bool = False
    auto_rollback: bool = False
    promotion_activated: bool = False
    training_activated: bool = False

    def as_dict(self) -> dict[str, Any]:
        return {
            "replacement_id": self.replacement_id,
            "comparison_id": self.comparison_id,
            "proposal_id": self.proposal_id,
            "proposal_evaluation_id": self.proposal_evaluation_id,
            "target_capability_id": self.target_capability_id,
            "candidate_capability_id": self.candidate_capability_id,
            "old_artifact_hash": self.old_artifact_hash,
            "candidate_artifact_hash": self.candidate_artifact_hash,
            "behavioral_certification_ref": self.behavioral_certification_ref,
            "authority_result": self.authority_result,
            "pre_replacement_snapshot_ref": self.pre_replacement_snapshot_ref,
            "switch_result": self.switch_result,
            "post_switch_verification": dict(self.post_switch_verification),
            "runtime_verification_ref": self.runtime_verification_ref,
            "replacement_eligibility": self.replacement_eligibility,
            "status": self.status,
            "reason": self.reason,
            "created_at": self.created_at,
            "created_by": self.created_by,
            "auto_replacement": False,
            "auto_rollback": False,
            "promotion_activated": False,
            "training_activated": False,
        }


def get_capability_replacement(replacement_id: str) -> CapabilityReplacement | None:
    return _REPLACEMENTS.get(replacement_id)


def _comparison_from_mapping(data: Mapping[str, Any]) -> ImprovementComparison:
    workload = dict(data.get("workload_definition") or {})
    return ImprovementComparison(
        comparison_id=str(data["comparison_id"]),
        target_capability_id=str(data["target_capability_id"]),
        baseline_artifact_hash=data.get("baseline_artifact_hash"),
        candidate_artifact_hash=str(data["candidate_artifact_hash"]),
        workload_definition=workload,
        sample_count_baseline=int(data.get("sample_count_baseline") or 0),
        sample_count_candidate=int(data.get("sample_count_candidate") or 0),
        baseline_metrics=dict(data.get("baseline_metrics") or {}),
        candidate_metrics=dict(data.get("candidate_metrics") or {}),
        acceptance_criteria_results=dict(data.get("acceptance_criteria_results") or {}),
        performance_delta=dict(data.get("performance_delta") or {}),
        reliability_delta=dict(data.get("reliability_delta") or {}),
        status=str(data["status"]),
        reason=str(data.get("reason") or ""),
        evidence_refs=tuple(data.get("evidence_refs") or ()),
        created_at=str(data.get("created_at") or _now()),
        expected_outcome=str(data.get("expected_outcome") or ""),
        expected_outcome_metric=data.get("expected_outcome_metric"),
        expected_outcome_tested=bool(data.get("expected_outcome_tested")),
        replacement_eligibility=str(data.get("replacement_eligibility") or "NO"),
    )


def _load_comparison(store: PerformanceStore, comparison_id: str) -> ImprovementComparison:
    loaded = _COMPARISONS.get(comparison_id)
    if loaded is not None:
        return loaded
    try:
        return _comparison_from_mapping(store.get_improvement_comparison(comparison_id))
    except StoreReadFailed as exc:
        raise ImprovementError("UNKNOWN_COMPARISON") from exc


def replace_existing_capability(
    store: PerformanceStore,
    *,
    comparison_id: str,
    requester: str = "learner",
    claims: Mapping[str, Any] | None = None,
    historical_records: tuple[Mapping[str, Any], ...] = (),
    target_capability_id: str | None = None,
) -> CapabilityReplacement:
    """Owner-gated same-ID replacement. Never auto-replaces or auto-rolls back."""
    _reject_claims(claims)
    del historical_records
    if requester in _BLOCKED_REPLACERS or requester not in _REPLACER_IDENTITIES:
        raise ImprovementError("SELF_REPLACEMENT_FORBIDDEN")

    comparison = _load_comparison(store, comparison_id)
    if comparison.status != "PROVEN_IMPROVEMENT":
        raise ImprovementError("REPLACEMENT_DENIED")
    if comparison.replacement_eligibility != "ELIGIBLE_FOR_CONTROLLED_REPLACEMENT":
        raise ImprovementError("REPLACEMENT_DENIED")

    candidate_id = str(comparison.workload_definition.get("candidate_id") or "")
    loaded = get_improvement_implementation(candidate_id)
    if loaded is None:
        raise ImprovementError("UNKNOWN_IMPROVEMENT_CANDIDATE")
    target = loaded.requirement.target_capability_id
    if comparison.target_capability_id != target:
        raise ImprovementError("CROSS_CAPABILITY_EVIDENCE")
    if target_capability_id and target_capability_id != target:
        raise ImprovementError("CROSS_CAPABILITY_EVIDENCE")
    if target not in HANDLERS:
        raise ImprovementError("TARGET_NOT_ACTIVE")
    if candidate_id == target or candidate_id in HANDLERS:
        raise ImprovementError("LOGICAL_ID_CHANGE_FORBIDDEN")

    record = get_candidate(candidate_id)
    if record is None:
        raise ImprovementError("CANDIDATE_NOT_REGISTERED")
    if record.artifact_class != ARTIFACT_IMPLEMENTATION_SOURCE:
        raise ImprovementError("PIPELINE_CERTIFICATION_INSUFFICIENT")
    expected_hash = loaded.genesis.generated.artifact_hash if loaded.genesis.generated else ""
    if not expected_hash:
        raise ImprovementError("ARTIFACT_IDENTITY_MISMATCH")
    _assert_hash(expected_hash, record.artifact_hash, "registration")
    _assert_hash(expected_hash, comparison.candidate_artifact_hash, "comparison")

    sandbox = get_candidate_sandbox(candidate_id)
    behavior = get_candidate_behavior(candidate_id)
    behavioral_eval = get_candidate_behavior_evaluation(candidate_id)
    cert = get_candidate_behavior_certification(candidate_id)
    if sandbox is None or not sandbox.validated:
        raise ImprovementError("BEHAVIORAL_SANDBOX_FAILED")
    if behavior is None:
        raise ImprovementError("BEHAVIORAL_CERTIFICATION_REQUIRED")
    if behavioral_eval is None or behavioral_eval.status != "PASSED":
        raise ImprovementError("BEHAVIORAL_CERTIFICATION_REQUIRED")
    if (
        cert is None
        or cert.certification_kind != CERTIFICATION_KIND_BEHAVIORAL
        or cert.status != CANDIDATE_BEHAVIORALLY_CERTIFIED
    ):
        raise ImprovementError("BEHAVIORAL_CERTIFICATION_REQUIRED")
    _assert_hash(expected_hash, sandbox.artifact_hash, "sandbox")
    _assert_hash(expected_hash, behavior.artifact_hash, "behavior")
    _assert_hash(expected_hash, behavioral_eval.artifact_hash, "evaluation")
    _assert_hash(expected_hash, cert.artifact_hash, "certification")

    current = active_version_id(target) or artifact_hash(target)
    if not current or current != comparison.baseline_artifact_hash:
        raise ImprovementError("STALE_TARGET")

    keys_before = list(HANDLERS)
    old_handler = HANDLERS[target]
    old_overlay = _ACTIVE.get(target)
    old_restore = export_active_restore(target)
    old_hash = current

    authority = resolve(AuthorityRequest(action="replace_capability"))
    if authority.outcome != "ALLOW":
        raise ImprovementError("REPLACEMENT_DENIED")

    try:
        snapshot = snapshot_capability(target, store=store)
    except SnapshotFailed as exc:
        raise ImprovementError("SNAPSHOT_FAILED") from exc
    if not snapshot.snapshot_id or snapshot.capability_id != target:
        raise ImprovementError("SNAPSHOT_FAILED")

    candidate_record, blob = export_candidate_artifact(candidate_id)
    live_hash = __import__("hashlib").sha256(blob).hexdigest()
    _assert_hash(expected_hash, candidate_record.artifact_hash, "export")
    _assert_hash(expected_hash, live_hash, "live")
    source = blob.decode("utf-8")
    handler = _load_certified_handle(candidate_id, source)

    switched = False
    try:
        encoded = __import__("base64").b64encode(
            __import__("marshal").dumps(handler.__code__)
        ).decode("ascii")
        HANDLERS[target] = handler
        bind_active(target, expected_hash, handler)
        set_active_restore(
            target,
            {
                "capability_id": target,
                "artifact": encoded,
                "artifact_hash": hashlib.sha256(handler.__code__.co_code).hexdigest(),
            },
        )
        switched = True
        if list(HANDLERS.keys()) != keys_before:
            raise ImprovementError("LOGICAL_ID_CHANGE_FORBIDDEN")
        if candidate_id in HANDLERS:
            raise ImprovementError("LOGICAL_ID_CHANGE_FORBIDDEN")
        if active_version_id(target) != expected_hash:
            raise ImprovementError("POST_SWITCH_VERIFICATION_FAILED")
        if get_active_handler(target) is None:
            raise ImprovementError("POST_SWITCH_VERIFICATION_FAILED")
        isolated = __import__("capability_cycle.sandbox", fromlist=["run_sandboxed"]).run_sandboxed(
            target, {"capability_id": target, "data": {"replacement": True}}
        )
        if not isolated.validated:
            raise ImprovementError("POST_SWITCH_VERIFICATION_FAILED")
        certified = evaluate(
            target,
            sandbox=isolated,
            contract_valid=True,
            tests_present=True,
            evidence={"provenance": "controlled_replacement", "artifact_hash": expected_hash},
            requester="runtime",
        )
        if not is_usable(certified):
            raise ImprovementError("POST_SWITCH_VERIFICATION_FAILED")
        runtime = execute_plan(
            Requirement(explicit_capability_ids=(target,)),
            payloads={target: {"data": {"replacement": True}}},
            performance_store=store,
            max_retries=0,
        )
        mission = runtime.mission_verification
        if (
            runtime.status != "PASSED"
            or mission is None
            or mission.status != "VERIFIED"
        ):
            raise ImprovementError("POST_SWITCH_RUNTIME_FAILED")
        verification = {
            "logical_id": target,
            "active_artifact_hash": active_version_id(target),
            "sandbox": isolated.outcome,
            "certification": certified.state,
            "mission": mission.status,
            "resolver": has_implementation(target),
        }
        result = CapabilityReplacement(
            replacement_id=uuid.uuid4().hex,
            comparison_id=comparison.comparison_id,
            proposal_id=str(
                comparison.workload_definition.get("proposal_id")
                or loaded.requirement.source_proposal_id
            ),
            proposal_evaluation_id=str(
                comparison.workload_definition.get("proposal_evaluation_id")
                or loaded.requirement.source_proposal_evaluation_id
            ),
            target_capability_id=target,
            candidate_capability_id=candidate_id,
            old_artifact_hash=old_hash,
            candidate_artifact_hash=expected_hash,
            behavioral_certification_ref=f"candidate-behavior-cert:{cert.certification_id}",
            authority_result=authority.outcome,
            pre_replacement_snapshot_ref=snapshot.snapshot_id,
            switch_result="APPLIED",
            post_switch_verification=verification,
            runtime_verification_ref=runtime.performance_record_ids[0]
            if runtime.performance_record_ids
            else None,
            replacement_eligibility=comparison.replacement_eligibility,
            status="APPLIED",
            reason="CONTROLLED_REPLACEMENT_APPLIED",
            created_at=_now(),
            created_by=requester,
        )
        _REPLACEMENTS[result.replacement_id] = result
        store.persist_capability_replacement(result.as_dict())
        return result
    except Exception:
        if switched:
            restored = restore_capability(
                target, store=store, snapshot_id=snapshot.snapshot_id
            )
            if restored.restore_result != "VERIFIED":
                HANDLERS[target] = old_handler
                if old_overlay is not None:
                    bind_active(target, old_overlay[0], old_overlay[1])
                else:
                    from .handlers import unbind_active

                    unbind_active(target)
                if old_restore is not None:
                    set_active_restore(target, old_restore)
            raise ImprovementError("POST_SWITCH_VERIFICATION_FAILED")
        raise
