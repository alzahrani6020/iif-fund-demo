"""Current-state readiness for W7-P01 / W7-P08. Evaluation creates no authority."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .handlers import has_implementation

MANIFESTS = {
    "W7-P01": "owner-packages/WAVE_07_PACKAGE_01_CANONICAL_W7_P01/MANIFEST.json",
    "W7-P08": "owner-packages/WAVE_07_PACKAGE_08_CANONICAL_W7_P08/MANIFEST.json",
}


def evaluate_package(repo_root: str | Path, package_id: str) -> dict[str, Any]:
    root = Path(repo_root)
    rel = MANIFESTS.get(package_id)
    if not rel:
        return {
            "package_id": package_id,
            "readiness": "NOT_READY",
            "source": "LIVE_MANIFEST_ABSENT",
            "blockers": ["unknown_package"],
            "authority_created": False,
            "historical_label_inherited": False,
        }
    path = root / rel
    if not path.is_file():
        return {
            "package_id": package_id,
            "readiness": "NOT_READY",
            "source": "LIVE_MANIFEST_ABSENT",
            "blockers": [f"missing:{rel}"],
            "authority_created": False,
            "historical_label_inherited": False,
        }
    manifest = json.loads(path.read_text(encoding="utf-8"))
    blockers: list[str] = []
    if manifest.get("readiness_state") != "READY":
        blockers.append(f"readiness_state={manifest.get('readiness_state')}")
    if manifest.get("overall_state") != "READY":
        blockers.append(f"overall_state={manifest.get('overall_state')}")
    if manifest.get("validation_state") != "VALIDATED":
        blockers.append(f"validation_state={manifest.get('validation_state')}")
    if manifest.get("runtime_state") != "ACTIVE":
        blockers.append(f"runtime_state={manifest.get('runtime_state')}")
    if package_id == "W7-P08" and not has_implementation("CAP-TRUTH-001"):
        blockers.append("capability_runtime_missing")
    readiness = "READY" if not blockers else "NOT_READY"
    if blockers and manifest.get("overall_state") == "BUILDING":
        readiness = "NOT_READY"
    return {
        "package_id": package_id,
        "readiness": readiness,
        "source": "LIVE_PACKAGE_MANIFEST",
        "blockers": blockers,
        "authority_created": False,
        "historical_label_inherited": False,
    }
