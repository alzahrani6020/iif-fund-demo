"""Benchmark Laboratory suite runner for ENG-CAP-093.

Supports golden, negative-control, adversarial, failure, recovery and
performance cases. A passed suite is benchmark evidence, not production
admission and not a marketing claim.
"""

from __future__ import annotations

import hashlib
import json
import statistics
import time
from dataclasses import dataclass
from typing import Any, Callable, Mapping


Executor = Callable[[Mapping[str, Any]], Mapping[str, Any]]
_ALLOWED_KINDS = {
    "GOLDEN",
    "NEGATIVE_CONTROL",
    "ADVERSARIAL",
    "FAILURE",
    "RECOVERY",
    "PERFORMANCE",
}


@dataclass(frozen=True)
class BenchmarkSuiteCase:
    case_id: str
    kind: str
    input: dict[str, Any]
    expected: dict[str, Any]
    evidence_refs: tuple[str, ...] = ()


@dataclass(frozen=True)
class BenchmarkSuiteCaseResult:
    case_id: str
    kind: str
    passed: bool
    elapsed_ms: float
    output_hash: str
    observed_ok: bool
    reason: str
    evidence_refs: tuple[str, ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "case_id": self.case_id,
            "kind": self.kind,
            "passed": self.passed,
            "elapsed_ms": self.elapsed_ms,
            "output_hash": self.output_hash,
            "observed_ok": self.observed_ok,
            "reason": self.reason,
            "evidence_refs": list(self.evidence_refs),
        }


@dataclass(frozen=True)
class BenchmarkSuiteReport:
    subject_id: str
    state: str
    total_cases: int
    passed_cases: int
    pass_rate: float
    category_pass_rates: dict[str, float]
    p50_ms: float
    p95_ms: float
    p99_ms: float
    results: tuple[BenchmarkSuiteCaseResult, ...]
    evidence_refs: tuple[str, ...]
    marketing_claim_not_evidence: bool = True
    production_admission: bool = False

    def as_dict(self) -> dict[str, Any]:
        return {
            "subject_id": self.subject_id,
            "state": self.state,
            "total_cases": self.total_cases,
            "passed_cases": self.passed_cases,
            "pass_rate": self.pass_rate,
            "category_pass_rates": dict(self.category_pass_rates),
            "p50_ms": self.p50_ms,
            "p95_ms": self.p95_ms,
            "p99_ms": self.p99_ms,
            "results": [item.as_dict() for item in self.results],
            "evidence_refs": list(self.evidence_refs),
            "marketing_claim_not_evidence": True,
            "production_admission": False,
        }


def _digest(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, default=str, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _percentile(values: list[float], fraction: float) -> float:
    ordered = sorted(values)
    if not ordered:
        return 0.0
    if len(ordered) == 1:
        return round(ordered[0], 6)
    pos = (len(ordered) - 1) * fraction
    low = int(pos)
    high = min(low + 1, len(ordered) - 1)
    part = pos - low
    return round(ordered[low] + (ordered[high] - ordered[low]) * part, 6)


def _matches_expected(output: Mapping[str, Any], expected: Mapping[str, Any]) -> tuple[bool, str]:
    if "expect_ok" in expected:
        observed = bool(output.get("ok"))
        if observed != bool(expected["expect_ok"]):
            return False, "EXPECT_OK_MISMATCH"

    if "expected_failure_class" in expected:
        failure = (
            output.get("failure_class")
            or (output.get("evidence") or {}).get("failure_class")
            if isinstance(output.get("evidence"), Mapping)
            else output.get("failure_class")
        )
        if str(failure or "") != str(expected["expected_failure_class"]):
            return False, "FAILURE_CLASS_MISMATCH"

    expected_contains = expected.get("contains")
    if isinstance(expected_contains, Mapping):
        for key, value in expected_contains.items():
            if output.get(key) != value:
                return False, f"FIELD_MISMATCH:{key}"

    expected_absent = expected.get("must_not_contain")
    if isinstance(expected_absent, (list, tuple)):
        blob = json.dumps(output, sort_keys=True, default=str)
        for item in expected_absent:
            if str(item) in blob:
                return False, f"FORBIDDEN_VALUE_PRESENT:{item}"

    max_latency_ms = expected.get("max_latency_ms")
    if max_latency_ms is not None:
        # evaluated by caller with actual elapsed value
        pass

    return True, "EXPECTED_CONDITIONS_MATCHED"


def run_benchmark_suite(
    *,
    subject_id: str,
    executor: Executor,
    cases: tuple[BenchmarkSuiteCase, ...],
    minimum_pass_rate: float = 1.0,
) -> BenchmarkSuiteReport:
    if not cases:
        raise ValueError("benchmark suite requires at least one case")
    if not (0.0 < minimum_pass_rate <= 1.0):
        raise ValueError("minimum_pass_rate must be in (0,1]")

    results: list[BenchmarkSuiteCaseResult] = []
    collected_refs: list[str] = []

    for case in cases:
        kind = case.kind.upper().strip()
        if kind not in _ALLOWED_KINDS:
            raise ValueError(f"unsupported benchmark case kind: {case.kind}")

        started = time.perf_counter()
        try:
            output = dict(executor(dict(case.input)))
            observed_ok = bool(output.get("ok"))
        except Exception as exc:  # noqa: BLE001
            output = {
                "ok": False,
                "error_class": type(exc).__name__,
            }
            observed_ok = False
        elapsed_ms = round((time.perf_counter() - started) * 1000, 6)

        passed, reason = _matches_expected(output, case.expected)
        max_latency = case.expected.get("max_latency_ms")
        if passed and max_latency is not None and elapsed_ms > float(max_latency):
            passed = False
            reason = "LATENCY_BUDGET_EXCEEDED"

        output_hash = _digest(output)
        refs = tuple(
            sorted(
                dict.fromkeys(
                    (
                        *case.evidence_refs,
                        f"benchmark-case:{case.case_id}:{output_hash}",
                    )
                )
            )
        )
        collected_refs.extend(refs)
        results.append(
            BenchmarkSuiteCaseResult(
                case_id=case.case_id,
                kind=kind,
                passed=passed,
                elapsed_ms=elapsed_ms,
                output_hash=output_hash,
                observed_ok=observed_ok,
                reason=reason,
                evidence_refs=refs,
            )
        )

    total = len(results)
    passed_count = sum(item.passed for item in results)
    pass_rate = round(passed_count / total, 6)

    category_rates: dict[str, float] = {}
    for kind in sorted({item.kind for item in results}):
        subset = [item for item in results if item.kind == kind]
        category_rates[kind] = round(
            sum(item.passed for item in subset) / len(subset),
            6,
        )

    latencies = [item.elapsed_ms for item in results]
    state = (
        "BENCHMARK_PASSED"
        if pass_rate >= minimum_pass_rate
        else "BENCHMARK_FAILED"
    )

    return BenchmarkSuiteReport(
        subject_id=subject_id,
        state=state,
        total_cases=total,
        passed_cases=passed_count,
        pass_rate=pass_rate,
        category_pass_rates=category_rates,
        p50_ms=_percentile(latencies, 0.50),
        p95_ms=_percentile(latencies, 0.95),
        p99_ms=_percentile(latencies, 0.99),
        results=tuple(results),
        evidence_refs=tuple(sorted(dict.fromkeys(collected_refs))),
        marketing_claim_not_evidence=True,
        production_admission=False,
    )


def cases_from_payload(values: Any) -> tuple[BenchmarkSuiteCase, ...]:
    if not isinstance(values, (list, tuple)):
        return ()
    out: list[BenchmarkSuiteCase] = []
    for index, raw in enumerate(values):
        if not isinstance(raw, Mapping):
            continue
        out.append(
            BenchmarkSuiteCase(
                case_id=str(raw.get("case_id") or f"case-{index + 1}"),
                kind=str(raw.get("kind") or "GOLDEN"),
                input=dict(raw.get("input") or {}),
                expected=dict(raw.get("expected") or {}),
                evidence_refs=tuple(
                    str(x) for x in (raw.get("evidence_refs") or ())
                ),
            )
        )
    return tuple(out)
