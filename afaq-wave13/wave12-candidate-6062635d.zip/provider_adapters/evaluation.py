"""Evaluation of one local evidence receipt.

Samples are scored and the case is left waiting for the owner. An owner
decision records approval or rejection. Neither step changes production.
"""

from __future__ import annotations

from typing import Any, Mapping

from provider_adapters.evidence_receipt import EvidenceReceiptError, require_local_receipt
from provider_adapters.training_cycle import TrainingCycleError, apply_action


def evaluate_receipt(
    receipt: Mapping[str, Any],
    samples: list[Mapping[str, Any]] | None = None,
) -> dict[str, Any]:
    current = _require_receipt(receipt)
    if current["training"]["state"] != "OBSERVE":
        raise EvidenceReceiptError("evaluation starts from observation")
    case = _apply(_case_from_receipt(current), "collect", samples or [])
    case = _apply(case, "evaluate")
    case = _apply(case, "submit")
    return _with_training(current, case)


def decide_receipt(receipt: Mapping[str, Any], decision: str) -> dict[str, Any]:
    current = _require_receipt(receipt)
    if current["training"]["state"] != "AWAITING_OWNER":
        raise EvidenceReceiptError("owner decision waits for evaluation")
    verb = str(decision or "").strip().lower()
    if verb not in {"approve", "reject"}:
        raise EvidenceReceiptError("owner decision must approve or reject")
    case = _apply(_case_from_receipt(current), verb)
    return _with_training(current, case)


def _require_receipt(receipt: Mapping[str, Any]) -> dict[str, Any]:
    return require_local_receipt(receipt)


def _case_from_receipt(receipt: Mapping[str, Any]) -> dict[str, Any]:
    training = receipt["training"]
    return {
        "ok": True,
        "subject": str(receipt.get("subject") or ""),
        "state": training.get("state"),
        "samples": [dict(row) for row in (training.get("samples") or [])],
        "score": training.get("score"),
        "owner_decision": training.get("owner_decision"),
        "production_changed": False,
    }


def _apply(
    case: Mapping[str, Any],
    action: str,
    samples: list[Mapping[str, Any]] | None = None,
) -> dict[str, Any]:
    try:
        return apply_action(case, action, samples)
    except TrainingCycleError as exc:
        raise EvidenceReceiptError(str(exc)) from exc


def _with_training(receipt: Mapping[str, Any], case: Mapping[str, Any]) -> dict[str, Any]:
    updated = dict(receipt)
    updated["promotion_authorized"] = False
    updated["production_changed"] = False
    updated["privacy_class"] = "LOCAL_ONLY"
    updated["training"] = {
        "state": case["state"],
        "samples": case["samples"],
        "score": case["score"],
        "owner_decision": case.get("owner_decision"),
        "production_changed": False,
    }
    return updated
