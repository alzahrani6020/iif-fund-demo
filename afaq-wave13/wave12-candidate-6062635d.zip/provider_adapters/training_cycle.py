"""Training cycle that stops for an owner decision.

Samples can be collected and scored. The cycle may reach APPROVED or
REJECTED. It cannot enter production, canary, or shadow, and a promotion
call is always refused.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping

REPO = Path(__file__).resolve().parents[1]
CYCLE_PATH = REPO / "saudi_saas" / "owner_console" / "modules" / "training_cycle.json"


class TrainingCycleError(ValueError):
    """The training action is not allowed from the current state."""


def load_cycle(path: Path | None = None) -> dict[str, Any]:
    data = json.loads((path or CYCLE_PATH).read_text(encoding="utf-8"))
    if not isinstance(data, dict) or data.get("schema") != "AFAQ_TRAINING_CYCLE_V1":
        raise TrainingCycleError("unsupported training cycle")
    if data.get("production_changed") is not False:
        raise TrainingCycleError("training cycle must not change production")
    forbidden = set(data.get("forbidden_states") or [])
    if not {"SHADOW", "CANARY", "PRODUCTION"} <= forbidden:
        raise TrainingCycleError("production states must stay forbidden")
    return data


def start_case(subject: str, cycle: Mapping[str, Any] | None = None) -> dict[str, Any]:
    spec = dict(cycle) if cycle is not None else load_cycle()
    _assert_closed(spec)
    name = str(subject or "").strip()
    if not name:
        raise TrainingCycleError("subject is required")
    return _case(spec, name, "OBSERVE", samples=[])


def apply_action(
    case: Mapping[str, Any],
    action: str,
    samples: list[Mapping[str, Any]] | None = None,
    cycle: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    spec = dict(cycle) if cycle is not None else load_cycle()
    _assert_closed(spec)
    current = str(case.get("state") or "")
    verb = str(action or "").strip().lower()
    rule = _transition(spec, current, verb)
    if rule is None:
        raise TrainingCycleError("transition is not allowed")
    held = [dict(row) for row in (case.get("samples") or [])]
    incoming = [dict(row) for row in (samples or [])]
    if rule.get("requires") == "samples":
        if not incoming:
            raise TrainingCycleError("samples are required")
        held = incoming
    if rule.get("requires") == "ground_truth" and not _has_ground_truth(held):
        raise TrainingCycleError("ground truth is required")
    updated = _case(
        spec,
        str(case.get("subject") or ""),
        str(rule["to"]),
        samples=held,
        score=_score(held) if rule["to"] in {"EVALUATED", "AWAITING_OWNER", "APPROVED", "REJECTED"} else None,
    )
    if verb == "approve":
        updated["owner_decision"] = "approved"
    elif verb == "reject":
        updated["owner_decision"] = "rejected"
    return updated


def promote(case: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "ok": False,
        "status": "DENIED",
        "code": "PROMOTION_BLOCKED",
        "state": case.get("state"),
        "production_changed": False,
    }


def _transition(spec: Mapping[str, Any], state: str, action: str) -> Mapping[str, Any] | None:
    for row in spec.get("transitions") or []:
        if isinstance(row, Mapping) and row.get("from") == state and row.get("on") == action:
            return row
    return None


def _has_ground_truth(samples: list[Mapping[str, Any]]) -> bool:
    if not samples:
        return False
    return all("actual" in row and str(row.get("actual") or "").strip() for row in samples)


def _score(samples: list[Mapping[str, Any]]) -> float | None:
    if not _has_ground_truth(samples):
        return None
    matches = sum(1 for row in samples if str(row.get("prediction")) == str(row.get("actual")))
    return matches / len(samples)


def _case(
    spec: Mapping[str, Any],
    subject: str,
    state: str,
    samples: list[dict[str, Any]],
    score: float | None = None,
) -> dict[str, Any]:
    if state in set(spec.get("forbidden_states") or []):
        raise TrainingCycleError("forbidden training state")
    return {
        "ok": True,
        "subject": subject,
        "state": state,
        "samples": samples,
        "score": score,
        "owner_decision": None,
        "production_changed": False,
    }


def _assert_closed(spec: Mapping[str, Any]) -> None:
    if spec.get("production_changed") is not False:
        raise TrainingCycleError("training cycle must not change production")
    targets = {str(row.get("to")) for row in (spec.get("transitions") or []) if isinstance(row, Mapping)}
    forbidden = set(spec.get("forbidden_states") or [])
    if targets & forbidden:
        raise TrainingCycleError("a forbidden state is reachable")
