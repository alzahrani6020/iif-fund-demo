"""Deterministic task and risk classification.

The instruction picks a task, a risk, and a local selection mode. The
privacy class stays on this machine. Classification does not execute work
and does not promote anything.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping

from provider_adapters.selection import SELECTION_MODES

REPO = Path(__file__).resolve().parents[1]
CATALOG_PATH = REPO / "saudi_saas" / "owner_console" / "modules" / "task_catalog.json"
RISKS = frozenset({"LOW", "MEDIUM", "HIGH"})


class TaskClassifierError(ValueError):
    """The task catalog cannot be applied."""


def load_task_catalog(path: Path | None = None) -> dict[str, Any]:
    data = json.loads((path or CATALOG_PATH).read_text(encoding="utf-8"))
    if not isinstance(data, dict) or data.get("schema") != "AFAQ_TASK_CLASSIFIER_V1":
        raise TaskClassifierError("unsupported task catalog")
    if data.get("privacy_class") != "LOCAL_ONLY":
        raise TaskClassifierError("task privacy must stay local")
    for rule in [data.get("default"), *(data.get("rules") or [])]:
        if not isinstance(rule, Mapping):
            raise TaskClassifierError("task rule must be an object")
        if rule.get("mode") not in SELECTION_MODES or rule.get("risk") not in RISKS:
            raise TaskClassifierError("task rule is outside the local contract")
    return data


def classify_task(text: str, catalog: Mapping[str, Any] | None = None) -> dict[str, Any]:
    spec = dict(catalog) if catalog is not None else load_task_catalog()
    if spec.get("privacy_class") != "LOCAL_ONLY":
        raise TaskClassifierError("task privacy must stay local")
    haystack = str(text or "").casefold()
    chosen = spec.get("default")
    for rule in spec.get("rules") or []:
        terms = rule.get("terms") or []
        if any(str(term).casefold() in haystack for term in terms if str(term).strip()):
            chosen = rule
            break
    if not isinstance(chosen, Mapping):
        raise TaskClassifierError("task catalog has no default")
    return {
        "ok": True,
        "task": chosen.get("task"),
        "label": chosen.get("label") or chosen.get("task"),
        "risk": chosen.get("risk"),
        "mode": chosen.get("mode"),
        "privacy_class": "LOCAL_ONLY",
        "confirmation_required": chosen.get("risk") == "HIGH",
        "promotion_authorized": False,
    }
