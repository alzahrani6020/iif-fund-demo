"""Provider adapter package — fail-closed by default."""

from .capability_gateway import describe, discover, invoke
from .eligibility import verify_eligibility
from .evaluation import decide_receipt, evaluate_receipt
from .evidence_receipt import compose_receipt
from .fail_closed import invoke_provider, provider_readiness
from .lesson import apply_owner_decision, continue_from_lesson, present_lesson, record_lesson, select_recorded_lesson
from .selection import select_route
from .task_classifier import classify_task
from .task_record import attach_task_record
from .training_cycle import promote, start_case

__all__ = [
    "classify_task",
    "compose_receipt",
    "continue_from_lesson",
    "decide_receipt",
    "describe",
    "discover",
    "evaluate_receipt",
    "verify_eligibility",
    "invoke",
    "invoke_provider",
    "promote",
    "present_lesson",
    "provider_readiness",
    "record_lesson",
    "select_recorded_lesson",
    "select_route",
    "start_case",
    "attach_task_record",
    "apply_owner_decision",
]
