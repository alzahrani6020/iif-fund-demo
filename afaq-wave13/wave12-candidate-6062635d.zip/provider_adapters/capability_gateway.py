"""Capability protocol over the live engine and capability registry.

The registry stays the only source of names. This module can discover,
describe, and authorize a registered capability. It does not execute one:
a permitted invoke returns PERMITTED_NOT_EXECUTED, and the existing engine
runtime remains the executor. An unknown name is denied. Nothing here
promotes a component.
"""

from __future__ import annotations

from typing import Any, Mapping

ROLES = frozenset({"owner", "operator"})
RISKS = frozenset({"LOW", "MEDIUM", "HIGH", "CRITICAL"})
CONFIRMED_RISKS = frozenset({"HIGH", "CRITICAL"})

_registry_cache: dict[str, Any] | None = None


class CapabilityGatewayError(ValueError):
    """The protocol request cannot be resolved."""


def load_live_registry() -> dict[str, Any]:
    global _registry_cache
    if _registry_cache is None:
        from afaq_registry.loader import load_registry

        loaded = load_registry()
        if not isinstance(loaded, dict):
            raise CapabilityGatewayError("live registry must be an object")
        _registry_cache = loaded
    return _registry_cache


def discover(query: str = "", limit: int = 20, registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    index = _index(registry)
    needle = str(query or "").strip().casefold()
    names = sorted(index["names"])
    if needle:
        names = [name for name in names if needle in name.casefold()]
    bounded = _limit(limit)
    return {
        "ok": True,
        "protocol": "discover",
        "status": "LISTED",
        "query": str(query or ""),
        "count": len(names),
        "matches": [_public_name(index, name) for name in names[:bounded]],
        "promotion_authorized": False,
    }


def describe(name: str, registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    index = _index(registry)
    key = str(name or "").strip()
    record = index["by_name"].get(key)
    if record is None:
        return _denied("describe", key, "UNKNOWN_CAPABILITY")
    return {
        "ok": True,
        "protocol": "describe",
        "status": "DESCRIBED",
        "name": key,
        "capability_id": record["capability_id"],
        "packages": record["packages"],
        "engines": record["engines"],
        "promotion_authorized": False,
    }


def authorize(
    name: str,
    role: str,
    risk: str = "LOW",
    confirmed: bool = False,
    registry: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    described = describe(name, registry)
    if not described["ok"]:
        return described
    actor = str(role or "").strip().lower()
    level = str(risk or "").strip().upper()
    if actor not in ROLES:
        return _denied("authorize", described["name"], "ROLE_DENIED")
    if level not in RISKS:
        return _denied("authorize", described["name"], "RISK_DENIED")
    if level in CONFIRMED_RISKS and not confirmed:
        return _denied("authorize", described["name"], "CONFIRMATION_REQUIRED")
    return {
        "ok": True,
        "protocol": "authorize",
        "status": "PERMITTED",
        "name": described["name"],
        "capability_id": described["capability_id"],
        "role": actor,
        "risk": level,
        "promotion_authorized": False,
    }


def invoke(
    name: str,
    role: str,
    risk: str = "LOW",
    confirmed: bool = False,
    registry: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    permit = authorize(name, role, risk, confirmed, registry)
    if not permit["ok"]:
        permit["protocol"] = "invoke"
        return permit
    return {
        "ok": True,
        "protocol": "invoke",
        "status": "PERMITTED_NOT_EXECUTED",
        "name": permit["name"],
        "capability_id": permit["capability_id"],
        "role": permit["role"],
        "risk": permit["risk"],
        "execution": "engine_runtime",
        "promotion_authorized": False,
    }


def verify(receipt: Mapping[str, Any]) -> dict[str, Any]:
    if not isinstance(receipt, Mapping):
        raise CapabilityGatewayError("receipt must be an object")
    if receipt.get("promotion_authorized") is not False:
        return _denied("verify", str(receipt.get("name") or ""), "PROMOTION_BLOCKED")
    status = receipt.get("status")
    if status not in {"LISTED", "DESCRIBED", "PERMITTED", "DENIED", "PERMITTED_NOT_EXECUTED", "VERIFIED", "OBSERVED"}:
        return _denied("verify", str(receipt.get("name") or ""), "RECEIPT_INVALID")
    if status == "PERMITTED_NOT_EXECUTED" and receipt.get("execution") != "engine_runtime":
        return _denied("verify", str(receipt.get("name") or ""), "EXECUTION_CLAIM_REJECTED")
    return {
        "ok": True,
        "protocol": "verify",
        "status": "VERIFIED",
        "receipt_status": status,
        "promotion_authorized": False,
    }


def observe(receipts: list[Mapping[str, Any]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for receipt in receipts:
        if not isinstance(receipt, Mapping):
            continue
        status = str(receipt.get("status") or "UNKNOWN")
        counts[status] = counts.get(status, 0) + 1
    return {
        "ok": True,
        "protocol": "observe",
        "status": "OBSERVED",
        "receipts": len(receipts),
        "by_status": counts,
        "promotion_authorized": False,
    }


def _index(registry: Mapping[str, Any] | None) -> dict[str, Any]:
    source = registry if registry is not None else load_live_registry()
    by_name: dict[str, dict[str, Any]] = {}
    for row in source.get("capability_identities") or []:
        if not isinstance(row, Mapping):
            continue
        name = str(row.get("name") or "").strip()
        if not name:
            continue
        by_name[name] = {
            "capability_id": row.get("capability_id"),
            "packages": [],
            "engines": [],
        }
    package_names: dict[str, list[str]] = {}
    for package in source.get("capability_packages") or []:
        if not isinstance(package, Mapping):
            continue
        package_id = str(package.get("package_id") or "").strip()
        names = [str(item).strip() for item in (package.get("capabilities") or []) if str(item).strip()]
        package_names[package_id] = names
        for name in names:
            record = by_name.setdefault(name, {"capability_id": None, "packages": [], "engines": []})
            if package_id and package_id not in record["packages"]:
                record["packages"].append(package_id)
    for engine in source.get("engines") or []:
        if not isinstance(engine, Mapping):
            continue
        engine_id = str(engine.get("engine_id") or "").strip()
        linked = set()
        for package_id in engine.get("capability_packages") or []:
            linked.update(package_names.get(str(package_id), []))
        for name in engine.get("required_capabilities") or []:
            if str(name).strip():
                linked.add(str(name).strip())
        for name in linked:
            record = by_name.setdefault(name, {"capability_id": None, "packages": [], "engines": []})
            if engine_id and engine_id not in record["engines"]:
                record["engines"].append(engine_id)
    for record in by_name.values():
        record["packages"].sort()
        record["engines"].sort()
    return {"by_name": by_name, "names": set(by_name)}


def _public_name(index: dict[str, Any], name: str) -> dict[str, Any]:
    record = index["by_name"][name]
    return {"name": name, "capability_id": record["capability_id"]}


def _limit(limit: int) -> int:
    try:
        value = int(limit)
    except (TypeError, ValueError):
        value = 20
    return min(max(value, 1), 50)


def _denied(protocol: str, name: str, code: str) -> dict[str, Any]:
    return {
        "ok": False,
        "protocol": protocol,
        "status": "DENIED",
        "name": name,
        "code": code,
        "promotion_authorized": False,
    }
