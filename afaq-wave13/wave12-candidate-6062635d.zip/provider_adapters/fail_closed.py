"""Fail-closed external provider adapters for Saudi SaaS / AFAQ-GIE.

Network I/O is disabled unless a provider is explicitly verified AND its
allowlist entry enables network execution. Secrets are read only from the
named environment variable and are never returned.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Mapping

from current_authority.resolver import AuthorityRequest, resolve
from web_acquisition.fetch import AcquisitionBlocked, validate_public_url
from web_acquisition.compliance import (
    ComplianceDecision,
    ProcessingProfile,
    evaluate_external_execution,
)

REPO = Path(__file__).resolve().parents[1]
ALLOWLIST_PATH = REPO / "provider_adapters" / "ALLOWLIST.json"
RUNTIME_REGISTRY_PATH = REPO / "provider_adapters" / "RUNTIME_REGISTRY.json"
_MAX_RESPONSE_BYTES = 4_000_000


def _load_allowlist() -> dict[str, Any]:
    if not ALLOWLIST_PATH.exists():
        return {"providers": {}}
    try:
        return json.loads(ALLOWLIST_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {"providers": {}}


def _load_runtime_registry() -> dict[str, Any]:
    if not RUNTIME_REGISTRY_PATH.exists():
        return {"providers": {}}
    try:
        return json.loads(RUNTIME_REGISTRY_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {"providers": {}}


def _provider_runtime_entry(provider_id: str) -> dict[str, Any] | None:
    providers = _load_runtime_registry().get("providers") or {}
    if not isinstance(providers, Mapping):
        return None
    entry = providers.get(provider_id)
    return dict(entry) if isinstance(entry, Mapping) else None


def _effective_runtime_config(
    trust_entry: Mapping[str, Any],
    runtime_entry: Mapping[str, Any],
) -> dict[str, Any]:
    """Runtime config cannot override trust/credential boundary settings."""
    merged = dict(runtime_entry)
    for name in ("env_api_key", "auth_scheme", "api_key_header"):
        if name in trust_entry:
            merged[name] = trust_entry[name]
    merged["allow_private_networks"] = bool(
        trust_entry.get("allow_private_networks", False)
    )
    return merged


def provider_readiness(provider_id: str | None = None) -> dict[str, Any]:
    allow = _load_allowlist().get("providers") or {}
    runtime = _load_runtime_registry().get("providers") or {}
    allow = allow if isinstance(allow, Mapping) else {}
    runtime = runtime if isinstance(runtime, Mapping) else {}

    ids = (
        {provider_id}
        if provider_id
        else set(str(key) for key in allow).union(str(key) for key in runtime)
    )
    providers: dict[str, Any] = {}
    for pid in sorted(ids):
        trust = allow.get(pid)
        run = runtime.get(pid)
        trust = dict(trust) if isinstance(trust, Mapping) else None
        run = dict(run) if isinstance(run, Mapping) else None

        verified = bool(trust and trust.get("verified"))
        registered = run is not None
        network_enabled = bool(run and run.get("network_enabled"))
        credential_required = bool(trust and trust.get("env_api_key"))
        credential_present = bool(
            trust
            and trust.get("env_api_key")
            and os.environ.get(str(trust.get("env_api_key")))
        )
        adapter_kind = str((run or {}).get("adapter_kind") or "http_json")
        operations = (run or {}).get("operations")
        operation_names = (
            sorted(str(name) for name in operations)
            if isinstance(operations, Mapping)
            else []
        )
        trusted_operations = (
            sorted(
                str(name)
                for name in (trust.get("allowed_operations") or ())
                if str(name).strip()
            )
            if trust
            else []
        )
        untrusted_runtime_operations = sorted(
            set(operation_names) - set(trusted_operations)
        )

        blockers: list[str] = []
        if trust is None:
            blockers.append("PROVIDER_NOT_ALLOWLISTED")
        elif not verified:
            blockers.append("PROVIDER_NOT_VERIFIED")
        if not registered:
            blockers.append("PROVIDER_RUNTIME_NOT_REGISTERED")
        elif not network_enabled:
            blockers.append("PROVIDER_NETWORK_DISABLED")
        if registered and adapter_kind != "http_json":
            blockers.append("PROVIDER_ADAPTER_KIND_UNSUPPORTED")
        if registered and network_enabled and credential_required and not credential_present:
            blockers.append("PROVIDER_CREDENTIAL_MISSING")
        if verified and not trusted_operations:
            blockers.append("PROVIDER_TRUST_OPERATIONS_NOT_DECLARED")
        if registered and network_enabled and not operation_names:
            blockers.append("PROVIDER_OPERATIONS_NOT_REGISTERED")
        if untrusted_runtime_operations:
            blockers.append("PROVIDER_RUNTIME_HAS_UNTRUSTED_OPERATIONS")
        if registered and network_enabled:
            base_url = str((run or {}).get("base_url") or "").strip()
            if not base_url:
                blockers.append("PROVIDER_ENDPOINT_NOT_CONFIGURED")
            if isinstance(operations, Mapping):
                for operation_name, operation_spec in operations.items():
                    if not isinstance(operation_spec, Mapping):
                        blockers.append(
                            f"PROVIDER_OPERATION_CONFIG_INVALID:{operation_name}"
                        )
                        continue
                    method = str(operation_spec.get("method") or "POST").upper()
                    path = str(operation_spec.get("path") or "").strip()
                    if method not in {"GET", "POST", "PUT", "PATCH", "DELETE"} or not path:
                        blockers.append(
                            f"PROVIDER_OPERATION_CONFIG_INVALID:{operation_name}"
                        )

        providers[pid] = {
            "provider_id": pid,
            "allowlisted": trust is not None,
            "verified": verified,
            "runtime_registered": registered,
            "network_enabled": network_enabled,
            "adapter_kind": adapter_kind if registered else None,
            "operations": operation_names,
            "trusted_operations": trusted_operations,
            "credential_required": credential_required,
            "credential_present": credential_present,
            "ready_for_network": not blockers,
            "blockers": blockers,
        }

    return {
        "schema": "afaq.provider-readiness/v1",
        "providers": providers,
    }



def _compliance_gate(
    provider_id: str,
    payload: dict[str, Any],
) -> dict[str, Any]:
    raw_profile = payload.pop("_processing_profile", None)
    raw_decision = payload.pop("_compliance_decision", None)
    if not isinstance(raw_profile, Mapping):
        return {
            "allowed": False,
            "state": "REVIEW_REQUIRED",
            "reason": "PROCESSING_PROFILE_REQUIRED_BEFORE_EXTERNAL_PROVIDER",
            "required_controls": [],
            "evidence_refs": [],
        }

    profile = ProcessingProfile(
        personal_data=bool(raw_profile.get("personal_data")),
        sensitive_data=bool(raw_profile.get("sensitive_data")),
        data_categories=tuple(str(x) for x in (raw_profile.get("data_categories") or ())),
        data_subject_jurisdictions=tuple(str(x) for x in (raw_profile.get("data_subject_jurisdictions") or ())),
        origin_jurisdictions=tuple(str(x) for x in (raw_profile.get("origin_jurisdictions") or ())),
        destination_jurisdictions=tuple(str(x) for x in (raw_profile.get("destination_jurisdictions") or ())),
        purposes=tuple(str(x) for x in (raw_profile.get("purposes") or ())),
        automated_decision=bool(raw_profile.get("automated_decision")),
        continuous_monitoring=bool(raw_profile.get("continuous_monitoring")),
        emerging_technology=bool(raw_profile.get("emerging_technology")),
        cross_border_paths=tuple(str(x) for x in (raw_profile.get("cross_border_paths") or ())),
    )
    decision = None
    if isinstance(raw_decision, Mapping):
        decision = ComplianceDecision(
            decision_id=str(raw_decision.get("decision_id") or ""),
            state=str(raw_decision.get("state") or "REVIEW_REQUIRED"),
            policy_versions=tuple(str(x) for x in (raw_decision.get("policy_versions") or ())),
            provider_id=str(raw_decision["provider_id"]) if raw_decision.get("provider_id") else None,
            transfer_legal_path=str(raw_decision["transfer_legal_path"]) if raw_decision.get("transfer_legal_path") else None,
            protection_level_assessment_ref=str(raw_decision["protection_level_assessment_ref"]) if raw_decision.get("protection_level_assessment_ref") else None,
            transfer_risk_assessment_ref=str(raw_decision["transfer_risk_assessment_ref"]) if raw_decision.get("transfer_risk_assessment_ref") else None,
            required_controls=tuple(str(x) for x in (raw_decision.get("required_controls") or ())),
            evidence_refs=tuple(str(x) for x in (raw_decision.get("evidence_refs") or ())),
            limitations=tuple(str(x) for x in (raw_decision.get("limitations") or ())),
            metadata=dict(raw_decision.get("metadata") or {}),
        )
    return evaluate_external_execution(
        profile,
        decision,
        provider_id=provider_id,
    ).as_dict()

def _operation_spec(entry: Mapping[str, Any], operation: str) -> dict[str, Any] | None:
    operations = entry.get("operations")
    if not isinstance(operations, Mapping):
        return None
    spec = operations.get(operation)
    return dict(spec) if isinstance(spec, Mapping) else None


def _authorization_header(entry: Mapping[str, Any], env_key: str | None) -> tuple[str, str] | None:
    if not env_key:
        return None
    secret = os.environ.get(env_key)
    if not secret:
        return None
    auth_scheme = str(entry.get("auth_scheme") or "bearer").lower()
    if auth_scheme == "bearer":
        return ("Authorization", f"Bearer {secret}")
    if auth_scheme == "api_key_header":
        header = str(entry.get("api_key_header") or "X-API-Key")
        return (header, secret)
    return None


def _invoke_http_json(
    provider_id: str,
    operation: str,
    entry: Mapping[str, Any],
    payload: Mapping[str, Any],
) -> dict[str, Any]:
    spec = _operation_spec(entry, operation)
    if spec is None:
        return {
            "ok": False,
            "status": "BLOCKED",
            "reason": "PROVIDER_OPERATION_NOT_ALLOWLISTED",
            "provider_id": provider_id,
            "operation": operation,
        }

    base_url = str(entry.get("base_url") or "").rstrip("/")
    path = str(spec.get("path") or "")
    if not base_url or not path:
        return {
            "ok": False,
            "status": "BLOCKED",
            "reason": "PROVIDER_ENDPOINT_NOT_CONFIGURED",
            "provider_id": provider_id,
            "operation": operation,
        }

    url = urllib.parse.urljoin(base_url + "/", path.lstrip("/"))
    try:
        url = validate_public_url(
            url,
            allow_private_networks=bool(entry.get("allow_private_networks", False)),
        )
    except AcquisitionBlocked as exc:
        return {
            "ok": False,
            "status": "BLOCKED",
            "reason": "PROVIDER_ENDPOINT_BLOCKED",
            "blocked_reason": str(exc),
            "provider_id": provider_id,
            "operation": operation,
        }

    method = str(spec.get("method") or "POST").upper()
    if method not in {"GET", "POST", "PUT", "PATCH", "DELETE"}:
        return {
            "ok": False,
            "status": "BLOCKED",
            "reason": "PROVIDER_METHOD_NOT_ALLOWED",
            "provider_id": provider_id,
            "operation": operation,
        }

    timeout = float(spec.get("timeout_seconds") or entry.get("timeout_seconds") or 30.0)
    timeout = max(1.0, min(timeout, 60.0))
    max_bytes = int(spec.get("max_response_bytes") or _MAX_RESPONSE_BYTES)
    max_bytes = max(1, min(max_bytes, _MAX_RESPONSE_BYTES))

    headers = {
        "Accept": "application/json",
        "User-Agent": "AFAQ-GIE-ProviderAdapter/1.0",
    }
    body: bytes | None = None
    if method in {"POST", "PUT", "PATCH", "DELETE"}:
        body = json.dumps(dict(payload), ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        headers["Content-Type"] = "application/json"

    env_key = str(entry.get("env_api_key") or "") or None
    auth_header = _authorization_header(entry, env_key)
    if env_key and auth_header is None:
        return {
            "ok": False,
            "status": "BLOCKED",
            "reason": "PROVIDER_CREDENTIAL_MISSING_OR_UNSUPPORTED_SCHEME",
            "provider_id": provider_id,
            "operation": operation,
            "credential_required": True,
        }
    if auth_header:
        headers[auth_header[0]] = auth_header[1]

    started = time.perf_counter()
    request = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read(max_bytes + 1)
            truncated = len(raw) > max_bytes
            if truncated:
                raw = raw[:max_bytes]
            content_hash = hashlib.sha256(raw).hexdigest()
            content_type = response.headers.get_content_type()
            parsed: Any
            if "json" in content_type:
                try:
                    parsed = json.loads(raw.decode("utf-8"))
                except (UnicodeDecodeError, json.JSONDecodeError):
                    parsed = None
            else:
                parsed = None
            return {
                "ok": 200 <= int(response.status) < 300,
                "status": "EXECUTED",
                "reason": "PROVIDER_HTTP_EXECUTED",
                "provider_id": provider_id,
                "operation": operation,
                "http_status": int(response.status),
                "elapsed_ms": round((time.perf_counter() - started) * 1000, 3),
                "response_content_type": content_type,
                "response_bytes": len(raw),
                "response_sha256": content_hash,
                "response_truncated": truncated,
                "result": parsed,
                "network_invoked": True,
                "credential_value_exposed": False,
            }
    except urllib.error.HTTPError as exc:
        raw = exc.read(max_bytes) if hasattr(exc, "read") else b""
        return {
            "ok": False,
            "status": "FAILED",
            "reason": f"PROVIDER_HTTP_{int(exc.code)}",
            "provider_id": provider_id,
            "operation": operation,
            "http_status": int(exc.code),
            "elapsed_ms": round((time.perf_counter() - started) * 1000, 3),
            "response_sha256": hashlib.sha256(raw).hexdigest() if raw else None,
            "network_invoked": True,
            "credential_value_exposed": False,
        }
    except (urllib.error.URLError, TimeoutError) as exc:
        return {
            "ok": False,
            "status": "FAILED",
            "reason": "PROVIDER_NETWORK_FAILURE",
            "provider_id": provider_id,
            "operation": operation,
            "error_class": type(exc).__name__,
            "elapsed_ms": round((time.perf_counter() - started) * 1000, 3),
            "network_invoked": True,
            "credential_value_exposed": False,
        }


def invoke_provider(
    provider_id: str,
    *,
    operation: str,
    payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Invoke a provider only when verification, authority and network gates pass."""
    payload = dict(payload or {})
    auth = resolve(AuthorityRequest(action="execute_tool", path=f"provider:{provider_id}"))
    if auth.outcome != "ALLOW":
        return {
            "ok": False,
            "status": "BLOCKED",
            "reason": f"AUTHORITY_{auth.outcome}",
            "authority_reason": auth.reason,
            "provider_id": provider_id,
            "operation": operation,
        }

    allow = _load_allowlist().get("providers") or {}
    entry = allow.get(provider_id) if isinstance(allow, dict) else None
    if not isinstance(entry, dict) or not entry.get("verified"):
        return {
            "ok": False,
            "status": "BLOCKED",
            "reason": "PROVIDER_ADAPTER_UNVERIFIED",
            "provider_id": provider_id,
            "operation": operation,
            "hint": "Set verified=true only after owner verification and evidence review.",
        }

    trusted_operations = {
        str(name)
        for name in (entry.get("allowed_operations") or ())
        if str(name).strip()
    }
    if operation not in trusted_operations:
        return {
            "ok": False,
            "status": "BLOCKED",
            "reason": "PROVIDER_OPERATION_NOT_TRUSTED",
            "provider_id": provider_id,
            "operation": operation,
            "network_invoked": False,
        }

    runtime_entry = _provider_runtime_entry(provider_id)
    if runtime_entry is None:
        return {
            "ok": False,
            "status": "BLOCKED",
            "reason": "PROVIDER_RUNTIME_NOT_REGISTERED",
            "provider_id": provider_id,
            "operation": operation,
            "network_invoked": False,
        }

    entry = _effective_runtime_config(entry, runtime_entry)

    if not bool(entry.get("network_enabled", False)):
        return {
            "ok": True,
            "status": "READY_NOT_INVOKED",
            "reason": "PROVIDER_VERIFIED_NETWORK_DISABLED",
            "provider_id": provider_id,
            "operation": operation,
            "network_invoked": False,
            "payload_keys": sorted(payload.keys()),
        }

    env_key = str(entry.get("env_api_key") or "") or None
    if env_key and not os.environ.get(env_key):
        return {
            "ok": False,
            "status": "BLOCKED",
            "reason": "PROVIDER_CREDENTIAL_MISSING",
            "provider_id": provider_id,
            "operation": operation,
            "credential_required": True,
            "network_invoked": False,
        }

    compliance = _compliance_gate(provider_id, payload)
    if not compliance.get("allowed"):
        return {
            "ok": False,
            "status": "BLOCKED",
            "reason": str(compliance.get("reason") or "COMPLIANCE_BLOCK"),
            "provider_id": provider_id,
            "operation": operation,
            "compliance": compliance,
            "network_invoked": False,
        }

    adapter_kind = str(entry.get("adapter_kind") or "http_json")
    if adapter_kind != "http_json":
        return {
            "ok": False,
            "status": "BLOCKED",
            "reason": "PROVIDER_ADAPTER_KIND_UNSUPPORTED",
            "provider_id": provider_id,
            "operation": operation,
        }

    return _invoke_http_json(provider_id, operation, entry, payload)
