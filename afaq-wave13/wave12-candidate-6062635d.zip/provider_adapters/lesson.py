"""Lesson kept from one task record.

The lesson records the owner's outcome. It does not change the model,
and it does not authorize activation.
"""

from __future__ import annotations

from typing import Any, Mapping

from provider_adapters.evidence_receipt import EvidenceReceiptError

RECORDED = frozenset({"ELIGIBLE_NOT_ACTIVATED", "NOT_ELIGIBLE"})


RECORDED_ELIGIBILITY = frozenset({
    "ELIGIBLE_NOT_ACTIVATED",
    "NOT_ELIGIBLE",
    "مؤهلة بلا تفعيل",
    "غير مؤهلة",
})


def _saved_at(record: Mapping[str, Any]) -> str:
    return str(record.get("savedAt") or record.get("saved_at") or "")


def _is_blocked(record: Mapping[str, Any]) -> bool:
    return (
        record.get("model_changed") is True
        or record.get("activation_authorized") is True
        or record.get("production_changed") is True
        or record.get("promotion_authorized") is True
    )


def select_recorded_lesson(records: Mapping[str, Any] | list[Any] | None) -> dict[str, Any]:
    if records is None:
        return present_lesson(None)
    if isinstance(records, Mapping):
        rows = [row for row in records.values() if isinstance(row, Mapping)]
    elif isinstance(records, list):
        rows = [row for row in records if isinstance(row, Mapping)]
    else:
        raise EvidenceReceiptError("lesson records must be a list or object")
    rows.sort(key=_saved_at, reverse=True)
    recorded = [
        row for row in rows
        if not _is_blocked(row) and str(row.get("eligibility") or "") in RECORDED_ELIGIBILITY
    ]
    if recorded:
        return present_lesson(recorded[0])
    waiting = [row for row in rows if not _is_blocked(row)]
    if waiting:
        view = present_lesson(waiting[0])
        view["status"] = "WAITING"
        return view
    if rows:
        view = present_lesson(None)
        view["ok"] = False
        view["status"] = "BLOCKED"
        return view
    return present_lesson(None)


def present_lesson(record: Mapping[str, Any] | None) -> dict[str, Any]:
    view = {
        "ok": True,
        "schema": "AFAQ_LESSON_VIEW_V1",
        "status": "EMPTY",
        "task_id": "",
        "subject": "",
        "provider_id": "",
        "model_id": "",
        "eligibility": "",
        "learning": "",
        "model_changed": False,
        "activation_authorized": False,
        "promotion_authorized": False,
        "production_changed": False,
        "privacy_class": "LOCAL_ONLY",
    }
    if record is None:
        return view
    if not isinstance(record, Mapping):
        raise EvidenceReceiptError("lesson record must be an object")
    if (
        record.get("model_changed") is True
        or record.get("activation_authorized") is True
        or record.get("production_changed") is True
        or record.get("promotion_authorized") is True
    ):
        view["ok"] = False
        view["status"] = "BLOCKED"
        return view
    view["status"] = "SHOWN"
    view["task_id"] = str(record.get("task_id") or record.get("taskId") or "")
    view["subject"] = str(record.get("subject") or "")
    view["provider_id"] = str(record.get("provider_id") or record.get("provider") or "")
    view["model_id"] = str(record.get("model_id") or record.get("model") or "")
    view["eligibility"] = str(record.get("eligibility") or "")
    view["learning"] = str(record.get("learning") or "")
    return view


def continue_from_lesson(
    task_record: Mapping[str, Any],
    prior: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    if not isinstance(task_record, Mapping) or task_record.get("schema") != "AFAQ_TASK_RECEIPT_V1":
        raise EvidenceReceiptError("unsupported task record")
    if task_record.get("privacy_class") != "LOCAL_ONLY":
        raise EvidenceReceiptError("continuation must stay local")
    if (
        task_record.get("activation_authorized") is not False
        or task_record.get("production_changed") is not False
        or task_record.get("promotion_authorized") is not False
    ):
        raise EvidenceReceiptError("task record must not change production")
    provider_id = str(task_record.get("provider_id") or "").strip()
    model_id = str(task_record.get("model_id") or "").strip()
    task_id = str(task_record.get("task_id") or "").strip()
    if not task_id or not provider_id or not model_id:
        raise EvidenceReceiptError("task record is incomplete")
    shown = present_lesson(prior)
    same_task = shown["task_id"] == task_id
    adopted = shown["status"] == "SHOWN" and bool(shown["task_id"]) and not same_task
    model_differs = bool(shown["model_id"]) and shown["model_id"] != model_id
    provider_differs = bool(shown["provider_id"]) and shown["provider_id"] != provider_id
    if adopted and (model_differs or provider_differs):
        adopted = False
    if shown["status"] == "BLOCKED" or (shown["status"] == "SHOWN" and not adopted and not same_task and (model_differs or provider_differs)):
        prior_status = "REFUSED"
    elif adopted:
        prior_status = "ADOPTED"
    else:
        prior_status = "NONE"
    return {
        "ok": True,
        "schema": "AFAQ_TASK_CONTINUATION_V1",
        "task_id": task_id,
        "provider_id": provider_id,
        "model_id": model_id,
        "prior_task_id": shown["task_id"] if adopted else "",
        "prior_status": prior_status,
        "model_changed": False,
        "activation_authorized": False,
        "promotion_authorized": False,
        "production_changed": False,
        "privacy_class": "LOCAL_ONLY",
    }


def record_lesson(task_record: Mapping[str, Any]) -> dict[str, Any]:
    if not isinstance(task_record, Mapping) or task_record.get("schema") != "AFAQ_TASK_RECEIPT_V1":
        raise EvidenceReceiptError("unsupported task record")
    if task_record.get("privacy_class") != "LOCAL_ONLY":
        raise EvidenceReceiptError("lesson must stay local")
    if task_record.get("activation_authorized") is not False or task_record.get("production_changed") is not False:
        raise EvidenceReceiptError("task record must not change production")
    if task_record.get("promotion_authorized") is not False:
        raise EvidenceReceiptError("task record must not change production")
    provider_id = str(task_record.get("provider_id") or "").strip()
    model_id = str(task_record.get("model_id") or "").strip()
    task_id = str(task_record.get("task_id") or "").strip()
    if not task_id or not provider_id or not model_id:
        raise EvidenceReceiptError("task record is incomplete")
    eligibility = str(task_record.get("eligibility") or "")
    if eligibility in RECORDED:
        status = "RECORDED"
    elif eligibility == "INCOMPLETE":
        status = "WAITING"
    else:
        raise EvidenceReceiptError("unknown eligibility")
    return {
        "ok": True,
        "schema": "AFAQ_LESSON_V1",
        "task_id": task_id,
        "subject": str(task_record.get("subject") or ""),
        "provider_id": provider_id,
        "model_id": model_id,
        "eligibility": eligibility,
        "status": status,
        "model_changed": False,
        "activation_authorized": False,
        "promotion_authorized": False,
        "production_changed": False,
        "privacy_class": "LOCAL_ONLY",
    }


OWNER_DECISIONS = {
    "approved": ("مؤهلة بلا تفعيل", "قرار موافقة"),
    "rejected": ("غير مؤهلة", "قرار رفض"),
}


def _sample_score(record: Mapping[str, Any]) -> str:
    score = str(record.get("score") or "").strip()
    left, slash, right = score.partition("/")
    if slash and left.isdigit() and right.isdigit():
        return score
    return ""


def apply_owner_decision(record: Mapping[str, Any], decision: str) -> dict[str, Any]:
    if not isinstance(record, Mapping):
        raise EvidenceReceiptError("lesson record must be an object")
    if _is_blocked(record):
        raise EvidenceReceiptError("task record must not change production")
    choice = str(decision or "").strip()
    if choice not in OWNER_DECISIONS:
        raise EvidenceReceiptError("unknown owner decision")
    task_id = str(record.get("task_id") or record.get("taskId") or "").strip()
    provider_id = str(record.get("provider_id") or record.get("provider") or "").strip()
    model_id = str(record.get("model_id") or record.get("model") or "").strip()
    if not task_id or not provider_id or not model_id:
        raise EvidenceReceiptError("task record is incomplete")
    eligibility, training = OWNER_DECISIONS[choice]
    score = _sample_score(record)
    if score:
        training = f"{training} · النتيجة {score}"
    return {
        "ok": True,
        "schema": "AFAQ_OWNER_DECISION_V1",
        "task_id": task_id,
        "subject": str(record.get("subject") or ""),
        "provider_id": provider_id,
        "model_id": model_id,
        "eligibility": eligibility,
        "training": training,
        "score": score,
        "learning": "التعلم مسجّل · الموديل لم يتغير",
        "prior_task_id": str(record.get("prior_task_id") or ""),
        "prior_status": str(record.get("prior_status") or "NONE"),
        "model_changed": False,
        "activation_authorized": False,
        "promotion_authorized": False,
        "production_changed": False,
        "privacy_class": "LOCAL_ONLY",
    }
