"""Eligibility check for one local evidence receipt.

Approval records eligibility. It does not authorize activation, and the
production composition stays unchanged.
"""

from __future__ import annotations

from typing import Any, Mapping

from provider_adapters.evidence_receipt import EvidenceReceiptError, require_local_receipt


def verify_eligibility(receipt: Mapping[str, Any]) -> dict[str, Any]:
    current = require_local_receipt(receipt)
    route = current.get("route")
    if not isinstance(route, Mapping) or route.get("privacy_class") != "LOCAL_ONLY":
        raise EvidenceReceiptError("route must stay local")
    provider_id = str(route.get("provider_id") or "").strip()
    model_id = str(route.get("model_id") or "").strip()
    if not provider_id or not model_id:
        raise EvidenceReceiptError("route target is missing")

    training = current["training"]
    state = str(training.get("state") or "")
    decision = training.get("owner_decision")
    if state == "APPROVED" and decision == "approved":
        status = "ELIGIBLE_NOT_ACTIVATED"
        eligible = True
    elif state == "REJECTED" and decision == "rejected":
        status = "NOT_ELIGIBLE"
        eligible = False
    elif state in {"OBSERVE", "COLLECTED", "EVALUATED", "AWAITING_OWNER"} and not decision:
        status = "INCOMPLETE"
        eligible = False
    else:
        raise EvidenceReceiptError("owner decision does not match the training state")

    return {
        "ok": True,
        "schema": "AFAQ_ELIGIBILITY_V1",
        "status": status,
        "eligible": eligible,
        "activation_authorized": False,
        "promotion_authorized": False,
        "production_changed": False,
        "privacy_class": "LOCAL_ONLY",
        "provider_id": provider_id,
        "model_id": model_id,
        "training_state": state,
        "owner_decision": decision,
    }
