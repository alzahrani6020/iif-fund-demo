"""Evidence receipt for one local task.

The receipt joins the classified task, the local provider and model, an
optional registered capability, and a training case that stays under
observation. It does not execute the capability and it does not promote
the case.
"""

from __future__ import annotations

from typing import Any, Mapping

from provider_adapters.capability_gateway import describe, invoke
from provider_adapters.selection import select_route
from provider_adapters.task_classifier import classify_task
from provider_adapters.training_cycle import start_case


class EvidenceReceiptError(ValueError):
    """The receipt cannot be composed."""


def compose_receipt(
    instruction: str,
    mode: str = "AUTO",
    capability: str = "",
    role: str = "owner",
    confirmed: bool = False,
    registry: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    subject = str(instruction or "").strip()
    if not subject:
        raise EvidenceReceiptError("instruction is required")

    classified = classify_task(subject)
    requested = str(mode or "AUTO").strip().upper() or "AUTO"
    effective = classified["mode"] if requested == "AUTO" else requested
    route = select_route(effective)
    capability_block = _capability(capability, classified, role, confirmed, registry)
    training = start_case(subject)
    capability_ready = capability_block["status"] in {"NOT_REQUESTED", "PERMITTED_NOT_EXECUTED"}
    confirmed_ready = not classified["confirmation_required"] or bool(confirmed)

    return {
        "ok": bool(route.get("ok") and capability_ready and confirmed_ready),
        "schema": "AFAQ_EVIDENCE_RECEIPT_V1",
        "subject": subject,
        "privacy_class": "LOCAL_ONLY",
        "promotion_authorized": False,
        "production_changed": False,
        "task": {
            "task": classified["task"],
            "label": classified["label"],
            "risk": classified["risk"],
            "mode": classified["mode"],
            "confirmation_required": classified["confirmation_required"],
        },
        "route": {
            "mode": route["mode"],
            "provider_id": route["provider_id"],
            "model_id": route["model_id"],
            "privacy_class": "LOCAL_ONLY",
            "reason": route["reason"],
        },
        "capability": capability_block,
        "engine_id": capability_block["engine_id"],
        "training": {
            "state": training["state"],
            "samples": [],
            "score": None,
            "owner_decision": None,
            "production_changed": False,
        },
    }


def _capability(
    name: str,
    classified: Mapping[str, Any],
    role: str,
    confirmed: bool,
    registry: Mapping[str, Any] | None,
) -> dict[str, Any]:
    key = str(name or "").strip()
    if not key:
        return {
            "status": "NOT_REQUESTED",
            "name": "",
            "code": "",
            "capability_id": "",
            "engine_id": "",
            "engines": [],
            "execution": "",
        }
    described = describe(key, registry)
    if not described["ok"]:
        return {
            "status": "DENIED",
            "name": key,
            "code": described.get("code") or "UNKNOWN_CAPABILITY",
            "capability_id": "",
            "engine_id": "",
            "engines": [],
            "execution": "",
        }
    engines = [str(item) for item in (described.get("engines") or []) if str(item).strip()]
    invoked = invoke(
        key,
        role,
        risk=str(classified.get("risk") or "LOW"),
        confirmed=bool(confirmed),
        registry=registry,
    )
    return {
        "status": invoked["status"],
        "name": described["name"],
        "code": invoked.get("code") or "",
        "capability_id": described.get("capability_id") or "",
        "engine_id": engines[0] if engines else "",
        "engines": engines,
        "execution": invoked.get("execution") or "",
    }


def require_local_receipt(receipt: Mapping[str, Any]) -> dict[str, Any]:
    if not isinstance(receipt, Mapping) or receipt.get("schema") != "AFAQ_EVIDENCE_RECEIPT_V1":
        raise EvidenceReceiptError("unsupported evidence receipt")
    if receipt.get("privacy_class") != "LOCAL_ONLY":
        raise EvidenceReceiptError("receipt must stay local")
    if receipt.get("promotion_authorized") is not False or receipt.get("production_changed") is not False:
        raise EvidenceReceiptError("receipt must not change production")
    training = receipt.get("training")
    if not isinstance(training, Mapping) or training.get("production_changed") is not False:
        raise EvidenceReceiptError("training record must not change production")
    state = str(training.get("state") or "")
    if state in {"SHADOW", "CANARY", "PRODUCTION"}:
        raise EvidenceReceiptError("forbidden training state")
    return dict(receipt)
