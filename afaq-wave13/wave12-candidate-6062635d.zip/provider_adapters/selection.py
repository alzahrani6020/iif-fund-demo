"""Selection contract for the local provider.

Modes choose among enabled catalog routes. A route is eligible only when
its provider and model stay on this machine. External providers are never
selected, and nothing in this module promotes a component into production.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping

REPO = Path(__file__).resolve().parents[1]
CATALOG_PATH = REPO / "saudi_saas" / "owner_console" / "modules" / "selection_catalog.json"

SELECTION_MODES = (
    "AUTO",
    "FAST",
    "REASONING",
    "FINANCIAL",
    "DOCUMENT",
    "CODING",
    "PRIVATE_LOCAL",
    "LOW_COST",
    "HIGH_ACCURACY",
)


class SelectionError(ValueError):
    """The requested mode cannot be resolved on an eligible local route."""


def load_catalog(path: Path | None = None) -> dict[str, Any]:
    catalog_path = path or CATALOG_PATH
    data = json.loads(catalog_path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise SelectionError("selection catalog must be an object")
    if data.get("schema") != "AFAQ_SELECTION_CATALOG_V1":
        raise SelectionError("unsupported selection catalog")
    return data


def select_route(mode: str, catalog: Mapping[str, Any] | None = None) -> dict[str, Any]:
    source = dict(catalog) if catalog is not None else load_catalog()
    selected = str(mode or "").strip().upper()
    if selected not in SELECTION_MODES:
        raise SelectionError("unknown selection mode")

    routes = source.get("routes") or {}
    providers = source.get("providers") or []
    models = source.get("models") or []
    if not isinstance(routes, Mapping) or not isinstance(providers, list) or not isinstance(models, list):
        raise SelectionError("selection catalog is incomplete")

    route = routes.get(selected)
    if not isinstance(route, Mapping):
        raise SelectionError("mode has no route")

    provider = _match(providers, "provider_id", route.get("provider_id"))
    model = _match(models, "model_id", route.get("model_id"))
    if provider is None or model is None:
        raise SelectionError("route target is not registered")
    if not provider.get("enabled") or not model.get("enabled"):
        raise SelectionError("route is disabled")
    if provider.get("placement") != "local" or provider.get("privacy_class") != "LOCAL_ONLY":
        raise SelectionError("external provider is not eligible")
    if model.get("provider_id") != provider.get("provider_id") or model.get("privacy_class") != "LOCAL_ONLY":
        raise SelectionError("model is not local to the selected provider")

    return {
        "ok": True,
        "mode": selected,
        "provider_id": provider["provider_id"],
        "model_id": model["model_id"],
        "privacy_class": "LOCAL_ONLY",
        "endpoint": provider.get("endpoint") or "",
        "promotion_authorized": False,
        "reason": str(route.get("reason") or "local provider is the only eligible route"),
    }


def _match(rows: list[Any], key: str, value: Any) -> Mapping[str, Any] | None:
    for row in rows:
        if isinstance(row, Mapping) and row.get(key) == value:
            return row
    return None
