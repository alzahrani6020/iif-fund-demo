"""Bind one local evidence receipt to an existing task id.

The record stays with the task. Approval can mark eligibility, and
activation stays unauthorized.
"""

from __future__ import annotations

from typing import Any, Mapping

from provider_adapters.eligibility import verify_eligibility
from provider_adapters.evidence_receipt import EvidenceReceiptError


def attach_task_record(task_id: str, receipt: Mapping[str, Any]) -> dict[str, Any]:
    key = str(task_id or "").strip()
    if not key:
        raise EvidenceReceiptError("task id is required")
    eligibility = verify_eligibility(receipt)
    return {
        "ok": True,
        "schema": "AFAQ_TASK_RECEIPT_V1",
        "task_id": key,
        "subject": str(receipt.get("subject") or ""),
        "provider_id": eligibility["provider_id"],
        "model_id": eligibility["model_id"],
        "training_state": eligibility["training_state"],
        "eligibility": eligibility["status"],
        "eligible": eligibility["eligible"],
        "activation_authorized": False,
        "promotion_authorized": False,
        "production_changed": False,
        "privacy_class": "LOCAL_ONLY",
    }
