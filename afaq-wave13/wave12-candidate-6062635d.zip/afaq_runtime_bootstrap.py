"""AFAQ runtime composition root.

This outer module composes the concrete live-engine fabric with the protected
Agent Runtime through the dependency-inversion capability port.
"""

from __future__ import annotations

# Importing engines_live performs the explicit one-way capability binding.
import engines_live  # noqa: F401

from afaq_agent_runtime.runtime_server import main as runtime_main


def main() -> int:
    return runtime_main()


if __name__ == "__main__":
    raise SystemExit(main())
