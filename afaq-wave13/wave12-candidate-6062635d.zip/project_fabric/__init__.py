"""Project identity and enrollment contracts for AFAQ project fabric.

Pure contracts only: no persistence, runtime attachment, authority, mutation,
or project filesystem writes.
"""

from .contracts import (
    ENROLLMENT_SCHEMA_V1,
    IDENTITY_SCHEMA_V1,
    EnrollmentState,
    ProjectIdentity,
    ProjectOrigin,
    ProjectEnrollment,
)

__all__ = [
    "ENROLLMENT_SCHEMA_V1",
    "IDENTITY_SCHEMA_V1",
    "EnrollmentState",
    "ProjectEnrollment",
    "ProjectIdentity",
    "ProjectOrigin",
]
