"""Pure project identity and enrollment contracts.

These contracts deliberately grant no runtime, policy, promotion, deployment,
or mutation authority. They define durable identity/enrollment facts only.

Key invariants:
- AFAQ-created projects must not be represented as ENROLLED without evidence.
- UNKNOWN is never silently converted to success.
- identity conflicts are explicit first-class states.
- source identity is represented by references/fingerprints, not copied payloads.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import Enum
from typing import Any


IDENTITY_SCHEMA_V1 = "AFAQ_PROJECT_IDENTITY_V1"
ENROLLMENT_SCHEMA_V1 = "AFAQ_PROJECT_ENROLLMENT_V1"


class ProjectOrigin(str, Enum):
    AFAQ_CREATED = "AFAQ_CREATED"
    IMPORTED = "IMPORTED"
    EXTERNAL = "EXTERNAL"


class EnrollmentState(str, Enum):
    ENROLLED = "ENROLLED"
    IDENTITY_CONFLICT = "IDENTITY_CONFLICT"
    ENROLLMENT_FAILED = "ENROLLMENT_FAILED"


def _require_text(value: str, field: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field} must be a non-empty string")


def _validate_refs(values: tuple[str, ...], field: str) -> None:
    if not isinstance(values, tuple):
        raise TypeError(f"{field} must be tuple[str, ...]")
    seen: set[str] = set()
    for value in values:
        _require_text(value, field)
        if value in seen:
            raise ValueError(f"{field} contains duplicate references")
        seen.add(value)


@dataclass(frozen=True)
class ProjectIdentity:
    """Durable logical identity for an AFAQ-managed project.

    ``source_fingerprint`` identifies the bound source/workspace lineage without
    embedding source content. It is evidence input, not mutation authority.
    """

    project_id: str
    tenant_id: str
    origin: ProjectOrigin
    source_fingerprint: str
    created_at: str
    schema_version: str = IDENTITY_SCHEMA_V1

    def __post_init__(self) -> None:
        if self.schema_version != IDENTITY_SCHEMA_V1:
            raise ValueError("unsupported ProjectIdentity schema")
        for field, value in (
            ("project_id", self.project_id),
            ("tenant_id", self.tenant_id),
            ("source_fingerprint", self.source_fingerprint),
            ("created_at", self.created_at),
        ):
            _require_text(value, field)
        if not isinstance(self.origin, ProjectOrigin):
            raise TypeError("origin must be ProjectOrigin")

    def as_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["origin"] = self.origin.value
        return data


@dataclass(frozen=True)
class ProjectEnrollment:
    """Reference-only enrollment fact.

    ENROLLED means identity binding was evidenced. It does not mean runtime
    capability activation, authorization, certification, or production
    admission.
    """

    enrollment_id: str
    identity_ref: str
    project_id: str
    tenant_id: str
    source_ref: str
    source_fingerprint: str
    state: EnrollmentState
    reason_codes: tuple[str, ...]
    evidence_refs: tuple[str, ...]
    recorded_at: str
    schema_version: str = ENROLLMENT_SCHEMA_V1

    def __post_init__(self) -> None:
        if self.schema_version != ENROLLMENT_SCHEMA_V1:
            raise ValueError("unsupported ProjectEnrollment schema")
        for field, value in (
            ("enrollment_id", self.enrollment_id),
            ("identity_ref", self.identity_ref),
            ("project_id", self.project_id),
            ("tenant_id", self.tenant_id),
            ("source_ref", self.source_ref),
            ("source_fingerprint", self.source_fingerprint),
            ("recorded_at", self.recorded_at),
        ):
            _require_text(value, field)
        if not isinstance(self.state, EnrollmentState):
            raise TypeError("state must be EnrollmentState")
        _validate_refs(self.reason_codes, "reason_codes")
        _validate_refs(self.evidence_refs, "evidence_refs")
        if not self.reason_codes:
            raise ValueError("reason_codes must not be empty")
        if self.state is EnrollmentState.ENROLLED and not self.evidence_refs:
            raise ValueError("ENROLLED requires explicit evidence_refs")
        if self.state is EnrollmentState.IDENTITY_CONFLICT:
            if len(self.evidence_refs) < 2:
                raise ValueError(
                    "IDENTITY_CONFLICT requires at least two evidence_refs"
                )
        if self.state is EnrollmentState.ENROLLMENT_FAILED:
            if not any(code.startswith("ENROLLMENT_") for code in self.reason_codes):
                raise ValueError(
                    "ENROLLMENT_FAILED requires an ENROLLMENT_* reason code"
                )

    def as_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["state"] = self.state.value
        data["reason_codes"] = list(self.reason_codes)
        data["evidence_refs"] = list(self.evidence_refs)
        return data
