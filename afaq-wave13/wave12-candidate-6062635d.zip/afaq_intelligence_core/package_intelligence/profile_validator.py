"""Validate a normalized package profile against the frozen contract.

Validation is fail-closed: required sections must be present, the contract's
structural rules are enforced, and missing/UNKNOWN values are reported but
not silently coerced.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .models import UNKNOWN, ValidationReport


class ProfileValidationError(RuntimeError):
    pass


class PackageProfileValidator:
    """Validate a normalized profile against PACKAGE_PROFILE_CONTRACT.json."""

    def __init__(self, contract_path: Path | None = None) -> None:
        self.contract_path = contract_path or self._default_contract_path()
        self._contract = self._load_contract()
        self._lifecycle_path = self.contract_path.with_name(
            "LIFECYCLE_STATE_MATURITY_MODELS.json"
        )
        self._authority_levels = self._load_authority_levels()

    @staticmethod
    def _default_contract_path() -> Path:
        return (
            Path(__file__).resolve().parents[2]
            / "project-records"
            / "architecture"
            / "v1"
            / "PACKAGE_PROFILE_CONTRACT.json"
        )

    def _load_contract(self) -> dict[str, Any]:
        text = self.contract_path.read_text(encoding="utf-8")
        return json.loads(text)

    def _load_lifecycle_model(self) -> dict[str, Any]:
        text = self._lifecycle_path.read_text(encoding="utf-8")
        return json.loads(text)

    def _load_authority_levels(self) -> set[str]:
        model = self._load_lifecycle_model()
        return set(model.get("authority_levels", []))

    def _validate_authority_ceiling(
        self, value: Any, report: ValidationReport
    ) -> None:
        if value == UNKNOWN:
            return
        if isinstance(value, str) and value in self._authority_levels:
            return
        report.valid = False
        report.errors.append(
            f"authority.authority_ceiling value {value!r} is not in the canonical "
            f"authority vocabulary ({self._lifecycle_path.name} authority_levels)"
        )

    def validate(self, profile: dict[str, Any]) -> ValidationReport:
        package_id = profile.get("identity", {}).get("package_id", UNKNOWN)
        report = ValidationReport(valid=True, package_id=package_id)
        required_sections = set(self._contract.get("required_sections", {}).keys())
        present_sections = set(profile.keys())

        missing_sections = required_sections - present_sections
        if missing_sections:
            report.valid = False
            for section in sorted(missing_sections):
                report.errors.append(f"missing required section: {section}")

        for section in required_sections & present_sections:
            self._validate_section(section, profile[section], report)

        # Contract rule: target state must not be reported as current state.
        state = profile.get("state", {})
        if isinstance(state, dict):
            impl = state.get("implementation_state", UNKNOWN)
            target = state.get("target_state", UNKNOWN)
            if (
                impl != UNKNOWN
                and target != UNKNOWN
                and impl == target
            ):
                report.valid = False
                report.errors.append(
                    "state.implementation_state must not equal state.target_state"
                )

        return report

    def _validate_section(
        self, section_name: str, section_value: Any, report: ValidationReport
    ) -> None:
        if not isinstance(section_value, dict):
            report.valid = False
            report.errors.append(
                f"section '{section_name}' must be a mapping, got {type(section_value).__name__}"
            )
            return

        spec = self._contract.get("required_sections", {}).get(section_name, {})
        expected_fields = set(spec.get("fields", {}).keys())
        for field in expected_fields:
            if field not in section_value:
                # Contract allows UNKNOWN for required fields when evidence is
                # genuinely unavailable; absence is recorded as a warning so
                # the report remains complete without inventing values.
                report.warnings.append(
                    f"section '{section_name}' missing field '{field}' (will be UNKNOWN)"
                )

        # Light type sanity for provided non-UNKNOWN values.
        for field, value in section_value.items():
            if value == UNKNOWN:
                continue
            if field.endswith("_state") and not isinstance(value, str):
                report.errors.append(
                    f"section '{section_name}.{field}' state must be a string"
                )
                report.valid = False

        # Canonical authority ceiling vocabulary enforcement.
        if section_name == "authority":
            ceiling = section_value.get("authority_ceiling", UNKNOWN)
            self._validate_authority_ceiling(ceiling, report)
