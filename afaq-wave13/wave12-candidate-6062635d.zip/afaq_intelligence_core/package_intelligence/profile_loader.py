"""Load and normalize package manifests into the Package Profile Contract shape.

Normalization is read-only and preserves source metadata as observed legacy
fields. It never manufactures canonical ownership, architecture, authority,
or capability facts.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .models import UNKNOWN, LoadedProfile


class PackageProfileError(RuntimeError):
    pass


class PackageNotFoundError(PackageProfileError):
    pass


class PackageProfileLoader:
    """Discover physical packages under a root directory and load manifests."""

    def __init__(self, packages_root: Path | None = None) -> None:
        self.packages_root = packages_root or self._default_packages_root()
        self._index: dict[str, Path] | None = None

    @staticmethod
    def _default_packages_root() -> Path:
        return Path(__file__).resolve().parents[2] / "owner-packages"

    def _discover(self) -> dict[str, Path]:
        if self._index is not None:
            return self._index
        index: dict[str, Path] = {}
        if self.packages_root.exists():
            for subdir in sorted(self.packages_root.iterdir()):
                manifest = subdir / "MANIFEST.json"
                if manifest.is_file():
                    try:
                        data = self._read_json(manifest)
                    except Exception:
                        continue
                    pkg_id = data.get("package_id") if isinstance(data, dict) else None
                    if not pkg_id:
                        pkg_id = subdir.name
                    index[pkg_id] = manifest
        self._index = index
        return index

    @staticmethod
    def _read_json(path: Path) -> dict[str, Any]:
        raw = path.read_bytes()
        if raw.startswith(b"\xef\xbb\xbf"):
            raw = raw[3:]
        text = raw.decode("utf-8")
        return json.loads(text)

    def load(self, package_id: str) -> LoadedProfile:
        if not package_id:
            raise PackageProfileError("package_id is required")
        index = self._discover()
        if package_id not in index:
            raise PackageNotFoundError(
                f"Physical package not found for package_id={package_id!r}"
            )
        path = index[package_id]
        source = self._read_json(path)
        if not isinstance(source, dict):
            raise PackageProfileError(
                f"Manifest at {path} is not a JSON object"
            )
        normalized = self._normalize(source)
        return LoadedProfile(
            package_id=package_id,
            source_path=str(path),
            source_metadata=source,
            normalized_profile=normalized,
        )

    @staticmethod
    def _normalize(source: dict[str, Any]) -> dict[str, Any]:
        """Map structurally equivalent observed fields to contract sections.

        All other contract fields are set to UNKNOWN or empty collections so
        the normalized profile is structurally complete without inventing
        semantic content.
        """
        impl_state = source.get("implementation_state") or source.get("status")

        return {
            "identity": {
                "package_id": source.get("package_id") or UNKNOWN,
                "package_version": source.get("version")
                or source.get("package_version")
                or UNKNOWN,
                # canonical_owner is NOT derived from architectural_owner.
                "canonical_owner": UNKNOWN,
                "entity_type": UNKNOWN,
            },
            "architecture": {
                "macro_group": UNKNOWN,
                "canonical_plane": UNKNOWN,
                "canonical_component": UNKNOWN,
                "architecture_traceability": [],
            },
            "boundaries": {
                "purpose": source.get("name") or UNKNOWN,
                "owns": [],
                "does_not_own": [],
            },
            "capability": {
                "capabilities": [],
                "provides": [],
                "consumes": [],
                "capability_contract_ids": [],
                "dependencies": [str(d) for d in source.get("dependencies", [])],
                "optional_dependencies": [],
                "conflicts": [],
            },
            "provider": {
                "providers": [],
                "adapters": [],
                "provider_contract": UNKNOWN,
                "provider_health": UNKNOWN,
                "provider_certification": UNKNOWN,
                "fallback": UNKNOWN,
            },
            "authority": {
                "authority_ceiling": UNKNOWN,
                "required_authorizations": [],
                "forbidden_authorities": [],
            },
            "side_effect_data_evidence": {
                "side_effect_class": UNKNOWN,
                "data_ownership": [],
                "data_access": [],
                "privacy_data_requirements": UNKNOWN,
                "evidence_requirements": [],
                "evidence_freshness": UNKNOWN,
            },
            "state": {
                "implementation_state": impl_state or UNKNOWN,
                "target_state": UNKNOWN,
                "maturity": UNKNOWN,
                "health": UNKNOWN,
                "certification_state": UNKNOWN,
            },
            "failure_recovery": {
                "known_failure_modes": [],
                "failure_contract": UNKNOWN,
                "recovery_contract": UNKNOWN,
                "rollback_or_compensation_contract": UNKNOWN,
            },
            "quality": {
                "tests": [],
                "security_tests": [],
                "failure_tests": [],
                "recovery_tests": [],
                "benchmarks": [],
            },
            "evolution": {
                "stronger_candidate": UNKNOWN,
                "semantic_comparison": UNKNOWN,
                "unique_behavior_to_preserve": [],
                "improvement_candidates": [],
                "migration_state": UNKNOWN,
                "deprecation_state": UNKNOWN,
            },
        }
