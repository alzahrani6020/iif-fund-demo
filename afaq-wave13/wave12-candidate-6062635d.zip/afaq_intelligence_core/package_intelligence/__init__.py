"""C1-01 Shared Package Intelligence — Read Model.

Public surface exposes nine read-only / advisory APIs through
`PackageIntelligenceKernel`.
"""
from __future__ import annotations

from .kernel import PackageIntelligenceKernel
from .models import (
    UNKNOWN,
    ArchitectureTraceabilityReport,
    AuthorityBoundaryReport,
    CapabilityList,
    DependencyList,
    LoadedProfile,
    SelfModelReport,
    StateReport,
    UnknownsReport,
    ValidationReport,
)

__all__ = [
    "UNKNOWN",
    "PackageIntelligenceKernel",
    "LoadedProfile",
    "ValidationReport",
    "SelfModelReport",
    "ArchitectureTraceabilityReport",
    "CapabilityList",
    "DependencyList",
    "AuthorityBoundaryReport",
    "StateReport",
    "UnknownsReport",
]
