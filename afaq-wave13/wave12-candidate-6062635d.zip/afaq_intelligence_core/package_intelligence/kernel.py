"""C1-01 Shared Package Intelligence Kernel.

Orchestrates the five read-only components and exposes nine public
read-only / advisory APIs.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from .canonical_resolver import CanonicalReferenceResolver
from .models import (
    UNKNOWN,
    ArchitectureTraceabilityReport,
    AuthorityBoundaryReport,
    CapabilityList,
    DependencyList,
    LoadedProfile,
    SelfModelReport,
    StateReport,
    UnknownsReport,
    ValidationReport,
)
from .profile_loader import (
    PackageNotFoundError,
    PackageProfileError,
    PackageProfileLoader,
)
from .profile_validator import PackageProfileValidator
from .self_model import PackageSelfModel


class PackageIntelligenceKernel:
    """Read-only shared kernel for package intelligence queries."""

    def __init__(
        self,
        packages_root: Path | None = None,
        canonical_root: Path | None = None,
        contract_path: Path | None = None,
    ) -> None:
        self.loader = PackageProfileLoader(packages_root)
        self.validator = PackageProfileValidator(contract_path)
        self.resolver = CanonicalReferenceResolver(canonical_root)
        self.self_model = PackageSelfModel(self.resolver, self.loader)

    def load_profile(self, package_id: str) -> LoadedProfile:
        """Load a package manifest and return the raw + normalized profile."""
        return self.loader.load(package_id)

    def validate_profile(self, package_id: str) -> ValidationReport:
        """Validate the normalized profile against the Package Profile Contract."""
        profile = self.loader.load(package_id)
        return self.validator.validate(profile.normalized_profile)

    def describe_package(self, package_id: str) -> SelfModelReport:
        """Return the full self-model report for a package."""
        return self._build_self_model(package_id)

    def resolve_architecture(self, package_id: str) -> ArchitectureTraceabilityReport:
        """Return architecture traceability for a package."""
        report = self._build_self_model(package_id)
        return self.self_model.build_architecture_report(report)

    def list_capabilities(self, package_id: str) -> CapabilityList:
        """Return the capability list for a package."""
        report = self._build_self_model(package_id)
        return self.self_model.build_capability_report(report)

    def list_dependencies(self, package_id: str) -> DependencyList:
        """Return forward and reverse package dependencies."""
        report = self._build_self_model(package_id)
        return self.self_model.build_dependency_report(report)

    def get_authority_boundary(self, package_id: str) -> AuthorityBoundaryReport:
        """Return the authority boundary for a package."""
        report = self._build_self_model(package_id)
        return self.self_model.build_authority_boundary_report(report)

    def get_state(self, package_id: str) -> StateReport:
        """Return the implementation/maturity/health state for a package."""
        report = self._build_self_model(package_id)
        return self.self_model.build_state_report(report)

    def get_unknowns(self, package_id: str) -> UnknownsReport:
        """Return all UNKNOWN / unresolved fields for a package."""
        report = self._build_self_model(package_id)
        return self.self_model.build_unknowns_report(report)

    def _build_self_model(self, package_id: str) -> SelfModelReport:
        try:
            loaded = self.loader.load(package_id)
        except PackageProfileError as exc:
            return SelfModelReport(
                package_id=package_id,
                errors=[str(exc)],
                unknowns=[UNKNOWN],
            )
        profile = loaded.normalized_profile
        validation = self.validator.validate(profile)
        report = self.self_model.build(profile, loaded.source_metadata)
        if not validation.valid:
            report.errors.extend(validation.errors)
            report.unknowns.append("profile_validation_failed")
        return report
