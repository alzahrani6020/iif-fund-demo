"""Build the Package Self Model from a profile and canonical references.

All answers are derived from the Package Profile Contract and C0-A canonical
registries. Missing or unprovable facts are reported as UNKNOWN.
"""
from __future__ import annotations

import copy
from typing import Any

from .canonical_resolver import CanonicalReferenceResolver
from .models import UNKNOWN, AuthorityBoundaryReport, CapabilityList, DependencyList
from .models import SelfModelReport as SelfModelReportType
from .models import StateReport, UnknownsReport
from .profile_loader import PackageProfileLoader


class PackageSelfModel:
    """Answer the self-model questions defined by the Package Intelligence Contract."""

    def __init__(
        self,
        resolver: CanonicalReferenceResolver,
        loader: PackageProfileLoader,
    ) -> None:
        self.resolver = resolver
        self.loader = loader

    _REQUIRED_SECTIONS = frozenset({
        "identity",
        "architecture",
        "boundaries",
        "capability",
        "provider",
        "authority",
        "side_effect_data_evidence",
        "state",
        "failure_recovery",
        "quality",
        "evolution",
    })

    def build(
        self, profile: dict[str, Any], source_metadata: dict[str, Any]
    ) -> SelfModelReportType:
        package_id = UNKNOWN
        identity_section = profile.get("identity", {})
        if isinstance(identity_section, dict):
            package_id = identity_section.get("package_id", UNKNOWN)
        working = copy.deepcopy(profile)
        report = SelfModelReportType(package_id=package_id)
        for section in self._REQUIRED_SECTIONS:
            if section not in working:
                report.errors.append(f"missing required section: {section}")
                working[section] = {}
        report.identity = self._identity(working, source_metadata)
        report.architecture = self._architecture(working)
        report.boundaries = self._boundaries(working)
        report.capabilities = self._capabilities(working)
        report.providers = self._providers(working)
        report.authority = self._authority(working)
        report.side_effect_data_evidence = self._side_effect_data_evidence(working)
        report.state = self._state(working)
        report.failure_recovery = self._failure_recovery(working)
        report.quality = self._quality(working)
        report.evolution = self._evolution(working)
        report.unknowns = self._collect_unknowns(working, report)
        return report

    def _identity(
        self, profile: dict[str, Any], source_metadata: dict[str, Any]
    ) -> dict[str, Any]:
        identity = profile["identity"]
        # Source owner is observed legacy metadata only, never canonical.
        source_owner = source_metadata.get("architectural_owner") or source_metadata.get("owner")
        claimed_owner = identity.get("canonical_owner", UNKNOWN)
        # Canonical owner must be proven by the ownership registry;
        # a package-local claim is not authoritative.
        resolved_owner = (
            self.resolver.resolve_owner(claimed_owner)
            if claimed_owner != UNKNOWN
            else UNKNOWN
        )
        proven = resolved_owner != UNKNOWN
        return {
            "who_am_i": identity.get("package_id"),
            "package_version": identity.get("package_version", UNKNOWN),
            "entity_type": self.resolver.resolve_entity_type(
                identity.get("entity_type", UNKNOWN)
            ),
            "canonical_owner": resolved_owner,
            "claimed_owner": claimed_owner,
            "source_owner": source_owner or UNKNOWN,
            "canonical_owner_proven": proven,
        }

    def _architecture(self, profile: dict[str, Any]) -> dict[str, Any]:
        arch = profile["architecture"]
        plane_id = arch.get("canonical_plane", UNKNOWN)
        component_id = arch.get("canonical_component", UNKNOWN)
        macro_id = arch.get("macro_group", UNKNOWN)
        trace_ids = arch.get("architecture_traceability", [])
        unresolved: list[str] = []
        resolved_trace = []
        for ref in trace_ids:
            if ref == UNKNOWN or not isinstance(ref, str) or not ref:
                unresolved.append(str(ref))
                continue
            resolved = self.resolver.resolve_traceability(ref)
            if resolved == UNKNOWN:
                unresolved.append(ref)
            else:
                resolved_trace.append(resolved)
        return {
            "where_do_i_belong": {
                "canonical_plane": self.resolver.resolve_plane(plane_id),
                "macro_group": self.resolver.resolve_macro_group(macro_id),
            },
            "canonical_component": self.resolver.resolve_component(component_id),
            "architecture_traceability": resolved_trace,
            "unresolved_references": unresolved,
        }

    def _boundaries(self, profile: dict[str, Any]) -> dict[str, Any]:
        boundaries = profile["boundaries"]
        return {
            "purpose": boundaries.get("purpose", UNKNOWN),
            "what_i_own": boundaries.get("owns", []),
            "what_i_do_not_own": boundaries.get("does_not_own", []),
        }

    def _capabilities(self, profile: dict[str, Any]) -> dict[str, Any]:
        caps = profile["capability"]
        raw_capabilities = caps.get("capabilities", [])
        provided = []
        consumed = []
        unresolved: list[str] = []
        for item in raw_capabilities:
            cap_id = item.get("capability_id", UNKNOWN) if isinstance(item, dict) else UNKNOWN
            role = item.get("role", UNKNOWN) if isinstance(item, dict) else UNKNOWN
            resolved = self.resolver.resolve_capability(cap_id)
            if resolved == UNKNOWN and cap_id != UNKNOWN:
                unresolved.append(cap_id)
            if role == "PROVIDE":
                provided.append(resolved)
            elif role == "CONSUME":
                consumed.append(resolved)
        return {
            "what_i_can_do": provided if raw_capabilities else UNKNOWN,
            "what_i_can_not_do": consumed if raw_capabilities else UNKNOWN,
            "provided_capabilities": provided if raw_capabilities else UNKNOWN,
            "consumed_capabilities": consumed if raw_capabilities else UNKNOWN,
            "capability_contract_ids": caps.get("capability_contract_ids", []),
            "dependencies": caps.get("dependencies", []),
            "optional_dependencies": caps.get("optional_dependencies", []),
            "unresolved_capabilities": unresolved,
        }

    def _providers(self, profile: dict[str, Any]) -> dict[str, Any]:
        provider = profile["provider"]
        return {
            "providers": provider.get("providers", []),
            "adapters": provider.get("adapters", []),
            "provider_contract": provider.get("provider_contract", UNKNOWN),
            "provider_health": provider.get("provider_health", UNKNOWN),
            "provider_certification": provider.get("provider_certification", UNKNOWN),
            "fallback": provider.get("fallback", UNKNOWN),
        }

    def _authority(self, profile: dict[str, Any]) -> dict[str, Any]:
        auth = profile["authority"]
        ceiling_id = auth.get("authority_ceiling", UNKNOWN)
        required_ids = auth.get("required_authorizations", [])
        forbidden_ids = auth.get("forbidden_authorities", [])
        # Unknown authority remains UNKNOWN; it is never coerced to NONE.
        ceiling = (
            self.resolver.resolve_authority(ceiling_id)
            if ceiling_id != UNKNOWN
            else UNKNOWN
        )
        required = []
        unresolved_required: list[str] = []
        for ref in required_ids:
            if not isinstance(ref, str):
                unresolved_required.append(str(ref))
                continue
            resolved = self.resolver.resolve_authority(ref)
            if resolved == UNKNOWN:
                unresolved_required.append(ref)
            required.append(resolved)
        forbidden = []
        unresolved_forbidden: list[str] = []
        for ref in forbidden_ids:
            if not isinstance(ref, str):
                unresolved_forbidden.append(str(ref))
                continue
            resolved = self.resolver.resolve_authority(ref)
            if resolved == UNKNOWN:
                unresolved_forbidden.append(ref)
            forbidden.append(resolved)
        return {
            "authority_ceiling": ceiling,
            "required_authorizations": required,
            "forbidden_authorities": forbidden,
            "unresolved_authorities": unresolved_required + unresolved_forbidden,
            # Explicit authority invariants preserved in report form.
            "package_intelligence_has_authority": False,
            "provider_is_not_authority": True,
            "maturity_is_not_authority": True,
            "certification_is_not_promotion": True,
        }

    def _side_effect_data_evidence(self, profile: dict[str, Any]) -> dict[str, Any]:
        side = profile["side_effect_data_evidence"]
        data_ownership = []
        for item in side.get("data_ownership", []):
            if isinstance(item, dict):
                store_id = item.get("store_id", UNKNOWN)
                resolved = self.resolver.resolve_data_store(store_id)
                data_ownership.append({**item, "resolved_store": resolved})
        data_access = []
        for item in side.get("data_access", []):
            if isinstance(item, dict):
                store_id = item.get("store_id", UNKNOWN)
                resolved = self.resolver.resolve_data_store(store_id)
                data_access.append({**item, "resolved_store": resolved})
        evidence = []
        for item in side.get("evidence_requirements", []):
            if isinstance(item, dict):
                ev_id = item.get("evidence_type_id", UNKNOWN)
                resolved = self.resolver.resolve_evidence_type(ev_id)
                evidence.append({**item, "resolved_evidence_type": resolved})
        return {
            "side_effect_class": side.get("side_effect_class", UNKNOWN),
            "data_ownership": data_ownership,
            "data_access": data_access,
            "evidence_requirements": evidence,
            "evidence_freshness": side.get("evidence_freshness", UNKNOWN),
        }

    def _state(self, profile: dict[str, Any]) -> dict[str, Any]:
        state = profile["state"]
        return {
            "implementation_state": state.get("implementation_state", UNKNOWN),
            "target_state": state.get("target_state", UNKNOWN),
            "maturity": state.get("maturity", UNKNOWN),
            "health": state.get("health", UNKNOWN),
            "certification_state": state.get("certification_state", UNKNOWN),
        }

    def _failure_recovery(self, profile: dict[str, Any]) -> dict[str, Any]:
        fr = profile["failure_recovery"]
        return {
            "known_failure_modes": fr.get("known_failure_modes", []),
            "failure_contract": fr.get("failure_contract", UNKNOWN),
            "recovery_contract": fr.get("recovery_contract", UNKNOWN),
            "rollback_or_compensation_contract": fr.get(
                "rollback_or_compensation_contract", UNKNOWN
            ),
        }

    def _quality(self, profile: dict[str, Any]) -> dict[str, Any]:
        quality = profile["quality"]
        return {
            "tests": quality.get("tests", []),
            "security_tests": quality.get("security_tests", []),
            "failure_tests": quality.get("failure_tests", []),
            "recovery_tests": quality.get("recovery_tests", []),
            "benchmarks": quality.get("benchmarks", []),
        }

    def _evolution(self, profile: dict[str, Any]) -> dict[str, Any]:
        evo = profile["evolution"]
        return {
            "stronger_candidate": evo.get("stronger_candidate", UNKNOWN),
            "semantic_comparison": evo.get("semantic_comparison", UNKNOWN),
            "unique_behavior_to_preserve": evo.get("unique_behavior_to_preserve", []),
            "improvement_candidates": evo.get("improvement_candidates", []),
            "migration_state": evo.get("migration_state", UNKNOWN),
            "deprecation_state": evo.get("deprecation_state", UNKNOWN),
        }

    @staticmethod
    def _collect_unknowns(
        profile: dict[str, Any], report: SelfModelReportType
    ) -> list[str]:
        unknowns: list[str] = []

        def walk(prefix: str, value: Any) -> None:
            if value == UNKNOWN:
                unknowns.append(prefix)
            elif isinstance(value, list):
                if not value:
                    unknowns.append(prefix)
                else:
                    for i, item in enumerate(value):
                        walk(f"{prefix}[{i}]", item)
            elif isinstance(value, dict):
                if not value:
                    unknowns.append(prefix)
                else:
                    for k, v in value.items():
                        walk(f"{prefix}.{k}", v)

        for section_name, section in profile.items():
            walk(section_name, section)

        if not report.architecture.get("unresolved_references"):
            pass
        else:
            for ref in report.architecture.get("unresolved_references", []):
                unknowns.append(f"architecture_traceability.{ref}")
        for ref in report.capabilities.get("unresolved_capabilities", []):
            unknowns.append(f"capability.{ref}")
        for ref in report.authority.get("unresolved_authorities", []):
            unknowns.append(f"authority.{ref}")

        return sorted(set(unknowns))

    def build_authority_boundary_report(
        self, report: SelfModelReportType
    ) -> AuthorityBoundaryReport:
        auth = report.authority
        identity = report.identity
        return AuthorityBoundaryReport(
            package_id=report.package_id,
            authority_ceiling=auth.get("authority_ceiling", UNKNOWN),
            required_authorizations=auth.get("required_authorizations", []),
            forbidden_authorities=auth.get("forbidden_authorities", []),
            canonical_owner=identity.get("canonical_owner", UNKNOWN),
            source_owner=identity.get("source_owner", UNKNOWN),
            errors=report.errors,
        )

    def build_state_report(self, report: SelfModelReportType) -> StateReport:
        state = report.state
        return StateReport(
            package_id=report.package_id,
            implementation_state=state.get("implementation_state", UNKNOWN),
            target_state=state.get("target_state", UNKNOWN),
            maturity=state.get("maturity", UNKNOWN),
            health=state.get("health", UNKNOWN),
            certification_state=state.get("certification_state", UNKNOWN),
            errors=report.errors,
        )

    def build_unknowns_report(self, report: SelfModelReportType) -> UnknownsReport:
        return UnknownsReport(
            package_id=report.package_id,
            unknowns=report.unknowns,
            errors=report.errors,
        )

    def build_dependency_report(
        self, report: SelfModelReportType
    ) -> DependencyList:
        package_id = report.package_id
        dependencies = report.capabilities.get("dependencies", [])
        reverse = self.resolver.reverse_package_dependencies(
            package_id, self.loader.packages_root
        )
        return DependencyList(
            package_id=package_id,
            dependencies=dependencies,
            reverse_dependencies=reverse,
            errors=report.errors,
        )

    def build_capability_report(
        self, report: SelfModelReportType
    ) -> CapabilityList:
        caps = report.capabilities
        return CapabilityList(
            package_id=report.package_id,
            provided=caps.get("provided_capabilities", UNKNOWN),
            consumed=caps.get("consumed_capabilities", UNKNOWN),
            capabilities=caps.get("what_i_can_do", UNKNOWN),
            capability_contract_ids=caps.get("capability_contract_ids", []),
            errors=report.errors,
        )

    def build_architecture_report(
        self, report: SelfModelReportType
    ) -> Any:
        from .models import ArchitectureTraceabilityReport

        arch = report.architecture
        return ArchitectureTraceabilityReport(
            package_id=report.package_id,
            canonical_plane=arch.get("where_do_i_belong", {}).get("canonical_plane", UNKNOWN),
            macro_group=arch.get("where_do_i_belong", {}).get("macro_group", UNKNOWN),
            canonical_component=arch.get("canonical_component", UNKNOWN),
            architecture_traceability=arch.get("architecture_traceability", []),
            unresolved_references=arch.get("unresolved_references", []),
            errors=report.errors,
        )
