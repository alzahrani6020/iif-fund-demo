"""Data models for the C1-01 Shared Package Intelligence read model.

All reports are advisory. UNKNOWN is preserved as an explicit sentinel.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any

UNKNOWN = "UNKNOWN"


def _coerce_unknown(value: Any) -> Any:
    """Preserve explicit UNKNOWN; map None / empty to UNKNOWN for report fields."""
    if value is None or value == "":
        return UNKNOWN
    return value


@dataclass
class LoadedProfile:
    package_id: str
    source_path: str
    source_metadata: dict[str, Any] = field(default_factory=dict)
    normalized_profile: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ValidationReport:
    package_id: str = UNKNOWN
    valid: bool = False
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    unresolved_references: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ArchitectureTraceabilityReport:
    package_id: str = UNKNOWN
    canonical_plane: Any = UNKNOWN
    macro_group: Any = UNKNOWN
    canonical_component: Any = UNKNOWN
    architecture_traceability: list[Any] = field(default_factory=list)
    unresolved_references: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class CapabilityList:
    package_id: str = UNKNOWN
    provided: Any = UNKNOWN
    consumed: Any = UNKNOWN
    capabilities: list[Any] = field(default_factory=list)
    capability_contract_ids: list[Any] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class DependencyList:
    package_id: str = UNKNOWN
    dependencies: list[str] = field(default_factory=list)
    reverse_dependencies: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class AuthorityBoundaryReport:
    package_id: str = UNKNOWN
    authority_ceiling: Any = UNKNOWN
    required_authorizations: list[Any] = field(default_factory=list)
    forbidden_authorities: list[Any] = field(default_factory=list)
    canonical_owner: Any = UNKNOWN
    source_owner: Any = UNKNOWN
    errors: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class StateReport:
    package_id: str = UNKNOWN
    implementation_state: Any = UNKNOWN
    target_state: Any = UNKNOWN
    maturity: Any = UNKNOWN
    health: Any = UNKNOWN
    certification_state: Any = UNKNOWN
    errors: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class UnknownsReport:
    package_id: str = UNKNOWN
    unknowns: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class SelfModelReport:
    package_id: str = UNKNOWN
    identity: dict[str, Any] = field(default_factory=dict)
    architecture: dict[str, Any] = field(default_factory=dict)
    boundaries: dict[str, Any] = field(default_factory=dict)
    capabilities: dict[str, Any] = field(default_factory=dict)
    providers: dict[str, Any] = field(default_factory=dict)
    authority: dict[str, Any] = field(default_factory=dict)
    side_effect_data_evidence: dict[str, Any] = field(default_factory=dict)
    state: dict[str, Any] = field(default_factory=dict)
    failure_recovery: dict[str, Any] = field(default_factory=dict)
    quality: dict[str, Any] = field(default_factory=dict)
    evolution: dict[str, Any] = field(default_factory=dict)
    unknowns: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
