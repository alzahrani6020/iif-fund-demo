"""Resolve canonical architecture references from frozen C0-A registries.

All lookups are read-only and fail-closed: an unresolvable reference returns
UNKNOWN rather than raising or returning None/False.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .models import UNKNOWN


class CanonicalResolutionError(RuntimeError):
    pass


class CanonicalReferenceResolver:
    """Load canonical architecture registries and resolve IDs."""

    def __init__(self, canonical_root: Path | None = None) -> None:
        self.canonical_root = canonical_root or self._default_canonical_root()
        self._registries = self._load_registries()

    @staticmethod
    def _default_canonical_root() -> Path:
        return (
            Path(__file__).resolve().parents[2]
            / "project-records"
            / "architecture"
            / "v1"
        )

    def _load_json(self, filename: str) -> dict[str, Any] | list[Any]:
        path = self.canonical_root / filename
        text = path.read_text(encoding="utf-8")
        return json.loads(text)

    def _load_registries(self) -> dict[str, Any]:
        root = self.canonical_root
        if not root.exists():
            raise CanonicalResolutionError(
                f"Canonical architecture root does not exist: {root}"
            )

        def load(filename: str) -> dict[str, Any] | list[Any]:
            return self._load_json(filename)

        plane_registry = load("PLANE_REGISTRY.json")
        component_registry = load("COMPONENT_REGISTRY.json")
        capability_map = load("CAPABILITY_PROVIDER_MAP.json")
        ownership_registry = load("OWNERSHIP_REGISTRY.json")
        authority_model = load("AUTHORITY_MODEL.json")
        entity_taxonomy = load("ENTITY_TYPE_TAXONOMY.json")
        macro_groups = load("MACRO_GROUP_REGISTRY.json")
        lifecycle = load("LIFECYCLE_STATE_MATURITY_MODELS.json")
        traceability = load("TRACEABILITY_REGISTRY.json")
        dependency_dag = load("DEPENDENCY_DAG.json")
        data_ownership = load("DATA_OWNERSHIP_MAP.json")
        evidence_provenance = load("EVIDENCE_PROVENANCE_MAP.json")

        return {
            "planes": self._list_to_dict(plane_registry, "plane_id", "planes"),
            "components": self._list_to_dict(
                component_registry, "component_id", "components"
            ),
            "capabilities": self._list_to_dict(
                capability_map, "capability_id", "capabilities"
            ),
            "ownership": self._list_to_dict(
                ownership_registry, "element_id", "ownership_entries"
            ),
            "authorities": self._list_to_dict(
                authority_model, "authority_id", "authority_classes"
            ),
            "entity_types": self._list_to_dict(
                entity_taxonomy, "id", "entity_types"
            ),
            "macro_groups": self._list_to_dict(
                macro_groups, "macro_id", "macro_groups"
            ),
            "lifecycle": lifecycle,
            "traceability": self._list_to_dict(traceability, "id", "traceability_entries"),
            "dependency_dag": dependency_dag,
            "data_ownership": self._list_to_dict(
                data_ownership, "store_id", "data_stores"
            ),
            "evidence_provenance": self._list_to_dict(
                evidence_provenance, "evidence_type_id", "evidence_types"
            ),
        }

    @staticmethod
    def _list_to_dict(
        data: dict[str, Any] | list[Any], key_field: str, list_field: str
    ) -> dict[str, Any]:
        if isinstance(data, dict):
            items = data.get(list_field, [])
        else:
            items = data
        result: dict[str, Any] = {}
        for item in items:
            if isinstance(item, dict):
                key = item.get(key_field)
                if key is not None:
                    result[str(key)] = item
        return result

    def resolve_plane(self, plane_id: str) -> Any:
        return self._resolve("planes", plane_id)

    def resolve_component(self, component_id: str) -> Any:
        return self._resolve("components", component_id)

    def resolve_capability(self, capability_id: str) -> Any:
        return self._resolve("capabilities", capability_id)

    def resolve_owner(self, element_id: str) -> Any:
        return self._resolve("ownership", element_id)

    def resolve_authority(self, authority_id: str) -> Any:
        return self._resolve("authorities", authority_id)

    def resolve_entity_type(self, entity_type_id: str) -> Any:
        return self._resolve("entity_types", entity_type_id)

    def resolve_macro_group(self, macro_group_id: str) -> Any:
        return self._resolve("macro_groups", macro_group_id)

    def resolve_data_store(self, store_id: str) -> Any:
        return self._resolve("data_ownership", store_id)

    def resolve_evidence_type(self, evidence_type_id: str) -> Any:
        return self._resolve("evidence_provenance", evidence_type_id)

    def resolve_traceability(self, traceability_id: str) -> Any:
        return self._resolve("traceability", traceability_id)

    def _resolve(self, registry_name: str, ref_id: str) -> Any:
        if ref_id == UNKNOWN or not isinstance(ref_id, str) or not ref_id:
            return UNKNOWN
        registry = self._registries.get(registry_name, {})
        return registry.get(ref_id, UNKNOWN)

    def is_valid_lifecycle_state(self, value: str, category: str) -> bool:
        lifecycle = self._registries.get("lifecycle", {})
        states = lifecycle.get(category, [])
        return isinstance(states, list) and value in states

    def reverse_package_dependencies(
        self, package_id: str, packages_root: Path | None = None
    ) -> list[str]:
        """Compute reverse dependencies by scanning physical package manifests."""
        root = packages_root or (
            Path(__file__).resolve().parents[2] / "owner-packages"
        )
        reverse: list[str] = []
        if not root.exists():
            return reverse
        for subdir in sorted(root.iterdir()):
            manifest = subdir / "MANIFEST.json"
            if not manifest.is_file():
                continue
            try:
                raw = manifest.read_bytes()
                if raw.startswith(b"\xef\xbb\xbf"):
                    raw = raw[3:]
                data = json.loads(raw.decode("utf-8"))
            except Exception:
                continue
            deps = data.get("dependencies", []) if isinstance(data, dict) else []
            if package_id in [str(d) for d in deps]:
                pkg_id = data.get("package_id") if isinstance(data, dict) else None
                reverse.append(pkg_id or subdir.name)
        return sorted(set(reverse))

    def canonical_dependency_edges(self) -> list[dict[str, Any]]:
        dag = self._registries.get("dependency_dag", {})
        return dag.get("edges", []) if isinstance(dag, dict) else []

    def canonical_dependency_nodes(self) -> list[dict[str, Any]]:
        dag = self._registries.get("dependency_dag", {})
        return dag.get("nodes", []) if isinstance(dag, dict) else []
