"""Deterministic experiment design for capability assimilation benchmarks.

The designer creates an auditable plan. Execution belongs to the benchmark
runtime and any deployment decision remains governed elsewhere.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class ExperimentPlan:
    experiment_id: str
    objective: str
    baseline_id: str
    candidate_id: str
    metrics: tuple[str, ...]
    cases: tuple[dict[str, Any], ...]
    success_thresholds: dict[str, float]
    failure_injections: tuple[str, ...]
    rollback_conditions: tuple[str, ...]
    evidence_refs: tuple[str, ...]
    plan_hash: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "experiment_id": self.experiment_id,
            "objective": self.objective,
            "baseline_id": self.baseline_id,
            "candidate_id": self.candidate_id,
            "metrics": list(self.metrics),
            "cases": list(self.cases),
            "success_thresholds": dict(self.success_thresholds),
            "failure_injections": list(self.failure_injections),
            "rollback_conditions": list(self.rollback_conditions),
            "evidence_refs": list(self.evidence_refs),
            "plan_hash": self.plan_hash,
            "execution_authority": False,
        }


def _hash_payload(payload: Mapping[str, Any]) -> str:
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def design_experiment(
    *,
    objective: str,
    baseline_id: str,
    candidate_id: str,
    cases: tuple[Mapping[str, Any], ...],
    metrics: tuple[str, ...] = (
        "task_completion",
        "correctness",
        "latency_ms",
        "reliability",
        "evidence_completeness",
    ),
    success_thresholds: Mapping[str, float] | None = None,
    failure_injections: tuple[str, ...] = (
        "TIMEOUT",
        "TRANSIENT_5XX",
        "SCHEMA_VARIATION",
    ),
    rollback_conditions: tuple[str, ...] = (
        "candidate_success_rate_below_baseline",
        "critical_evidence_regression",
        "unauthorized_side_effect",
    ),
    evidence_refs: tuple[str, ...] = (),
) -> ExperimentPlan:
    if not objective.strip():
        raise ValueError("objective required")
    if not baseline_id.strip() or not candidate_id.strip():
        raise ValueError("baseline_id and candidate_id required")
    if not cases:
        raise ValueError("at least one experiment case required")
    normalized_cases = tuple(dict(case) for case in cases)
    thresholds = dict(success_thresholds or {
        "task_completion": 1.0,
        "correctness": 1.0,
        "evidence_completeness": 1.0,
    })

    base_payload = {
        "objective": objective,
        "baseline_id": baseline_id,
        "candidate_id": candidate_id,
        "metrics": list(metrics),
        "cases": list(normalized_cases),
        "success_thresholds": thresholds,
        "failure_injections": list(failure_injections),
        "rollback_conditions": list(rollback_conditions),
        "evidence_refs": list(evidence_refs),
    }
    digest = _hash_payload(base_payload)
    return ExperimentPlan(
        experiment_id=f"exp-{digest[:16]}",
        objective=objective,
        baseline_id=baseline_id,
        candidate_id=candidate_id,
        metrics=tuple(metrics),
        cases=normalized_cases,
        success_thresholds={str(k): float(v) for k, v in thresholds.items()},
        failure_injections=tuple(failure_injections),
        rollback_conditions=tuple(rollback_conditions),
        evidence_refs=tuple(evidence_refs),
        plan_hash=digest,
    )
