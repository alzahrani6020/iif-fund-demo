"""Evidence-aware capability economics comparison.

Scores are advisory inputs to selection. They do not override authority,
compliance, verification or production-admission gates.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class EconomicsProfile:
    subject_id: str
    quality: float
    reliability: float
    latency_ms: float
    unit_cost: float
    compute_cost: float = 0.0
    data_transfer_cost: float = 0.0
    strategic_dependency: float = 0.0
    licensing_risk: float = 0.0
    evidence_refs: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        for name in ("quality", "reliability", "strategic_dependency", "licensing_risk"):
            value = getattr(self, name)
            if not (0.0 <= value <= 1.0):
                raise ValueError(f"{name} must be in [0,1]")
        for name in ("latency_ms", "unit_cost", "compute_cost", "data_transfer_cost"):
            if getattr(self, name) < 0:
                raise ValueError(f"{name} must be >= 0")


@dataclass(frozen=True)
class EconomicsDecision:
    ranked_subjects: tuple[str, ...]
    scores: dict[str, float]
    breakdown: dict[str, dict[str, float]]
    evidence_refs: tuple[str, ...]
    advisory_only: bool = True

    def as_dict(self) -> dict[str, Any]:
        return {
            "ranked_subjects": list(self.ranked_subjects),
            "scores": dict(self.scores),
            "breakdown": {k: dict(v) for k, v in self.breakdown.items()},
            "evidence_refs": list(self.evidence_refs),
            "advisory_only": True,
        }


_DEFAULT_WEIGHTS = {
    "quality": 0.30,
    "reliability": 0.25,
    "latency": 0.15,
    "cost": 0.15,
    "strategic_dependency": 0.10,
    "licensing_risk": 0.05,
}


def compare_economics(
    profiles: tuple[EconomicsProfile, ...],
    *,
    weights: Mapping[str, float] | None = None,
) -> EconomicsDecision:
    if not profiles:
        raise ValueError("at least one economics profile required")
    w = dict(_DEFAULT_WEIGHTS)
    if weights:
        w.update({str(k): float(v) for k, v in weights.items()})
    total_w = sum(max(0.0, value) for value in w.values())
    if total_w <= 0:
        raise ValueError("weights must contain positive total weight")
    w = {key: max(0.0, value) / total_w for key, value in w.items()}

    max_latency = max(profile.latency_ms for profile in profiles) or 1.0
    max_cost = max(
        profile.unit_cost + profile.compute_cost + profile.data_transfer_cost
        for profile in profiles
    ) or 1.0

    scores: dict[str, float] = {}
    breakdown: dict[str, dict[str, float]] = {}
    evidence: list[str] = []

    for profile in profiles:
        total_cost = profile.unit_cost + profile.compute_cost + profile.data_transfer_cost
        latency_score = 1.0 - min(1.0, profile.latency_ms / max_latency)
        cost_score = 1.0 - min(1.0, total_cost / max_cost)
        dependency_score = 1.0 - profile.strategic_dependency
        license_score = 1.0 - profile.licensing_risk
        parts = {
            "quality": profile.quality,
            "reliability": profile.reliability,
            "latency": latency_score,
            "cost": cost_score,
            "strategic_dependency": dependency_score,
            "licensing_risk": license_score,
        }
        score = sum(parts[key] * w.get(key, 0.0) for key in parts)
        scores[profile.subject_id] = round(score, 6)
        breakdown[profile.subject_id] = {
            **{f"{key}_normalized": round(value, 6) for key, value in parts.items()},
            "total_cost": round(total_cost, 6),
            "latency_ms": round(profile.latency_ms, 6),
        }
        evidence.extend(profile.evidence_refs)

    ranked = tuple(sorted(scores, key=lambda subject: (-scores[subject], subject)))
    return EconomicsDecision(
        ranked_subjects=ranked,
        scores=scores,
        breakdown=breakdown,
        evidence_refs=tuple(sorted(dict.fromkeys(evidence))),
        advisory_only=True,
    )
