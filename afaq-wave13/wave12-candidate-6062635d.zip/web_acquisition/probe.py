"""Controlled active capability probing.

Probes are read-only by default. Side-effecting probes require an explicit
remote verifier and are not marked proven from an executor response alone.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from .browser import BrowserAction, run_browser
from .fetch import fetch_url
from .verification import verify_remote_resource


@dataclass(frozen=True)
class ProbeResult:
    state: str
    capability: str
    evidence_refs: tuple[str, ...]
    observations: dict[str, Any]
    proven: bool
    reason: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "state": self.state,
            "capability": self.capability,
            "evidence_refs": list(self.evidence_refs),
            "observations": dict(self.observations),
            "proven": self.proven,
            "reason": self.reason,
        }


def probe_http_read(
    capability: str,
    url: str,
    *,
    expected_contains: str | None = None,
    allow_private_networks: bool = False,
) -> ProbeResult:
    result = fetch_url(url, allow_private_networks=allow_private_networks)
    refs = (
        (f"web:{result.evidence.content_hash}:{url}",)
        if result.evidence.content_hash
        else ()
    )
    proven = bool(result.ok and (expected_contains is None or expected_contains in result.text))
    return ProbeResult(
        state="PROVEN" if proven else ("BLOCKED" if not result.executed else "FAILED"),
        capability=capability,
        evidence_refs=refs,
        observations={
            "status_code": result.evidence.status_code,
            "content_type": result.evidence.content_type,
            "content_hash": result.evidence.content_hash,
        },
        proven=proven,
        reason="CONTROLLED_READ_PROBE_MATCHED" if proven else (result.evidence.failure_class or "PROBE_MISMATCH"),
    )


def probe_browser_interaction(
    capability: str,
    url: str,
    *,
    actions: tuple[BrowserAction, ...],
    allow_private_networks: bool = False,
) -> ProbeResult:
    result = run_browser(
        url,
        actions=actions,
        allow_private_networks=allow_private_networks,
        capture_network=True,
    )
    refs = tuple(
        ref
        for ref in (
            f"dom:{result.html_sha256}" if result.html_sha256 else None,
            f"screen:{result.screenshot_sha256}" if result.screenshot_sha256 else None,
        )
        if ref
    )
    proven = bool(result.ok and result.executed and result.state == "EFFECT_OBSERVED" and refs)
    return ProbeResult(
        state="PROVEN" if proven else result.state,
        capability=capability,
        evidence_refs=refs,
        observations={
            "final_url": result.final_url,
            "title": result.title,
            "action_count": len(result.actions),
            "network_event_count": len(result.network),
        },
        proven=proven,
        reason="CONTROLLED_BROWSER_EFFECT_OBSERVED" if proven else (result.failure_class or "BROWSER_PROBE_FAILED"),
    )


def probe_side_effect_with_readback(
    capability: str,
    *,
    executor_result: Mapping[str, Any],
    verification_url: str,
    expected_contains: str | None = None,
    expected_sha256: str | None = None,
    allow_private_networks: bool = False,
) -> ProbeResult:
    if not bool(executor_result.get("ok")):
        return ProbeResult(
            state="FAILED",
            capability=capability,
            evidence_refs=(),
            observations={"executor_result": dict(executor_result)},
            proven=False,
            reason="EXECUTOR_DID_NOT_REPORT_SUCCESS",
        )
    verified = verify_remote_resource(
        verification_url,
        expected_contains=expected_contains,
        expected_sha256=expected_sha256,
        allow_private_networks=allow_private_networks,
    )
    evidence = verified.evidence
    content_hash = evidence.get("content_hash")
    refs = (f"web:{content_hash}:{verification_url}",) if content_hash else ()
    return ProbeResult(
        state="PROVEN" if verified.verified else verified.state,
        capability=capability,
        evidence_refs=refs,
        observations={
            "executor_acknowledged": True,
            "verification": verified.as_dict(),
        },
        proven=verified.verified,
        reason="REMOTE_EFFECT_VERIFIED" if verified.verified else verified.reason,
    )
