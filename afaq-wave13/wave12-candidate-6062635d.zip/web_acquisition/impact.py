"""Dependency blast-radius analysis for technology assimilation changes."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class ImpactReport:
    subject: str
    directly_affected: tuple[str, ...]
    transitively_affected: tuple[str, ...]
    blast_radius: int
    unknown_dependencies: tuple[str, ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "subject": self.subject,
            "directly_affected": list(self.directly_affected),
            "transitively_affected": list(self.transitively_affected),
            "blast_radius": self.blast_radius,
            "unknown_dependencies": list(self.unknown_dependencies),
        }


def analyze_dependency_impact(
    subject: str,
    *,
    consumers_by_dependency: Mapping[str, tuple[str, ...] | list[str]],
    known_nodes: tuple[str, ...] = (),
) -> ImpactReport:
    direct = tuple(sorted(dict.fromkeys(str(x) for x in consumers_by_dependency.get(subject, ()))))
    visited = set(direct)
    queue = deque(direct)
    while queue:
        current = queue.popleft()
        for child in consumers_by_dependency.get(current, ()):
            child = str(child)
            if child not in visited:
                visited.add(child)
                queue.append(child)

    known = set(known_nodes)
    unknown = tuple(sorted(node for node in visited if known and node not in known))
    transitive = tuple(sorted(visited - set(direct)))
    return ImpactReport(
        subject=subject,
        directly_affected=direct,
        transitively_affected=transitive,
        blast_radius=len(visited),
        unknown_dependencies=unknown,
    )


@dataclass(frozen=True)
class RetirementPlan:
    state: str
    subject: str
    replacement: str | None
    affected_consumers: tuple[str, ...]
    steps: tuple[str, ...]
    blocked_reasons: tuple[str, ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "state": self.state,
            "subject": self.subject,
            "replacement": self.replacement,
            "affected_consumers": list(self.affected_consumers),
            "steps": list(self.steps),
            "blocked_reasons": list(self.blocked_reasons),
            "execution_authority": False,
        }


def plan_safe_retirement(
    subject: str,
    *,
    replacement: str | None,
    impact: ImpactReport,
    replacement_verified: bool,
    rollback_available: bool,
) -> RetirementPlan:
    blockers: list[str] = []
    if impact.blast_radius and not replacement:
        blockers.append("REPLACEMENT_REQUIRED")
    if replacement and not replacement_verified:
        blockers.append("REPLACEMENT_NOT_VERIFIED")
    if not rollback_available:
        blockers.append("ROLLBACK_NOT_AVAILABLE")

    state = "READY_FOR_GOVERNED_REVIEW" if not blockers else "BLOCKED"
    steps = (
        "DEPRECATE",
        "NOTIFY_CONSUMERS",
        "SUBSTITUTE",
        "SHADOW_VERIFY",
        "DRAIN_OR_QUIESCE",
        "POST_SWITCH_VERIFY",
        "RETIRE",
    )
    return RetirementPlan(
        state=state,
        subject=subject,
        replacement=replacement,
        affected_consumers=tuple(sorted((*impact.directly_affected, *impact.transitively_affected))),
        steps=steps,
        blocked_reasons=tuple(blockers),
    )
