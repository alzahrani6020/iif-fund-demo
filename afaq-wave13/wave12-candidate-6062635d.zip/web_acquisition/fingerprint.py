"""Capability fingerprints and behavioral equivalence classification."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Any, Mapping


@dataclass(frozen=True)
class CapabilityFingerprint:
    capability_id: str
    semantic_goal: str
    input_contract: Mapping[str, Any]
    output_contract: Mapping[str, Any]
    side_effects: tuple[str, ...] = ()
    dependencies: tuple[str, ...] = ()
    authority_requirements: tuple[str, ...] = ()
    failure_modes: tuple[str, ...] = ()
    evidence_model: tuple[str, ...] = ()
    quality_metrics: tuple[str, ...] = ()
    latency_class: str | None = None
    cost_class: str | None = None
    data_exposure: tuple[str, ...] = ()
    jurisdictions: tuple[str, ...] = ()
    provider: str | None = None
    version: str | None = None

    def canonical_dict(self) -> dict[str, Any]:
        return {
            "capability_id": self.capability_id,
            "semantic_goal": self.semantic_goal,
            "input_contract": dict(self.input_contract),
            "output_contract": dict(self.output_contract),
            "side_effects": list(self.side_effects),
            "dependencies": list(self.dependencies),
            "authority_requirements": list(self.authority_requirements),
            "failure_modes": list(self.failure_modes),
            "evidence_model": list(self.evidence_model),
            "quality_metrics": list(self.quality_metrics),
            "latency_class": self.latency_class,
            "cost_class": self.cost_class,
            "data_exposure": list(self.data_exposure),
            "jurisdictions": list(self.jurisdictions),
            "provider": self.provider,
            "version": self.version,
        }

    @property
    def fingerprint_hash(self) -> str:
        raw = json.dumps(self.canonical_dict(), sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class EquivalenceResult:
    state: str
    score: float
    matched_dimensions: tuple[str, ...]
    mismatched_dimensions: tuple[str, ...]
    unknown_dimensions: tuple[str, ...]
    evidence_refs: tuple[str, ...] = ()
    details: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "state": self.state,
            "score": self.score,
            "matched_dimensions": list(self.matched_dimensions),
            "mismatched_dimensions": list(self.mismatched_dimensions),
            "unknown_dimensions": list(self.unknown_dimensions),
            "evidence_refs": list(self.evidence_refs),
            "details": dict(self.details),
        }


def compare_fingerprints(
    external: CapabilityFingerprint,
    internal: CapabilityFingerprint,
    *,
    evidence_refs: tuple[str, ...] = (),
) -> EquivalenceResult:
    dimensions = {
        "semantic_goal": (
            external.semantic_goal.strip().lower(),
            internal.semantic_goal.strip().lower(),
        ),
        "input_contract": (dict(external.input_contract), dict(internal.input_contract)),
        "output_contract": (dict(external.output_contract), dict(internal.output_contract)),
        "side_effects": (set(external.side_effects), set(internal.side_effects)),
        "authority_requirements": (
            set(external.authority_requirements),
            set(internal.authority_requirements),
        ),
        "failure_modes": (set(external.failure_modes), set(internal.failure_modes)),
        "evidence_model": (set(external.evidence_model), set(internal.evidence_model)),
        "data_exposure": (set(external.data_exposure), set(internal.data_exposure)),
    }

    matched: list[str] = []
    mismatched: list[str] = []
    unknown: list[str] = []

    for name, (left, right) in dimensions.items():
        if left in ({}, set(), "", None) or right in ({}, set(), "", None):
            unknown.append(name)
        elif left == right:
            matched.append(name)
        else:
            mismatched.append(name)

    known = len(matched) + len(mismatched)
    score = round(len(matched) / max(1, known), 6)
    if known == 0:
        state = "UNKNOWN"
    elif not mismatched and not unknown:
        state = "EQUIVALENT"
    elif score >= 0.75:
        state = "PARTIAL"
    else:
        state = "NON_EQUIVALENT"

    return EquivalenceResult(
        state=state,
        score=score,
        matched_dimensions=tuple(matched),
        mismatched_dimensions=tuple(mismatched),
        unknown_dimensions=tuple(unknown),
        evidence_refs=evidence_refs,
        details={
            "external_hash": external.fingerprint_hash,
            "internal_hash": internal.fingerprint_hash,
            "behavioral_benchmark_required_before_superiority_claim": True,
        },
    )
