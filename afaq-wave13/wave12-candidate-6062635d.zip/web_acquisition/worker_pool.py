"""Bounded multi-target acquisition worker pool.

This is a local concurrency primitive, not a claim of distributed production
deployment. It preserves per-target crawl contracts and returns explicit
per-target failures.
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from typing import Any

from .contracts import CrawlRequest, CrawlResult
from .crawler import crawl


@dataclass(frozen=True)
class WorkerPoolResult:
    results: dict[str, CrawlResult]
    failures: dict[str, str]
    worker_count: int

    def as_dict(self) -> dict[str, Any]:
        return {
            "results": {key: value.as_dict() for key, value in self.results.items()},
            "failures": dict(self.failures),
            "worker_count": self.worker_count,
            "distributed_runtime": False,
        }


def crawl_many(
    requests: dict[str, CrawlRequest],
    *,
    max_workers: int = 4,
) -> WorkerPoolResult:
    if max_workers <= 0 or max_workers > 32:
        raise ValueError("max_workers must be 1..32")
    if not requests:
        return WorkerPoolResult(results={}, failures={}, worker_count=max_workers)

    results: dict[str, CrawlResult] = {}
    failures: dict[str, str] = {}
    with ThreadPoolExecutor(max_workers=min(max_workers, len(requests))) as pool:
        futures = {pool.submit(crawl, request): key for key, request in requests.items()}
        for future in as_completed(futures):
            key = futures[future]
            try:
                results[key] = future.result()
            except Exception as exc:  # noqa: BLE001
                failures[key] = f"{type(exc).__name__}: {str(exc)[:300]}"

    return WorkerPoolResult(
        results=results,
        failures=failures,
        worker_count=min(max_workers, len(requests)),
    )
