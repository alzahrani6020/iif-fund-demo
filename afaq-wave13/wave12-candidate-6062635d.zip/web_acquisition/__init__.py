"""Governed external web acquisition runtime."""

from .contracts import AcquisitionState, CrawlRequest
from .crawler import crawl
from .fetch import fetch_url
from .verification import verify_remote_resource

__all__ = [
    "AcquisitionState",
    "CrawlRequest",
    "crawl",
    "fetch_url",
    "verify_remote_resource",
]
