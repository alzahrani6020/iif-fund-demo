"""Provider/capability substitutability and portability analysis."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from .fingerprint import CapabilityFingerprint, compare_fingerprints


@dataclass(frozen=True)
class SubstitutionDecision:
    state: str
    compatibility_score: float
    blocking_reasons: tuple[str, ...]
    migration_requirements: tuple[str, ...]
    evidence_refs: tuple[str, ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "state": self.state,
            "compatibility_score": self.compatibility_score,
            "blocking_reasons": list(self.blocking_reasons),
            "migration_requirements": list(self.migration_requirements),
            "evidence_refs": list(self.evidence_refs),
        }


def assess_substitution(
    source: CapabilityFingerprint,
    target: CapabilityFingerprint,
    *,
    portability: Mapping[str, Any] | None = None,
    evidence_refs: tuple[str, ...] = (),
) -> SubstitutionDecision:
    equivalence = compare_fingerprints(source, target, evidence_refs=evidence_refs)
    portability = dict(portability or {})
    blockers: list[str] = []
    migration: list[str] = []

    if equivalence.state == "NON_EQUIVALENT":
        blockers.append("BEHAVIORAL_CONTRACT_MISMATCH")
    for key in ("session_state", "data_state", "credential_model", "schema", "side_effect_semantics"):
        state = str(portability.get(key) or "UNKNOWN").upper()
        if state in {"INCOMPATIBLE", "BLOCKED"}:
            blockers.append(f"{key.upper()}_INCOMPATIBLE")
        elif state in {"PARTIAL", "MIGRATION_REQUIRED"}:
            migration.append(f"{key.upper()}_MIGRATION_REQUIRED")
        elif state == "UNKNOWN":
            migration.append(f"{key.upper()}_UNVERIFIED")

    if blockers:
        state = "NOT_SUBSTITUTABLE"
    elif equivalence.state == "EQUIVALENT" and not migration:
        state = "SUBSTITUTABLE"
    elif equivalence.state in {"EQUIVALENT", "PARTIAL"}:
        state = "SUBSTITUTABLE_WITH_MIGRATION"
    else:
        state = "UNPROVEN"

    return SubstitutionDecision(
        state=state,
        compatibility_score=equivalence.score,
        blocking_reasons=tuple(sorted(dict.fromkeys(blockers))),
        migration_requirements=tuple(sorted(dict.fromkeys(migration))),
        evidence_refs=evidence_refs,
    )
