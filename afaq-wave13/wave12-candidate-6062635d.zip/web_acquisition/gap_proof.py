"""Evidence-backed capability gap proof.

A new capability or engine is not justified until reuse, composition, provider
and implementation alternatives have been checked with evidence.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class GapProof:
    state: str
    reuse_checked: bool
    composition_checked: bool
    provider_checked: bool
    extension_checked: bool
    evidence_refs: tuple[str, ...]
    unresolved_reasons: tuple[str, ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "state": self.state,
            "reuse_checked": self.reuse_checked,
            "composition_checked": self.composition_checked,
            "provider_checked": self.provider_checked,
            "extension_checked": self.extension_checked,
            "evidence_refs": list(self.evidence_refs),
            "unresolved_reasons": list(self.unresolved_reasons),
        }


def prove_gap(checks: Mapping[str, Mapping[str, Any]]) -> GapProof:
    required = ("reuse", "composition", "provider", "extension")
    evidence: list[str] = []
    unresolved: list[str] = []
    flags: dict[str, bool] = {}

    any_solution = False
    for name in required:
        item = checks.get(name) or {}
        checked = bool(item.get("checked"))
        flags[name] = checked
        refs = item.get("evidence_refs") or ()
        evidence.extend(str(x) for x in refs if x)
        if not checked:
            unresolved.append(f"{name.upper()}_NOT_CHECKED")
        if bool(item.get("satisfies_requirement")):
            any_solution = True

    if any_solution:
        state = "NO_REAL_GAP"
    elif all(flags.values()) and evidence:
        state = "REAL_GAP_PROVEN"
    else:
        state = "GAP_UNPROVEN"

    return GapProof(
        state=state,
        reuse_checked=flags["reuse"],
        composition_checked=flags["composition"],
        provider_checked=flags["provider"],
        extension_checked=flags["extension"],
        evidence_refs=tuple(sorted(dict.fromkeys(evidence))),
        unresolved_reasons=tuple(unresolved),
    )
