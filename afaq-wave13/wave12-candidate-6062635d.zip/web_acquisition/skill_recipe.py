"""Reusable teaching artifact for governed capability transfer."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class SkillRecipe:
    recipe_id: str
    capability_id: str
    mission_pattern: str
    tool_policy: tuple[str, ...]
    execution_steps: tuple[str, ...]
    failure_cases: tuple[str, ...]
    recovery_recipes: tuple[str, ...]
    demonstrations: tuple[dict[str, Any], ...]
    evaluation_cases: tuple[dict[str, Any], ...]
    competency_criteria: tuple[str, ...]
    evidence_refs: tuple[str, ...]

    @property
    def content_hash(self) -> str:
        payload = {
            "recipe_id": self.recipe_id,
            "capability_id": self.capability_id,
            "mission_pattern": self.mission_pattern,
            "tool_policy": list(self.tool_policy),
            "execution_steps": list(self.execution_steps),
            "failure_cases": list(self.failure_cases),
            "recovery_recipes": list(self.recovery_recipes),
            "demonstrations": list(self.demonstrations),
            "evaluation_cases": list(self.evaluation_cases),
            "competency_criteria": list(self.competency_criteria),
            "evidence_refs": list(self.evidence_refs),
        }
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def as_dict(self) -> dict[str, Any]:
        return {
            "recipe_id": self.recipe_id,
            "capability_id": self.capability_id,
            "mission_pattern": self.mission_pattern,
            "tool_policy": list(self.tool_policy),
            "execution_steps": list(self.execution_steps),
            "failure_cases": list(self.failure_cases),
            "recovery_recipes": list(self.recovery_recipes),
            "demonstrations": list(self.demonstrations),
            "evaluation_cases": list(self.evaluation_cases),
            "competency_criteria": list(self.competency_criteria),
            "evidence_refs": list(self.evidence_refs),
            "content_hash": self.content_hash,
            "deployment_allowed": False,
        }


def validate_recipe(recipe: SkillRecipe) -> tuple[bool, tuple[str, ...]]:
    reasons: list[str] = []
    if not recipe.evidence_refs:
        reasons.append("EVIDENCE_REQUIRED")
    if not recipe.execution_steps:
        reasons.append("EXECUTION_STEPS_REQUIRED")
    if not recipe.evaluation_cases:
        reasons.append("HOLDOUT_OR_EVALUATION_CASES_REQUIRED")
    if not recipe.competency_criteria:
        reasons.append("COMPETENCY_CRITERIA_REQUIRED")
    return (not reasons, tuple(reasons))
