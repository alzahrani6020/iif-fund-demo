"""Execution truth gate for external work.

A successful dispatch or executor return value is never enough to claim the
mission succeeded. Claims advance only when the required evidence stage exists.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from .contracts import AcquisitionState


_ORDER = {
    AcquisitionState.PLANNED: 0,
    AcquisitionState.DISPATCHED: 1,
    AcquisitionState.ACKNOWLEDGED: 2,
    AcquisitionState.EXECUTED: 3,
    AcquisitionState.EFFECT_OBSERVED: 4,
    AcquisitionState.EFFECT_VERIFIED: 5,
    AcquisitionState.MISSION_VERIFIED: 6,
    AcquisitionState.BLOCKED: -1,
    AcquisitionState.FAILED: -1,
}


@dataclass(frozen=True)
class TruthDecision:
    state: AcquisitionState
    claim_allowed: bool
    reason: str
    evidence_refs: tuple[str, ...]
    limitations: tuple[str, ...] = ()

    def as_dict(self) -> dict[str, Any]:
        return {
            "state": self.state.value,
            "claim_allowed": self.claim_allowed,
            "reason": self.reason,
            "evidence_refs": list(self.evidence_refs),
            "limitations": list(self.limitations),
        }


def require_state(
    observed: AcquisitionState,
    required: AcquisitionState,
    *,
    evidence_refs: tuple[str, ...] = (),
    limitations: tuple[str, ...] = (),
) -> TruthDecision:
    if observed in {AcquisitionState.BLOCKED, AcquisitionState.FAILED}:
        return TruthDecision(
            state=observed,
            claim_allowed=False,
            reason="EXECUTION_DID_NOT_REACH_REQUIRED_TRUTH_STAGE",
            evidence_refs=evidence_refs,
            limitations=limitations,
        )
    if not evidence_refs:
        return TruthDecision(
            state=observed,
            claim_allowed=False,
            reason="NO_EVIDENCE_NO_CLAIM",
            evidence_refs=(),
            limitations=limitations,
        )
    if _ORDER.get(observed, -1) < _ORDER.get(required, 99):
        return TruthDecision(
            state=observed,
            claim_allowed=False,
            reason=f"{required.value}_REQUIRED",
            evidence_refs=evidence_refs,
            limitations=limitations,
        )
    return TruthDecision(
        state=observed,
        claim_allowed=True,
        reason="TRUTH_STAGE_AND_EVIDENCE_SATISFIED",
        evidence_refs=evidence_refs,
        limitations=limitations,
    )


def mission_success_allowed(
    *,
    observed_state: AcquisitionState,
    evidence_refs: tuple[str, ...],
    independent_verification: Mapping[str, Any] | None,
) -> TruthDecision:
    if not independent_verification or not bool(independent_verification.get("verified")):
        return TruthDecision(
            state=observed_state,
            claim_allowed=False,
            reason="INDEPENDENT_MISSION_VERIFICATION_REQUIRED",
            evidence_refs=evidence_refs,
        )
    return require_state(
        AcquisitionState.MISSION_VERIFIED,
        AcquisitionState.MISSION_VERIFIED,
        evidence_refs=evidence_refs,
    )
