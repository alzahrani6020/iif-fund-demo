"""Evidence-backed practice and competency evaluation for SkillRecipe artifacts.

This does not modify models or deploy capability changes. It evaluates a
candidate executor against held-out cases and returns a competency result that
can be consumed by existing certification/governance flows.
"""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass
from typing import Any, Callable, Mapping

from .skill_recipe import SkillRecipe, validate_recipe


Executor = Callable[[Mapping[str, Any]], Mapping[str, Any]]


def _digest(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, default=str, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class PracticeCaseResult:
    case_id: str
    passed: bool
    elapsed_ms: float
    output_hash: str
    reason: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "case_id": self.case_id,
            "passed": self.passed,
            "elapsed_ms": self.elapsed_ms,
            "output_hash": self.output_hash,
            "reason": self.reason,
        }


@dataclass(frozen=True)
class CompetencyReport:
    recipe_id: str
    capability_id: str
    state: str
    pass_rate: float
    passed_cases: int
    total_cases: int
    case_results: tuple[PracticeCaseResult, ...]
    evidence_refs: tuple[str, ...]
    deployment_allowed: bool = False

    def as_dict(self) -> dict[str, Any]:
        return {
            "recipe_id": self.recipe_id,
            "capability_id": self.capability_id,
            "state": self.state,
            "pass_rate": self.pass_rate,
            "passed_cases": self.passed_cases,
            "total_cases": self.total_cases,
            "case_results": [item.as_dict() for item in self.case_results],
            "evidence_refs": list(self.evidence_refs),
            "deployment_allowed": False,
        }


def _expected_match(output: Mapping[str, Any], expected: Any) -> bool:
    if isinstance(expected, Mapping):
        return all(output.get(key) == value for key, value in expected.items())
    return output == expected


def evaluate_skill_recipe(
    recipe: SkillRecipe,
    executor: Executor,
    *,
    minimum_pass_rate: float = 1.0,
) -> CompetencyReport:
    valid, reasons = validate_recipe(recipe)
    if not valid:
        raise ValueError("INVALID_SKILL_RECIPE:" + ",".join(reasons))
    if not (0.0 < minimum_pass_rate <= 1.0):
        raise ValueError("minimum_pass_rate must be in (0,1]")

    results: list[PracticeCaseResult] = []
    for index, case in enumerate(recipe.evaluation_cases):
        case_id = str(case.get("case_id") or f"eval-{index + 1}")
        payload = case.get("input")
        if not isinstance(payload, Mapping):
            payload = {"value": payload}
        expected = case.get("expected")
        started = time.perf_counter()
        try:
            output = dict(executor(dict(payload)))
            passed = _expected_match(output, expected)
            reason = "EXPECTED_OUTPUT_MATCHED" if passed else "EXPECTED_OUTPUT_MISMATCH"
        except Exception as exc:  # noqa: BLE001
            output = {"ok": False, "error_class": type(exc).__name__}
            passed = False
            reason = f"EXECUTOR_EXCEPTION:{type(exc).__name__}"
        elapsed = round((time.perf_counter() - started) * 1000, 3)
        results.append(
            PracticeCaseResult(
                case_id=case_id,
                passed=passed,
                elapsed_ms=elapsed,
                output_hash=_digest(output),
                reason=reason,
            )
        )

    passed_count = sum(item.passed for item in results)
    total = len(results)
    pass_rate = round(passed_count / max(1, total), 6)
    state = "COMPETENT_ON_EVALUATION_SET" if pass_rate >= minimum_pass_rate else "NOT_COMPETENT"

    evidence = tuple(
        sorted(
            dict.fromkeys(
                (
                    *recipe.evidence_refs,
                    *(f"practice:{item.case_id}:{item.output_hash}" for item in results),
                )
            )
        )
    )
    return CompetencyReport(
        recipe_id=recipe.recipe_id,
        capability_id=recipe.capability_id,
        state=state,
        pass_rate=pass_rate,
        passed_cases=passed_count,
        total_cases=total,
        case_results=tuple(results),
        evidence_refs=evidence,
        deployment_allowed=False,
    )
